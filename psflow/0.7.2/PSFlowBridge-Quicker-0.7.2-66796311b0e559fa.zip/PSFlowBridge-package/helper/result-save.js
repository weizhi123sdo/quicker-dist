/**
 * PSFlowBridge - Result Save Module
 *
 * Handles verified saving of generated images:
 * 1. Explicit path (e.g. from UI pick-save-file): saves atomically and remembers target parent directory for future runs.
 * 2. Associated PSD exists: saves to <PSD-directory>/PSFlow Results/.
 * 3. No PSD / text-to-image without known directory:
 *    - If a remembered directory exists in settings: saves to <remembered-directory>/.
 *    - Else returns { needsDirectory: true, defaultFilename: ... } for UI directory picker prompt.
 * 4. Naming: Unique auto-increment naming, never silently overwrites (even on explicit path collision).
 * 5. Integrity: Atomic write with exclusive copy (COPYFILE_EXCL), verifies PNG signature, non-empty, full raw decodable via sharp, and verifies written disk file bytes and dimensions.
 */

'use strict';

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { createRequire } = require('node:module');

const helperRequire = createRequire(path.join(__dirname, 'package.json'));

function getSharp() {
  try { return helperRequire('sharp'); } catch (_) {
    try { return require('sharp'); } catch (e) { return null; }
  }
}

const SETTINGS_FILE = 'save-settings.json';

async function readJsonFile(filePath, fallback = {}) {
  try {
    const text = (await fsp.readFile(filePath, 'utf8')).replace(/^\uFEFF/, '');
    return JSON.parse(text);
  } catch (_) { return fallback; }
}

async function writeJsonFile(filePath, data) {
  const temp = filePath + '.' + Date.now() + '.' + Math.random().toString(36).slice(2, 8) + '.tmp';
  const content = JSON.stringify(data, null, 2);
  await fsp.writeFile(temp, content, 'utf8');
  try { await fsp.rename(temp, filePath); }
  catch (err) { await fsp.unlink(temp).catch(() => {}); throw err; }
}

async function getRememberedDirectory(dataDir) {
  if (!dataDir) return null;
  const file = path.join(dataDir, SETTINGS_FILE);
  const data = await readJsonFile(file, {});
  if (typeof data.lastSaveDirectory === 'string' && path.isAbsolute(data.lastSaveDirectory)) {
    try {
      const stat = await fsp.stat(data.lastSaveDirectory);
      if (stat.isDirectory()) return data.lastSaveDirectory;
    } catch (_) {}
  }
  return null;
}

async function setRememberedDirectory(dataDir, directory) {
  if (!dataDir || !directory || !path.isAbsolute(directory)) return;
  try {
    await fsp.mkdir(dataDir, { recursive: true });
    const file = path.join(dataDir, SETTINGS_FILE);
    const data = await readJsonFile(file, {});
    data.lastSaveDirectory = directory;
    data.updatedAt = new Date().toISOString();
    await writeJsonFile(file, data);
  } catch (_) {}
}

function sanitizeFilenameBase(name) {
  const raw = String(name || '').trim();
  const cleaned = raw.replace(/[^a-zA-Z0-9_\-\u4e00-\u9fa5]/g, '_').replace(/\.+$/, '').slice(0, 80);
  return cleaned || 'PSFlow-Result';
}

function buildDefaultBasename(capture, id, index, expectedHash) {
  const rawDoc = capture && capture.documentName ? capture.documentName : '';
  const docBase = path.basename(rawDoc, path.extname(rawDoc));
  const base = sanitizeFilenameBase(docBase || ('PSFlow-' + String(id || '').slice(0, 8)));
  const idx = typeof index === 'number' ? index + 1 : 1;
  const hashPart = expectedHash ? ('_' + String(expectedHash).slice(0, 8)) : '';
  return base + '_' + idx + hashPart;
}

function verifyPngBytes(bytes) {
  if (!Buffer.isBuffer(bytes) || bytes.length < 8) {
    throw new Error('保存数据无效：图片数据为空或过短。');
  }
  const isPng =
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4e &&
    bytes[3] === 0x47 &&
    bytes[4] === 0x0d &&
    bytes[5] === 0x0a &&
    bytes[6] === 0x1a &&
    bytes[7] === 0x0a;
  if (!isPng) {
    throw new Error('保存数据无效：非合法 PNG 文件头签名。');
  }
}

async function verifySharpDecode(bytes, sharpInstance) {
  const s = sharpInstance || getSharp();
  if (!s) {
    throw new Error('缺少 sharp 图像解码组件，无法验证保存图片。');
  }
  try {
    const { data, info } = await s(bytes).raw().toBuffer({ resolveWithObject: true });
    if (!info || !info.width || !info.height || !data || data.length === 0) {
      throw new Error('PNG 像素数据损坏或无法完整解码。');
    }
    return info;
  } catch (err) {
    throw new Error('PNG 完整解码校验失败：' + err.message);
  }
}

async function verifyDiskFile(filePath, expectedBytes, sharpInstance) {
  const stat = await fsp.stat(filePath);
  if (!stat.isFile() || stat.size === 0) {
    throw new Error('落盘文件为空或不是有效文件。');
  }
  const diskBytes = await fsp.readFile(filePath);
  if (!diskBytes.equals(expectedBytes)) {
    throw new Error('落盘文件字节内容与内存源数据不一致。');
  }
  verifyPngBytes(diskBytes);
  const info = await verifySharpDecode(diskBytes, sharpInstance);
  return { size: stat.size, width: info.width, height: info.height };
}

async function writeAtomicallyExclusive(targetPath, bytes) {
  const dir = path.dirname(targetPath);
  const ext = path.extname(targetPath).toLowerCase();
  if (ext !== '.png') {
    throw new Error('仅支持保存为 PNG 图片。');
  }
  const base = path.basename(targetPath, ext);

  for (let attempt = 0; attempt < 100; attempt++) {
    const suffix = attempt === 0 ? '' : ('_' + attempt);
    const destination = path.join(dir, base + suffix + '.png');
    const tempPath = path.join(dir, '.' + base + suffix + '.' + Date.now() + '.' + Math.random().toString(36).slice(2, 8) + '.tmp');

    try {
      await fsp.writeFile(tempPath, bytes, { flag: 'wx' });
    } catch (err) {
      if (err.code === 'EEXIST') continue;
      throw err;
    }

    try {
      await fsp.copyFile(tempPath, destination, fs.constants.COPYFILE_EXCL);
      await fsp.unlink(tempPath).catch(() => {});
      return destination;
    } catch (copyErr) {
      await fsp.unlink(tempPath).catch(() => {});
      if (copyErr.code === 'EEXIST') continue;
      throw copyErr;
    }
  }
  throw new Error('无法以排他独占方式写入目标文件，文件名可能持续冲突。');
}

async function saveResult(options = {}) {
  const { bytes, capture, id, index, expectedHash, dataDir, sharpInstance } = options;
  const explicitPath = typeof options.path === 'string' ? options.path.trim() : '';

  verifyPngBytes(bytes);
  await verifySharpDecode(bytes, sharpInstance);

  const defaultBasename = buildDefaultBasename(capture, id, index, expectedHash);
  const defaultFilename = defaultBasename + '.png';

  if (explicitPath) {
    if (!path.isAbsolute(explicitPath)) throw new Error('保存路径必须是完整绝对路径。');
    const ext = path.extname(explicitPath).toLowerCase();
    if (ext !== '.png') throw new Error('仅支持保存为 PNG 图片。');
    const targetDir = path.dirname(explicitPath);
    await fsp.mkdir(targetDir, { recursive: true });

    const finalPath = await writeAtomicallyExclusive(explicitPath, bytes);
    await verifyDiskFile(finalPath, bytes, sharpInstance);
    if (dataDir) await setRememberedDirectory(dataDir, targetDir);
    return { ok: true, path: finalPath, location: 'explicit', filename: path.basename(finalPath) };
  }

  let psdDirectory = null;
  const docPath = capture && typeof capture.documentPath === 'string' && path.isAbsolute(capture.documentPath) ? capture.documentPath : null;
  if (docPath) {
    try {
      const stat = await fsp.stat(docPath);
      if (stat.isFile()) {
        const parent = path.dirname(docPath);
        await fsp.access(parent, fs.constants.W_OK);
        psdDirectory = path.join(parent, 'PSFlow Results');
      }
    } catch (_) {}
  }

  if (psdDirectory) {
    await fsp.mkdir(psdDirectory, { recursive: true });
    const initialTarget = path.join(psdDirectory, defaultFilename);
    const finalPath = await writeAtomicallyExclusive(initialTarget, bytes);
    await verifyDiskFile(finalPath, bytes, sharpInstance);
    return { ok: true, path: finalPath, location: 'source', filename: path.basename(finalPath) };
  }

  const remembered = await getRememberedDirectory(dataDir);
  if (remembered) {
    const initialTarget = path.join(remembered, defaultFilename);
    const finalPath = await writeAtomicallyExclusive(initialTarget, bytes);
    await verifyDiskFile(finalPath, bytes, sharpInstance);
    return { ok: true, path: finalPath, location: 'remembered', filename: path.basename(finalPath) };
  }

  return { ok: false, needsDirectory: true, defaultFilename };
}

module.exports = {
  saveResult,
  verifyPngBytes,
  verifySharpDecode,
  verifyDiskFile,
  getRememberedDirectory,
  setRememberedDirectory,
  buildDefaultBasename,
  writeAtomicallyExclusive,
  getSharp
};
