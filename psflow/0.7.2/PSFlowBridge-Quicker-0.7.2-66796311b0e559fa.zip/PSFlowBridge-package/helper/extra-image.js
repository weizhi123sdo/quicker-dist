'use strict';
const crypto=require('node:crypto');
const MAX_BYTES=64*1024*1024,MAX_PIXELS=25000000;
function invalid(message,status=400){return Object.assign(new Error(message),{status,field:'extraImage',code:'invalid_extra_image',submissionSent:false});}
function fromBase64(input){
  let value=typeof input==='string'?input:input?.base64||input?.data;
  if(typeof value!=='string'||!value)throw invalid('附加参考图数据为空，未提交生成。');
  if(value.startsWith('data:')){
    const match=/^data:image\/(png|jpeg|webp);base64,(.*)$/s.exec(value);
    if(!match)throw invalid('附加参考图格式不受支持，未提交生成。');
    value=match[2];
  }
  if(value.length>Math.ceil(MAX_BYTES/3)*4)throw invalid('附加参考图超过 64MB，未提交生成。',413);
  if(value.length%4||!/^[A-Za-z0-9+/]*={0,2}$/.test(value))throw invalid('附加参考图 Base64 格式无效，未提交生成。');
  const decoded=Buffer.from(value,'base64');
  if(decoded.toString('base64')!==value)throw invalid('附加参考图 Base64 格式无效，未提交生成。');
  return decoded;
}
async function validate(bytes,sharp,{resize=false,purpose='reference'}={}){
  if(!Buffer.isBuffer(bytes)||bytes.length<8)throw invalid('附加参考图为空或损坏，未提交生成。');
  if(bytes.length>MAX_BYTES)throw invalid('附加参考图超过 64MB，未提交生成。',413);
  try{
    const decoder=sharp(bytes,{limitInputPixels:MAX_PIXELS,failOn:'warning'}),meta=await decoder.metadata();
    if(!['png','jpeg','webp'].includes(meta.format)||!meta.width||!meta.height||meta.width*meta.height>MAX_PIXELS||(meta.pages||1)>1)throw invalid('仅支持有效的静态 PNG、JPEG、WebP 参考图。');
    // Metadata alone does not validate image pixels (for example a truncated PNG IDAT).
    await decoder.clone().raw().toBuffer();
    const output=resize?await decoder.resize(2048,2048,{fit:'inside',withoutEnlargement:true}).png().toBuffer():meta.format==='png'?bytes:await decoder.png().toBuffer();
    const dimensions=await sharp(output).metadata();
    return {bytes:output,metadata:{width:dimensions.width,height:dimensions.height,sha256:crypto.createHash('sha256').update(output).digest('hex'),bytes:output.length,purpose:String(purpose).slice(0,50)||'reference'}};
  }catch(error){if(error.field==='extraImage')throw error;throw invalid('附加参考图无法完整解码，未提交生成。');}
}
function matches(expected,actual){return !expected||['width','height','sha256','purpose'].every(k=>expected[k]===undefined||expected[k]===actual[k]);}
async function validateReferences(refs,sharp){
  if(refs===undefined)return [];
  if(!Array.isArray(refs)||refs.length>4)throw invalid('参考图片仅支持 0 到 4 张，未提交生成。');
  const output=[];
  for(let index=0;index<refs.length;index++){
    const item=refs[index],checked=await validate(fromBase64(item),sharp,{resize:true,purpose:'reference'});
    output.push({...checked,name:String(item?.name||`参考图 ${index+1}`).slice(0,120)});
  }
  return output;
}
module.exports={MAX_BYTES,fromBase64,validate,validateReferences,matches,invalid};
