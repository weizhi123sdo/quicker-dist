﻿# PSFlowBridge packaged bootstrap.
# Runs from the extracted package only; all mutable state stays under
# %LOCALAPPDATA%\PSFlowBridge. Runtime is required upfront; npm deps auto-install.
[CmdletBinding()]
param(
  [ValidateRange(1, 60)][int]$TimeoutSec = 20,
  [switch]$Login,
  [string]$Root = '',
  [string]$TargetPackageRoot = ''
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$global:LASTEXITCODE = 0
$nodeMajor = 0

$packageRoot = (Resolve-Path -LiteralPath $PSScriptRoot).Path
if ($TargetPackageRoot) { $packageRoot = (Resolve-Path -LiteralPath $TargetPackageRoot).Path }
$warnings = New-Object System.Collections.Generic.List[string]
# Quicker 侧用管道读取状态；隐藏启动的长期子进程会继承该管道句柄，导致父进程
# 读不到 EOF 而永久阻塞。因此状态同时写入一个显式文件（由 PSFB_STATUS_FILE
# 指定），调用方以该文件为准，不再依赖管道关闭。
$statusFile = $env:PSFB_STATUS_FILE
function Get-PsfbBuildId {
  param([string]$PackageRoot)
  if (-not [string]::IsNullOrWhiteSpace($env:PSFB_BUILD_ID)) {
    return ($env:PSFB_BUILD_ID.Trim() -replace '\s+', '-')
  }
  $appName = Split-Path -Leaf $PackageRoot
  if ($appName -eq 'PSFlowBridge-package') { $appName = Split-Path -Leaf (Split-Path -Parent $PackageRoot) }
  if ($appName -match '^([0-9a-f]{16})(?:-repair-[0-9a-f]+)?$') { return $Matches[1] }
  return 'dev'
}
$buildId = Get-PsfbBuildId -PackageRoot $packageRoot

# 安装布局是 <apps>\<16位哈希>\PSFlowBridge-package。buildId / apps 指针
# 必须用哈希目录名，而不是内层的 PSFlowBridge-package，否则会把 current 写成
# 一个不存在的目录，随后的历史裁剪就会误删全部真实包。
$appName = Split-Path -Leaf $packageRoot
if ($appName -eq 'PSFlowBridge-package') {
  $appName = Split-Path -Leaf (Split-Path -Parent $packageRoot)
}
if ([string]::IsNullOrWhiteSpace($Root)) { $Root = Join-Path $env:LOCALAPPDATA 'PSFlowBridge' }
$manageAppsPointer = ($appName -match '^[0-9a-f]{16}(?:-repair-[0-9a-f]+)?$' -and [IO.Path]::GetFullPath((Split-Path -Parent (Split-Path -Parent $packageRoot))).TrimEnd('\') -eq [IO.Path]::GetFullPath((Join-Path $Root 'apps')).TrimEnd('\'))

# 把最后一次要输出的状态写进显式文件（若调用方给了路径），供父进程可靠读取。
$script:lastStatusLine = $null
function Write-StatusFile {
  if ([string]::IsNullOrWhiteSpace($statusFile)) { return }
  if ($null -eq $script:lastStatusLine) { return }
  try {
    $dir = Split-Path -Parent $statusFile
    if ($dir) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [System.IO.File]::WriteAllText($statusFile, $script:lastStatusLine, (New-Object System.Text.UTF8Encoding($false)))
  } catch { }
}

function Send-Status {
  param([hashtable]$Status)
  [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
  $Status.schema = 'psflowbridge.bootstrap/1'
  $Status.ok = ($Status.status -eq 'running')
  $Status.timestamp = (Get-Date).ToUniversalTime().ToString('o')
  $script:lastStatusLine = ($Status | ConvertTo-Json -Depth 8 -Compress)
  Write-StatusFile
  $script:lastStatusLine
}

function Send-Error {
  param([string]$Code, [string]$Message, [object]$Details = $null)
  Send-Status @{
    status      = 'error'
    code        = $Code
    message     = $Message
    details     = $Details
    root        = $packageRoot
    packageRoot = $packageRoot
  }
  exit 1
}

function Resolve-Tool {
  param([string]$Name, [string]$Override)
  if (-not [string]::IsNullOrWhiteSpace($Override)) {
    if (-not (Test-Path -LiteralPath $Override -PathType Leaf)) {
      Send-Error 'dependency_missing' "$Name override does not exist: $Override"
    }
    return (Resolve-Path -LiteralPath $Override).Path
  }
  $command = Get-Command -Name $Name -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $command) {
    Send-Error 'dependency_missing' "$Name was not found on PATH" @{ tool = $Name }
  }
  return $command.Source
}

if ([string]::IsNullOrWhiteSpace($Root)) { $Root = Join-Path $env:LOCALAPPDATA 'PSFlowBridge' }
. (Join-Path $packageRoot 'launcher\launcher-lib.ps1')
$startupMutex = New-Object Threading.Mutex($false, 'Local\PSFlowBridgeStartup')
$startupLock = $false
try {
  try { $startupLock = $startupMutex.WaitOne(30000) } catch [Threading.AbandonedMutexException] { $startupLock = $true }
  if (-not $startupLock) { Send-Error 'startup_busy' 'Another startup is in progress; retry later.' }
  if (-not (Test-PackageManifest -PackageRoot $packageRoot)) { Send-Error 'package_incomplete' 'Package manifest validation failed; repair through the packaged launcher.' }
$required = @(
  'launcher\start.ps1',
  'launcher\launcher-lib.ps1',
  'helper\server.js',
  'backend\prepare-runtime.py',
  'backend\patches\api_server.py',
  'backend\patches\client.py',
  'backend\patches\flow_current.py',
  'backend\patches\config.py',
  'backend\patches\personal_captcha.py',
  'backend\patches\window_policy.py',
  'backend\patches\service_logging.py'
)
$missing = @($required | Where-Object { -not (Test-Path -LiteralPath (Join-Path $packageRoot $_) -PathType Leaf) })
if ($missing.Count -gt 0) {
  Send-Error 'package_incomplete' 'Required package files are missing' @{ files = $missing }
}

$node = Resolve-Tool -Name 'node.exe' -Override $env:PSFB_NODE
$python = Join-Path $Root 'runtime\flow-api\.venv\Scripts\python.exe'
$helperDir = Join-Path $packageRoot 'helper'

# Node >= 20 is required by helper/package.json engines field.
$nodeVersionText = ''
$versionOut = Join-Path $env:TEMP ('psfb-node-' + [guid]::NewGuid().ToString('N') + '.out')
$versionErr = $versionOut + '.err'
try {
  $versionProcess = Start-Process -FilePath $node -ArgumentList @('--version') -WindowStyle Hidden -RedirectStandardOutput $versionOut -RedirectStandardError $versionErr -PassThru
  $handle = $versionProcess.Handle
  if (-not $versionProcess.WaitForExit(5000)) { try { $versionProcess.Kill() } catch { }; Send-Error 'dependency_timeout' 'Node version probe exceeded five seconds.' }
  $nodeVersionText = Get-Content -LiteralPath $versionOut -Raw
  $nodeMajor = [int]($nodeVersionText.Trim().TrimStart('v').Split('.')[0])
} catch {
  Send-Error 'dependency_missing' ('Cannot determine Node.js version from: {0}' -f $nodeVersionText.Trim()) @{ tool = $node }
} finally {
  Remove-Item -LiteralPath $versionOut, $versionErr -Force -ErrorAction SilentlyContinue
}
if ($nodeMajor -lt 20) {
  Send-Error 'dependency_missing' ('Node.js >= 20 required, found {0}: {1}' -f $nodeMajor, $nodeVersionText.Trim()) @{ tool = $node; version = $nodeVersionText.Trim() }
}

# Dependencies are shared by stable dependency fingerprint; packages remain immutable.
$depScript = Join-Path $packageRoot 'shared\dependency-cache.cjs'
$fingerprint = ''
$fpInfo = $null
$fpOut = Join-Path $env:TEMP ('psfb-fp-' + [guid]::NewGuid().ToString('N') + '.out')
$fpErr = $fpOut + '.err'
try {
  $fpProc = Start-Process -FilePath $node -ArgumentList @(('"' + $depScript + '"'), 'fingerprint', ('"' + (Join-Path $helperDir 'package-lock.json') + '"')) -WindowStyle Hidden -RedirectStandardOutput $fpOut -RedirectStandardError $fpErr -PassThru
  $handle = $fpProc.Handle
  if (-not $fpProc.WaitForExit(5000)) {
    try { $fpProc.Kill() } catch { }
    try { $fpProc.WaitForExit(3000) | Out-Null } catch { }
    Send-Error 'dependency_fingerprint_failed' 'Dependency fingerprint calculation timed out.'
  }
  $fpProc.Refresh()
  if ($fpProc.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $fpOut)) {
    $errText = if (Test-Path -LiteralPath $fpOut) { (Get-Content -LiteralPath $fpOut -Raw) } else { '' }
    Send-Error 'dependency_fingerprint_failed' ('Dependency fingerprint calculation failed: {0}' -f $errText.Trim())
  }
  $fpInfo = (Get-Content -LiteralPath $fpOut -Raw) | ConvertFrom-Json
  $fingerprint = [string]$fpInfo.fingerprint
  if ([string]::IsNullOrWhiteSpace($fingerprint)) {
    Send-Error 'dependency_fingerprint_failed' 'Dependency fingerprint is empty.'
  }
} finally {
  Remove-Item -LiteralPath $fpOut, $fpErr -Force -ErrorAction SilentlyContinue
}

$dependencyRoot = Join-Path $Root ('dependencies\' + $fingerprint)
if ($env:PSFB_DEPENDENCY_ROOT) {
  $portableBoundary = [IO.Path]::GetFullPath((Join-Path $Root 'runtime\portable')).TrimEnd('\') + '\'
  $dependencyRoot = [IO.Path]::GetFullPath($env:PSFB_DEPENDENCY_ROOT)
  if (-not $dependencyRoot.StartsWith($portableBoundary,[StringComparison]::OrdinalIgnoreCase)) { Send-Error 'runtime_path_invalid' 'Portable dependency root is outside the application data directory.' }
}
$dependencyModules = Join-Path $dependencyRoot 'node_modules'
$sharpReady = $false
$sharpVersion = ''
$checkScript = "try { const sharp = require(process.argv[1]); console.log('ok:' + sharp.versions.vips); } catch (e) { process.exitCode = 1; }"
function Test-SharpCache {
  param([string]$Cache)
  $probeOut = Join-Path $env:TEMP ('psfb-sharp-' + [guid]::NewGuid().ToString('N') + '.out')
  $probeErr = $probeOut + '.err'
  try {
    $probe = Start-Process -FilePath $node -ArgumentList @('-e', ('"' + $checkScript + '"'), ('"' + (Join-Path $Cache 'node_modules\sharp') + '"')) -WindowStyle Hidden -RedirectStandardOutput $probeOut -RedirectStandardError $probeErr -PassThru
    $handle = $probe.Handle
    if (-not $probe.WaitForExit(5000)) { try { $probe.Kill() } catch { }; return $false }
    $probe.Refresh()
    return $probe.ExitCode -eq 0
  } finally {
    Remove-Item -LiteralPath $probeOut, $probeErr -Force -ErrorAction SilentlyContinue
  }
}

function Test-DependencyCacheValid {
  param([string]$CacheDir, [string]$ExpectedFingerprint)
  if (-not (Test-Path -LiteralPath $CacheDir)) { return $false }
  if ([string]::IsNullOrWhiteSpace($ExpectedFingerprint)) { return $false }
  # Full fingerprint equality (tree + ABI + platform + arch + format version)
  # is enforced by the shared verifier, not just "sharp is requireable".
  $verifyOut = Join-Path $env:TEMP ('psfb-verify-' + [guid]::NewGuid().ToString('N') + '.out')
  $verifyErr = $verifyOut + '.err'
  try {
    $verifyCode = "const m=require(process.argv[1]);const fs=require('fs');const p=process.argv[2];const lock=process.argv[3];const fp=m.computeFingerprint(lock);const ok=m.verifyCacheManifest(p,fp);process.stdout.write(ok?'1':'0');"
    $vProc = Start-Process -FilePath $node -ArgumentList @('-e', ('"' + $verifyCode + '"'), ('"' + $depScript + '"'), ('"' + $CacheDir + '"'), ('"' + (Join-Path $helperDir 'package-lock.json') + '"')) -WindowStyle Hidden -RedirectStandardOutput $verifyOut -RedirectStandardError $verifyErr -PassThru
    $handle = $vProc.Handle
    if (-not $vProc.WaitForExit(5000)) {
      try { $vProc.Kill() } catch { }
      try { $vProc.WaitForExit(3000) | Out-Null } catch { }
      return $false
    }
    $vProc.Refresh()
    if ($vProc.ExitCode -ne 0) { return $false }
    if (-not (Test-Path -LiteralPath $verifyOut)) { return $false }
    if ((Get-Content -LiteralPath $verifyOut -Raw).Trim() -ne '1') { return $false }
  } catch {
    return $false
  } finally {
    Remove-Item -LiteralPath $verifyOut, $verifyErr -Force -ErrorAction SilentlyContinue
  }
  return Test-SharpCache -Cache $CacheDir
}

function Remove-PsfbStagingDirectory {
  param([string]$StagingPath, [string]$DependenciesRoot)
  if ([string]::IsNullOrWhiteSpace($StagingPath)) { return }
  if (-not (Test-Path -LiteralPath $StagingPath)) { return }
  $safeStage = [IO.Path]::GetFullPath($StagingPath)
  $safeDepRoot = [IO.Path]::GetFullPath($DependenciesRoot).TrimEnd('\') + '\'
  if (-not $safeStage.StartsWith($safeDepRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw ('Unsafe dependency staging path: {0}' -f $safeStage)
  }
  Remove-Item -LiteralPath $safeStage -Recurse -Force -ErrorAction SilentlyContinue
}

# Runs `node -e <code> <args...>` with a hard timeout. On timeout the process is
# killed and reaped so no orphan keeps writing to a staging directory, and the
# caller receives an explicit failure instead of a stale exit code.
function Invoke-NodeBounded {
  param(
    [string]$Code,
    [string[]]$NodeArguments,
    [int]$TimeoutMs = 5000
  )
  $out = Join-Path $env:TEMP ('psfb-node-' + [guid]::NewGuid().ToString('N') + '.out')
  $err = $out + '.err'
  $argList = @('-e', ('"' + $Code + '"')) + @($NodeArguments | ForEach-Object { '"' + $_ + '"' })
  try {
    $proc = Start-Process -FilePath $node -ArgumentList $argList -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru
    $handle = $proc.Handle
    if (-not $proc.WaitForExit($TimeoutMs)) {
      try { & (Join-Path $env:SystemRoot 'System32\taskkill.exe') /PID $proc.Id /T /F 2>&1 | Out-Null } catch { }
      try { $proc.Kill() } catch { }
      try { $proc.WaitForExit(3000) | Out-Null } catch { }
      return @{ ok = $false; timedOut = $true; exitCode = $null; stdout = ''; stderr = '' }
    }
    $proc.Refresh()
    $stdout = if (Test-Path -LiteralPath $out) { (Get-Content -LiteralPath $out -Raw) } else { '' }
    $stderr = if (Test-Path -LiteralPath $err) { (Get-Content -LiteralPath $err -Raw) } else { '' }
    return @{ ok = ($proc.ExitCode -eq 0); timedOut = $false; exitCode = $proc.ExitCode; stdout = $stdout; stderr = $stderr }
  } finally {
    Remove-Item -LiteralPath $out, $err -Force -ErrorAction SilentlyContinue
  }
}

$sharpReady = Test-DependencyCacheValid -CacheDir $dependencyRoot -ExpectedFingerprint $fingerprint
if ($env:PSFB_DEPENDENCY_ROOT -and -not $sharpReady) { Send-Error 'portable_runtime_invalid' 'Pinned portable runtime validation failed; no npm installation was attempted.' }
if (-not $sharpReady) {
  # 1. 尝试从已有缓存迁移/复用（比对锁文件语义与 Node ABI，支持旧缓存原子迁移并写 manifest）
  $stage = $null
  try {
    $reuseCode = "const {computeFingerprint,findReusableCache,createManifest}=require(process.argv[1]);const fp=computeFingerprint(process.argv[2]);const f=findReusableCache(process.argv[3],fp,process.argv[4]);console.log(JSON.stringify(f||{}));"
    $reuse = Invoke-NodeBounded -Code $reuseCode -NodeArguments @($depScript, (Join-Path $helperDir 'package-lock.json'), (Join-Path $Root 'dependencies'), $node)
    if ($reuse.ok -and $reuse.stdout.Trim()) {
      $rData = $reuse.stdout | ConvertFrom-Json
      if ($rData -and $rData.path -and (Test-Path -LiteralPath (Join-Path $rData.path 'node_modules\sharp'))) {
        $stage = $dependencyRoot + '.staging-' + [guid]::NewGuid().ToString('N')
        New-Item -ItemType Directory -Force -Path $stage | Out-Null
        Copy-Item -LiteralPath (Join-Path $rData.path 'node_modules') -Destination $stage -Recurse -Force
        Copy-Item -LiteralPath (Join-Path $helperDir 'package.json'), (Join-Path $helperDir 'package-lock.json') -Destination $stage
        $manifestScript = "const {computeFingerprint,createManifest}=require(process.argv[1]);const fs=require('fs');const fp=computeFingerprint(process.argv[2]);fs.writeFileSync(process.argv[3],JSON.stringify(createManifest(fp),null,2));"
        $manifest = Invoke-NodeBounded -Code $manifestScript -NodeArguments @($depScript, (Join-Path $helperDir 'package-lock.json'), (Join-Path $stage 'manifest.json'))
        if ($manifest.ok -and (Test-DependencyCacheValid -CacheDir $stage -ExpectedFingerprint $fingerprint)) {
          if (-not (Test-Path -LiteralPath $dependencyRoot)) {
            [IO.Directory]::Move($stage, $dependencyRoot)
            $sharpReady = $true
            $stage = $null
            $warnings.Add(('已从已有依赖缓存复用并建立指纹清单：{0}' -f $rData.sourceName))
          }
        }
      }
    }
  } catch { } finally {
    Remove-PsfbStagingDirectory -StagingPath $stage -DependenciesRoot (Join-Path $Root 'dependencies')
  }
}

if (-not $sharpReady) {
  if (Test-Path -LiteralPath $dependencyRoot) { Send-Error 'dependency_cache_invalid' 'Shared dependency cache is damaged; repair requires a new cache, not an in-place npm ci.' }
  # 跨动作并发共享锁：同一指纹只允许一个进程执行 npm ci，另一个进程等待完成后直接复用
  $depMutexName = 'Local\PSFlowBridge-Dep-' + $fingerprint.Substring(0, [Math]::Min(16, $fingerprint.Length))
  $depMutex = New-Object Threading.Mutex($false, $depMutexName)
  $depLock = $false
  $stage = $null
  try {
    try { $depLock = $depMutex.WaitOne(90000) } catch [Threading.AbandonedMutexException] { $depLock = $true }
    if (-not $depLock) {
      Send-Error 'dependency_busy' 'Another dependency installation is in progress; timed out waiting for shared lock.'
    }
    if (Test-DependencyCacheValid -CacheDir $dependencyRoot -ExpectedFingerprint $fingerprint) {
      $sharpReady = $true
    } else {
      $npmCmd = Join-Path (Split-Path -Parent $node) 'npm.cmd'
      if (-not (Test-Path -LiteralPath $npmCmd)) { $npmCmd = Resolve-Tool -Name 'npm.cmd' -Override '' }
      $stage = $dependencyRoot + '.staging-' + [guid]::NewGuid().ToString('N')
      New-Item -ItemType Directory -Force -Path $stage | Out-Null
      Copy-Item -LiteralPath (Join-Path $helperDir 'package.json'), (Join-Path $helperDir 'package-lock.json') -Destination $stage
      $logDir = Join-Path $Root 'logs'
      New-Item -ItemType Directory -Force -Path $logDir | Out-Null
      $proc = Start-Process -FilePath $env:ComSpec -ArgumentList @('/d', '/s', '/c', ('""' + $npmCmd + '" ci --omit=dev --no-audit --no-fund"')) -WorkingDirectory $stage -WindowStyle Hidden -RedirectStandardOutput (Join-Path $logDir 'npm-install.out.log') -RedirectStandardError (Join-Path $logDir 'npm-install.err.log') -PassThru
      $handle = $proc.Handle
      if (-not $proc.WaitForExit(90000)) {
        & (Join-Path $env:SystemRoot 'System32\taskkill.exe') /PID $proc.Id /T /F 2>&1 | Out-Null
        Send-Error 'npm_install_timeout' 'Dependency installation exceeded 90 seconds.'
      }
      $proc.Refresh()
      if ($proc.ExitCode -ne 0) {
        Send-Error 'npm_install_failed' 'Shared sharp dependency installation failed; see local npm logs.'
      }
      $manifestScript = "const {computeFingerprint,createManifest}=require(process.argv[1]);const fs=require('fs');const fp=computeFingerprint(process.argv[2]);fs.writeFileSync(process.argv[3],JSON.stringify(createManifest(fp),null,2));"
      $manifest = Invoke-NodeBounded -Code $manifestScript -NodeArguments @($depScript, (Join-Path $helperDir 'package-lock.json'), (Join-Path $stage 'manifest.json'))
      if (-not $manifest.ok) {
        Send-Error 'dependency_manifest_failed' 'Dependency cache manifest could not be written after npm ci.'
      }
      if (-not (Test-DependencyCacheValid -CacheDir $stage -ExpectedFingerprint $fingerprint)) {
        Send-Error 'npm_install_failed' 'Shared sharp dependency validation failed after npm ci.'
      }
      [IO.Directory]::Move($stage, $dependencyRoot)
      $sharpReady = $true
      $stage = $null
    }
  } finally {
    Remove-PsfbStagingDirectory -StagingPath $stage -DependenciesRoot (Join-Path $Root 'dependencies')
    if ($depLock) { $depMutex.ReleaseMutex() }
    $depMutex.Dispose()
  }
}
if ([string]::IsNullOrWhiteSpace($Root)) {
  $Root = Join-Path $env:LOCALAPPDATA 'PSFlowBridge'
}
$stateRoot = (Join-Path $Root 'flow-state')
$runtimeRoot = (Join-Path $Root 'runtime\flow-api')
$runtimePython = (Join-Path $runtimeRoot '.venv\Scripts\python.exe')
$runtimeApi = (Join-Path $runtimeRoot 'flow_cli\api_server.py')

# 运行模式：local 需要本机 Python 运行时；browser 由浏览器扩展托管生成，
# 完全不需要 Python/Playwright。契约统一缺省为 browser + quicker。

# Atomic JSON writer: temp file in the same directory, then replace/move so a
# crash never leaves a half-written config that native tick would reject.
function Write-PsfbJsonAtomic {
  param([string]$Path, [hashtable]$Value)
  $dir = Split-Path -Parent $Path
  if ($dir) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  $tmp = $Path + '.tmp-' + [guid]::NewGuid().ToString('N')
  $json = ($Value | ConvertTo-Json -Depth 4 -Compress)
  [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
  # Move-Item -Force replaces the destination in one step and works whether or
  # not the config already exists (File.Replace rejects some legal paths).
  Move-Item -LiteralPath $tmp -Destination $Path -Force
}

# Preserve an unreadable/invalid config before normalizing it, so a damaged
# file can always be recovered instead of silently overwritten.
function Backup-PsfbConfig {
  param([string]$Path)
  try {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
    $backup = '{0}.invalid-{1}' -f $Path, (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssfff')
    Copy-Item -LiteralPath $Path -Destination $backup -Force -ErrorAction SilentlyContinue
  } catch { }
}

function Get-PsfbRuntimeMode {
  param([string]$Root = '')
  if ([string]::IsNullOrWhiteSpace($Root)) { $Root = $script:Root }
  if ([string]::IsNullOrWhiteSpace($Root)) { $Root = Join-Path $env:LOCALAPPDATA 'PSFlowBridge' }
  $modeFile = Join-Path $Root 'mode.json'
  if (-not (Test-Path -LiteralPath $modeFile -PathType Leaf)) { return 'browser' }
  $invalid = $null
  try {
    $raw = [System.IO.File]::ReadAllText($modeFile)
    if ($raw.StartsWith([string][char]0xFEFF, [System.StringComparison]::Ordinal)) { $raw = $raw.Substring(1) }
    $parsed = $raw | ConvertFrom-Json
    $value = [string]$parsed.mode
    if ($value -ceq 'local') { return 'local' }
    if ($value -ceq 'browser') { return 'browser' }
    $invalid = if ([string]::IsNullOrWhiteSpace($value)) { 'missing_mode' } else { 'invalid_mode' }
  } catch {
    $invalid = 'corrupt_json'
  }
  # 无效/损坏配置：备份后原子归一为 browser，保证 native tick 不会因缺字段失败。
  try {
    Backup-PsfbConfig -Path $modeFile
    Write-PsfbJsonAtomic -Path $modeFile -Value @{ mode = 'browser'; repairedFrom = $invalid; updatedAt = (Get-Date).ToUniversalTime().ToString('o') }
  } catch { }
  return 'browser'
}
$runtimeMode = Get-PsfbRuntimeMode
$browserMode = ($runtimeMode -eq 'browser')

# 首次初始化或未配置时原子写入缺省模式与浏览器（browser + quicker）
$modeFile = Join-Path $Root 'mode.json'
if (-not (Test-Path -LiteralPath $modeFile -PathType Leaf)) {
  try {
    Write-PsfbJsonAtomic -Path $modeFile -Value @{ mode = 'browser'; updatedAt = (Get-Date).ToUniversalTime().ToString('o') }
  } catch { }
}
$browserPrefFile = Join-Path $Root 'browser.json'
$browserValue = ''
$browserInvalid = $null
if (Test-Path -LiteralPath $browserPrefFile -PathType Leaf) {
  try {
    $browserRaw = [System.IO.File]::ReadAllText($browserPrefFile)
    if ($browserRaw.StartsWith([string][char]0xFEFF, [System.StringComparison]::Ordinal)) { $browserRaw = $browserRaw.Substring(1) }
    $browserParsed = $browserRaw | ConvertFrom-Json
    $browserValue = [string]$browserParsed.browser
  } catch {
    $browserInvalid = 'corrupt_json'
  }
}
if ([string]::IsNullOrWhiteSpace($browserValue)) {
  if (-not $browserInvalid) { $browserInvalid = 'missing_browser' }
} elseif ($browserValue -ceq 'quicker' -or $browserValue -ceq 'edge' -or $browserValue -ceq 'chrome') {
  # 有效选择：quicker（内置，默认）或用户明确指定的 edge/chrome，保留原值不重写。
} else {
  # 'default' 及任何非法值统一迁移为 quicker（契约默认内置浏览器）。
  $browserInvalid = if ($browserValue -ceq 'default') { 'legacy_default' } else { 'invalid_browser' }
}
if ($browserInvalid) {
  try {
    Backup-PsfbConfig -Path $browserPrefFile
    Write-PsfbJsonAtomic -Path $browserPrefFile -Value @{ browser = 'quicker'; repairedFrom = $browserInvalid; updatedAt = (Get-Date).ToUniversalTime().ToString('o') }
  } catch { }
}

# 自愈与半安装降级：配置了 local 但缺少完整 Python 或 API 后端源文件时，
# 启动层完成降级为 browser 免 Python 模式并原子写入 mode.json。
$runtimeFallback = $false
if (-not $browserMode) {
  $hasPython = Test-Path -LiteralPath $runtimePython -PathType Leaf
  $hasApi = Test-Path -LiteralPath $runtimeApi -PathType Leaf
  if (-not $hasPython -or -not $hasApi) {
    if ($env:PSFB_REQUIRE_LOCAL -eq '1') { Send-Error 'local_runtime_missing' 'Existing local mode is incomplete; its preference and data were preserved.' }
    try {
      $fallbackReason = if (-not $hasPython) { 'python_missing' } else { 'api_missing' }
      Write-PsfbJsonAtomic -Path $modeFile -Value @{ mode = 'browser'; updatedAt = (Get-Date).ToUniversalTime().ToString('o'); fallbackFrom = 'local'; fallbackReason = $fallbackReason }
      $runtimeMode = 'browser'
      $browserMode = $true
      $runtimeFallback = $true
      $warnings.Add('本机未安装完整 Python/API 后端运行时，已自动降级为「浏览器托管」免 Python 模式并更新 mode.json。')
    } catch {
      Send-Error 'runtime_missing' ('本机未安装完整 Python 运行时，且无法写入模式配置以自动降级：{0}。' -f $_.Exception.Message)
    }
  }
}

if (-not $browserMode) {
  if (-not (Test-Path -LiteralPath $runtimeApi -PathType Leaf)) {
    Send-Error 'runtime_missing' ('本机全自动模式缺少后端 API 源文件：{0}；请配置完整环境或切换为浏览器模式运行。' -f $runtimeApi)
  }
}

$libPath = Join-Path $packageRoot 'launcher\launcher-lib.ps1'
. $libPath

# bootstrap 是唯一的生命周期入口：这里直接负责“复用或隐藏启动”两个本地服务。
# launcher/start.ps1 只是给手动使用者的薄壳（解析 apps\current 后回到本脚本），
# 因此这里绝不回调 start.ps1，避免循环委托。
$logDir = Join-Path $Root 'logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

function Rotate-PsfbLog {
  param([string]$Path, [long]$MaxBytes = 5242880)
  if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return }
  $item = Get-Item -LiteralPath $Path
  if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -lt $MaxBytes) { return }
  try {
    for ($i = 5; $i -ge 1; $i--) {
      $archive = $Path + '.' + $i
      if (Test-Path -LiteralPath $archive) {
        $archiveItem = Get-Item -LiteralPath $archive
        if ($archiveItem.PSIsContainer -or ($archiveItem.Attributes -band [IO.FileAttributes]::ReparsePoint)) { return }
      }
    }
    if (Test-Path -LiteralPath ($Path + '.5')) { Remove-Item -LiteralPath ($Path + '.5') -Force }
    for ($i = 4; $i -ge 1; $i--) {
      $archive = $Path + '.' + $i
      if (Test-Path -LiteralPath $archive) { Move-Item -LiteralPath $archive -Destination ($Path + '.' + ($i + 1)) }
    }
    Move-Item -LiteralPath $Path -Destination ($Path + '.1')
  } catch { }
}

function Write-BootstrapLog {
  param([string]$Message, [string]$Level = 'INFO')
  $line = '{0} [{1}] {2}' -f (Get-Date).ToString('s'), $Level, $Message
  Rotate-PsfbLog -Path (Join-Path $logDir 'bootstrap.log')
  Add-Content -LiteralPath (Join-Path $logDir 'bootstrap.log') -Value $line -Encoding UTF8
}

function Start-PsfbHiddenProcess {
  param(
    [string]$FilePath,
    [string[]]$Arguments,
    [string]$WorkingDirectory,
    [hashtable]$EnvVars,
    [string]$LogName
  )
  $saved = @{}
  try {
    foreach ($key in $EnvVars.Keys) {
      $saved[$key] = [Environment]::GetEnvironmentVariable($key, 'Process')
      [Environment]::SetEnvironmentVariable($key, [string]$EnvVars[$key], 'Process')
    }
    $out = Join-Path $logDir ($LogName + '.out.log')
    $err = Join-Path $logDir ($LogName + '.err.log')
    # Preserve previous service output before Start-Process truncates it.
    Rotate-PsfbLog -Path $out -MaxBytes 1
    Rotate-PsfbLog -Path $err -MaxBytes 1
    return Start-Process -FilePath $FilePath -ArgumentList $Arguments -WorkingDirectory $WorkingDirectory -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError $err -PassThru
  } finally {
    foreach ($key in $saved.Keys) { [Environment]::SetEnvironmentVariable($key, $saved[$key], 'Process') }
  }
}

# 停止本项目自己的旧构建占用者，并等待端口释放。只接收已确认“就是本应用”的 PID，
# 绝不用于外部进程；等待有界，超时即报错。
function Stop-PsfbProcesses {
  param([int[]]$ProcessIds, [int]$Port, [string]$Service)
  foreach ($procId in ($ProcessIds | Sort-Object -Unique)) {
    try { Stop-Process -Id $procId -Force -ErrorAction Stop; Write-BootstrapLog ('已停止旧构建{0} PID {1}（端口 {2}）' -f $Service, $procId, $Port) 'WARN' }
    catch { Write-BootstrapLog ('停止旧构建{0} PID {1} 失败：{2}' -f $Service, $procId, $_.Exception.Message) 'WARN' }
  }
  $deadline = (Get-Date).AddSeconds(10)
  while ((Get-Date) -lt $deadline) {
    if (@(Get-PortListeners -Port $Port).Count -eq 0) { return }
    Start-Sleep -Milliseconds 250
  }
  Send-Error 'port_release_timeout' ('端口 {0} 停止旧构建后仍未释放，请手动检查后重试。' -f $Port) @{ port = $Port; pids = $ProcessIds }
}

$backendPort = 8787
$helperPort = if($env:PSFB_PORT){[int]$env:PSFB_PORT}else{47831}
$backendBase = 'http://127.0.0.1:8787'
$helperBase = 'http://127.0.0.1:' + $helperPort
New-Item -ItemType Directory -Force -Path $stateRoot | Out-Null
$configPath = Join-Path $stateRoot 'config.toml'
if (-not (Test-Path -LiteralPath $configPath)) {
  $defaultConfig = @('[flow]', 'max_retries = 1', 'timeout = 180', '', '[captcha]', 'method = "personal"', 'personal_headless = false', 'visible_browser = false')
  Set-Content -LiteralPath $configPath -Value ($defaultConfig -join "`n") -Encoding UTF8
}

$runtimeBuildId = Get-RuntimeBuildId (Join-Path $packageRoot 'backend\patches')
$diskBuildId = ''
if (-not $browserMode) { $diskBuildId = Get-RuntimeBuildId (Join-Path $runtimeRoot 'flow_cli') }
if ($browserMode) { $runtimeBuildId = '' }
$backendListeners = @(if(-not $browserMode){Get-PortListeners -Port $backendPort})
$helperListeners = @(Get-PortListeners -Port $helperPort)
$backendHealth = $null
$helperHealth = $null
if ($backendListeners.Count) {
  $response = Get-JsonResponse ($backendBase + '/health') -Headers @{ Host = '127.0.0.1:8787' }
  if ($response) { $backendHealth = $response.body }
}
if ($helperListeners.Count) { $helperHealth = Get-HelperHealthBody -BaseUrl $helperBase -Root $Root }
$backendDecision = 'start'
$helperDecision = 'start'
if ($backendListeners.Count) { $backendDecision = Get-ServiceUpgradeDecision $backendHealth 'PSFlowBridge-FlowAPI' $runtimeBuildId 'runtimeBuildId' }
if ($helperListeners.Count) {
  $helperDecision = Get-ServiceUpgradeDecision $helperHealth 'PSFlowBridge' $buildId
  if ($helperDecision -eq 'reuse' -and $env:PSFB_FORCE_RESTART -eq '1') { $helperDecision = 'upgrade' }
  if ($helperDecision -eq 'reuse' -and $null -ne $helperHealth -and $helperHealth.PSObject.Properties['effectiveMode']) {
    $helperMode = [string]$helperHealth.effectiveMode
    $expectedMode = if ($browserMode) { 'browser' } else { 'local' }
    if ($helperMode -ne $expectedMode) { $helperDecision = 'upgrade' }
  }
}
# browser 模式没有 Python 后端参与：本机遗留的 backend 监听既不构成本次运行的状态，
# 也不允许被升级、排空或停止，否则会误杀其他流程或误报 port_conflict。必须在任何
# decision 消费点之前兜底，后续 backend 分支全部只读。
if ($browserMode) { $backendDecision = 'reuse' }
if ($diskBuildId -ne $runtimeBuildId -and $backendDecision -eq 'reuse') { $backendDecision = 'upgrade' }
if (-not $browserMode -and (($backendDecision -eq 'start' -and $helperListeners.Count) -or ($helperDecision -eq 'start' -and $backendListeners.Count))) {
  # Recovery of one missing service must not admit new work through the other
  # while runtime code is changing or the pair is only partly ready.
  if ($backendDecision -eq 'reuse') { $backendDecision = 'upgrade' }
  if ($helperDecision -eq 'reuse') { $helperDecision = 'upgrade' }
}
function Send-Deferred {
  param([string]$Reason)
  Send-Status @{ status = 'deferred'; code = 'upgrade_deferred'; message = $Reason; packageRoot = $packageRoot; buildId = $buildId; runtimeBuildId = $runtimeBuildId }
  exit 2
}
if ($backendDecision -eq 'conflict' -or $helperDecision -eq 'conflict') { Send-Error 'port_conflict' 'A service identity could not be confirmed; no process was stopped.' }
if ($browserMode -and $backendListeners.Count) { $warnings.Add('browser 模式忽略本机 8787 端口上的既有进程，未做任何停止。') }
if ($backendDecision -eq 'deferred' -or $helperDecision -eq 'deferred') { Send-Deferred 'Upgrade deferred: tasks are active or task state is unknown.' }
# Check both services before touching code or stopping either one.
if ($backendDecision -eq 'upgrade' -or $helperDecision -eq 'upgrade') {
  foreach ($body in @($backendHealth, $helperHealth)) {
    if ($null -ne $body) {
      $active = Get-HealthField $body 'activeTasks'
      if ((Get-HealthField $body 'app') -eq 'PSFlowBridge') {
        $busy = Get-HealthField $body 'busy'
        if ($busy -isnot [bool] -or $busy) { Send-Deferred 'Helper capture/paste or generation is busy/unknown.' }
        if ($null -eq $active) { $active = 0 }
      }
      if ($null -eq $active -or $active -is [bool] -or [string]$active -notmatch '^0$') { Send-Deferred 'Upgrade deferred: active/unknown task state.' }
    }
  }
}
$backendCfg = $null
if (-not $browserMode -and ($backendDecision -ne 'reuse' -or $helperDecision -eq 'upgrade')) {
  # Fail configuration checks before closing a context or stopping any service.
  try { $backendCfg = Read-BackendConfig -Root $Root }
  catch { Send-Error 'backend_config_invalid' 'Backend configuration cannot be read; no service was stopped.' }
  if (-not $backendCfg -or -not $backendCfg.enabled) { Send-Error 'backend_disabled' 'Backend connection must be configured before startup; no service was stopped.' }
}
# Ownership proof guards the right to stop a process, not the right to reuse it:
# a reused listener has already proven app/buildId/mode/draining/activeTasks via
# its own health endpoint. The check costs a ~250ms CIM query per listener, so it
# runs only when this launch can actually stop the helper. Reuse keeps its full
# identity requirement, and every upgrade path still refuses an unowned listener.
$mayStopHelper = ($backendDecision -eq 'upgrade' -or $helperDecision -eq 'upgrade')
if (-not $browserMode) { foreach ($procId in $backendListeners) {
  if (-not (Test-BackendProcess -ProcessId $procId -Root $Root -Port $backendPort)) { Send-Error 'ownership_unknown' 'Backend listener ownership is unknown; no process was stopped.' }
} }
# An older helper may reside in another immutable apps hash directory.
if ($mayStopHelper) { foreach ($procId in $helperListeners) {
  if (-not (Test-OwnedHelperProcess $procId $Root $helperDir)) { Send-Error 'ownership_unknown' 'Helper listener ownership is unknown; no process was stopped.' }
} }
# Drain endpoints must freeze admission and return explicit confirmation. Legacy
# services without a drain protocol are deferred rather than force-upgraded.
function Request-ServiceDrain {
  param([string]$Uri, [hashtable]$Headers, [int]$TimeoutSec = 5)
  try {
    $r = Invoke-WebRequest -Uri $Uri -Method Post -Headers $Headers -TimeoutSec $TimeoutSec -UseBasicParsing
    $body = $r.Content | ConvertFrom-Json
    return Test-ServiceDrainResponse -StatusCode $r.StatusCode -Body $body
  } catch { return $false }
}
$helperDrained = $false
$backendDrained = $false
if ($backendDecision -eq 'upgrade' -or $helperDecision -eq 'upgrade') {
  if ($helperListeners.Count) {
    $token = Read-PairingToken $Root
    $helperDrained = Request-ServiceDrain ($helperBase + '/api/lifecycle/drain') @{ Host = ([Uri]$helperBase).Authority; Authorization = ('Bearer ' + $token) }
    if (-not $helperDrained) { Send-Deferred 'Helper cannot confirm a safe task drain; upgrade deferred.' }
  }
  if ($backendListeners.Count -and $backendDecision -eq 'upgrade') {
    # Backend allows up to 15s for context.close plus 10s for Playwright.stop.
    # No reset/relogin fallback: the reviewed legacy routes clear user state.
    $backendDrained = Request-ServiceDrain ($backendBase + '/setup/close') @{ Host = '127.0.0.1:8787' } -TimeoutSec 30
    if (-not $backendDrained) {
      if ($helperDrained) { $null = Request-ServiceDrain ($helperBase + '/api/lifecycle/resume') @{ Host = ([Uri]$helperBase).Authority; Authorization = ('Bearer ' + $token) } }
      Send-Deferred 'Backend cannot close its login context safely; upgrade deferred.'
    }
  }
  # Reconfirm process ownership immediately before stopping drained services.
  foreach ($procId in $backendListeners) { if (-not (Test-BackendProcess $procId $Root $backendPort)) { Send-Deferred 'Backend ownership changed during drain.' } }
  foreach ($procId in $helperListeners) { if (-not (Test-OwnedHelperProcess $procId $Root $helperDir)) { Send-Deferred 'Helper ownership changed during drain.' } }
  # A helper-only update must preserve the verified browser session. Only
  # restart the backend when its runtime code actually needs upgrading.
  if ($helperListeners.Count) { Stop-PsfbProcesses $helperListeners $helperPort 'helper' }
  if ($backendDrained -and $backendListeners.Count) { Stop-PsfbProcesses $backendListeners $backendPort 'backend'; $backendDecision = 'start' }
  $helperDecision = 'start'
}
if (-not $browserMode -and $diskBuildId -ne $runtimeBuildId) {
  if (@(Get-PortListeners $backendPort).Count) { Send-Deferred 'Backend is still listening; runtime patch update deferred.' }
  Sync-RuntimePatches -PatchDir (Join-Path $packageRoot 'backend\patches') -RuntimeDir (Join-Path $runtimeRoot 'flow_cli') -Expected $runtimeBuildId
}
if ($browserMode -and $runtimeBuildId) { $runtimeBuildId = '' }
$backendPid = 0
$helperPid = 0
$backendState = 'reused'
$helperState = 'reused'
if ($browserMode) {
  # 浏览器模式下 Python 后端完全不参与；helper 直接把任务交给浏览器扩展。
  $backendState = 'reused'
  $backendReady = $true
}
if ($backendDecision -eq 'start' -and -not $browserMode) {
  if ($null -eq $backendCfg) { $backendCfg = Read-BackendConfig -Root $Root }
  if (-not $backendCfg -or -not $backendCfg.enabled) { Send-Error 'backend_disabled' 'Backend connection must be configured before startup.' }
  $backendEnv = @{ FLOW_API_KEY = $backendCfg.apiKey; FLOW_CLI_HOME = $stateRoot; FLOW_CONFIG = $configPath; PSFB_LOG_DIR = $logDir; PYTHONIOENCODING = 'utf-8'; PYTHONUTF8 = '1' }
  # Portable distributions own their browser binaries. Existing venv installs
  # retain their original browser-cache contract when no bundled browser exists.
  $bundledBrowsers = Join-Path $runtimeRoot '.local-browsers'
  if (Test-Path -LiteralPath $bundledBrowsers -PathType Container) { $backendEnv['PLAYWRIGHT_BROWSERS_PATH'] = $bundledBrowsers }
  $proc = Start-PsfbHiddenProcess -FilePath $runtimePython -Arguments @('-m', 'flow_cli.api_server', '--host', '127.0.0.1', '--port', '8787') -WorkingDirectory $runtimeRoot -LogName 'backend' -EnvVars $backendEnv
  $backendPid = $proc.Id
  $backendState = 'started'
}
if ($helperDecision -eq 'start') {
  $proc = Start-PsfbHiddenProcess -FilePath $node -Arguments @(('"' + (Join-Path $helperDir 'server.js') + '"')) -WorkingDirectory $helperDir -LogName 'helper' -EnvVars @{ PSFB_BUILD_ID = $buildId; PSFB_DATA_DIR = $Root; NODE_PATH = $dependencyModules; PSFB_PORT = [string]$helperPort; PSFB_RUNTIME_ID = $env:PSFB_RUNTIME_ID; PSFB_DEPENDENCY_ROOT = $env:PSFB_DEPENDENCY_ROOT }
  $helperPid = $proc.Id
  $helperState = 'started'
}

# ---- 等待就绪：以服务自己的 HTTP 身份为准 ----
$deadline = (Get-Date).AddSeconds($TimeoutSec)
$backendReady = ($backendState -eq 'reused')
$helperReady = ($helperState -eq 'reused')
while ((Get-Date) -lt $deadline) {
  if (-not $backendReady) {
    $backendReady = Test-BackendIdentity -BaseUrl $backendBase -TimeoutSec 2 -ExpectedRuntimeBuildId $runtimeBuildId
    if ($backendReady -and $backendPid -eq 0) {
      foreach ($procId in @(Get-PortListeners -Port $backendPort)) {
        if (Test-BackendProcess -ProcessId $procId -Root $Root -Port $backendPort) { $backendPid = $procId; break }
      }
    }
  }
  if (-not $helperReady) {
    $helperReady = Test-HelperIdentity -BaseUrl $helperBase -Root $Root -TimeoutSec 2 -ExpectedBuildId $buildId
    if ($helperReady -and $helperPid -eq 0) {
      foreach ($procId in @(Get-PortListeners -Port $helperPort)) {
        if (Test-HelperProcess -ProcessId $procId -HelperDir $helperDir) { $helperPid = $procId; break }
      }
    }
  }
  if ($backendReady -and $helperReady) { break }
  Start-Sleep -Milliseconds 500
}

if ($Login) {
  $setupUrl = $backendBase + '/setup'
  try {
    $backendCfg = Read-BackendConfig -Root $Root
    if ($backendCfg -and $backendCfg.baseUrl) { $setupUrl = ($backendCfg.baseUrl + '/setup') }
  } catch { }
  Start-Process -FilePath $setupUrl
  Write-BootstrapLog '已打开 Flow 登录设置页'
}

$backendBase = 'http://127.0.0.1:8787'
$helperBase = 'http://127.0.0.1:' + $helperPort
$backendReady = $false
$helperReady = $false
if ($browserMode) { $backendReady = $true }
else { try { $backendReady = Test-BackendIdentity -BaseUrl $backendBase -TimeoutSec 3 -ExpectedRuntimeBuildId $runtimeBuildId } catch { $warnings.Add(('backend health check failed: {0}' -f $_.Exception.Message)) } }
try { $helperReady = Test-HelperIdentity -BaseUrl $helperBase -Root $Root -TimeoutSec 3 -ExpectedBuildId $buildId } catch { $warnings.Add(('helper health check failed: {0}' -f $_.Exception.Message)) }

# 防御性双检：占用端口的旧版本不能冒充本次运行。
$helperHealth = $null
try { $helperHealth = Get-HelperHealthBody -BaseUrl $helperBase -Root $Root -TimeoutSec 3 } catch { }
$helperBuildId = Get-HealthBuildId -HealthBody $helperHealth
if ($helperReady -and ((Compare-ServiceBuildId -Expected $buildId -Observed $helperBuildId) -ne 'match')) {
  Send-Error 'build_id_mismatch' ('Helper is running a different build (observed: {0}, expected: {1}). Stop the old process and retry.' -f $helperBuildId, $buildId) @{
    observed = $helperBuildId
    expected = $buildId
  }
}

$missingServiceChecks = @()
if (-not $backendReady) { $missingServiceChecks += 'backend' }
if (-not $helperReady) { $missingServiceChecks += 'helper' }
if ($missingServiceChecks.Count -gt 0) {
  Send-Error 'services_not_ready' ('One or more services are not ready: {0}' -f ($missingServiceChecks -join ', ')) @{
    backendReady = [bool]$backendReady
    helperReady  = [bool]$helperReady
    warnings     = @($warnings)
  }
}

$backendStatus = $null
if (-not $browserMode) {
  try { $backendStatus = Get-BackendStatus -Root $Root -TimeoutSec 3 } catch { $warnings.Add(('backend status check failed: {0}' -f $_.Exception.Message)) }
} else {
  # browser 模式没有 Python 后端；状态由 helper 依据已配对浏览器扩展给出。
  $backendStatus = [pscustomobject]@{
    configured    = $false
    online        = $false
    loginRequired = $false
    mode          = 'browser'
    model         = ''
    message       = '浏览器托管模式：请在 Chrome/Edge 打开并登录 Flow 页面，并确认已加载 PS Flow Bridge 扩展。'
  }
}

# 全部就绪且身份核对通过后，才把本包记为 current，并把历史裁剪到 current + previous。
$pointerSummary = $null
# 只有从标准 apps\<16位哈希>\ 布局运行时才维护 current 指针并裁剪历史。
# 直接从解压目录（开发/手动）运行时绝不写指针，避免污染或误删真实包。
if ($manageAppsPointer) {
  try {
    $appsDir = Join-Path $Root 'apps'
    $history = Update-AppsHistory -AppsDir $appsDir -CurrentName $appName -ProtectedPaths @($packageRoot)
    if ($history.failed.Count -gt 0) {
      $warnings.Add(('apps history prune had failures for: {0}' -f ($history.failed -join ', ')))
    }
    $verifiedName = Resolve-AppsCurrentName -AppsDir $appsDir
    if ($verifiedName -ne $appName) {
      Send-Error 'apps_pointer_failed' ('Failed to update apps/current to {0}; observed value: {1}' -f $appName, $verifiedName) @{
        current  = $verifiedName
        expected = $appName
      }
    }
    $pointerSummary = @{
      current  = $appName
      previous = $history.previous
      pruned   = $history.pruned
    }
  } catch {
    Send-Error 'apps_pointer_failed' $_.Exception.Message
  }
}

Send-Status @{
  status        = 'running'
  root          = $packageRoot
  packageRoot   = $packageRoot
  stateRoot     = $Root
  tools         = @{
    node   = $node
    python = $python
  }
  sharp         = @{
    ready   = [bool]$sharpReady
    version = $sharpVersion
  }
  runtime       = @{
    root   = $runtimeRoot
    python = $runtimePython
    mode   = $runtimeMode
    autoFallback = $runtimeFallback
  }
  ports         = @{
    backend = 8787
    helper  = $helperPort
  }
  backendReady  = [bool]$backendReady
  helperReady   = [bool]$helperReady
  buildId       = $buildId
  runtimeBuildId = $runtimeBuildId
  apps          = $pointerSummary
  backendStatus = $backendStatus
  warnings      = @($warnings)
}

} catch {
  Send-Error 'startup_failed' 'Startup failed; see local bootstrap logs. No task was resubmitted.'
} finally {
  if ($startupLock) { $startupMutex.ReleaseMutex() }
  $startupMutex.Dispose()
}
