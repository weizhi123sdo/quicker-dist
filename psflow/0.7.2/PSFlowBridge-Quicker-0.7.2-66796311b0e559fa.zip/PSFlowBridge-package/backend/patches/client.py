"""
Flow API 客户端
"""
import asyncio
import os
import ntpath
from datetime import datetime, timedelta, timezone
import base64
import json
import random
import time
import uuid
import hashlib
import io
import sys
from typing import Dict, Any, List, Optional, Tuple, Callable
from pathlib import Path

try:
    from curl_cffi.requests import AsyncSession
    HAS_CURL_CFFI = True
except ImportError:
    HAS_CURL_CFFI = False
    try:
        import aiohttp
    except ImportError:
        aiohttp = None

from .config import get_config
from .flow_current import FlowCurrentClient, FlowRpcError, FlowPreSubmissionError
from .models import DEFAULT_MODEL, get_model_config
from .personal_captcha import get_personal_recaptcha_token


_login_context_getter = None
_login_recover = None
_login_required_getter = None
_generation_window_guard = None


def _configure_safe_output() -> None:
    """Never let progress logging terminate an HTTP request on a GBK console."""
    for stream_name in ("stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if stream is None:
            continue
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, io.UnsupportedOperation, OSError, ValueError):
            try:
                stream.reconfigure(errors="replace")
            except (AttributeError, OSError, ValueError):
                pass


def safe_print(*values: object) -> None:
    """Print progress with text errors escaped rather than raising."""
    try:
        print(*values)
    except UnicodeEncodeError:
        try:
            encoding = sys.stdout.encoding or "ascii"
        except (AttributeError, OSError):
            encoding = "ascii"
        try:
            text = " ".join(str(value) for value in values)
            sys.stdout.write(text.encode(encoding, errors="replace").decode(encoding))
        except Exception:
            pass
    finally:
        try:
            sys.stdout.flush()
        except (OSError, ValueError):
            pass


def register_login_context(getter) -> None:
    """由 api_server 注入「拿登录浏览器 context」的回调。"""
    global _login_context_getter
    _login_context_getter = getter


def get_login_context():
    return _login_context_getter() if _login_context_getter else None


def register_login_recover(recover) -> None:
    """由 api_server 注入「浏览器被关闭后恢复 context」的回调。"""
    global _login_recover
    _login_recover = recover


def register_login_required(getter) -> None:
    """Inject LoginSessionManager's live login-state probe."""
    global _login_required_getter
    _login_required_getter = getter


async def get_login_required() -> bool:
    if _login_required_getter is None:
        return False
    value = _login_required_getter()
    if hasattr(value, "__await__"):
        return bool(await value)
    return bool(value)


def register_generation_window_guard(guard) -> None:
    """Inject the persistent-browser hide/restore guard used during generation."""
    global _generation_window_guard
    _generation_window_guard = guard


def get_generation_window_guard():
    return _generation_window_guard


async def recover_login_context() -> None:
    if _login_recover:
        await _login_recover()


def _is_target_closed_error(error: Exception) -> bool:
    if type(error).__name__ == "TargetClosedError":
        return True
    return "target page, context or browser has been closed" in str(error).lower()


class _null_async_context:
    def __aenter__(self):
        return None

    def __aexit__(self, exc_type, exc, tb):
        return False


def upscale_supported() -> bool:
    """新版 Flow 的 2K/4K 放大走 batchexecute，只接受第三方打码 token。"""
    return False


def _parse_content_length(raw_header: Optional[str]) -> Optional[int]:
    """安全解析 HTTP 响应头的 Content-Length。

    仅在合法非负整数时返回 int，缺失、未知或非法时严格返回 None，绝不伪造百分比。
    """
    if not raw_header:
        return None
    try:
        val = int(str(raw_header).strip())
        return val if val >= 0 else None
    except (ValueError, TypeError):
        return None


async def _notify_progress(
    callback: Optional[Callable[[int, Optional[int]], Any]],
    loaded: int,
    total: Optional[int],
) -> None:
    """派发下载进度更新，兼容普通同步回调与异步协程回调。

    若外部回调抛出业务异常，予以保护以免中断核心数据流；正确响应 asyncio.CancelledError。
    """
    if callback is None:
        return
    try:
        res = callback(loaded, total)
        if asyncio.iscoroutine(res):
            await res
    except asyncio.CancelledError:
        raise
    except Exception:
        pass


_configure_safe_output()


class FlowClient:
    """Flow API 客户端"""
    
    def __init__(self):
        self.config = get_config()
        self._user_agent_cache = {}
        
        self._default_headers = {
            "sec-ch-ua-mobile": "?1",
            "sec-ch-ua-platform": '"Android"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "cross-site",
            "x-browser-channel": "stable",
            "x-browser-copyright": "Copyright 2026 Google LLC. All Rights reserved.",
            "x-browser-validation": "UujAs0GAwdnCJ9nvrswZ+O+oco0=",
            "x-browser-year": "2026",
            "x-client-data": "CJS2yQEIpLbJAQipncoBCNj9ygEIlKHLAQiFoM0BGP6lzwE="
        }
    
    def _generate_user_agent(self, account_id: str = None) -> str:
        """生成 User-Agent"""
        if not account_id:
            account_id = f"random_{random.randint(1, 999999)}"
        
        if account_id in self._user_agent_cache:
            return self._user_agent_cache[account_id]
        
        seed = int(hashlib.md5(account_id.encode()).hexdigest()[:8], 16)
        rng = random.Random(seed)
        
        chrome_versions = ["130.0.0.0", "131.0.0.0", "132.0.0.0"]
        user_agent = f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{rng.choice(chrome_versions)} Safari/537.36"
        
        self._user_agent_cache[account_id] = user_agent
        return user_agent
    
    def _generate_session_id(self) -> str:
        """生成 sessionId"""
        return f";{int(time.time() * 1000)}"

    def _get_retry_reason(self, error: Exception) -> Optional[str]:
        """识别可重试错误"""
        error_text = str(error).lower()
        if "http 401" in error_text or "unauthenticated" in error_text:
            return "401 鉴权失败"
        if "recaptcha evaluation failed" in error_text:
            return "reCAPTCHA 验证失败"
        if "recaptcha" in error_text:
            return "reCAPTCHA 错误"
        if "http 403" in error_text:
            return "403 错误"
        if "http 429" in error_text or "too many requests" in error_text:
            return "429 限流"
        if "http 500" in error_text or "internal" in error_text:
            return "500 内部错误"
        return None

    async def _get_recaptcha_token(self, project_id: str, action: str = "IMAGE_GENERATION") -> Optional[str]:
        """根据配置获取 reCAPTCHA token"""
        method = (self.config.captcha.method or "").strip().lower()
        if method in {"", "none", "off", "disabled"}:
            return None
        if method == "personal":
            st_token = self.config.token.st
            # A live missing session (closed browser or no cookies) forces the
            # personal window on-screen; the hidden generation path otherwise wins.
            login_required = bool(await get_login_required()) or not st_token
            return await get_personal_recaptcha_token(
                project_id=project_id,
                action=action,
                st_token=st_token,
                visible=bool(self.config.captcha.visible_browser),
                login_required=login_required,
                headless=bool(self.config.captcha.personal_headless),
                timeout_seconds=int(self.config.captcha.personal_timeout),
                settle_seconds=float(self.config.captcha.personal_settle_seconds),
            )
        raise Exception(f"不支持的 captcha.method: {self.config.captcha.method}，仅支持 personal/none")
    
    async def _make_request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict] = None,
        json_data: Optional[Dict] = None,
        use_st: bool = False,
        st_token: Optional[str] = None,
        use_at: bool = False,
        at_token: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """发送 HTTP 请求"""
        if headers is None:
            headers = {}
        else:
            headers = dict(headers)
        
        if use_st and st_token:
            headers["Cookie"] = f"__Secure-next-auth.session-token={st_token}"
        
        if use_at and at_token:
            headers["authorization"] = f"Bearer {at_token}"
        
        account_id = None
        if st_token:
            account_id = st_token[:16]
        elif at_token:
            account_id = at_token[:16]
        
        headers.update({
            "Content-Type": "application/json",
            "User-Agent": self._generate_user_agent(account_id)
        })
        
        for key, value in self._default_headers.items():
            headers.setdefault(key, value)
        
        request_timeout = timeout or self.config.flow.timeout
        
        if self.config.debug:
            print(f"[DEBUG] {method} {url}")
            if json_data:
                print(f"[DEBUG] Body: {json.dumps(json_data, ensure_ascii=False)[:500]}")
        
        try:
            if HAS_CURL_CFFI:
                async with AsyncSession() as session:
                    if method.upper() == "GET":
                        response = await session.get(
                            url, headers=headers, timeout=request_timeout, impersonate="chrome110"
                        )
                    else:
                        response = await session.post(
                            url, headers=headers, json=json_data, timeout=request_timeout, impersonate="chrome110"
                        )
                    
                    if response.status_code >= 400:
                        error_body = response.text[:500]
                        raise Exception(f"HTTP {response.status_code}: {error_body}")
                    
                    return response.json()
            else:
                async with aiohttp.ClientSession() as session:
                    if method.upper() == "GET":
                        async with session.get(
                            url, headers=headers, timeout=aiohttp.ClientTimeout(total=request_timeout)
                        ) as response:
                            if response.status >= 400:
                                error_body = await response.text()
                                raise Exception(f"HTTP {response.status}: {error_body[:500]}")
                            return await response.json()
                    else:
                        async with session.post(
                            url, headers=headers, json=json_data, timeout=aiohttp.ClientTimeout(total=request_timeout)
                        ) as response:
                            if response.status >= 400:
                                error_body = await response.text()
                                raise Exception(f"HTTP {response.status}: {error_body[:500]}")
                            return await response.json()
                            
        except Exception as e:
            raise Exception(f"请求失败: {str(e)}")
    
    async def st_to_at(self, st: str) -> Dict[str, Any]:
        """ST 转 AT"""
        url = f"{self.config.flow.labs_base_url}/auth/session"
        return await self._make_request(method="GET", url=url, use_st=True, st_token=st)

    async def refresh_at(self) -> str:
        """强制刷新 AT"""
        config = self.config
        if not config.token.st:
            raise Exception("未配置 Session Token (ST)，无法刷新 AT")

        result = await self.st_to_at(config.token.st)
        config.token.at = result.get("access_token", "")
        config.token.at_expires = result.get("expires", "")
        if "user" in result:
            config.token.user_paygate_tier = result["user"].get("userPaygateTier", config.token.user_paygate_tier)
        if not config.token.at:
            raise Exception("刷新 Access Token 失败")

        config.save_token()
        return config.token.at
    
    async def create_project(self, st: str, title: str = "Flow CLI Project") -> str:
        """创建项目"""
        url = f"{self.config.flow.labs_base_url}/trpc/project.createProject"
        json_data = {"json": {"projectTitle": title, "toolName": "PINHOLE"}}
        
        result = await self._make_request(
            method="POST", url=url, json_data=json_data, use_st=True, st_token=st
        )
        
        return result["result"]["data"]["json"]["result"]["projectId"]
    
    async def get_credits(self, at: str) -> Dict[str, Any]:
        """查询余额"""
        url = f"{self.config.flow.api_base_url}/credits"
        return await self._make_request(method="GET", url=url, use_at=True, at_token=at)
    
    def _detect_image_mime_type(self, image_bytes: bytes) -> str:
        """检测图片 MIME 类型"""
        if len(image_bytes) < 12:
            return "image/jpeg"
        if image_bytes[:4] == b'RIFF' and image_bytes[8:12] == b'WEBP':
            return "image/webp"
        if image_bytes[:4] == b'\x89PNG':
            return "image/png"
        if image_bytes[:3] == b'\xff\xd8\xff':
            return "image/jpeg"
        if image_bytes[:6] in (b'GIF87a', b'GIF89a'):
            return "image/gif"
        return "image/jpeg"
    
    async def upload_image(
        self, at: str, image_bytes: bytes, aspect_ratio: str = "IMAGE_ASPECT_RATIO_LANDSCAPE", project_id: Optional[str] = None
    ) -> str:
        """上传图片"""
        if aspect_ratio.startswith("VIDEO_"):
            aspect_ratio = aspect_ratio.replace("VIDEO_", "IMAGE_")
        
        mime_type = self._detect_image_mime_type(image_bytes)
        image_base64 = base64.b64encode(image_bytes).decode('utf-8')
        
        ext = "png" if "png" in mime_type else "jpg"
        upload_file_name = f"flow_cli_upload_{int(time.time() * 1000)}.{ext}"
        
        url = f"{self.config.flow.api_base_url}/flow/uploadImage"
        
        client_context = {"tool": "PINHOLE"}
        if project_id:
            client_context["projectId"] = project_id
        
        json_data = {
            "clientContext": client_context,
            "fileName": upload_file_name,
            "imageBytes": image_base64,
            "isHidden": False,
            "isUserUploaded": True,
            "mimeType": mime_type
        }
        
        result = await self._make_request(
            method="POST", url=url, json_data=json_data, use_at=True, at_token=at
        )
        
        media_id = (
            result.get("media", {}).get("name")
            or result.get("mediaGenerationId", {}).get("mediaGenerationId")
        )
        
        if not media_id:
            raise Exception(f"上传响应缺少 media id: {list(result.keys())}")
        
        return media_id
    
    async def generate_image(
        self,
        at: str,
        project_id: str,
        prompt: str,
        model_name: str,
        aspect_ratio: str,
        image_inputs: Optional[List[Dict]] = None,
    ) -> Tuple[Dict[str, Any], str]:
        """生成图片"""
        self.last_native_timings = {}
        url = f"{self.config.flow.api_base_url}/projects/{project_id}/flowMedia:batchGenerateImages"
        max_retries = max(1, int(self.config.flow.max_retries))
        last_error = None

        for retry_attempt in range(max_retries):
            recaptcha_token = await self._get_recaptcha_token(project_id=project_id, action="IMAGE_GENERATION")
            session_id = self._generate_session_id()
            client_context = {
                "sessionId": session_id,
                "projectId": project_id,
                "tool": "PINHOLE"
            }
            if recaptcha_token:
                client_context["recaptchaContext"] = {
                    "token": recaptcha_token,
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB"
                }

            request_data = {
                "clientContext": client_context,
                "seed": random.randint(1, 999999),
                "imageModelName": model_name,
                "imageAspectRatio": aspect_ratio,
                "structuredPrompt": {"parts": [{"text": prompt}]},
                "imageInputs": image_inputs or []
            }

            json_data = {
                "clientContext": client_context,
                "mediaGenerationContext": {"batchId": str(uuid.uuid4())},
                "useNewMedia": True,
                "requests": [request_data]
            }

            try:
                result = await self._make_request(
                    method="POST",
                    url=url,
                    json_data=json_data,
                    use_at=True,
                    at_token=at,
                    timeout=self.config.flow.timeout,
                )
                return result, session_id
            except Exception as e:
                last_error = e
                reason = self._get_retry_reason(e)
                is_last_attempt = retry_attempt >= max_retries - 1
                if reason == "401 鉴权失败" and not is_last_attempt:
                    safe_print("   提示: Access Token 失效，正在自动刷新...")
                    at = await self.refresh_at()
                    await asyncio.sleep(0.5)
                    continue
                if (not reason) or is_last_attempt:
                    raise
                safe_print(f"   提示: {reason}，正在重试 ({retry_attempt + 2}/{max_retries})...")
                await asyncio.sleep(1)

        if last_error:
            raise last_error
        raise Exception("生成图片失败")

    async def upsample_image(
        self,
        at: str,
        project_id: str,
        media_id: str,
        target_resolution: str = "UPSAMPLE_IMAGE_RESOLUTION_2K",
        session_id: Optional[str] = None,
    ) -> str:
        """放大图片，返回 base64 编码图像"""
        url = f"{self.config.flow.api_base_url}/flow/upsampleImage"
        max_retries = max(1, int(self.config.flow.max_retries))
        last_error = None

        for retry_attempt in range(max_retries):
            recaptcha_token = await self._get_recaptcha_token(project_id=project_id, action="IMAGE_GENERATION")
            upsample_session_id = session_id or self._generate_session_id()

            client_context = {
                "sessionId": upsample_session_id,
                "projectId": project_id,
                "tool": "PINHOLE",
                "userPaygateTier": self.config.token.user_paygate_tier,
            }
            if recaptcha_token:
                client_context["recaptchaContext"] = {
                    "token": recaptcha_token,
                    "applicationType": "RECAPTCHA_APPLICATION_TYPE_WEB",
                }

            json_data = {
                "mediaId": media_id,
                "targetResolution": target_resolution,
                "clientContext": client_context,
            }

            try:
                result = await self._make_request(
                    method="POST",
                    url=url,
                    json_data=json_data,
                    use_at=True,
                    at_token=at,
                    timeout=max(self.config.flow.timeout, 300),
                )
                encoded = result.get("encodedImage", "")
                if not encoded:
                    raise Exception(f"放大响应缺少 encodedImage: {list(result.keys())}")
                return encoded
            except Exception as e:
                last_error = e
                reason = self._get_retry_reason(e)
                is_last_attempt = retry_attempt >= max_retries - 1
                if reason == "401 鉴权失败" and not is_last_attempt:
                    safe_print("   提示: Access Token 失效，正在自动刷新...")
                    at = await self.refresh_at()
                    await asyncio.sleep(0.5)
                    continue
                if (not reason) or is_last_attempt:
                    raise
                safe_print(f"   提示: {reason}，放大重试 ({retry_attempt + 2}/{max_retries})...")
                await asyncio.sleep(1)

        if last_error:
            raise last_error
        raise Exception("图片放大失败")
    
    async def ensure_valid_at(self) -> str:
        """确保 AT 有效"""
        config = self.config
        # 新版 flow.google.com 不再走 labs 的 ST/AT。会话凭据由登录浏览器持有，
        # 这里返回一个占位 token，只为兼容旧调用点。
        if config.token.at:
            return config.token.at
        return "flow-frontend-cookie"
    
    async def ensure_project(self) -> str:
        """确保项目存在"""
        config = self.config
        if config.token.project_id:
            return config.token.project_id
        raise Exception("尚未创建 Flow 项目，请先在 /setup 完成配置")


_DOCUMENT_PROJECT_LOCK = asyncio.Lock()

def document_project_date():
    return datetime.now(timezone(timedelta(hours=8))).date().isoformat()

class ImageGenerator:
    """图片生成器"""
    
    def __init__(self):
        self.client = FlowClient()
        self.config = get_config()
        from .flow_current import FlowCurrentClient
        self.current = FlowCurrentClient(get_login_context())

    def _require_context(self):
        return self._context_or_error()

    def _context_or_error(self):
        context = get_login_context()
        self.current._context = context
        if context is None:
            raise Exception(
                "登录浏览器未打开，请先调用 /setup/open-login 打开并登录 flow.google.com"
            )
        return context

    async def _ensure_context(self):
        context = self._context_or_error()
        if context is not None:
            return context
        await recover_login_context()
        return self._context_or_error()

    async def generate(
        self,
        prompt: str,
        model: str = None,
        aspect_ratio: Optional[str] = None,
        reference_image: Optional[bytes] = None,
        output_path: Optional[str] = None,
        upscale: str = "none",
        n: int = 1,
        defer_download: bool = False,
        on_progress: Optional[Callable[[int, Optional[int]], Any]] = None,
        document_context: Optional[Dict[str, Any]] = None,
        reuse_reference: bool = False,
        project_id: Optional[str] = None,
        references: Optional[List[Dict[str, Any]]] = None,
    ):
        """生成图片"""
        if n not in (1, 2, 3, 4):
            raise ValueError("Unsupported generation count")
        model = model or DEFAULT_MODEL
        if upscale and upscale.lower() != "none":
            raise Exception(f"当前 Flow 运行时不支持 {upscale.upper()} 放大，请使用 standard/original")
        model_config = get_model_config(model)
        requested_aspect = (aspect_ratio or model_config["aspect_ratio"]).strip()
        normalized_aspect = {
            "1:1": "IMAGE_ASPECT_RATIO_SQUARE",
            "16:9": "IMAGE_ASPECT_RATIO_LANDSCAPE",
            "9:16": "IMAGE_ASPECT_RATIO_PORTRAIT",
            "4:3": "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE",
            "3:4": "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR",
        }.get(requested_aspect.lower(), requested_aspect)
        if normalized_aspect == "IMAGE_ASPECT_RATIO_ULTRAWIDE":
            raise Exception("Flow 当前不支持 21:9，请改用 16:9")
        
        safe_print("\n开始生成图片")
        safe_print(f"   模型: {model}")
        safe_print(f"   比例: {normalized_aspect}")
        safe_print(f"   提示词: {prompt[:100]}{'...' if len(prompt) > 100 else ''}")

        await self._ensure_context()
        project_id = await self.ensure_generation_project(document_context, project_id)

        safe_print("   正在生成图片...")
        guard_factory = get_generation_window_guard()
        guard = await guard_factory() if guard_factory else None
        try:
            if guard is not None:
                await guard.__aenter__()
            # Once native submission starts, errors never trigger another submission.
            result = await self.current.generate_image_native(
                project_id=project_id,
                prompt=prompt,
                model_name=model_config["model_name"],
                aspect_ratio=normalized_aspect,
                reference_image=reference_image,
                count=n,
                reuse_reference=reuse_reference,
                references=references,
            )
        finally:
            if guard is not None:
                await guard.__aexit__(None, None, None)
        
        self.last_native_timings = result.get("timings", {})
        media = result.get("media", [])
        if not media:
            raise Exception("生成结果为空")
        
        urls = []
        for item in media:
            image_url = item.get("image", {}).get("generatedImage", {}).get("fifeUrl") or ""
            media_id = item.get("name")
            if not image_url and media_id:
                fetched = await self.current.get_media(project_id, media_id)
                image_url = fetched["image"]["generatedImage"]["fifeUrl"]
            if not image_url:
                raise Exception("Generation result is missing a download URL")
            urls.append(image_url)

        safe_print("   Completed: image generation succeeded")
        if defer_download:
            return urls
        if output_path:
            # Persist the entire batch before any network download.
            output = Path(output_path)
            output.parent.mkdir(parents=True, exist_ok=True)
            manifest = output.with_suffix(output.suffix + ".batch.json")
            temporary = manifest.with_suffix(".part")
            temporary.write_text(json.dumps({"urls": urls}), encoding="utf-8")
            temporary.replace(manifest)
            semaphore = asyncio.Semaphore(2)
            async def download(index, url):
                target = output if len(urls) == 1 else output.with_name(f"{output.stem}-{index}{output.suffix}")
                async with semaphore:
                    return await self._download_and_save(url, str(target), on_progress=on_progress if len(urls) == 1 else None)
            paths = await asyncio.gather(*(download(index, url) for index, url in enumerate(urls)))
            return paths[0] if n == 1 and len(paths) == 1 else paths
        return urls[0] if n == 1 and len(urls) == 1 else urls

    async def ensure_generation_project(self, document_context=None, project_id=None):
        if project_id:
            try:
                project_id = str(uuid.UUID(project_id))
            except (ValueError, TypeError, AttributeError) as exc:
                raise FlowPreSubmissionError('原任务项目编号无效，未提交生成') from exc
            if not await self.current.check_project(project_id):
                raise FlowPreSubmissionError('原任务项目无法访问，未创建替代项目、未提交生成')
        else:
            project_id = await self.ensure_document_project(document_context) if document_context else await self.ensure_current_project()
        self.last_project_id = project_id
        return project_id

    def _document_projects_path(self):
        config_path = Path(os.environ.get('FLOW_CONFIG', str(Path.home() / '.flow-cli/config.toml')))
        return config_path.parent / 'document-projects.json'

    async def ensure_document_project(self, document):
        self._require_context()
        name = str(document.get('name') or '').strip()
        saved_path = str(document.get('path') or '').strip()
        document_id = str(document.get('id') or '').strip()
        session = str(document.get('session') or '').strip()
        if not saved_path and not document_id:
            return await self.ensure_current_project()
        identity = ('path:' + ntpath.normcase(ntpath.normpath(saved_path))) if saved_path else ('session:' + session + ':' + document_id + ':' + name)
        date = document_project_date()
        key = hashlib.sha256((identity + '\n' + date).encode('utf-8')).hexdigest()
        title = ((name or ntpath.basename(saved_path) or '未保存文档')[:120] + ' - ' + date)
        file = self._document_projects_path()
        async with _DOCUMENT_PROJECT_LOCK:
            try:
                registry = json.loads(file.read_text(encoding='utf-8')) if file.exists() else {'version':1,'projects':{}}
                if not isinstance(registry, dict) or not isinstance(registry.get('projects'), dict):
                    raise ValueError('Invalid document project registry')
            except (OSError, ValueError) as exc:
                raise FlowPreSubmissionError('文档项目记录无法读取，未提交生成') from exc
            entry = registry['projects'].get(key) or {}
            if not isinstance(entry, dict):
                raise FlowPreSubmissionError('文档项目记录无效，未提交生成')
            previous = entry.get('id')
            if previous and await self.current.check_project(previous):
                self.last_project_id = previous
                return previous
            # Only a proven missing project reaches this point; transient/auth
            # failures propagate without creating another project or submitting.
            project_id = await self.current.create_project(title=title)
            if not await self.current.check_project(project_id):
                raise FlowPreSubmissionError('文档项目未确认，未提交生成')
            registry['projects'][key] = {'id':project_id,'title':title,'date':date}
            file.parent.mkdir(parents=True,exist_ok=True)
            temporary = file.with_name(file.name + '.' + uuid.uuid4().hex + '.tmp')
            try:
                temporary.write_text(json.dumps(registry,ensure_ascii=False,indent=2),encoding='utf-8')
                os.replace(temporary,file)
            except OSError as exc:
                raise FlowPreSubmissionError('文档项目记录无法保存，未提交生成') from exc
            finally:
                temporary.unlink(missing_ok=True)
            self.last_project_id = project_id
            return project_id

    async def ensure_current_project(self) -> str:
        """Validate a saved project; replace only a proven missing project."""
        config = self.config
        self._require_context()
        previous = config.token.project_id
        if previous and await self.current.check_project(previous):
            return previous
        safe_print('正在创建可用的 Flow 项目...' if not previous else '原 Flow 项目无法访问，正在准备新的项目；未提交生成...')
        project_id = await self.current.create_project()
        if not await self.current.check_project(project_id):
            raise FlowRpcError('新 Flow 项目未能验证；旧项目记录已保留，未提交生成')
        config.token.project_id = project_id
        config.save_token()
        safe_print(f'完成: 项目已验证: {project_id}')
        return project_id

    async def _download_and_save(
        self,
        url: str,
        output_path: str,
        on_progress: Optional[Callable[[int, Optional[int]], Any]] = None,
    ) -> str:
        """下载远端图片并原子保存到本地文件，支持真实的远端下载字节流进度回调。

        【架构考量与局限性说明】
        为何采用网络 Stream 分块下载而非浏览器 page.evaluate fetch 返回 base64：
        1. 进度断层局限：若在浏览器页面内通过 page.evaluate 执行 fetch 并提取 base64，
           必须等待整张图片在浏览器内部完全缓冲完毕后才一次性返回给 Python，
           中间完全缺失流式字节传输的 progress 事件（导致进度只能呈现 0% 直接跃升至 100%），
           无法获知真实的字节下载动态。
        2. 内存与性能开销：Base64 编码会引入约 33% 的内存膨胀；对于多兆字节的高清大图，
           跨 Chromium 渲染层、Playwright CDP 协议与 Python 进程传输巨大 JSON 字符串，
           极易引发内存抖动、CPU 负载飙升与主线程卡顿。
        3. 跨进程流传输开销：若在浏览器环境使用 ReadableStream 拆分 chunk 并通过 expose_function
           频繁跨进程往返调度，过高的 IPC 频次会导致显著性能瓶颈甚至协议心跳超时。
        4. 最佳方案：优先复用 self.current._context 的认证凭据（Cookies）与请求上下文，
           采用底层异步流式 HTTP 客户端（curl_cffi 模拟 Chrome TLS 指纹，或 aiohttp / urllib）
           建立直接流式连接，零内存膨胀、真实逐字节累加、严格遵循 Content-Length 语义
           （未知时不伪造百分比），并在下载异常时自动清理临时文件，确保重试安全与原子写入。

        函数契约:
        - url: 图片远端地址 (如 Google 签名地址 fifeUrl 或标准 HTTP/HTTPS URL)
        - output_path: 目标文件保存路径 (保持最终文件的绝对路径返回)
        - on_progress: 可选回调，入参为 (loaded: int, total: Optional[int])
          - loaded: 已累计读取写入本地临时文件的字节数 (>= 0)
          - total: 远端响应 Content-Length 确定的总字节数；若未知、缺失或无效则严格为 None
        - 重试安全与原子性: 写入独占的临时文件 (*.part)，全部接收且完整性校验通过后原子替换目标文件；
          任何网络错误或异常均保证清理临时文件，不留半拉残损文件。
        """
        output_file = Path(output_path).resolve()
        output_file.parent.mkdir(parents=True, exist_ok=True)

        # 1. 优先尝试 self.current 原生下载方法 (若宿主或外部扩展提供了原生下载)
        if hasattr(self, "current") and self.current is not None:
            for method_name in ("download_file", "download_image", "download"):
                native_fn = getattr(self.current, method_name, None)
                if callable(native_fn):
                    try:
                        import inspect
                        sig = inspect.signature(native_fn)
                        if "on_progress" in sig.parameters:
                            return await native_fn(url, str(output_file), on_progress=on_progress)
                        res = await native_fn(url, str(output_file))
                        if on_progress:
                            try:
                                size = output_file.stat().st_size
                                await _notify_progress(on_progress, size, size)
                            except Exception:
                                pass
                        return res
                    except (asyncio.CancelledError, KeyboardInterrupt):
                        raise
                    except Exception:
                        pass

        # 2. 构造请求头，注入浏览器 context 的 Cookie 会话
        headers = {
            "User-Agent": self.client._generate_user_agent(),
            "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
            "Referer": "https://flow.google.com/",
        }
        context = getattr(self.current, "_context", None) if hasattr(self, "current") else None
        if context is not None and hasattr(context, "cookies"):
            try:
                context_cookies = await asyncio.wait_for(context.cookies([url]), timeout=2.0)
                if isinstance(context_cookies, list):
                    cookie_strs = [
                        f"{c['name']}={c['value']}"
                        for c in context_cookies
                        if isinstance(c, dict) and "name" in c and "value" in c
                    ]
                    if cookie_strs:
                        headers["Cookie"] = "; ".join(cookie_strs)
            except (asyncio.CancelledError, KeyboardInterrupt):
                raise
            except Exception:
                pass

        # 3. 准备隔离的临时文件路径，保证并发下载与重试安全
        staging_file = output_file.with_name(f"{output_file.name}.{uuid.uuid4().hex[:8]}.part")
        loaded = 0
        total = None

        try:
            if HAS_CURL_CFFI:
                async with AsyncSession() as session:
                    async with session.stream("GET", url, headers=headers, timeout=60, impersonate="chrome110") as response:
                        if response.status_code >= 400:
                            err_text = response.text[:500] if hasattr(response, "text") else ""
                            raise Exception(f"HTTP {response.status_code}: {err_text}")

                        raw_len = response.headers.get("content-length") or response.headers.get("Content-Length")
                        total = _parse_content_length(raw_len)
                        await _notify_progress(on_progress, 0, total)

                        with open(staging_file, "wb") as f:
                            async for chunk in response.aiter_content(chunk_size=65536):
                                if not chunk:
                                    continue
                                f.write(chunk)
                                loaded += len(chunk)
                                await _notify_progress(on_progress, loaded, total)

            elif aiohttp is not None:
                async with aiohttp.ClientSession() as session:
                    async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=60)) as response:
                        if response.status >= 400:
                            err_text = await response.text()
                            raise Exception(f"HTTP {response.status}: {err_text[:500]}")

                        raw_len = response.headers.get("Content-Length") or response.headers.get("content-length")
                        total = _parse_content_length(raw_len)
                        await _notify_progress(on_progress, 0, total)

                        with open(staging_file, "wb") as f:
                            async for chunk in response.content.iter_chunked(65536):
                                if not chunk:
                                    continue
                                f.write(chunk)
                                loaded += len(chunk)
                                await _notify_progress(on_progress, loaded, total)

            else:
                import urllib.request
                req = urllib.request.Request(url, headers=headers)
                resp = await asyncio.to_thread(urllib.request.urlopen, req, timeout=60)
                try:
                    raw_len = resp.headers.get("Content-Length") or resp.headers.get("content-length")
                    total = _parse_content_length(raw_len)
                    await _notify_progress(on_progress, 0, total)

                    with open(staging_file, "wb") as f:
                        while True:
                            chunk = await asyncio.to_thread(resp.read, 65536)
                            if not chunk:
                                break
                            f.write(chunk)
                            loaded += len(chunk)
                            await _notify_progress(on_progress, loaded, total)
                finally:
                    resp.close()

            # 4. 完整性校验：若已知 Content-Length，实际读取字节数必须严格一致
            if total is not None and loaded != total:
                raise IOError(f"下载不完整: 预期 {total} 字节，实际接收 {loaded} 字节 (url={url})")
            if loaded == 0:
                raise IOError(f"下载内容为空 (url={url})")

            # 5. 原子替换至最终目标文件
            staging_file.replace(output_file)
            return str(output_file.absolute())

        except asyncio.CancelledError:
            staging_file.unlink(missing_ok=True)
            raise

        except Exception:
            staging_file.unlink(missing_ok=True)
            raise

    def _save_base64_image(self, encoded_image: str, output_path: str) -> str:
        """保存 base64 图片到文件"""
        if "," in encoded_image and encoded_image.strip().startswith("data:image"):
            encoded_image = encoded_image.split(",", 1)[1]

        image_data = base64.b64decode(encoded_image)
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        with open(output_file, "wb") as f:
            f.write(image_data)

        return str(output_file.absolute())
    
    async def check_credits(self) -> Dict[str, Any]:
        """查询余额"""
        context = get_login_context()
        if context is None:
            raise Exception("登录浏览器未打开，无法查询额度")
        self.current._context = context
        return await self.current.get_credits()
