import argparse

import asyncio

import base64

import ctypes

import hashlib

import json

import os

import re

import secrets

import socket

import tempfile

import time

import uuid

from pathlib import Path
import io
from PIL import Image

from contextlib import asynccontextmanager

from typing import Any, Optional

from urllib.parse import parse_qs, urlparse



from fastapi import Depends, FastAPI, File, Form, Header, HTTPException, Request, UploadFile

from fastapi.responses import FileResponse, HTMLResponse, JSONResponse

from pydantic import BaseModel, Field



# Identify this module load, not whatever happens to be on disk at /health time.

RUNTIME_PATCH_FILES = (

    "api_server.py", "client.py", "flow_current.py", "config.py",

    "personal_captcha.py", "window_policy.py", "service_logging.py",

)





def runtime_build_id(directory: Path) -> str:

    hashes = [hashlib.sha256((directory / name).read_bytes()).hexdigest()

              for name in RUNTIME_PATCH_FILES]

    return hashlib.sha256("\n".join(hashes).encode("ascii")).hexdigest()





RUNTIME_BUILD_ID = runtime_build_id(Path(__file__).resolve().parent)



from .client import ImageGenerator

from .client import register_login_context

from .client import register_login_recover

from .client import register_login_required, register_generation_window_guard

from .config import get_config

from .flow_current import FlowCurrentClient, FlowPreSubmissionError, PROGRESS_TASK, read_web_progress, read_transfer_progress, set_transfer_progress

from .models import IMAGE_MODELS, DEFAULT_MODEL

from .personal_captcha import async_playwright

from .service_logging import install_service_logging

from .window_policy import BROWSER_WINDOW_TITLE_PREFIX

from .window_policy import browser_launch_args





API_KEY_ENV = "FLOW_API_KEY"

DEFAULT_API_KEY = "flow-local-key"

SESSION_STATUS_CACHE_SECONDS = 15.0

SESSION_STATUS_RPC_TIMEOUT_SECONDS = 6.0

SESSION_STATUS_PAGE_TIMEOUT_SECONDS = 3.0

SESSION_STATUS_COOKIE_TIMEOUT_SECONDS = 1.5

OUTPUT_ROOT = Path(os.environ.get("FLOW_CLI_HOME", str(Path.home() / ".flow-cli"))) / "output"

DEBUG_ROOT = OUTPUT_ROOT / "_debug"

PROFILE_ROOT = Path(os.environ.get("FLOW_CLI_HOME", str(Path.home() / ".flow-cli"))) / "browser-profile"



if os.name == "nt":

    from ctypes import wintypes



    SW_HIDE = 0

    SW_SHOW = 5

    SW_RESTORE = 9





def set_windows_browser_visibility(visible: bool) -> bool:

    if os.name != "nt":

        return False



    user32 = ctypes.windll.user32

    titles: list[tuple[int, str]] = []



    @ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)

    def enum_proc(hwnd, _lparam):

        length = user32.GetWindowTextLengthW(hwnd)

        if length <= 0:

            return True

        buffer = ctypes.create_unicode_buffer(length + 1)

        user32.GetWindowTextW(hwnd, buffer, length + 1)

        title = buffer.value.strip()

        if not title:

            return True

        lowered = title.lower()

        if lowered.startswith(BROWSER_WINDOW_TITLE_PREFIX.lower()):

            titles.append((hwnd, title))

        return True



    user32.EnumWindows(enum_proc, 0)

    if not titles:

        return False



    changed = False

    for hwnd, _title in titles:

        if visible:

            user32.ShowWindow(hwnd, SW_RESTORE)

            user32.ShowWindow(hwnd, SW_SHOW)

            user32.SetForegroundWindow(hwnd)

            rect = wintypes.RECT()

            if user32.GetWindowRect(hwnd, ctypes.byref(rect)) and (rect.right <= 0 or rect.bottom <= 0):

                user32.SetWindowPos(hwnd, 0, 100, 100, 0, 0, 0x0001 | 0x0004 | 0x0010)

        else:

            user32.ShowWindow(hwnd, SW_HIDE)

        changed = True

    return changed





MAX_REFERENCE_IMAGES = 4

def decode_reference_image(data: bytes, label: str) -> str:
    """Return the MIME type of a fully decodable static PNG/JPEG/WEBP image."""
    try:
        with Image.open(io.BytesIO(data)) as img:
            fmt = (img.format or "").upper()
            if fmt not in ("PNG", "JPEG", "JPG", "WEBP"):
                raise FlowPreSubmissionError(f"{label}格式不支持: {fmt or '未知'}，仅支持 PNG/JPEG/WEBP，未提交生成")
            if getattr(img, "n_frames", 1) > 1:
                raise FlowPreSubmissionError(f"{label}是动图，仅支持静态图片，未提交生成")
            img.verify()
        with Image.open(io.BytesIO(data)) as img:
            img.load()
    except FlowPreSubmissionError:
        raise
    except Exception as exc:
        raise FlowPreSubmissionError(f"{label}损坏或数据被截断，未提交生成") from exc
    return "image/png" if fmt == "PNG" else ("image/webp" if fmt == "WEBP" else "image/jpeg")

def validate_and_decode_references(refs: Any) -> list[dict[str, Any]]:
    """Validate reference images by hand so malformed input is a 409, not a 422.

    ``ImageGenerationRequest.references`` intentionally accepts ``Any``: FastAPI
    would otherwise reject the whole body with 422 before this function runs,
    which the helper could only treat as an unknown submission. Every shape
    error here becomes ``FlowPreSubmissionError`` so the caller can answer
    ``generation_not_submitted`` with ``submissionSent: false``.
    """
    if refs is None:
        return []
    if not isinstance(refs, list):
        raise FlowPreSubmissionError("参考图必须是数组，未提交生成")
    if len(refs) > MAX_REFERENCE_IMAGES:
        raise FlowPreSubmissionError(f"参考图数量不能超过 {MAX_REFERENCE_IMAGES} 张，未提交生成")
    decoded_refs = []
    for idx, item in enumerate(refs):
        label = f"第 {idx + 1} 张参考图"
        if not isinstance(item, dict):
            raise FlowPreSubmissionError(f"{label}结构无效，应为包含 base64 的对象，未提交生成")
        b64_str = item.get("base64")
        if b64_str is None:
            b64_str = item.get("data")
        if not isinstance(b64_str, str) or not b64_str.strip():
            raise FlowPreSubmissionError(f"{label} Base64 数据缺失或无效，未提交生成")
        name = item.get("name")
        if name is not None and not isinstance(name, str):
            raise FlowPreSubmissionError(f"{label}名称无效，未提交生成")
        if b64_str.strip().startswith("data:"):
            header, separator, payload = b64_str.partition(",")
            if not separator or ";base64" not in header.lower():
                raise FlowPreSubmissionError(f"{label} Data URL 无效，未提交生成")
            b64_str = payload
        try:
            data = base64.b64decode(b64_str, validate=True)
        except Exception as exc:
            raise FlowPreSubmissionError(f"{label} Base64 编码非法，未提交生成") from exc
        if not data:
            raise FlowPreSubmissionError(f"{label}内容为空，未提交生成")
        mime = decode_reference_image(data, label)
        decoded_refs.append({"bytes": data, "name": name or f"reference-{idx}.png", "mime": mime})
    return decoded_refs

class ImageGenerationRequest(BaseModel):

    model: str = Field(default=DEFAULT_MODEL)

    prompt: str

    size: Optional[str] = Field(default=None, description="1024x1024 / 1024x1536 / 1536x1024")

    aspect_ratio: Optional[str] = Field(default=None, description="1:1 / 9:16 / 16:9 / 21:9")

    quality: Optional[str] = Field(default="standard", description="standard / hd / 2k / 4k")

    response_format: Optional[str] = Field(default="url", description="url / b64_json")

    n: int = Field(default=1)

    # Validated by validate_and_decode_references, not by Pydantic: a malformed
    # reference must reach the handler so it can answer 409 + submissionSent:false.
    references: Optional[Any] = Field(default=None)





class ChatCompletionRequest(BaseModel):

    model: str = Field(default=DEFAULT_MODEL)

    messages: list[dict[str, Any]]

    size: Optional[str] = None

    quality: Optional[str] = None

    aspect_ratio: Optional[str] = None

    response_format: Optional[str] = "url"

    stream: Optional[bool] = False

    n: Optional[int] = 1



    model_config = {"extra": "allow"}





def is_flow_authentication_error(error: BaseException) -> bool:

    """Recognize explicit Flow authentication rejections, not transport failures."""

    message = str(error).lower()

    return bool(re.search(r"(?<!\d)(?:401|unauthenticated|unauthorized)(?!\d)", message))         or "cookie 失效" in message or "请重新登录" in message





class LoginSessionManager:

    def __init__(self) -> None:

        self._lock = asyncio.Lock()

        self._playwright = None

        self._context = None

        self._page = None

        self._last_cookie_error = ""

        self._window_visible = False

        self._visibility_choice = None

        self._session_state = "not_started"

        self._session_error = ""

        self._checked_at = 0.0

        self._live_login_detected = False

        self._status_probe_task = None

        self._probe_in_progress = False

        self._probe_started_at = 0.0

        self._probe_phase = "idle"

        self._probe_duration_ms = None



    def _start_status_probe(self) -> None:

        task = self._status_probe_task

        if task is not None and not task.done():

            return

        self._probe_started_at = time.monotonic()

        self._probe_phase = "queued"

        self._status_probe_task = asyncio.create_task(self._run_status_probe())



    async def _run_status_probe(self) -> None:

        task = asyncio.current_task()

        self._probe_phase = "waiting_for_session_lock"

        try:

            async with self._lock:

                if not self._context_alive():

                    self._session_state = "closed"

                    self._live_login_detected = False

                    return

                if time.monotonic() - self._checked_at < SESSION_STATUS_CACHE_SECONDS:

                    self._probe_phase = "complete"

                    return

                await self._probe_session_locked(retry_after_refresh=False)

        except asyncio.CancelledError:

            raise

        except Exception as exc:

            self._session_state = "login_required" if is_flow_authentication_error(exc) else "unverified"

            self._session_error = str(exc) or type(exc).__name__

            self._checked_at = time.monotonic()

        finally:

            if not self._probe_in_progress and self._probe_phase != "complete":

                self._probe_phase = "complete" if self._checked_at else "failed"

            if self._status_probe_task is task:

                self._status_probe_task = None



    def status_snapshot(self) -> dict[str, Any]:

        """Return cached state immediately and queue one stale read-only probe."""

        now = time.monotonic()

        browser_open = self._context_alive()

        task = self._status_probe_task

        active = self._probe_in_progress or (task is not None and not task.done())

        active = active or self._session_state in {"restoring", "checking"}



        if not browser_open and not active:

            if self._session_state not in {

                "not_started", "profile_missing", "restore_failed", "error", "closed"

            }:

                self._session_state = "closed"

            self._live_login_detected = False

        elif browser_open and not active and now - self._checked_at >= SESSION_STATUS_CACHE_SECONDS:

            self._start_status_probe()

            task = self._status_probe_task

            active = task is not None and not task.done()



        state = "checking" if active else self._session_state

        checked_age_ms = max(0, int((now - self._checked_at) * 1000)) if self._checked_at else None

        elapsed_ms = max(0, int((now - self._probe_started_at) * 1000)) if active and self._probe_started_at else 0

        ready = bool(browser_open and not active and state == "ready"

                     and self._checked_at and now - self._checked_at < SESSION_STATUS_CACHE_SECONDS)

        error = "" if active else self._session_error

        message = {

            "ready": "Flow 会话已通过只读接口确认。",

            "checking": "正在通过 Flow 只读接口确认登录状态；此查询不会创建项目或提交生成。",

            "login_required": "Flow 登录会话已失效。请点击“连接 / 登录 Flow”重新登录，再查询连接状态。",

            "verification_required": "Flow 要求完成人工验证。请在 Flow 登录窗口完成验证，再查询连接状态。",

            "unverified": "暂时无法确认 Flow 登录状态。请检查网络和 Flow 页面后重新查询；当前状态不能视为已连接。",

            "not_started": "Flow 登录会话尚未启动，请点击“连接 / 登录 Flow”。",

            "profile_missing": "没有可恢复的 Flow 浏览器会话，请点击“连接 / 登录 Flow”。",

            "closed": "Flow 浏览器会话已关闭，请点击“连接 / 登录 Flow”恢复。",

            "restore_failed": "Flow 浏览器会话恢复失败，请检查浏览器环境后重新连接。",

            "error": "Flow 登录检查失败，请点击“连接 / 登录 Flow”重试。",

        }.get(state, "Flow 登录状态暂不可用，请点击“连接 / 登录 Flow”重试。")

        return {

            "browser_open": browser_open,

            "browser_visible": self._window_visible if browser_open else False,

            "live_login_detected": bool(browser_open and self._live_login_detected),

            "session_ready": ready,

            "session_state": state,

            "session_error": error,

            "session_message": message,

            "session_check_active": active,

            "session_check_phase": self._probe_phase if active else ("complete" if self._checked_at else "idle"),

            "session_check_elapsed_ms": elapsed_ms,

            "session_check_duration_ms": self._probe_duration_ms,

            "session_checked_at_age_ms": checked_age_ms,

            "login_error": self._last_cookie_error,

        }



    async def _probe_phase_update(self, phase: str) -> None:

        self._probe_phase = phase



    def _prefers_visible(self) -> bool:

        if self._visibility_choice is not None:

            return self._visibility_choice

        # Honor an existing explicit user setting without writing new state.

        captcha = getattr(get_config(), "captcha", None)

        return bool(getattr(captcha, "visible_browser", False))



    async def open(self, flow_url: str, *, visible: bool = True) -> None:

        async with self._lock:

            # Showing a login challenge is temporary. Only the explicit window

            # toggle sets a lasting user visibility preference.

            desired_visible = visible or self._prefers_visible()

            if self._context is not None:

                if self._context_alive():

                    if visible:

                        # Explicit login is an interaction, not an automatic restore.

                        desired_visible = True

                        await self._set_window_visibility(True)

                    return

                await self._close_locked()



            self._session_state = "restoring" if not visible else "checking"

            self._session_error = ""

            self._probe_started_at = time.monotonic()

            self._probe_phase = "opening_browser"

            try:

                PROFILE_ROOT.mkdir(parents=True, exist_ok=True)

                policy = browser_launch_args("login" if desired_visible else "restore")

                self._playwright = await async_playwright().start()

                self._context = await self._playwright.chromium.launch_persistent_context(

                    user_data_dir=str(PROFILE_ROOT), headless=policy.headless,

                    args=list(policy.launch_args), viewport=None,

                )

                self._page = self._context.pages[0] if self._context.pages else await self._context.new_page()

                await self._page.add_init_script(

                    "Object.defineProperty(document, 'title', {configurable: true, get: () => "

                    + json.dumps(BROWSER_WINDOW_TITLE_PREFIX) + "});"

                )

                self._window_visible = desired_visible

                await self._set_window_visibility(desired_visible)

                try:
                    await self._page.goto(flow_url, wait_until="commit", timeout=30000)
                except Exception as navigation_error:
                    # Loading timeout does not prove that the saved login expired.
                    host = (urlparse(self._page.url).hostname or '').lower()
                    timed_out = type(navigation_error).__name__ == 'TimeoutError'
                    if not (timed_out and self._context_alive() and host in {'flow.google.com','labs.google'}):
                        raise

                await self._apply_window_title()

                await self._probe_phase_update("checking_page")

                await self._probe_session_locked()

            except BaseException as exc:

                self._session_state = "restore_failed" if not visible else "error"

                self._session_error = str(exc) or type(exc).__name__

                self._checked_at = time.monotonic()

                self._probe_duration_ms = max(0, int((self._checked_at - self._probe_started_at) * 1000))

                self._probe_phase = "failed"

                # Release a failed launch without deleting the persistent profile.

                try:

                    await self._close_locked()

                except Exception:

                    pass

                raise



    def _context_alive(self) -> bool:

        if self._context is None:

            return False

        try:

            browser = self._context.browser

            if browser is not None and not browser.is_connected():

                return False

            return any(not page.is_closed() for page in self._context.pages)

        except Exception:

            return False



    async def restore_existing(self) -> bool:

        # A new install must not create a login window or manufacture a profile.

        try:

            if not PROFILE_ROOT.is_dir() or not any(PROFILE_ROOT.iterdir()):

                self._session_state = "profile_missing"

                return False

            await self.open("https://flow.google.com/projects", visible=False)

            return True

        except Exception as exc:

            self._session_state = "restore_failed"

            self._session_error = str(exc) or type(exc).__name__

            raise



    async def _probe_session_locked(self, *, retry_after_refresh: bool = True) -> None:

        probe_task = asyncio.current_task()

        if probe_task is not self._status_probe_task:

            self._probe_started_at = time.monotonic()

        self._probe_in_progress = True

        self._probe_phase = "reading_cookies"

        self._session_error = ""

        try:

            if not self._context_alive():

                self._session_state = "closed"

                self._live_login_detected = False

                return

            self._ensure_probe_page_locked()

            if self._page is None:

                self._session_state = "closed"

                self._live_login_detected = False

                return

            try:

                self._live_login_detected = await asyncio.wait_for(

                    self._has_live_session_cookie_locked(),

                    timeout=SESSION_STATUS_COOKIE_TIMEOUT_SECONDS,

                )

            except Exception as cookie_error:

                self._live_login_detected = False

                self._last_cookie_error = str(cookie_error) or type(cookie_error).__name__



            self._probe_phase = "checking_page"

            evidence = {}

            try:

                evidence = await asyncio.wait_for(

                    self._page.evaluate(SESSION_EVIDENCE_SCRIPT),

                    timeout=SESSION_STATUS_PAGE_TIMEOUT_SECONDS,

                )

            except Exception:

                pass

            if evidence.get("login") or evidence.get("challenge"):

                self._session_state = "verification_required" if evidence.get("challenge") else "login_required"

                self._session_error = ""

                return



            # A Flow shell/editor in the DOM and session cookies are hints only.

            # The read-only authenticated RPC is the sole evidence for ready.

            payload = await self._verify_session_locked(retry_after_refresh=retry_after_refresh)

            if not isinstance(payload, list) or not any(

                isinstance(value, (int, float)) and not isinstance(value, bool) for value in payload

            ):

                raise RuntimeError("Session verification returned no authenticated credit data")

            self._session_state = "ready"

            self._session_error = ""

        except asyncio.CancelledError:

            raise

        except Exception as exc:

            self._session_error = str(exc) or type(exc).__name__

            self._session_state = "login_required" if is_flow_authentication_error(exc) else "unverified"

        finally:

            self._checked_at = time.monotonic()

            self._probe_duration_ms = max(0, int((self._checked_at - self._probe_started_at) * 1000))

            self._probe_in_progress = False

            self._probe_phase = "complete"



    async def _verify_session_locked(self, *, retry_after_refresh: bool = True) -> Any:

        """Run the read-only credit RPC, reloading once if it is rejected.



        The in-page batchexecute call depends on bootstrap metadata (``bl``,

        ``FdrFJe`` and the ``SNlM0e`` xsrf token) scraped from the *current*

        document. After a cookie import or a profile restore that document can

        still be an anonymous or stale one, which surfaces as either

        ``Failed to fetch`` or a ``401`` er-frame even though the session is

        valid. One forced navigation to the authenticated entry point gives the

        page a fresh bootstrap; retrying more than once would only mask a real

        logout, so this is deliberately a single retry.

        """

        client = FlowCurrentClient(self._context)

        self._probe_phase = "checking_rpc"

        try:

            return await asyncio.wait_for(

                client._rpc(self._page, "nzlxg", [], "/projects"),

                timeout=SESSION_STATUS_RPC_TIMEOUT_SECONDS,

            )

        except Exception as first:

            # A rejected session is already conclusive; reloading only delays

            # the actionable login state and cannot make an expired cookie valid.

            if is_flow_authentication_error(first) or not retry_after_refresh:

                raise

            self._probe_phase = "refreshing_page"

            try:

                await asyncio.wait_for(

                    self._reload_probe_page_locked("https://flow.google.com/projects"), timeout=12

                )

            except Exception as reload_error:

                raise RuntimeError(

                    "Flow 页面刷新失败，暂时无法确认登录状态：" + (str(reload_error) or type(reload_error).__name__)

                ) from first

            self._probe_phase = "checking_rpc_retry"

            try:

                return await asyncio.wait_for(

                    client._rpc(self._page, "nzlxg", [], "/projects"),

                    timeout=SESSION_STATUS_RPC_TIMEOUT_SECONDS,

                )

            except Exception as second:

                raise (second if str(second).strip() else first)



    def _ensure_probe_page_locked(self) -> None:

        """Return the probe page, reviving a closed one instead of raising.



        ``_context_alive`` only requires *some* page to be open, so the cached

        ``_page`` can be stale after the user closes a tab. StopIteration from

        an exhausted generator would surface as a confusing RuntimeError, so

        rebuild the handle here and re-arm the window title hook.

        """

        if self._page is not None and not self._page.is_closed():

            return

        page = next((item for item in self._context.pages if not item.is_closed()), None)

        if page is None:

            self._page = None

            return

        self._page = page



    async def _reload_probe_page_locked(self, url: str) -> None:

        """Force a fresh authenticated document before probing the session.



        Imported cookies only take effect on the next navigation: a page that

        was already loaded while signed out keeps its anonymous bootstrap, so

        the in-page batchexecute RPC fails even though the cookies are present.

        """

        self._ensure_probe_page_locked()

        if self._page is None:

            self._page = await self._context.new_page()

        try:

            await self._page.add_init_script(

                "Object.defineProperty(document, 'title', {configurable: true, get: () => "

                + json.dumps(BROWSER_WINDOW_TITLE_PREFIX) + "});"

            )

        except Exception:

            pass

        await self._page.goto(url, wait_until="domcontentloaded", timeout=45000)

        await self._apply_window_title()



    async def session_status(self) -> tuple[bool, str, str]:

        async with self._lock:

            if not self._context_alive():

                if self._session_state not in {"not_started", "profile_missing", "restore_failed", "error", "restoring"}:

                    self._session_state = "closed"

            elif (time.monotonic() - self._checked_at >= SESSION_STATUS_CACHE_SECONDS

                  or self._session_state == "unverified"):

                await self._probe_session_locked()

            return self._session_state == "ready", self._session_state, self._session_error



    async def require_interaction(self, state: str) -> None:

        async with self._lock:

            self._session_state = state

            # 登录（login_required）走动作内嵌的 Quicker WebView2：内嵌窗口完成后

            # 通过 /setup/import-cookies 把会话桥接进来，所以不再弹 Playwright

            # 浏览器，避免用户看到“动作内窗口 → 另一个浏览器窗口”。

            # 人机验证（verification_required）的验证码只存在于 Playwright 页面里，

            # 内嵌窗口无法代答，这一种情况仍需要显示该浏览器窗口。

            if state == "verification_required":

                await self._set_window_visibility(True)



    async def _apply_window_title(self) -> None:

        if self._page is None:

            return

        try:

            await self._page.evaluate(

                "prefix => { Object.defineProperty(document, 'title', {configurable: true, get: () => prefix}); }",

                BROWSER_WINDOW_TITLE_PREFIX,

            )

        except Exception:

            pass



    async def _set_window_visibility(self, visible: bool) -> bool:

        try:

            changed = set_windows_browser_visibility(visible)

            if changed:

                self._window_visible = visible

            return changed

        except Exception:

            return False



    def _extract_st_from_cookie_list(self, cookies: list[dict[str, Any]]) -> Optional[str]:

        exact_names = [

            "__Secure-next-auth.session-token",

            "next-auth.session-token",

        ]

        for name in exact_names:

            for cookie in cookies:

                if cookie.get("name") == name and cookie.get("value"):

                    return str(cookie["value"])



        chunk_prefixes = [

            "__Secure-next-auth.session-token.",

            "next-auth.session-token.",

        ]

        for prefix in chunk_prefixes:

            chunks: list[tuple[int, str]] = []

            for cookie in cookies:

                name = str(cookie.get("name") or "")

                value = str(cookie.get("value") or "")

                if not value or not name.startswith(prefix):

                    continue

                suffix = name[len(prefix) :]

                if suffix.isdigit():

                    chunks.append((int(suffix), value))

            if chunks:

                chunks.sort(key=lambda item: item[0])

                return "".join(value for _, value in chunks)



        return None



    async def _read_flow_session_token(self) -> Optional[str]:

        if self._context is None:

            return None



        last_error = None

        cookie_queries = [

            (),

            ("https://flow.google.com",),

            ("https://flow.google.com/",),

        ]

        for query in cookie_queries:

            try:

                cookies = await self._context.cookies(query)

                token = self._extract_st_from_cookie_list(cookies)

                if token:

                    self._last_cookie_error = ""

                    return token

            except Exception as exc:

                last_error = exc



        if last_error is not None:

            self._last_cookie_error = str(last_error)

        return None



    async def extract_st(self) -> str:

        async with self._lock:

            if self._context is None:

                raise HTTPException(status_code=400, detail="Login browser is not open")

            token = await self._read_flow_session_token()

            if token:

                return token

            raise HTTPException(status_code=400, detail="Flow session token not found. Please confirm Google Flow login is complete.")



    async def _has_live_session_cookie_locked(self) -> bool:

        if not self._context_alive():

            return False

        cookies = await self._context.cookies()

        if self._extract_st_from_cookie_list(cookies):

            return True

        has_osid = any(

            c.get("name") in ("OSID", "__Secure-OSID") and c.get("value")

            for c in cookies if _is_google_domain(str(c.get("domain") or ""))

        )

        has_sid = any(

            c.get("name") in ("SID", "__Secure-1PSID", "__Secure-3PSID") and c.get("value")

            for c in cookies if _is_google_domain(str(c.get("domain") or ""))

        )

        return bool(has_sid or has_osid)



    async def has_st_cookie(self) -> bool:

        async with self._lock:

            try:

                self._live_login_detected = await self._has_live_session_cookie_locked()

                self._last_cookie_error = ""

            except Exception as exc:

                self._last_cookie_error = str(exc) or type(exc).__name__

                self._live_login_detected = False

            return self._live_login_detected



    async def get_cookie_error(self) -> str:

        async with self._lock:

            return self._last_cookie_error



    async def set_window_visible(self, visible: bool) -> bool:

        async with self._lock:

            changed = await self._set_window_visibility(visible)

            if changed:

                self._visibility_choice = visible

            return changed



    async def hide_during_generation(self):

        """Normal work stays silent; an explicit user visibility choice wins."""

        class _GenerationWindowGuard:

            manager = self



            async def __aenter__(self):

                async with self.manager._lock:

                    if not self.manager._prefers_visible():

                        await self.manager._set_window_visibility(False)

                return None



            async def __aexit__(self, exc_type, exc, tb):

                # Do not pop a login window back up after every generation.

                return False



        return _GenerationWindowGuard()



    async def is_window_visible(self) -> bool:

        async with self._lock:

            return self._window_visible if self._context is not None else False



    async def reopen_fresh(self, flow_url: str) -> None:

        await self.close()

        await self.open(flow_url)



    async def _close_locked(self) -> None:

        if self._context is not None:

            await asyncio.wait_for(self._context.close(), timeout=15)

            self._context = None

            self._page = None

        if self._playwright is not None:

            await asyncio.wait_for(self._playwright.stop(), timeout=10)

            self._playwright = None

        self._window_visible = False



    async def close(self) -> None:

        async with self._lock:

            await self._close_locked()

            self._last_cookie_error = ""

            self._session_state = "closed"

            self._session_error = ""



    async def is_open(self) -> bool:

        async with self._lock:

            return self._context_alive()



    async def import_cookies(self, cookie_header: str, origin: str = "https://flow.google.com") -> int:

        """Adopt a session captured from an embedded browser (Quicker WebView2).



        The embedded window shares no user-data-dir with the Playwright profile,

        so the only safe bridge is to write its cookies into the persistent

        context and then re-probe the authenticated session. Cookies are never

        written to disk by this call beyond Playwright's own profile store.

        """

        parsed = parse_cookie_header(cookie_header)

        if not parsed:

            raise HTTPException(status_code=400, detail="No cookies were provided")

        # open() takes the same non-reentrant lock, so the context must be

        # started before the import lock is held.

        if not self._context_alive():

            await self.open(origin, visible=False)

        async with self._lock:

            if not self._context_alive():

                raise HTTPException(status_code=503, detail="Generation browser could not be started")

            # An already verified generation session owns its cookie jar.
            # Legacy WebView imports must never overwrite that session.
            if self._session_state == "ready":
                return 0

            host = (urlparse(origin).hostname or "flow.google.com").lower()

            # Google session cookies (SID/HSID/OSID/__Secure-*) live on the

            # registrable domain; scoping them to flow.google.com alone would

            # drop the accounts.google.com half of the session.

            domain = ".google.com" if host.endswith("google.com") else host

            cookies = []

            for name, value in parsed:

                cookie = {

                    "name": name,

                    "value": value,

                    "domain": domain,

                    "path": "/",

                    "secure": True,

                }

                if name.startswith("__Host-"):

                    cookie["domain"] = host

                cookies.append(cookie)

            # A long-lived context accumulates Google cookies from earlier

            # sessions. They are session-scoped, so they never reach the

            # on-disk profile and survive every restart in memory only. A stale

            # host-only copy (for example an expired "SID" on flow.google.com)

            # takes precedence over the freshly imported registrable-domain one,

            # which made a valid import look like a signed-out session. Drop the

            # existing Google cookies first so the imported jar is authoritative.

            previous = await self._context.cookies()
            try:
                await self._purge_google_cookies_locked()
                await self._context.add_cookies(cookies)
                await self._reload_probe_page_locked("https://flow.google.com/projects")
                await self._probe_session_locked()
                if self._session_state != "ready":
                    raise RuntimeError("Imported session was not authenticated")
            except Exception as exc:
                # Restore original cookie metadata if the candidate is rejected.
                await self._purge_google_cookies_locked()
                await self._context.add_cookies(previous)
                await self._reload_probe_page_locked("https://flow.google.com/projects")
                await self._probe_session_locked()
                raise HTTPException(status_code=409, detail="Cookie import failed; previous session was preserved") from exc
            return len(cookies)



    async def _purge_google_cookies_locked(self) -> None:

        """Delete every google.com cookie from the live context.



        Playwright only exposes an all-or-nothing ``clear_cookies``, so the

        per-cookie deletion goes through CDP. The context is dedicated to Flow

        generation, and only the Google tree can shadow an imported session, so

        a CDP failure falls back to clearing everything rather than leaving a

        conflicting jar in place.

        """

        try:

            existing = await self._context.cookies()

            targets = [c for c in existing if _is_google_domain(str(c.get("domain") or ""))]

            if not targets:

                return

            self._ensure_probe_page_locked()

            if self._page is None:

                self._page = await self._context.new_page()

            cdp = await self._context.new_cdp_session(self._page)

            try:

                for cookie in targets:

                    await cdp.send(

                        "Network.deleteCookies",

                        {

                            "name": str(cookie.get("name") or ""),

                            "domain": str(cookie.get("domain") or ""),

                            "path": str(cookie.get("path") or "/"),

                        },

                    )

            finally:

                try:

                    await cdp.detach()

                except Exception:

                    pass

        except Exception:

            raise RuntimeError("Selective cookie cleanup failed; existing cookies were preserved")





login_manager = LoginSessionManager()





SESSION_EVIDENCE_SCRIPT = """() => {

    const visible = node => {

        const rect = node.getBoundingClientRect();

        if (rect.width <= 0 || rect.height <= 0) return false;

        for (let parent = node; parent; parent = parent.parentElement) {

            const style = getComputedStyle(parent);

            if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;

        }

        return true;

    };

    return {

        login: location.hostname === 'accounts.google.com',

        challenge: Array.from(document.querySelectorAll('iframe[src*="recaptcha"][src*="bframe"], form[action*="challenge"]')).some(visible),

        authenticated_flow: location.hostname === 'flow.google.com' && (

            document.querySelector('.ProseMirror') !== null ||

            document.querySelector('flow-prompt-box') !== null ||

            document.querySelector('.base-prompt-box') !== null ||

            Array.from(document.querySelectorAll('img')).some(img => img.src && img.src.includes('googleusercontent.com/a/'))

        )

    };

}"""





register_login_context(lambda: login_manager._context)





async def _is_login_required_for_generation() -> bool:

    _, state, _ = await login_manager.session_status()

    return state in {"login_required", "verification_required"}





register_login_required(_is_login_required_for_generation)





async def recover_login_for_generation() -> None:

    """Reopen the persistent login browser after an external close."""

    try:

        if not await login_manager.restore_existing():

            raise RuntimeError("No existing browser profile to restore")

    except Exception as exc:

        raise Exception(

            "Existing Flow session could not be restored: " + str(exc)

        ) from exc





register_login_recover(recover_login_for_generation)

register_generation_window_guard(lambda: login_manager.hide_during_generation())





def get_api_key() -> str:

    import os



    return os.environ.get(API_KEY_ENV, DEFAULT_API_KEY).strip()





def verify_api_key(authorization: Optional[str] = Header(default=None)) -> None:

    expected = get_api_key()

    if not authorization or not authorization.startswith("Bearer "):

        raise HTTPException(status_code=401, detail="Missing Bearer token")

    provided = authorization.split(" ", 1)[1].strip()

    if not secrets.compare_digest(provided, expected):

        raise HTTPException(status_code=401, detail="Invalid API key")





def build_output_path(tag: str = "image") -> Path:

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    filename = f"{tag}_{int(time.time())}_{uuid.uuid4().hex[:8]}.png"

    return OUTPUT_ROOT / filename





def parse_cookie_header(header: str) -> list[tuple[str, str]]:

    """Split a document.cookie / Cookie header into (name, value) pairs.



    Values are never logged. Malformed fragments are skipped rather than

    aborting the whole import, because a single bad pair must not lock the

    user out of the session they just established.

    """

    pairs: list[tuple[str, str]] = []

    for fragment in str(header or "").split(";"):

        fragment = fragment.strip()

        if not fragment or "=" not in fragment:

            continue

        name, _, value = fragment.partition("=")

        name = name.strip()

        if not name or any(character in name for character in " \t\r\n"):

            continue

        pairs.append((name, value.strip()))

    return pairs





def _is_google_domain(value: str) -> bool:

    """Match the google.com registrable domain, not look-alike suffixes.



    Playwright reports a host-only cookie as "flow.google.com" and a domain

    cookie as ".google.com", so the leading dot must be tolerated. A bare

    endswith("google.com") would also accept notgoogle.com / evilgoogle.com.

    """

    domain = value.strip().lstrip(".").lower()

    return domain == "google.com" or domain.endswith(".google.com")





def normalize_quality(quality: Optional[str]) -> str:

    value = (quality or "standard").strip().lower()

    if value in {"hd", "2k"}:

        return "2k"

    if value == "4k":

        return "4k"

    if value in {"1k", "standard", "default", "original"}:

        return "none"

    return "none"





def normalize_size(size: Optional[str]) -> Optional[str]:

    if not size:

        return None

    value = size.strip().lower().replace(" ", "")

    if value in {"1k", "2k", "4k"}:

        return None

    mapping = {

        "1024x1024": "square",

        "1024x1536": "portrait",

        "1536x1024": "landscape",

        "1024x768": "landscape",

        "768x1024": "portrait",

        "2048x2048": "square",

        "2048x3072": "portrait",

        "3072x2048": "landscape",

        "4096x4096": "square",

        "4096x6144": "portrait",

        "6144x4096": "landscape",

    }

    return mapping.get(value)





def normalize_aspect_ratio(aspect_ratio: Optional[str]) -> Optional[str]:

    if not aspect_ratio:

        return None

    value = aspect_ratio.strip().lower().replace(" ", "")

    mapping = {

        "1:1": "square",

        "16:9": "landscape",

        "9:16": "portrait",

        "4:3": "landscape",

        "3:4": "portrait",

        "21:9": "ultrawide",

        "9:21": "portrait",

    }

    return mapping.get(value)





def detect_orientation(size: Optional[str], aspect_ratio: Optional[str]) -> str:

    return normalize_aspect_ratio(aspect_ratio) or normalize_size(size) or "landscape"





def get_model_variants(requested: str) -> Optional[dict[str, str]]:

    normalized = "".join(ch for ch in requested.lower() if ch.isalnum())

    variants = {

        "gemini-3.1-flash-image": {

            "landscape": "gemini-3.1-flash-image-landscape",

            "portrait": "gemini-3.1-flash-image-portrait",

            "square": "gemini-3.1-flash-image-square",

        },

        "gemini-3.0-pro-image": {

            "landscape": "gemini-3.0-pro-image-landscape",

            "portrait": "gemini-3.0-pro-image-portrait",

            "square": "gemini-3.0-pro-image-square",

        },

        "imagen-4.0-generate-preview": {

            "landscape": "imagen-4.0-generate-preview-landscape",

            "portrait": "imagen-4.0-generate-preview-portrait",

            "square": "imagen-4.0-generate-preview-landscape",

        },

        "nano-banana-2": {

            "landscape": "nano-banana-2-landscape",

            "portrait": "nano-banana-2-portrait",

            "square": "nano-banana-2-square",

            "ultrawide": "nano-banana-2-ultrawide",

        },

        "nano-banana-pro": {

            "landscape": "nano-banana-pro-landscape",

            "portrait": "nano-banana-pro-portrait",

            "square": "nano-banana-pro-square",

        },

    }

    normalized_aliases = {

        "nanobanana2": "nano-banana-2",

        "nanobananatwo": "nano-banana-2",

        "nanobananapro": "nano-banana-pro",

    }

    requested = normalized_aliases.get(normalized, requested)

    if requested in variants:

        return variants[requested]

    for family, mapping in variants.items():

        if requested in mapping.values():

            return mapping

    return None





def resolve_model(model: Optional[str], size: Optional[str], aspect_ratio: Optional[str] = None) -> str:

    requested = (model or DEFAULT_MODEL).strip()

    orientation = detect_orientation(size, aspect_ratio)



    family = get_model_variants(requested)

    if family:

        if orientation == "ultrawide" and "ultrawide" not in family:

            raise HTTPException(status_code=400, detail=f"Model {requested} does not support 21:9. Use nano banana 2.")

        return family.get(orientation, family["landscape"])



    if requested in IMAGE_MODELS:

        if orientation == "ultrawide":

            raise HTTPException(status_code=400, detail=f"Model {requested} does not support 21:9. Use nano banana 2.")

        return requested



    raise HTTPException(status_code=400, detail=f"Unknown model: {requested}")





def encode_image(path: Path) -> str:

    return base64.b64encode(path.read_bytes()).decode("ascii")





def build_image_item(request: Request, path: Path, response_format: str) -> dict:

    if response_format == "b64_json":

        return {"b64_json": encode_image(path)}

    return {"url": str(request.base_url).rstrip("/") + f"/v1/files/{path.name}"}





def save_debug_payload(name: str, payload: Any) -> None:

    DEBUG_ROOT.mkdir(parents=True, exist_ok=True)

    path = DEBUG_ROOT / name

    with open(path, "w", encoding="utf-8") as f:

        json.dump(payload, f, indent=2, ensure_ascii=False)





def extract_prompt(messages: list[dict[str, Any]]) -> str:

    text_parts: list[str] = []

    for message in messages:

        if message.get("role") != "user":

            continue

        content = message.get("content")

        if isinstance(content, str):

            text_parts.append(content)

            continue

        if isinstance(content, list):

            for item in content:

                if not isinstance(item, dict):

                    continue

                item_type = (item.get("type") or "").lower()

                if item_type in {"text", "input_text"} and item.get("text"):

                    text_parts.append(str(item["text"]))

    prompt = "\n".join(part.strip() for part in text_parts if str(part).strip()).strip()

    if not prompt:

        raise HTTPException(status_code=400, detail="No user prompt found in messages")

    return prompt





def extract_preferred_value(prompt: str, label: str) -> Optional[str]:

    patterns = [

        rf"{label}\s*:\s*([^\n\.]+)",

        rf"{label}\s*-\s*([^\n\.]+)",

    ]

    for pattern in patterns:

        match = re.search(pattern, prompt, flags=re.IGNORECASE)

        if match:

            value = match.group(1).strip()

            if value:

                return value

    return None





def strip_preference_lines(prompt: str) -> str:

    cleaned = re.sub(r"(?im)^\s*preferred\s+(size|aspect\s*ratio)\s*[:\-]\s*[^\n]+\s*$", "", prompt)

    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)

    return cleaned.strip()





def extract_reference_image(messages: list[dict[str, Any]]) -> Optional[bytes]:

    for message in messages:

        if message.get("role") != "user":

            continue

        content = message.get("content")

        if not isinstance(content, list):

            continue

        for item in content:

            if not isinstance(item, dict):

                continue

            item_type = (item.get("type") or "").lower()

            if item_type in {"image_url", "input_image"}:

                image_url = item.get("image_url")

                if isinstance(image_url, dict):

                    image_url = image_url.get("url")

                if isinstance(image_url, str) and image_url.startswith("data:") and "," in image_url:

                    return base64.b64decode(image_url.split(",", 1)[1])

    return None





def resolve_upscale(size: Optional[str], quality: Optional[str]) -> str:

    for raw in (quality, size):

        if not raw:

            continue

        value = str(raw).strip().lower()

        if value in {"4k"}:

            return "4k"

        if value in {"2k", "hd"}:

            return "2k"

        if value in {"1k", "standard", "default", "original"}:

            return "none"

    return "none"





def build_chat_response(

    request: Request,

    model_id: str,

    path: Path,

    response_format: str,

) -> dict:

    image_item = build_image_item(request, path, response_format)

    message_content = image_item.get("url") or image_item.get("b64_json") or ""

    return {

        "id": f"chatcmpl-{uuid.uuid4().hex}",

        "object": "chat.completion",

        "created": int(time.time()),

        "model": model_id,

        "choices": [

            {

                "index": 0,

                "message": {

                    "role": "assistant",

                    "content": message_content,

                },

                "finish_reason": "stop",

            }

        ],

        "usage": {

            "prompt_tokens": 0,

            "completion_tokens": 0,

            "total_tokens": 0,

        },

        "data": [image_item],

    }





def build_api_info(base_url: str) -> dict:

    return {

        "url": f"{base_url}/v1",

        "api_key": get_api_key(),

        "recommended_models": [

            "nano banana2",

            "nano banana pro",

        ],

        "notes": [

            "请保持这台电脑开机并保持 API 服务运行。",

            "请保持这台电脑上的 Google Flow 登录状态。",

            f"OpenAI Chat接口完整示例：{base_url}/v1/chat/completions",

            "其他接口格式详README-zh文件",

        ],

    }





def clear_flow_state() -> None:

    config = get_config()

    config.token.st = ""

    config.token.at = ""

    config.token.at_expires = ""

    config.token.project_id = ""

    config.token.user_paygate_tier = "PAYGATE_TIER_NOT_PAID"

    config.save_token()





async def perform_fresh_relogin() -> None:

    # Reopen for human login without erasing cookies or saved project binding.

    await login_manager.reopen_fresh("https://flow.google.com")





def check_host_connectivity(host: str, port: int = 443, timeout: float = 8.0) -> tuple[bool, str]:

    try:

        with socket.create_connection((host, port), timeout=timeout):

            return True, ""

    except Exception as exc:

        return False, str(exc)





async def finalize_flow_setup(base_url: str) -> dict:

    config = get_config()



    reachable, network_error = await asyncio.to_thread(check_host_connectivity, "flow.google.com", 443, 8.0)

    if not reachable:

        return {

            "success": False,

            "error_type": "network_unreachable",

            "message": "This computer cannot reach flow.google.com:443. Please check proxy, VPN, firewall, DNS, or network routing first.",

            "detail": network_error,

            "api": build_api_info(base_url),

        }



    generator = ImageGenerator()

    try:

        await prepare_generation_session()

        credits_info = await generator.check_credits()

        await generator.ensure_current_project()

    except Exception as exc:

        detail = str(exc)

        error_type = "flow_request_failed"

        lowered = detail.lower()

        if "failed to connect to flow.google.com" in lowered or "could not connect to server" in lowered:

            error_type = "network_unreachable"

        elif "timeout" in lowered:

            error_type = "network_timeout"



        return {

            "success": False,

            "error_type": error_type,

            "message": "Flow setup failed while requesting Google Flow. Please verify this computer can access flow.google.com and retry.",

            "detail": detail,

            "api": build_api_info(base_url),

        }



    return {

        "success": True,

        "credits": credits_info.get("credits"),

        "tier": credits_info.get("userPaygateTier"),

        "api": build_api_info(base_url),

    }





_active_tasks = 0

_draining = False





async def restore_at_startup() -> None:

    global _active_tasks

    try:

        await login_manager.restore_existing()

    except Exception as exc:

        login_manager._session_state = "restore_failed"

        login_manager._session_error = str(exc) or type(exc).__name__

    finally:

        _active_tasks -= 1





@asynccontextmanager

async def api_lifespan(_app):

    global _active_tasks

    _active_tasks += 1

    restore_task = asyncio.create_task(restore_at_startup())

    try:

        yield

    finally:

        if not restore_task.done():

            restore_task.cancel()

        try:

            await restore_task

        except asyncio.CancelledError:

            pass

        await login_manager.close()





async def prepare_generation_session() -> None:

    if not await login_manager.is_open():

        try:

            restored = await login_manager.restore_existing()

        except Exception as exc:

            raise HTTPException(status_code=503, detail="Flow profile restore failed: " + str(exc)) from exc

        if not restored:

            raise HTTPException(status_code=409, detail="Existing Flow profile is missing; explicit login is required")

    ready, state, error = await login_manager.session_status()

    if not ready:

        if state in {"login_required", "verification_required"}:

            await login_manager.require_interaction(state)

        raise HTTPException(status_code=409, detail="Flow session is " + state + (": " + error if error else ""))

    async with login_manager._lock:

        if login_manager._window_visible and not login_manager._prefers_visible():

            await login_manager._set_window_visibility(False)





async def report_generation_error(exc: Exception) -> None:

    lowered = str(exc).lower()

    if is_flow_authentication_error(exc):

        await login_manager.require_interaction("login_required")

    elif any(term in lowered for term in ("human verification", "captcha challenge", "人工验证")):

        await login_manager.require_interaction("verification_required")

    else:

        # A failed request invalidates the cached proof; it does not force login.

        login_manager._checked_at = 0.0

        state = None

        async with login_manager._lock:

            if login_manager._context_alive():

                for page in login_manager._context.pages:

                    if page.is_closed():

                        continue

                    try:

                        evidence = await asyncio.wait_for(page.evaluate(SESSION_EVIDENCE_SCRIPT), timeout=3)

                        if evidence.get("challenge") or evidence.get("login"):

                            state = "verification_required" if evidence.get("challenge") else "login_required"

                            break

                    except Exception:

                        continue

        if state:

            await login_manager.require_interaction(state)





app = FastAPI(title="Flow Image OpenAI-Compatible API", version="1.0.0", lifespan=api_lifespan)







@app.middleware("http")

async def local_origin_guard(request: Request, call_next):

    global _active_tasks

    host = request.headers.get("host", "")

    origin = request.headers.get("origin", "")

    allowed_hosts = {"127.0.0.1:8787", "localhost:8787"}

    allowed_origins = {"http://127.0.0.1:8787", "http://localhost:8787"}

    if host not in allowed_hosts or (origin and origin not in allowed_origins):

        return JSONResponse(status_code=403, content={"error": "Local access only"})

    tracked = request.method == "POST" and request.url.path in {

        "/v1/images/generations", "/v1/images/edits", "/v1/chat/completions",

        "/setup/verify-composer", "/setup/open-login", "/setup/relogin",

        "/setup/finalize", "/setup/reset", "/setup/toggle-browser", "/setup/restore",

        "/setup/import-cookies",

    }

    if tracked:

        # No await between admission and increment: atomic on the ASGI event loop.

        if _draining:

            return JSONResponse(status_code=503, content={"error": {"message": "Backend is draining for upgrade"}, "deferred": True})

        _active_tasks += 1

    progress_token = PROGRESS_TASK.set(request.headers.get("x-psfb-job-id", ""))

    try:

        if tracked and request.url.path in {"/v1/images/generations", "/v1/images/edits", "/v1/chat/completions", "/setup/verify-composer"}:

            verify_api_key(request.headers.get("authorization"))

            await prepare_generation_session()

        return await call_next(request)

    except HTTPException as exc:

        return JSONResponse(status_code=exc.status_code, content={"error": {"message": exc.detail}})

    finally:

        PROGRESS_TASK.reset(progress_token)

        if tracked:

            _active_tasks -= 1





@app.get("/setup/generation-progress/{task_id}", dependencies=[Depends(verify_api_key)])

async def generation_progress(task_id: str):

    if not re.fullmatch(r"[0-9a-f-]{36}", task_id):

        raise HTTPException(status_code=400, detail="Invalid task identifier")

    return {"webProgress": read_web_progress(task_id), "transferProgress": read_transfer_progress(task_id)}



@app.get("/health")

async def health():

    return {"status": "ok", "app": "PSFlowBridge-FlowAPI", "version": "1.0.0-psfb1",

            "runtimeBuildId": RUNTIME_BUILD_ID, "pid": os.getpid(),

            "activeTasks": _active_tasks, "draining": _draining}





@app.post("/setup/close")

async def setup_close():

    global _draining

    if _active_tasks:

        return JSONResponse(status_code=409, content={"success": False, "deferred": True, "activeTasks": _active_tasks, "draining": _draining})

    _draining = True

    try:

        await login_manager.close()

    except Exception as exc:

        return JSONResponse(status_code=500, content={"success": False, "closed": False, "activeTasks": 0, "draining": True, "message": str(exc) or type(exc).__name__})

    return {"success": True, "closed": True, "activeTasks": 0, "draining": True}





@app.post("/setup/restore")

async def setup_restore():

    try:

        restored = await login_manager.restore_existing()

    except Exception as exc:

        return JSONResponse(status_code=503, content={"success": False, "session_ready": False, "session_state": "restore_failed", "message": str(exc) or type(exc).__name__})

    ready, state, error = await login_manager.session_status()

    return {"success": restored, "session_ready": ready, "session_state": state, "session_error": error}





@app.get("/setup", response_class=HTMLResponse)

async def setup_page():

    return """

<!doctype html>

<html lang="zh-CN">

<head>

  <meta charset="utf-8" />

  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <title>Flow 本地配置</title>

  <style>

    :root { --bg:#f5f7fb; --card:#ffffff; --text:#111827; --muted:#6b7280; --border:#e5e7eb; --accent:#111827; --soft:#eef2ff; --ok:#0f766e; --warn:#b45309; --err:#b91c1c; }

    * { box-sizing:border-box; }

    body { font-family: Segoe UI, Microsoft YaHei, sans-serif; background:linear-gradient(180deg,#eef2ff 0%,#f8fafc 36%,#f5f7fb 100%); color:var(--text); margin:0; }

    .wrap { max-width: 980px; margin: 28px auto; padding: 0 18px 28px; }

    .hero { background:var(--card); border-radius:20px; padding:28px; box-shadow:0 14px 40px rgba(15,23,42,.08); border:1px solid rgba(229,231,235,.8); }

    h1 { margin:0 0 10px; font-size:32px; }

    .sub { color:var(--muted); margin:0; line-height:1.6; }

    .grid { display:grid; grid-template-columns: 1.2fr .8fr; gap:18px; margin-top:18px; }

    .card { background:var(--card); border:1px solid var(--border); border-radius:16px; padding:20px; box-shadow:0 8px 24px rgba(15,23,42,.04); }

    .title { font-size:18px; font-weight:700; margin:0 0 14px; }

    .step { display:flex; gap:12px; margin:12px 0; align-items:flex-start; }

    .num { width:28px; height:28px; border-radius:999px; background:var(--soft); display:flex; align-items:center; justify-content:center; font-weight:700; flex:none; }

    .step p { margin:2px 0 0; color:var(--muted); line-height:1.5; }

    .buttons { display:flex; flex-wrap:wrap; gap:10px; margin-top:16px; }

    button { border:none; border-radius:12px; padding:12px 16px; cursor:pointer; background:var(--accent); color:#fff; font-size:14px; font-weight:600; }

    button.secondary { background:#eef2f7; color:#111827; }

    button.warn { background:#f59e0b; }

    button.danger { background:#dc2626; }

    button:disabled { opacity:.55; cursor:not-allowed; }

    .status-grid { display:grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap:10px; }

    .pill { border:1px solid var(--border); border-radius:14px; padding:12px 14px; background:#fafafa; }

    .pill .label { font-size:12px; color:var(--muted); margin-bottom:6px; }

    .pill .value { font-weight:700; }

    .good { color:var(--ok); }

    .bad { color:var(--err); }

    .note { margin-top:14px; color:var(--muted); font-size:13px; line-height:1.6; }

    .api-box { display:grid; gap:12px; margin-top:8px; }

    .api-item { border:1px solid var(--border); background:#fafafa; border-radius:14px; padding:14px; }

    .api-item .label { font-size:12px; color:var(--muted); margin-bottom:8px; text-transform:uppercase; letter-spacing:.04em; }

    code { background:#f3f4f6; border-radius:8px; padding:2px 6px; word-break:break-all; }

    .models { display:flex; flex-wrap:wrap; gap:8px; }

    .model-chip { background:#eef2ff; color:#312e81; border-radius:999px; padding:7px 10px; font-size:13px; }

    ul { margin:10px 0 0 18px; color:var(--muted); padding:0; }

    .banner { border-radius:14px; padding:12px 14px; margin-top:14px; display:none; }

    .banner.ok { display:block; background:#ecfdf5; color:#065f46; }

    .banner.warn { display:block; background:#fff7ed; color:#9a3412; }

    .banner.err { display:block; background:#fef2f2; color:#991b1b; }

    .json { background:#0f172a; color:#e2e8f0; border-radius:14px; padding:16px; white-space:pre-wrap; font-size:12px; max-height:240px; overflow:auto; }

    @media (max-width: 860px) { .grid { grid-template-columns: 1fr; } }

  </style>

</head>

<body>

  <div class="wrap">

    <div class="hero">

      <h1>Flow 本地自动配置</h1>

      <p class="sub">用户只需要登录 Google Flow。登录完成后，系统会自动同步 Token、验证账号、初始化项目，并给出最终可用的 API 信息。</p>

      <div id="banner" class="banner"></div>

    </div>

    <div class="grid">

      <div class="card">

        <div class="title">使用步骤</div>

        <div class="step"><div class="num">1</div><div><strong>打开登录页</strong><p>系统会自动打开 Flow 登录页。如果没有弹出，可以手动点击下面的按钮重新打开。</p></div></div>

        <div class="step"><div class="num">2</div><div><strong>登录 Google Flow</strong><p>在弹出的浏览器中登录你的 Google 会员账号。登录完成后，不需要再做额外操作。</p></div></div>

        <div class="step"><div class="num">3</div><div><strong>自动完成配置</strong><p>页面会自动检测登录状态并完成配置。必要时你也可以手动点击“重新同步”。</p></div></div>

        <div class="step"><div class="num">4</div><div><strong>无法自动配置时</strong><p>如遇无法自动配置问题，请检查自身魔法网络，建议全局 + TUN 模式。</p></div></div>

        <div class="buttons">

          <button onclick="relogin()">重新登录</button>

          <button class="secondary" onclick="toggleBrowserWindow()">隐藏/显示浏览器</button>

          <button class="secondary" onclick="finalizeSetup()">重新同步</button>

          <button class="secondary" onclick="refreshStatus()">刷新状态</button>

          <button class="danger" onclick="resetSetup()">重置配置</button>

        </div>

        <div class="note">推荐做法：用户只登录一次。成功后，把右侧显示的 URL、API Key 和模型信息提供给用户即可。</div>

      </div>

      <div class="card">

        <div class="title">当前状态</div>

        <div class="status-grid">

          <div class="pill"><div class="label">浏览器窗口</div><div class="value" id="browser_state">检测中</div></div>

          <div class="pill"><div class="label">登录状态</div><div class="value" id="login_state">检测中</div></div>

          <div class="pill"><div class="label">Session Token</div><div class="value" id="st_state">检测中</div></div>

          <div class="pill"><div class="label">Project</div><div class="value" id="project_state">检测中</div></div>

        </div>

        <div class="note">如果“登录状态”已经变成已检测到，但还没有出现 API 信息，可以点击“重新同步”。</div>

      </div>

    </div>

    <div class="grid">

      <div class="card">

        <div class="title">完成后的 API 信息</div>

        <div id="api_result">

          <div class="note">尚未完成自动配置。</div>

        </div>

      </div>

      <div class="card">

        <div class="title">调试信息</div>

        <div id="debug_json" class="json">加载中...</div>

      </div>

    </div>

  </div>

  <script>

    let finalized = false;

    function setBanner(type, text) {

      const el = document.getElementById('banner');

      if (!text) {

        el.className = 'banner';

        el.textContent = '';

        return;

      }

      el.className = `banner ${type}`;

      el.textContent = text;

    }

    function yn(value, okText = '已就绪', badText = '未就绪') {

      return value ? `<span class="good">${okText}</span>` : `<span class="bad">${badText}</span>`;

    }

    function renderStatus(data) {

      const browserText = data.browser_open ? (data.browser_visible ? '已显示' : '已隐藏') : '未打开';

      document.getElementById('browser_state').innerHTML = data.browser_open ? `<span class="good">${browserText}</span>` : `<span class="bad">${browserText}</span>`;

      document.getElementById('login_state').innerHTML = yn(data.session_ready, '会话已验证', '会话未验证');

      document.getElementById('st_state').innerHTML = yn(data.has_st, '已保存', '未保存');

      document.getElementById('project_state').innerHTML = yn(data.project_ready, '已初始化', '未初始化');

      document.getElementById('debug_json').textContent = JSON.stringify(data, null, 2);

      if (data.session_ready && data.project_ready) {

        setBanner('ok', '配置已完成，可以直接复制右侧 API 信息给用户。');

      } else if (data.session_error || data.login_error) {

        setBanner('warn', `会话检测遇到问题：${data.session_error || data.login_error}`);

      } else if (data.session_ready) {

        setBanner('warn', '会话已验证，项目尚未初始化。');

      } else {

        setBanner('warn', `当前会话状态：${data.session_state || '未验证'}。已保存项目不会证明登录有效。`);

      }

    }

    function renderResult(data) {

      const api = data.api || {};

      const models = (api.recommended_models || []).map(m => `<span class="model-chip">${m}</span>`).join('');

      const notes = (api.notes || []).map(n => `<li>${n}</li>`).join('');

      document.getElementById('api_result').innerHTML = `

        <div class="api-box">

          <div class="api-item"><div class="label">URL</div><code>${api.url || ''}</code></div>

          <div class="api-item"><div class="label">API Key</div><code>${api.api_key || ''}</code></div>

          <div class="api-item"><div class="label">推荐模型</div><div class="models">${models}</div></div>

          <div class="api-item"><div class="label">账户信息</div><div>Credits: <strong>${data.credits ?? '-'}</strong><br/>Tier: <strong>${data.tier ?? '-'}</strong></div></div>

          <div class="api-item"><div class="label">必要说明</div><ul>${notes}</ul></div>

        </div>`;

    }

    async function refreshStatus() {

      const res = await fetch('/setup/status');

      const data = await res.json();

      renderStatus(data);

      if (!finalized && data.session_ready && !data.project_ready) {

        finalized = true;

        await finalizeSetup();

      }

    }

    async function openLogin() {

      const res = await fetch('/setup/open-login', { method: 'POST' });

      const data = await res.json();

      setBanner(data.success ? 'ok' : 'err', data.message || '已触发打开登录页。');

      await refreshStatus();

    }

    async function relogin() {

      finalized = false;

      document.getElementById('api_result').innerHTML = '<div class="note">正在退出当前浏览器登录状态并重新打开登录窗口...</div>';

      const res = await fetch('/setup/relogin', { method: 'POST' });

      const data = await res.json();

      setBanner(data.success ? 'ok' : 'err', data.message || '已重新打开登录页。');

      await refreshStatus();

    }

    async function toggleBrowserWindow() {

      const res = await fetch('/setup/toggle-browser', { method: 'POST' });

      const data = await res.json();

      setBanner(data.success ? 'ok' : 'err', data.message || '浏览器窗口状态已更新。');

      await refreshStatus();

    }

    async function finalizeSetup() {

      document.getElementById('api_result').innerHTML = '<div class="note">正在自动配置，请稍候...</div>';

      const res = await fetch('/setup/finalize', { method: 'POST' });

      const data = await res.json();

      if (data.success) {

        renderResult(data);

        setBanner('ok', '自动配置完成。现在可以把 URL、API Key 和模型信息提供给用户。');

      } else {

        document.getElementById('api_result').innerHTML = `<div class="note">配置失败：${data.message || 'Unknown error'}<br/><br/>${data.detail || ''}</div>`;

        setBanner('err', data.message || '自动配置失败，请检查登录状态后重试。');

      }

      await refreshStatus();

    }

    async function resetSetup() {

      finalized = false;

      const res = await fetch('/setup/reset', { method: 'POST' });

      const data = await res.json();

      document.getElementById('api_result').innerHTML = '<div class="note">配置已重置。</div>';

      setBanner(data.success ? 'ok' : 'err', data.message || '配置已重置。');

      await refreshStatus();

    }

    refreshStatus();

    setInterval(refreshStatus, 4000);

  </script>

</body>

</html>

"""







@app.get("/setup/status")

async def setup_status(request: Request):

    config = get_config()

    session = login_manager.status_snapshot()

    live_login_detected = session["live_login_detected"]

    persisted_login_detected = bool(config.token.project_id)

    page = login_manager._page

    flow_host = ""

    if page is not None:

        try:

            flow_host = urlparse(page.url).hostname or ""

        except Exception:

            pass

    return {

        "browser_open": session["browser_open"],

        "browser_visible": session["browser_visible"],

        "login_detected": live_login_detected or persisted_login_detected,

        "live_login_detected": live_login_detected,

        "flow_host": flow_host,

        "persisted_login_detected": persisted_login_detected,

        # Compatibility hints only; neither cookies nor saved project state prove a live session.

        "has_st": bool(config.token.st) or live_login_detected,

        "has_at": bool(config.token.at),

        "project_ready": bool(config.token.project_id),

        "session_ready": session["session_ready"],

        "session_state": session["session_state"],

        "session_error": session["session_error"],

        "session_message": session["session_message"],

        "session_check_active": session["session_check_active"],

        "session_check_phase": session["session_check_phase"],

        "session_check_elapsed_ms": session["session_check_elapsed_ms"],

        "session_check_duration_ms": session["session_check_duration_ms"],

        "session_checked_at_age_ms": session["session_checked_at_age_ms"],

        "login_error": session["login_error"],

        "api": build_api_info(str(request.base_url).rstrip("/")),

    }





@app.post("/setup/open-login")

async def setup_open_login():

    await login_manager.open("https://flow.google.com")

    return {"success": True, "message": "Flow login browser opened. Please complete Google login there."}





@app.post("/setup/relogin")

async def setup_relogin():

    if _active_tasks > 1:

        return JSONResponse(status_code=409, content={"success": False, "deferred": True, "message": "Active tasks must finish before reopening the login context"})

    await perform_fresh_relogin()

    return {

        "success": True,

        "message": "Flow login browser reopened. Existing profile and project have been preserved.",

    }





@app.post("/setup/toggle-browser")

async def setup_toggle_browser():

    browser_open = await login_manager.is_open()

    if not browser_open:

        # 生成浏览器可能还没被恢复（例如刚开机、还没生成过）。这里按用户

        # 的显隐意图启动一次后台上下文，避免“点了显示却没有窗口”的空操作。

        try:

            await login_manager.open("https://flow.google.com", visible=False)

        except Exception as exc:

            return {"success": False, "message": "Flow 窗口启动失败：" + (str(exc) or type(exc).__name__)}



    visible = await login_manager.is_window_visible()

    changed = await login_manager.set_window_visible(not visible)

    if not changed:

        return {"success": False, "message": "无法切换 Flow 窗口状态，请手动把窗口带到前台后重试。"}



    return {

        "success": True,

        "visible": not visible,

        "message": "Browser window is now visible." if not visible else "Browser window has been hidden.",

    }





@app.post("/setup/finalize")

async def setup_finalize(request: Request):

    return await finalize_flow_setup(str(request.base_url).rstrip("/"))





class CookieImportRequest(BaseModel):

    cookies: str = Field(default="", max_length=200000)

    origin: str = Field(default="https://flow.google.com", max_length=200)





@app.post("/setup/import-cookies", dependencies=[Depends(verify_api_key)])

async def setup_import_cookies(payload: CookieImportRequest):

    """Bridge a Quicker WebView2 login into the Playwright generation profile.



    Google blocks OAuth inside embedded webviews for fresh logins, but a WebView2

    window that is already signed in still exposes its session cookies. Importing

    them here lets the generation browser adopt that session without a second

    external login window.

    """

    origin = payload.origin.strip() or "https://flow.google.com"

    parsed = urlparse(origin)

    host = (parsed.hostname or "").lower()

    # A bare endswith("google.com") also accepts notgoogle.com / evilgoogle.com.

    if parsed.scheme != "https" or not (host == "google.com" or host.endswith(".google.com")):

        raise HTTPException(status_code=400, detail="Cookie import origin must be a Google HTTPS origin")

    count = await login_manager.import_cookies(payload.cookies, origin)

    session_ready, session_state, session_error = await login_manager.session_status()

    return {

        "success": True,

        "imported": count,

        "session_ready": session_ready,

        "session_state": session_state,

        "session_error": session_error,

    }





@app.post("/setup/reset")

async def setup_reset():

    if _active_tasks > 1:

        return JSONResponse(status_code=409, content={"success": False, "deferred": True, "message": "Active tasks must finish before closing the login context"})

    await login_manager.close()

    return {"success": True, "message": "Flow browser closed. Saved profile and project have been preserved."}





@app.get("/v1/models", dependencies=[Depends(verify_api_key)])

async def list_models():

    data = []

    for model_id in IMAGE_MODELS:

        data.append({"id": model_id, "object": "model", "owned_by": "flow-local"})

    return {"object": "list", "data": data}





@app.post("/v1/images/generations", dependencies=[Depends(verify_api_key)])

async def generate_image(request: Request, payload: ImageGenerationRequest):

    if payload.n not in (1, 2, 3, 4):

        raise HTTPException(status_code=400, detail="n must be 1, 2, 3 or 4")



    model_id = resolve_model(payload.model, payload.size, payload.aspect_ratio)

    upscale = resolve_upscale(payload.size, payload.quality)

    output_path = build_output_path("gen")



    generator = ImageGenerator()

    try:
        validated_references = validate_and_decode_references(payload.references)

        saved_path = await generator.generate(

            prompt=payload.prompt,

            model=model_id,

            aspect_ratio=payload.aspect_ratio,

            output_path=str(output_path),

            upscale=upscale,

            n=payload.n,

            defer_download=True,
            references=validated_references,

        )

    except FlowPreSubmissionError as exc:
        return JSONResponse(status_code=409, content={
            "error": {"code": "generation_not_submitted", "message": str(exc)},
            "submissionSent": False,
        })
    except Exception as exc:

        import traceback; traceback.print_exc()

        await report_generation_error(exc)

        raise HTTPException(status_code=500, detail=str(exc)) from exc



    return await build_batch_response(request, saved_path, output_path, payload.response_format or "url", getattr(generator, 'last_native_timings', None))





@app.post("/v1/images/edits", dependencies=[Depends(verify_api_key)])

async def edit_image(

    request: Request,

    image: UploadFile = File(...),

    prompt: str = Form(...),

    model: str = Form(default=DEFAULT_MODEL),

    size: Optional[str] = Form(default=None),

    aspect_ratio: Optional[str] = Form(default=None),

    quality: Optional[str] = Form(default="standard"),

    response_format: Optional[str] = Form(default="url"),

    n: int = Form(default=1),
    document_name: Optional[str] = Form(default=None),
    document_path: Optional[str] = Form(default=None),
    document_id: Optional[str] = Form(default=None),
    document_session: Optional[str] = Form(default=None),
    reuse_reference: Optional[str] = Form(default=None),
    project_id: Optional[str] = Form(default=None),
    references: Optional[str] = Form(default=None),

):

    if n not in (1, 2, 3, 4):

        raise HTTPException(status_code=400, detail="n must be 1, 2, 3 or 4")



    model_id = resolve_model(model, size, aspect_ratio)

    upscale = resolve_upscale(size, quality)

    image_bytes = await image.read()

    if not image_bytes:

        raise HTTPException(status_code=400, detail="Image file is empty")



    output_path = build_output_path("edit")

    generator = ImageGenerator()

    try:

        # Multi-reference edits send ``[base, ...ordered refs]`` to the native
        # path: Flow replaces the composer chips wholesale, so the base must be
        # the first attachment or it would be dropped in favour of the refs.
        validated_references: list[dict[str, Any]] = []
        if references is not None and references.strip():
            try:
                parsed_references = json.loads(references)
            except (TypeError, ValueError) as exc:
                raise FlowPreSubmissionError("参考图参数不是合法 JSON，未提交生成") from exc
            validated_references = validate_and_decode_references(parsed_references)
            if len(validated_references) + 1 > MAX_REFERENCE_IMAGES:
                raise FlowPreSubmissionError(
                    f"精修基底与参考图合计不能超过 {MAX_REFERENCE_IMAGES} 张，未提交生成"
                )
        ordered_references = None
        if validated_references:
            base_mime = decode_reference_image(image_bytes, "精修基底图")
            ordered_references = [{"bytes": image_bytes, "name": "source.png", "mime": base_mime}] + validated_references

        saved_path = await generator.generate(

            prompt=prompt,

            model=model_id,

            reference_image=None if ordered_references else image_bytes,

            aspect_ratio=aspect_ratio,

            output_path=str(output_path),

            upscale=upscale,

            n=n,

            defer_download=True,
            document_context={"name":document_name,"path":document_path,"id":document_id,"session":document_session} if (isinstance(document_path,str) and document_path) or (isinstance(document_id,str) and document_id) else None,
            reuse_reference=False if ordered_references else (str(reuse_reference).lower() in ("1", "true", "yes") if reuse_reference is not None else False),
            project_id=project_id if isinstance(project_id,str) and project_id else None,
            references=ordered_references,

        )

    except FlowPreSubmissionError as exc:
        return JSONResponse(status_code=409, content={
            "error": {"code": "generation_not_submitted", "message": str(exc)},
            "submissionSent": False,
            "projectId": getattr(generator, 'last_project_id', None),
        })
    except Exception as exc:

        import traceback; traceback.print_exc()

        await report_generation_error(exc)

        raise HTTPException(status_code=500, detail=str(exc)) from exc



    response = await build_batch_response(request, saved_path, output_path, response_format or "url", getattr(generator, 'last_native_timings', None))
    if isinstance(response, dict):
        response['projectId'] = getattr(generator, 'last_project_id', None)
    return response





@app.post("/setup/verify-composer", dependencies=[Depends(verify_api_key)])

async def verify_composer(

    image: UploadFile = File(...), prompt: str = Form(...),

    model: str = Form(default=DEFAULT_MODEL), aspect_ratio: str = Form(default="1:1"), n: int = Form(default=1),
    inspect_only: bool = Form(default=False), settings_only: bool = Form(default=False), project_id: Optional[str] = Form(default=None), reuse_reference: bool = Form(default=False),

):

    """Verify settings and reference attachment without pressing Generate."""
    project_id = project_id if isinstance(project_id,str) and project_id else None

    if n not in (1, 2, 3, 4):
        raise HTTPException(status_code=400, detail="Unsupported generation count")
    config = get_config()

    if not project_id and not config.token.project_id:

        raise HTTPException(status_code=400, detail="项目尚未初始化；预检不会自动创建项目。")

    generator = ImageGenerator()

    generator._require_context()

    from .models import get_model_config

    settings = get_model_config(resolve_model(model, None, aspect_ratio))

    page = await generator.current._ensure_page(

        "https://flow.google.com/project/" + (project_id or config.token.project_id), wait_editor=True

    )

    temporary = None

    try:
        if inspect_only is True:
            snapshot = []
            for round_index in range(3):
                state = await page.evaluate("""() => {
                    const trigger = Array.from(document.querySelectorAll('button')).find(n =>
                        n.offsetParent !== null && /设置触发器|settings trigger/i.test([
                            n.getAttribute('aria-label'),n.getAttribute('title'),n.innerText].join(' ')));
                    const countNodes = Array.from(document.querySelectorAll('button,[role=tab],[role=radio],[role=option],[role=menuitem],[role=menuitemradio]'))
                        .filter(n => n.offsetParent !== null);
                    return {expanded: trigger ? trigger.getAttribute('aria-expanded') : null,
                        overlayCount: document.querySelectorAll('.cdk-overlay-container *').length,
                        visibleButtons: countNodes.length};
                }""")
                snapshot.append({"round": round_index, "state": state})
                if state["overlayCount"] > 0 or state["visibleButtons"] > 2:
                    break
                await page.evaluate("""() => {
                    const n = Array.from(document.querySelectorAll('button')).find(n =>
                        n.offsetParent !== null && /设置触发器|settings trigger/i.test([
                            n.getAttribute('aria-label'),n.getAttribute('title'),n.innerText].join(' ')));
                    if (n) n.click();
                }""")
                await asyncio.sleep(0.5)
            controls = await page.evaluate("""() => [...document.querySelectorAll('button,[role=tab],[role=radio],[role=option],[role=menuitem],[role=menuitemradio],mat-slider,flow-slider')].map(n=>({role:n.getAttribute('role'),tag:n.tagName,label:n.getAttribute('aria-label'),haspopup:n.getAttribute('aria-haspopup'),expanded:n.getAttribute('aria-expanded'),visible:!!n.getClientRects().length,text:(n.innerText||n.textContent||'').replace(/\\s+/g,' ').trim().slice(0,80)})).filter(n=>n.visible).slice(0,80)""")
            return {"submissionSent":False,"snapshot":snapshot,"controls":controls}

        await generator.current._select_generation_settings(page, settings["model_name"], aspect_ratio, n)
        if settings_only is True:
            return {"prepared":True,"count":n,"submissionSent":False,"referenceUploaded":False}

        await page.locator(".ProseMirror:visible").last.fill(prompt)

        temporary = await generator.current._attach_reference_image(page, await image.read(), reuse_reference=reuse_reference is True)

        DEBUG_ROOT.mkdir(parents=True, exist_ok=True)

        await page.screenshot(path=str(DEBUG_ROOT / "last-preflight.png"))

        return {"prepared": True, "referenceAttached": True, "submissionSent": False, "referenceTransfer": await page.evaluate("window.__psfbReferenceTransfer || null")}

    except Exception as exc:

        diagnostics = await page.evaluate("""() => {

            const editor = document.querySelector('.ProseMirror');

            const describe = n => ({tag:n.tagName, cls:String(n.className||''),

                text:(n.innerText||n.getAttribute('aria-label')||'').slice(0,80)});

            return {settingsControls:Array.from(document.querySelectorAll('button,[role=tab],[role=radio],[role=option],[role=menuitem]')).filter(n=>n.offsetParent!==null).map(n=>({tag:n.tagName,role:n.getAttribute('role'),label:n.getAttribute('aria-label'),text:(n.innerText||'').slice(0,120),html:n.outerHTML.slice(0,900)})).filter(n=>/settings|设置|^[x×]?[1-4]|数量|output/i.test((n.label||'')+' '+n.text)).slice(0,25),editorChildren:editor?Array.from(editor.children).map(describe):[],

                chips:Array.from(document.querySelectorAll('[class*=chip]')).slice(0,15).map(describe),

                nearImages:editor?Array.from(editor.parentElement.querySelectorAll('img')).map(describe):[],

                ancestors:editor?Array.from((function*(node){for(let i=0;node&&i<5;i++,node=node.parentElement)yield node})(editor)).map(describe):[],

                options:Array.from(document.querySelectorAll('[role=option]')).filter(n=>n.offsetParent!==null).slice(0,8).map(describe)};

        }""")

        DEBUG_ROOT.mkdir(parents=True, exist_ok=True)

        await page.screenshot(path=str(DEBUG_ROOT / "last-preflight.png"))

        return JSONResponse(status_code=400, content={"error":{"message":str(exc)}, "diagnostics":diagnostics})

    finally:

        if temporary:

            Path(temporary).unlink(missing_ok=True)





@app.post("/v1/chat/completions", dependencies=[Depends(verify_api_key)])

async def chat_completions(request: Request, payload: ChatCompletionRequest):

    if payload.stream:

        raise HTTPException(status_code=400, detail="stream=true is not supported")

    if payload.n not in (None, 1):

        raise HTTPException(status_code=400, detail="Only n=1 is supported")



    payload_dict = payload.model_dump()

    save_debug_payload("latest_chat_request.json", payload_dict)



    prompt = extract_prompt(payload.messages)

    inferred_size = extract_preferred_value(prompt, "preferred size")

    inferred_aspect_ratio = extract_preferred_value(prompt, "preferred aspect ratio")

    prompt = strip_preference_lines(prompt)

    reference_image = extract_reference_image(payload.messages)

    size = payload.size or inferred_size

    aspect_ratio = payload.aspect_ratio or inferred_aspect_ratio

    model_id = resolve_model(payload.model, size, aspect_ratio)

    upscale = resolve_upscale(size, payload.quality)

    output_path = build_output_path("chat")



    generator = ImageGenerator()

    try:

        saved_path = await generator.generate(

            prompt=prompt,

            model=model_id,

            reference_image=reference_image,

            aspect_ratio=aspect_ratio,

            output_path=str(output_path),

            upscale=upscale,

        )

    except FlowPreSubmissionError as exc:
        return JSONResponse(status_code=409, content={
            "error": {"code": "generation_not_submitted", "message": str(exc)},
            "submissionSent": False,
        })
    except Exception as exc:

        import traceback; traceback.print_exc()

        await report_generation_error(exc)

        raise HTTPException(status_code=500, detail=str(exc)) from exc



    path = Path(saved_path)

    response_format = (payload.response_format or "url").lower()

    return build_chat_response(request, model_id, path, response_format)





_file_download_slots = asyncio.Semaphore(2)
_file_download_locks = {}


@asynccontextmanager
async def result_download_lock(filename):
    # Count holders and waiters, including cancelled waiters. Remove only when
    # nobody references the lock, so concurrent requests cannot create two locks.
    entry = _file_download_locks.setdefault(filename, {'lock': asyncio.Lock(), 'users': 0})
    entry['users'] += 1
    try:
        async with entry['lock']:
            yield
    finally:
        entry['users'] -= 1
        if not entry['users']:
            _file_download_locks.pop(filename, None)





async def build_batch_response(request, generated, output_path, response_format, timings=None):

    values = generated if isinstance(generated, list) else [generated]

    # Existing local-path generators remain compatible with the single-image API.

    if values and all(isinstance(value, str) and not value.startswith("https://") for value in values):

        return {"created": int(time.time()), "data": [

            build_image_item(request, Path(value), response_format.lower()) for value in values]}

    if not values or not all(isinstance(value, str) and value.startswith("https://") for value in values):

        raise HTTPException(status_code=500, detail="Generation result URLs could not be confirmed")

    paths = [output_path.with_name(f"{output_path.stem}-{index}.png") for index in range(len(values))]

    manifest = output_path.with_suffix(".batch.json")

    manifest.parent.mkdir(parents=True, exist_ok=True)

    temporary = manifest.with_suffix(".part")

    temporary.write_text(json.dumps({"urls": values, "jobId": PROGRESS_TASK.get()}), encoding="utf-8")

    temporary.replace(manifest)

    # Returning local URLs lets download failures be retried without native generation.

    if response_format.lower() == "b64_json":

        await asyncio.gather(*(ensure_generated_file(path.name) for path in paths))

    return {"created": int(time.time()), "timings": timings if isinstance(timings, dict) else {}, "data": [

        build_image_item(request, path, response_format.lower()) for path in paths]}





_download_measurements = {}
_DOWNLOAD_MEASUREMENT_TTL_SECONDS = 120


def update_download_progress(task_id, filename, loaded, total, count, complete=False):
    if not task_id:
        return
    now = time.monotonic()
    for old_task, records in list(_download_measurements.items()):
        last_seen = max((record.get('sampled', 0) for record in records.values()), default=0)
        if now - last_seen > _DOWNLOAD_MEASUREMENT_TTL_SECONDS:
            _download_measurements.pop(old_task, None)
    if len(_download_measurements) >= 128:
        completed_tasks = sorted(
            (
                max((record.get('sampled', 0) for record in records.values()), default=0),
                old_task,
            )
            for old_task, records in _download_measurements.items()
            if records and all(record.get('complete') for record in records.values())
        )
        while len(_download_measurements) >= 128 and completed_tasks:
            _, old_task = completed_tasks.pop(0)
            _download_measurements.pop(old_task, None)
    items = _download_measurements.setdefault(task_id, {})
    items[filename] = {'loaded':loaded,'total':total,'complete':complete,'sampled':now}
    total_known = len(items) == count and all(value['total'] is not None for value in items.values())
    size = sum(value['total'] for value in items.values()) if total_known else None
    transferred = sum(value['loaded'] for value in items.values())
    done = sum(bool(value['complete']) for value in items.values())
    set_transfer_progress(task_id, {'phase':'download','loaded':transferred,'total':size,
        'percent':min(100 if done == count else 99, int(100*transferred/size)) if size else None,
        'completed':done,'totalItems':count,'source':'flow-download'})


async def ensure_generated_file(filename: str, task_id: str = "") -> Path:

    if not re.fullmatch(r"[a-zA-Z0-9_.-]+", filename):

        raise HTTPException(status_code=404, detail="File not found")

    path = OUTPUT_ROOT / filename

    if path.exists() and not task_id:

        return path

    match = re.fullmatch(r"(.+)-(\d+)\.png", filename)

    manifest = OUTPUT_ROOT / (match[1] + ".batch.json") if match else None

    if manifest is None or not manifest.exists():

        if path.exists():
            return path
        raise HTTPException(status_code=404, detail="File not found")

    record = json.loads(manifest.read_text(encoding="utf-8"))
    urls = record['urls']
    task_id = task_id or record.get('jobId','')
    if task_id and not re.fullmatch(r'[0-9a-f-]{36}',task_id):
        task_id = ''
    if path.exists():
        size=path.stat().st_size
        update_download_progress(task_id,filename,size,size,len(urls),True)
        return path

    index = int(match[2])

    if index >= len(urls):

        raise HTTPException(status_code=404, detail="File not found")

    for cached_index in range(len(urls)):
        cached = OUTPUT_ROOT / f'{match[1]}-{cached_index}.png'
        if cached.exists():
            size = cached.stat().st_size
            update_download_progress(task_id,cached.name,size,size,len(urls),True)
    async with result_download_lock(filename), _file_download_slots:

        if not path.exists():

            # Unique staging names make simultaneous requests safe; never expose partial files.

            temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".part")

            try:

                update_download_progress(task_id, filename, 0, None, len(urls))
                on_progress = lambda loaded,total: update_download_progress(task_id,filename,loaded,total,len(urls))
                await ImageGenerator()._download_and_save(urls[index], str(temporary), on_progress=on_progress)
                size = temporary.stat().st_size
                temporary.replace(path)
                update_download_progress(task_id,filename,size,size,len(urls),True)

            except asyncio.CancelledError:

                temporary.unlink(missing_ok=True)

                raise

            except Exception as exc:

                temporary.unlink(missing_ok=True)

                raise HTTPException(status_code=502, detail="Result download failed; retry this file URL") from exc

    size = path.stat().st_size
    update_download_progress(task_id,filename,size,size,len(urls),True)
    return path





@app.get("/v1/files/{filename}")

async def get_generated_file(filename: str, request: Request):

    return FileResponse(await ensure_generated_file(filename, request.headers.get("x-psfb-job-id", "")))





@app.exception_handler(HTTPException)

async def http_exception_handler(_: Request, exc: HTTPException):

    return JSONResponse(status_code=exc.status_code, content={"error": {"message": exc.detail}})





def main():

    parser = argparse.ArgumentParser(description="Run OpenAI-compatible API wrapper for Flow Image CLI")

    parser.add_argument("--host", default="127.0.0.1")

    parser.add_argument("--port", type=int, default=8787)

    args = parser.parse_args()



    import uvicorn


    # Bounded rolling logs for this service only. No-op when PSFB_LOG_DIR is
    # unset, so module import and the test suite are unaffected. install_service_logging
    # itself never raises; a missing module is a hard import error, not a silent skip.
    install_service_logging()



    uvicorn.run("flow_cli.api_server:app", host=args.host, port=args.port, reload=False)





if __name__ == "__main__":

    main()

