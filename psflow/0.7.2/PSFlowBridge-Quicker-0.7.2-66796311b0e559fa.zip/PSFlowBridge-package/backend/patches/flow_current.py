"""新版 flow.google.com 生成链路（浏览器页内 RPC 驱动）。

旧版 labs.google 的 ST/AT 认证已失效。新版 Flow 用 Google 会话 Cookie
（OSID/SID 族）鉴权，业务 RPC 走页面同源的 batchexecute。这里复用
api_server 里已经登录好的 Playwright 持久 context，在同一个页面的
JS 环境里发 fetch，凭据由浏览器自带，后端不接触 Cookie 明文。
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import random
import re
import os
import tempfile
import time
import unicodedata
import uuid
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote, urlsplit
from pathlib import Path


FLOW_ORIGIN = "https://flow.google.com"
_PROJECT_WORKER_PAGES: Dict[Tuple[int, str], Any] = {}
_CONTEXT_LOCKS: Dict[int, asyncio.Lock] = {}
_PAGE_REFERENCE_FINGERPRINT: Dict[int, str] = {}
_PAGE_REFERENCE_FILENAME: Dict[int, str] = {}
_PAGE_REFERENCE_SIGNATURE: Dict[int, str] = {}
_PAGE_REFERENCE_SEQUENCES: Dict[int, Dict[str, Any]] = {}
_REFERENCE_ASSETS: Dict[str, str] = {}
_REFERENCE_ASSET_SIGNATURES: Dict[str, str] = {}


def get_context_lock(context: Any) -> asyncio.Lock:
    lock = getattr(context, '_psfb_native_lock', None)
    if not isinstance(lock, asyncio.Lock):
        lock = asyncio.Lock()
        setattr(context, '_psfb_native_lock', lock)
    return lock


def reference_asset_key(page, fingerprint):
    location = urlsplit(getattr(page, 'url', '') or '')
    match = re.search(r'^/project/([^/]+)', location.path)
    return (match.group(1) if location.hostname == 'flow.google.com' and match else '') + ':' + fingerprint


def reference_asset_name(key):
    if key in _REFERENCE_ASSETS:
        return _REFERENCE_ASSETS[key]
    config = os.environ.get('FLOW_CONFIG')
    if config:
        try:
            value=json.loads((Path(config).parent/'reference-assets.json').read_text(encoding='utf-8'))
            if isinstance(value,dict):
                entry=value.get(key)
                if isinstance(entry,str):return entry
                if isinstance(entry,dict) and isinstance(entry.get('name'),str):return entry['name']
        except (OSError,ValueError):
            pass
    return None


def _normalize_editor_text(value: str) -> str:
    """Normalize browser/Python line endings and invisible editor characters."""
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = re.sub(r"[\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff]", "", text)
    return re.sub(r"\s+", " ", text).strip()


def reference_asset_signature(key):
    if key in _REFERENCE_ASSET_SIGNATURES:return _REFERENCE_ASSET_SIGNATURES[key]
    config=os.environ.get('FLOW_CONFIG')
    if config:
        try:
            entry=json.loads((Path(config).parent/'reference-assets.json').read_text(encoding='utf-8')).get(key)
            if isinstance(entry,dict) and isinstance(entry.get('signature'),str):return entry['signature']
        except (OSError,ValueError,AttributeError):pass
    return None


def record_reference_asset(key, name, signature=None):
    _REFERENCE_ASSETS[key]=name
    if signature:_REFERENCE_ASSET_SIGNATURES[key]=signature
    config=os.environ.get('FLOW_CONFIG')
    if not config:
        return
    file=Path(config).parent/'reference-assets.json'
    temporary=file.with_name(file.name+'.'+uuid.uuid4().hex+'.tmp')
    try:
        try:value=json.loads(file.read_text(encoding='utf-8')) if file.exists() else {}
        except (OSError,ValueError):return
        if not isinstance(value,dict):return
        value[key]={'name':name,'signature':signature,'version':1} if signature else name
        file.parent.mkdir(parents=True,exist_ok=True)
        temporary.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
        os.replace(temporary,file)
    except OSError:
        pass  # Cache persistence must never mask the actual upload result.
    finally:
        temporary.unlink(missing_ok=True)


def clear_project_pages() -> None:
    _PROJECT_WORKER_PAGES.clear()
    _CONTEXT_LOCKS.clear()
    _PAGE_REFERENCE_FINGERPRINT.clear()
    _PAGE_REFERENCE_FILENAME.clear()
    _PAGE_REFERENCE_SIGNATURE.clear()
    _PAGE_REFERENCE_SEQUENCES.clear()
    _REFERENCE_ASSETS.clear()
    _REFERENCE_ASSET_SIGNATURES.clear()

PROGRESS_TASK = ContextVar("psfb_progress_task", default="")
WEB_PROGRESS = {}


def read_web_progress(task_id):
    value = WEB_PROGRESS.get(task_id)
    if not value or time.monotonic() - value["sampled"] > 5:
        return {"source": "flow-dom", "percent": None, "items": [], "updatedAt": None}
    return {key: item for key, item in value.items() if key != "sampled"}


WEB_PROGRESS_START = """() => {
    window.__psfbProgress = {baseline:new WeakSet(document.querySelectorAll('.loading_percentage, .loading-percentage, [class*="loading_percentage"], [class*="loading-percentage"]')), slots:new Map()};
}"""
WEB_PROGRESS_READ = """(count) => {
    const state = window.__psfbProgress;
    if (!state) return {percent:null,items:[]};
    const nodes = Array.from(document.querySelectorAll('.loading_percentage, .loading-percentage, [class*="loading_percentage"], [class*="loading-percentage"]')).filter(n =>
        !state.baseline.has(n) && n.getClientRects().length && n.offsetParent !== null);
    const items = [];
    for (const node of nodes) {
        const match = (node.textContent || '').trim().match(/^(\\d{1,3})\\s*%$/);
        if (!match || Number(match[1]) > 100) continue;
        if (!state.slots.has(node)) state.slots.set(node,state.slots.size + 1);
        items.push({slot:state.slots.get(node),percent:Number(match[1])});
    }
    // Old cards, incomplete sets and unrelated concurrent cards are not evidence
    // for this batch. A removed card must not be silently promoted to 100%.
    if (items.length !== count || state.slots.size !== count) return {percent:null,items:[]};
    return {percent:Math.round(items.reduce((sum,item)=>sum+item.percent,0)/count),items};
}"""


async def sample_web_progress(page, count):
    task_id = PROGRESS_TASK.get()
    if not task_id:
        return
    try:
        value = await asyncio.wait_for(page.evaluate(WEB_PROGRESS_READ, count), timeout=1)
        value = {"source": "flow-dom", "percent": value.get("percent"), "items": value.get("items", []),
                 "updatedAt": datetime.now(timezone.utc).isoformat(), "sampled": time.monotonic()}
    except Exception:
        value = {"source": "flow-dom", "percent": None, "items": [], "updatedAt": None, "sampled": time.monotonic()}
    if len(WEB_PROGRESS) > 128:
        WEB_PROGRESS.clear()
    WEB_PROGRESS[task_id] = value

TRANSFER_PROGRESS = {}
REFERENCE_ATTACH_TIMEOUT_SECONDS = 45


def read_transfer_progress(task_id):
    value = TRANSFER_PROGRESS.get(task_id)
    if not value:
        return None
    if time.monotonic() - value['sampled'] > 8:
        TRANSFER_PROGRESS.pop(task_id, None)
        measurements = globals().get('_download_measurements')
        if isinstance(measurements, dict):
            measurements.pop(task_id, None)
        return None
    return {key: item for key, item in value.items() if key != 'sampled'}


def set_transfer_progress(task_id, value):
    if not task_id:
        return
    if len(TRANSFER_PROGRESS) > 128:
        TRANSFER_PROGRESS.clear()
    if value is None:
        TRANSFER_PROGRESS.pop(task_id, None)
    else:
        TRANSFER_PROGRESS[task_id] = {**value, 'sampled': time.monotonic()}


UPLOAD_OBSERVER_START = r"""({size,mime}) => {
    window.__psfbUpload = {active:true,requests:0,loaded:0,total:null,percent:null,pending:0,failed:false,source:'flow-upload',expectedSize:size,expectedMime:mime};
    if (window.__psfbUploadHooks) return;
    window.__psfbUploadHooks = true;
    const matches = value => value instanceof Blob && value.size===window.__psfbUpload.expectedSize &&
        (!value.type || value.type.startsWith('image/'));
    const binary = body => matches(body) ||
        ((body instanceof ArrayBuffer || ArrayBuffer.isView(body)) && body.byteLength===window.__psfbUpload.expectedSize) ||
        (body instanceof FormData && [...body.values()].some(matches));
    const flowUpload = value => {
        try {
            const host=new URL(value,location.href).hostname.toLowerCase();
            return host==='flow.google.com'||host.endsWith('.google.com')||host==='googleapis.com'||
                host.endsWith('.googleapis.com')||host.endsWith('.googleusercontent.com');
        } catch (_) { return false; }
    };
    const begin = (body,url) => {
        const state=window.__psfbUpload;
        if (!state || !state.active || !flowUpload(url) || !binary(body)) return null;
        state.requests++;state.pending++;return state;
    };
    const open=XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open=function(method,url){
        this.__psfbUploadUrl=String(url||'');
        return open.apply(this,arguments);
    };
    const send=XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send=function(body){
        const state=begin(body,this.__psfbUploadUrl);
        if(state){
            state.source='flow-xhr';
            this.upload.addEventListener('progress',event=>{
                if(window.__psfbUpload!==state)return;
                state.loaded=event.loaded;state.total=event.lengthComputable?event.total:null;
                state.percent=state.total?Math.min(99,Math.floor(100*state.loaded/state.total)):null;
            });
            this.addEventListener('loadend',()=>{
                if(window.__psfbUpload!==state)return;
                state.pending=Math.max(0,state.pending-1);
                if(this.status<200||this.status>=300)state.failed=true;
            });
        }
        return send.call(this,body);
    };
    const fetch=window.fetch;
    window.fetch=async function(input,init){
        const url=typeof input==='string'?input:(input&&input.url)||'';
        const state=begin(init&&init.body,url);
        try{
            const response=await fetch.apply(this,arguments);
            if(state&&window.__psfbUpload===state){state.pending=Math.max(0,state.pending-1);if(!response.ok)state.failed=true;}
            return response;
        }catch(error){if(state&&window.__psfbUpload===state){state.pending=Math.max(0,state.pending-1);state.failed=true;}throw error;}
    };
}"""

REFERENCE_LIBRARY_STATE = r"""nodes => nodes.map((n,index) => {
    const id=n.getAttribute('data-media-id')||n.getAttribute('data-asset-id');
    const urls=[...n.querySelectorAll('img')].map(i=>i.src).filter(Boolean);
    const images=urls.map(value=>{try{const u=new URL(value,location.href);return u.origin+u.pathname.replace(/=[^/]*$/,'');}catch(_){return value;}});
    const identities=[...(id?['asset:'+id]:[]),...(images.length?['images:'+images.join('|')]:[])];
    return {index,signature:identities[0]||'',identities,urls};
})"""


async def choose_reference_asset(page, resource, image_bytes, expected_signature=None):
    rows=await resource.evaluate_all(REFERENCE_LIBRARY_STATE)
    if expected_signature:
        for row in rows:
            if expected_signature in row.get('identities',[]):return row
    # Legacy name-only records can have duplicates. Read the original pixels
    # from Google's asset image; never select an ambiguous row by its name.
    import io
    from PIL import Image, JpegImagePlugin
    try:
        with Image.open(io.BytesIO(image_bytes)) as image:
            expected_size=image.size;expected_pixels=image.convert('RGBA').tobytes()
    except Exception as exc:
        raise FlowPreSubmissionError('参考图像素无法校验，未上传、未提交生成') from exc
    async def matches(row):
        for url in row.get('urls',[])[:2]:
            parts=urlsplit(url);host=(parts.hostname or '').lower()
            flow_proxy=host=='flow.google.com' and parts.path.startswith('/asb/')
            if parts.scheme!='https' or not (flow_proxy or host.endswith('.googleusercontent.com') or host=='storage.googleapis.com'):continue
            original=parts.scheme+'://'+parts.netloc+re.sub(r'=[^/]*$','',parts.path)+'=s0' if flow_proxy or host.endswith('.googleusercontent.com') else url
            try:
                result=await page.evaluate(r"""async url => {
                    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
                    try {
                        const response=await fetch(url,{credentials:'same-origin',signal:controller.signal});
                        if(!response.ok||!/^image\//i.test(response.headers.get('content-type')||''))return null;
                        if(Number(response.headers.get('content-length'))>33554432)return null;
                        const bytes=new Uint8Array(await response.arrayBuffer());if(bytes.length>33554432)return null;
                        let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
                        return btoa(binary);
                    }catch(_){return null;}finally{clearTimeout(timer);}
                }""",original)
                if not result:continue
                body=base64.b64decode(result,validate=True)
                if len(body)>32*1024*1024:continue
                with Image.open(io.BytesIO(body)) as decoded:
                    if decoded.size!=expected_size:continue
                    pixels=decoded.convert('RGBA').tobytes()
                    verified=pixels==expected_pixels
                    # Flow /asb returns JPEG even for PNG uploads. Normalize the
                    # expected frame using its actual quantization/sampling;
                    # permit only tiny encoder rounding, not arbitrary resizing
                    # or a perceptual match. Conflicting candidate pixels below
                    # still reject the selection.
                    if not verified and decoded.format=='JPEG' and decoded.quantization:
                        expected=Image.frombytes('RGBA',expected_size,expected_pixels)
                        if expected.getchannel('A').getextrema()!=(255,255):continue
                        encoded=io.BytesIO();expected.convert('RGB').save(encoded,format='JPEG',qtables=decoded.quantization,subsampling=JpegImagePlugin.get_sampling(decoded))
                        with Image.open(io.BytesIO(encoded.getvalue())) as canonical:
                            a=canonical.convert('RGB').tobytes();b=decoded.convert('RGB').tobytes()
                            differences=[abs(x-y) for x,y in zip(a,b)]
                            verified=max(differences,default=0)<=6 and sum(differences)/max(1,len(differences))<=0.35
                    if verified:return {**row,'pixelDigest':hashlib.sha256(pixels).hexdigest()}
            except Exception:continue
        return None
    candidates=[r for r in rows if r.get('signature')][:8]
    matches_found=[]
    for offset in range(0,len(candidates),4):
        verified=await asyncio.gather(*(matches(row) for row in candidates[offset:offset+4]))
        matches_found.extend(row for row in verified if row)
    if matches_found and len({row['pixelDigest'] for row in matches_found})==1:return matches_found[0]
    raise FlowPreSubmissionError('同名复用素材无法通过身份或像素校验，未上传、未提交生成')


REFERENCE_CHIP_STATE = r"""() => {
    const editors=[...document.querySelectorAll('.ProseMirror')].filter(n=>n.getClientRects().length&&n.offsetParent!==null);
    const editor=editors.find(n=>n===document.activeElement)||editors[editors.length-1];
    const composer=editor&&(editor.closest('flow-base-prompt-box,flow-prompt-box')||editor.closest('.base-prompt-box'));
    if(!composer)return {signature:'',identities:[],chips:[],count:0,ready:false};
    const iconText=node=>String((node.querySelector('.hover-icon-overlay mat-icon,.hover-icon-overlay .material-symbols-outlined')||{}).textContent||'').trim();
    const visible=node=>node.getClientRects().length>0&&node.offsetParent!==null;
    // Flow wraps every chip in one or more ingredient elements. Counting both the
    // wrapper and its inner button double-counts the same reference, so a button
    // is the unit whenever it exists and a wrapper only stands in for a chip that
    // renders without one. That keeps the count exact in mixed markup too.
    const standalone=w=>!w.querySelector('button.chip-container')&&!w.parentElement?.closest('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip');
    // One DOM-ordered pass: the sequence is the reference order Flow shows, and
    // the reuse comparison depends on that order.
    const nodes=[...composer.querySelectorAll('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip')]
        .filter(n=>visible(n)&&(n.matches('button.chip-container')||standalone(n)))
        .filter(n=>iconText(n)==='cancel');
    const imageIdentity=value=>{
        if(!value)return '';
        try{
            const u=new URL(value,location.href);
            if(u.protocol==='http:'||u.protocol==='https:')return u.origin+u.pathname.replace(/=[^/]*$/,'');
            if(u.protocol==='blob:')return u.href;
        }catch(_){}
        return '';
    };
    const readyOf=n=>{
        const owner=n.closest('flow-ingredient-chip,flow-image-ingredient-chip')||n;
        return [n,owner].every(node=>node.getAttribute('aria-busy')!=='true'&&
            !node.querySelector('[aria-busy=true],mat-progress-spinner,[role=progressbar]')&&
            !/uploading|loading/i.test(String(node.className||'')));
    };
    const identities=[];
    const chips=nodes.map(n=>{
        const owner=n.closest('flow-image-ingredient-chip,flow-ingredient-chip')||n;
        const id=owner.getAttribute('data-media-id')||owner.getAttribute('data-asset-id')||n.getAttribute('data-media-id')||n.getAttribute('data-asset-id');
        const images=[...n.querySelectorAll('img')].map(i=>imageIdentity(i.getAttribute('src'))).filter(Boolean);
        const own=[...(id?['asset:'+id]:[]),...(images.length?['images:'+images.join('|')]:[])];
        identities.push(...own);
        const signature=id?'asset:'+id:(images.length?'images:'+images.join('|'):'');
        return {signature,identities:own,ready:readyOf(n)};
    });
    const signature=chips.map(chip=>chip.signature).filter(Boolean).join(';;');
    return {signature,identities,chips,count:chips.length,ready:chips.length>0&&chips.every(chip=>chip.ready)};
}"""

REMOVE_CURRENT_REFERENCE = r"""() => {
    const editors=[...document.querySelectorAll('.ProseMirror')].filter(n=>n.getClientRects().length&&n.offsetParent!==null);
    const editor=editors.find(n=>n===document.activeElement)||editors[editors.length-1];
    const composer=editor&&(editor.closest('flow-base-prompt-box,flow-prompt-box')||editor.closest('.base-prompt-box'));
    if(!composer)return;
    const iconText=node=>String((node.querySelector('.hover-icon-overlay mat-icon,.hover-icon-overlay .material-symbols-outlined')||{}).textContent||'').trim();
    const visible=node=>node.getClientRects().length>0&&node.offsetParent!==null;
    const standalone=w=>!w.querySelector('button.chip-container')&&!w.parentElement?.closest('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip');
    [...composer.querySelectorAll('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip')]
    .filter(n=>visible(n)&&(n.matches('button.chip-container')||standalone(n))&&iconText(n)==='cancel')
    .forEach(chip=>{
        const overlay=chip.querySelector('.hover-icon-overlay');
        if(overlay)overlay.click();
    });
}"""

# Text-to-image has no reference at all. The composer must be emptied of any
# chip left over from a previous turn, otherwise Flow would silently turn the
# text request into an edit of that stale image. Only the real reference chip is
# clicked: the "add media" chip lives in the same button.chip-container list and
# is identified by its own overlay icon, so it must never be treated as a chip
# to remove (clicking it opens the media picker).
CLEAR_REFERENCE_CHIPS = r"""() => {
    const editors=[...document.querySelectorAll('.ProseMirror')].filter(n=>n.getClientRects().length&&n.offsetParent!==null);
    const editor=editors.find(n=>n===document.activeElement)||editors[editors.length-1];
    const composer=editor&&(editor.closest('flow-base-prompt-box,flow-prompt-box')||editor.closest('.base-prompt-box'));
    if(!composer)return {clicked:0};
    const iconText=node=>String((node.querySelector('.hover-icon-overlay mat-icon,.hover-icon-overlay .material-symbols-outlined')||{}).textContent||'').trim();
    const visible=node=>node.getClientRects().length>0&&node.offsetParent!==null;
    const standalone=w=>!w.querySelector('button.chip-container')&&!w.parentElement?.closest('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip');
    const chips=[...composer.querySelectorAll('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip')]
        .filter(n=>visible(n)&&(n.matches('button.chip-container')||standalone(n)));
    let clicked=0;
    chips.forEach(chip=>{
        if(iconText(chip)!=='cancel')return; // never click the add-media chip
        const overlay=chip.querySelector('.hover-icon-overlay');
        if(!overlay)return;
        overlay.click();
        clicked+=1;
    });
    return {clicked};
}"""

PASTE_REFERENCE_IMAGES = r"""(files) => {
    const editors=[...document.querySelectorAll('.ProseMirror')].filter(n=>n.getClientRects().length&&n.offsetParent!==null);
    const editor=editors.find(n=>n===document.activeElement)||editors[editors.length-1];
    if(!editor)return {target:false,accepted:false,count:0};
    const transfer=new DataTransfer();
    for (const f of files) {
        const bytes=Uint8Array.from(atob(f.data),c=>c.charCodeAt(0));
        transfer.items.add(new File([bytes],f.name,{type:f.mime}));
    }
    editor.focus();
    const event=new ClipboardEvent('paste',{clipboardData:transfer,bubbles:true,cancelable:true,composed:true});
    editor.dispatchEvent(event);
    return {target:true,prevented:event.defaultPrevented,trusted:event.isTrusted,count:files.length};
}"""

PASTE_REFERENCE_IMAGE = r"""({data,mime,name}) => {
    const editors=[...document.querySelectorAll('.ProseMirror')].filter(n=>n.getClientRects().length&&n.offsetParent!==null);
    const editor=editors.find(n=>n===document.activeElement)||editors[editors.length-1];
    if(!editor)return {target:false,accepted:false};
    const bytes=Uint8Array.from(atob(data),c=>c.charCodeAt(0));
    const transfer=new DataTransfer();transfer.items.add(new File([bytes],name,{type:mime}));
    editor.focus();
    const event=new ClipboardEvent('paste',{clipboardData:transfer,bubbles:true,cancelable:true,composed:true});
    editor.dispatchEvent(event);
    return {target:true,prevented:event.defaultPrevented,trusted:event.isTrusted};
}"""

async def sample_upload_progress(page):
    state = await page.evaluate('window.__psfbUpload || {}')
    set_transfer_progress(PROGRESS_TASK.get(), {
        'phase':'upload','loaded':state.get('loaded',0),'total':state.get('total'),
        'percent':state.get('percent'),'completed':0,'totalItems':1,
        'source':state.get('source','flow-upload'),
    })
    return state

BATCHEXECUTE_PATH = "/_/AiSandboxAngularFrontend/data/batchexecute"
RECAPTCHA_SITE_KEY = "6LdsFiUsAAAAAIjVDZcuLhaHiDn5nnHVXVRQGeMV"

ASPECT_RATIO_CODES = {
    "IMAGE_ASPECT_RATIO_SQUARE": 1,
    "IMAGE_ASPECT_RATIO_PORTRAIT": 2,
    "IMAGE_ASPECT_RATIO_16_9": 3,
    "IMAGE_ASPECT_RATIO_LANDSCAPE": 3,
    "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE": 4,
    "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR": 5,
}

UUID_RE = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.IGNORECASE
)


# 在页面脚本执行前挂钩：新版 Flow 会把 enterprise.execute 换成
# extension_hijack_detected 包装，这里把原始闭包先存下来。
RECAPTCHA_INIT_SCRIPT = """
(() => {
  if (window.__psfbHookInstalled) return;
  Object.defineProperty(window, '__psfbHookInstalled', { value: true });
  const key = '__psfbTrustedExecute';
  const originalBind = Function.prototype.bind;
  Function.prototype.bind = function (thisArg, ...args) {
    const bound = originalBind.call(this, thisArg, ...args);
    try {
      const ent = window.grecaptcha && window.grecaptcha.enterprise;
      if (!window[key] && ent && this === ent.execute && typeof bound === 'function') {
        window[key] = bound;
      }
    } catch (e) {}
    return bound;
  };
  const originalAssign = Object.assign;
  Object.assign = function (target, ...sources) {
    let next = sources;
    if (sources.length >= 2) {
      const prev = sources[sources.length - 2];
      const last = sources[sources.length - 1];
      if (prev && typeof prev.action === 'string' && prev.action && last &&
          last.action === 'extension_hijack_detected') {
        next = sources.slice(0, -1);
      }
    }
    return originalAssign.call(this, target, ...next);
  };
})();
"""

RECAPTCHA_SCRIPT = """
async (cfg) => {
  for (let i = 0; i < 60; i += 1) {
    if (window.__psfbTrustedExecute) break;
    await new Promise((r) => setTimeout(r, 250));
  }
  let execute = window.__psfbTrustedExecute;
  if (typeof execute !== 'function') {
    const ent = window.grecaptcha && window.grecaptcha.enterprise;
    execute = ent && ent.execute;
  }
  if (typeof execute !== 'function') {
    return { ok: false, error: 'recaptcha execute unavailable' };
  }
  try {
    const token = await Promise.resolve(execute(cfg.siteKey, { action: cfg.action }));
    return { ok: !!token, token: String(token || '') };
  } catch (e) {
    try {
      const ent = window.grecaptcha && window.grecaptcha.enterprise;
      if (ent && typeof ent.render === 'function') {
        const id = ent.render(document.documentElement, {
          sitekey: cfg.siteKey, action: cfg.action
        });
        const token2 = await Promise.resolve(execute(id, { action: cfg.action }));
        return { ok: !!token2, token: String(token2 || '') };
      }
    } catch (e2) {
      return { ok: false, error: String((e2 && e2.message) || e2) };
    }
    return { ok: false, error: String((e && e.message) || e) };
  }
}
"""

RPC_SCRIPT = """
async (cfg) => {
  try {
    let bl = null, sid = null, at = null;
    const wiz = window.WIZ_global_data || {};
    if (wiz.cfb2h) bl = [String(wiz.cfb2h)];
    if (wiz.FdrFJe) sid = [null, String(wiz.FdrFJe)];
    if (wiz.SNlM0e) at = [null, String(wiz.SNlM0e)];

    if (!bl || !sid) {
      const html = (document.documentElement && document.documentElement.innerHTML) || '';
      bl = bl || html.match(/boq_[A-Za-z0-9_.-]+/);
      sid = sid || html.match(/"FdrFJe":"(-?[0-9]+)"/);
      at = at || html.match(/"SNlM0e":"([^"]+)"/);
    }

    if (!bl || !sid) {
      try {
        const pageRes = await fetch(location.href, { credentials: 'include' });
        const html = await pageRes.text();
        bl = bl || html.match(/boq_[A-Za-z0-9_.-]+/);
        sid = sid || html.match(/"FdrFJe":"(-?[0-9]+)"/);
        at = at || html.match(/"SNlM0e":"([^"]+)"/);
      } catch (_) {}
    }
    if (!bl || !sid) return { ok: false, error: 'bootstrap metadata unavailable' };

    const query = cfg.stream
      ? '?bl=' + encodeURIComponent(bl[0]) + '&f.sid=' + sid[1] +
        '&hl=en&_reqid=' + cfg.reqid + '&rt=c'
      : '?rpcids=' + encodeURIComponent(cfg.rpcId) +
        '&source-path=' + encodeURIComponent(cfg.sourcePath) +
        '&bl=' + encodeURIComponent(bl[0]) + '&f.sid=' + sid[1] +
        '&hl=en&_reqid=' + cfg.reqid + '&rt=c';
    const url = cfg.path + query;
    const headers = {
      'Accept': '*/*',
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'x-same-domain': '1'
    };
    const post = async (params) => {
      const r = await fetch(url, {
        method: 'POST', credentials: 'include',
        referrer: 'https://flow.google.com/', headers: headers, body: params
      });
      return { status: r.status, text: await r.text() };
    };
    const build = (withAt) => {
      const p = new URLSearchParams();
      p.set('f.req', cfg.freq);
      if (withAt && at) p.set('at', at[1]);
      return p;
    };
    let result;
    const sendWithAt = cfg.stream || Boolean(at);
    result = await post(build(sendWithAt));
    if (!result.text || (result.text.indexOf('"er"') >= 0 && result.text.indexOf('401') >= 0)) {
      if (at && !cfg.stream) {
        const alt = await post(build(!sendWithAt));
        if (alt.text && alt.text.indexOf('"er"') < 0) result = alt;
      }
    }
    return { ok: true, status: result.status, text: result.text };
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) };
  }
}
""".replace("FLOW_ORIGIN_PLACEHOLDER", "'" + FLOW_ORIGIN + "/'")


class FlowRpcError(RuntimeError):
    pass


class FlowPreSubmissionError(FlowRpcError):
    """A preparation failure before pressing Enter; no generation was submitted."""


class FlowProjectNotFoundError(FlowRpcError):
    """An explicit missing project before any generation submission."""
    pass


# 观察页面自己发出的 ogiZ0b（图片生成）请求与响应。不做任何拦截或改写，
# 让 Flow 正常提交；我们只记录响应文本。
NATIVE_GENERATION_OBSERVER = """() => {
    window.__psfbNative = { done: false, status: 0, text: '', error: '' };
    if (window.__psfbNativePatched) return;
    window.__psfbNativePatched = true;
    const rpcType = (u) => {
        const value = String(u || '');
        if (value.includes('ogiZ0b')) return 'ogiZ0b';
        if (value.includes('StreamChat')) return 'StreamChat';
        return '';
    };
    const open = XMLHttpRequest.prototype.open;
    const send = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (m, u, ...rest) {
        this.__psfbUrl = String(u || '');
        return open.call(this, m, u, ...rest);
    };
    XMLHttpRequest.prototype.send = function (body) {
        const req = this;
        const type = rpcType(req.__psfbUrl);
        if (type) {
            const state = window.__psfbNative;
            state.requestBody = String(body || '');
            state.rpcType = type;
            req.addEventListener('readystatechange', () => {
                if (req.readyState !== 4) return;
                state.status = Number(req.status || 0);
                state.text = String(req.responseText || '');
                state.done = true;
            });
            req.addEventListener('error', () => {
                state.error = 'network error';
                state.done = true;
            });
        }
        return send.call(this, body);
    };
    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
        window.fetch = function (input, init) {
            const url = typeof input === 'string'
                ? input
                : (input && typeof input.url === 'string' ? input.url : '');
            const type = rpcType(url);
            if (!type) return origFetch.call(window, input, init);
            const state = window.__psfbNative;
            state.requestBody = String((init && init.body) || '');
            state.rpcType = type;
            return origFetch.call(window, input, init).then((response) => {
                const clone = response.clone();
                state.status = Number(response.status || 0);
                clone.text().then((t) => {
                    state.text = String(t || '');
                    state.done = true;
                }).catch((e) => {
                    state.error = String(e || 'read failed');
                    state.done = true;
                });
                return response;
            }).catch((e) => {
                state.error = String((e && e.message) || e);
                state.done = true;
                throw e;
            });
        };
    }
}"""


def _decode_frames(text: str) -> List[List[Any]]:
    frames = _parse_frames(text)
    decoded: List[List[Any]] = []
    for frame in frames:
        for item in frame:
            if (
                isinstance(item, list)
                and len(item) >= 3
                and item[0] == "wrb.fr"
                and isinstance(item[2], str)
            ):
                try:
                    decoded.append(json.loads(item[2]))
                except (TypeError, ValueError):
                    continue
    return decoded


def _media_from_ogi_response(text: str) -> List[Dict[str, Any]]:
    """从 ogiZ0b 响应里取 (mediaId, 签名图 URL)。"""
    media: List[Dict[str, Any]] = []
    seen: set = set()
    for payload in _decode_frames(text):
        for url in re.findall(
            r"https://flow-content\.google/image/[^\"\\\\\s]+", json.dumps(payload)
        ):
            url = url.replace("\\u003d", "=").replace("\\u0026", "&")
            if url in seen:
                continue
            seen.add(url)
            media_id = ""
            match = re.search(r"/image/([0-9a-f-]{36})", url, re.I)
            if match:
                media_id = match.group(1)
            media.append(
                {
                    "name": media_id,
                    "image": {"generatedImage": {"fifeUrl": url}},
                }
            )
    return media


def _media_from_stream_ids(text: str) -> List[Dict[str, Any]]:
    media: List[Dict[str, Any]] = []
    for url in re.findall(
        r"https://flow-content\.google/(?:image|video)/[^\"\\\\\s]+", text
    ):
        url = url.replace("\\u003d", "=").replace("\\u0026", "&")
        media_id = ""
        match = re.search(r"/(?:image|video)/([0-9a-f-]{36})", url, re.I)
        if match:
            media_id = match.group(1)
        media.append(
            {"name": media_id, "image": {"generatedImage": {"fifeUrl": url}}}
        )
    return media


def _compact(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def _parse_frames(text: str) -> List[List[Any]]:
    frames: List[List[Any]] = []
    for line in str(text or "").splitlines():
        line = line.strip()
        if not line.startswith("["):
            continue
        try:
            frame = json.loads(line)
        except (TypeError, ValueError):
            continue
        if isinstance(frame, list):
            frames.append(frame)
    return frames


def _extract_payload(frames: List[List[Any]], rpc_id: str) -> Any:
    for frame in frames:
        for item in frame:
            if not isinstance(item, list) or len(item) < 3:
                continue
            if item[0] != "wrb.fr" or item[1] != rpc_id:
                continue
            try:
                return json.loads(item[2])
            except (TypeError, ValueError):
                return None
    return None


def _raise_frame_error(frames: List[List[Any]], rpc_id: str) -> None:
    def public_error(value):
        if isinstance(value, str) and value.startswith(("PUBLIC_ERROR_", "ERROR_")):
            return value
        if isinstance(value, (list, tuple)):
            for part in value:
                found = public_error(part)
                if found:
                    return found
        return ""

    for frame in frames:
        for item in frame:
            if not isinstance(item, list) or not item:
                continue
            if item[0] == "er":
                code = item[5] if len(item) > 5 and item[5] is not None else item[6] if len(item) > 6 else "unknown"
                hint = "Cookie 失效或账号不一致" if str(code) == "401" else ""
                raise FlowRpcError(
                    f"Flow RPC 被拒绝: rpc={rpc_id}, code={code} {hint}".strip()
                )
            if item[0] == "wrb.fr" and len(item) > 5 and item[1] == rpc_id:
                detail = item[5]
                code = public_error(detail)
                if code or (item[2] is None and detail is not None):
                    raise FlowRpcError(f"Flow RPC 被拒绝: rpc={rpc_id}, code={code or detail}")


def _find_content_url(value: Any, kind: str) -> str:
    marker = f"/{kind}/"
    if isinstance(value, str):
        return value if value.startswith("https://") and marker in value else ""
    if isinstance(value, list):
        for item in value:
            url = _find_content_url(item, kind)
            if url:
                return url
    elif isinstance(value, dict):
        for item in value.values():
            url = _find_content_url(item, kind)
            if url:
                return url
    return ""


def _find_uuid(value: Any, excluded: Optional[set] = None) -> str:
    excluded = excluded or set()
    if isinstance(value, str):
        for candidate in UUID_RE.findall(value):
            if candidate.lower() not in {item.lower() for item in excluded}:
                return candidate
        return ""
    if isinstance(value, list):
        for item in value:
            found = _find_uuid(item, excluded)
            if found:
                return found
    elif isinstance(value, dict):
        for item in value.values():
            found = _find_uuid(item, excluded)
            if found:
                return found
    return ""


def _extract_stream_media_ids(text: str) -> List[str]:
    """从 StreamChat 响应里找 ["media_id", [null, null, "<uuid>"]]。"""
    found: List[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, list):
            if (
                len(value) == 2
                and value[0] == "media_id"
                and isinstance(value[1], list)
                and len(value[1]) > 2
                and isinstance(value[1][2], str)
                and UUID_RE.fullmatch(value[1][2])
            ):
                found.append(value[1][2])
                return
            for item in value:
                walk(item)
        elif isinstance(value, dict):
            for item in value.values():
                walk(item)

    for frame in _parse_frames(text):
        for item in frame:
            if (
                isinstance(item, list)
                and len(item) >= 3
                and item[0] == "wrb.fr"
                and isinstance(item[2], str)
            ):
                try:
                    walk(json.loads(item[2]))
                except (TypeError, ValueError):
                    continue
    return list(dict.fromkeys(found))


class FlowCurrentClient:
    """在已登录的浏览器页面里驱动新版 Flow RPC。"""

    def __init__(self, context) -> None:
        self._context = context
        self._page = None
        self._page_key = ""
        self._native_lock = asyncio.Lock()

    async def _ensure_page(self, url: str, wait_editor: bool = False):
        project = re.search(r'/project/([^/?#]+)', url)
        if project and self._context is not None:
            key = (id(self._context), project.group(1))
            cached = _PROJECT_WORKER_PAGES.get(key)
            if cached is not None and not cached.is_closed() and (getattr(cached,'url',url).split('?')[0].rstrip('/') == url.rstrip('/')):
                self._page = cached
                self._page_key = url
                if wait_editor:await self._wait_ready(True)
                return cached
            page = await self._context.new_page()
            await page.add_init_script(RECAPTCHA_INIT_SCRIPT)
            await page.goto(url, wait_until='domcontentloaded', timeout=90000)
            self._page = page
            self._page_key = url
            await self._wait_ready(wait_editor)
            _PROJECT_WORKER_PAGES[key] = page
            return page
        if self._page is not None and self._page.is_closed():
            self._page = None
            self._page_key = ''
        if self._page is None:
            self._page = await self._context.new_page()
            await self._page.add_init_script(RECAPTCHA_INIT_SCRIPT)
            self._page_key = ''
        if self._page_key != url:
            await self._page.goto(url,wait_until='domcontentloaded',timeout=90000)
            self._page_key = url
            await self._wait_ready(wait_editor)
        elif wait_editor:
            await self._wait_ready(True)
        return self._page

    async def _wait_ready(self, wait_editor: bool) -> None:
        if not wait_editor:
            return  # Read-only RPCs do not require a grecaptcha global.
        state = await self._page.wait_for_function(r"""() => {
            const editor = [...document.querySelectorAll('.ProseMirror')].find(n=>n.getClientRects().length&&n.offsetParent!==null);
            if (editor) return 'ready';
            const text = (document.body && document.body.innerText) || '';
            return /找不到项目|找不到專案|project\s+not\s+found|could(?:n't| not)\s+find\s+(?:the\s+)?project/i.test(text) ? 'missing' : false;
        }""", timeout=60000)
        try:
            if await state.json_value() == 'missing':
                raise FlowProjectNotFoundError('Flow 项目不存在或当前账号无权访问，未提交生成')
        finally:
            await state.dispose()

    async def check_project(self, project_id: str) -> bool:
        try:
            await self._ensure_page(f'{FLOW_ORIGIN}/project/{project_id}', wait_editor=True)
            return True
        except FlowProjectNotFoundError:
            return False

    async def close(self) -> None:
        if self._page is not None and not self._page.is_closed():
            try:
                await self._page.close()
            except Exception:
                pass
        self._page = None
        self._page_key = ""

    async def _rpc(
        self,
        page,
        rpc_id: str,
        argument: List[Any],
        source_path: str,
    ) -> Any:
        freq = _compact([[[rpc_id, _compact(argument), None, "generic"]]])
        cfg = {
            "path": BATCHEXECUTE_PATH,
            "stream": False,
            "rpcId": rpc_id,
            "sourcePath": source_path,
            "freq": freq,
            "reqid": random.randint(100000, 999999),
        }
        result = await page.evaluate(RPC_SCRIPT, cfg)
        if not isinstance(result, dict) or not result.get("ok"):
            raise FlowRpcError(
                f"Flow RPC 请求失败: rpc={rpc_id}, "
                f"error={(result or {}).get('error', 'unknown')}"
            )
        text = str(result.get("text") or "")
        frames = _parse_frames(text)
        _raise_frame_error(frames, rpc_id)
        payload = _extract_payload(frames, rpc_id)
        if payload is None:
            snippet = text[:300].replace("\n", " ")
            raise FlowRpcError(
                f"Flow RPC 无返回数据: rpc={rpc_id}, status={result.get('status')}, "
                f"body={snippet}"
            )
        return payload

    async def _recaptcha(self, page, action: str) -> str:
        cfg = {"siteKey": RECAPTCHA_SITE_KEY, "action": action}
        result = await page.evaluate(RECAPTCHA_SCRIPT, cfg)
        token = str((result or {}).get("token") or "").strip()
        if not token:
            raise FlowRpcError(
                f"reCAPTCHA 取码失败 (action={action}): "
                f"{(result or {}).get('error', 'empty token')}"
            )
        return token

    async def get_credits(self) -> Dict[str, Any]:
        page = await self._ensure_page(f"{FLOW_ORIGIN}/projects")
        payload = await self._rpc(page, "nzlxg", [], "/projects")
        values = payload if isinstance(payload, list) else []
        credits = next(
            (
                int(value)
                for value in values
                if isinstance(value, (int, float)) and not isinstance(value, bool)
            ),
            0,
        )
        return {
            "credits": credits,
            "userPaygateTier": "PAYGATE_TIER_ONE"
            if credits > 0
            else "PAYGATE_TIER_NOT_PAID",
        }

    async def create_project(self, title: str = "PS Flow Bridge") -> str:
        page = await self._ensure_page(f"{FLOW_ORIGIN}/projects")
        payload = await self._rpc(
            page,
            "jHPbke",
            ["projects/*", [None, [title]], [None, 22]],
            "/projects",
        )
        project_id = _find_uuid(payload)
        if not project_id:
            raise FlowRpcError("创建项目返回缺少 projectId")
        return project_id

    async def upload_image(self, project_id: str, image_bytes: bytes) -> str:
        page = await self._ensure_page(f"{FLOW_ORIGIN}/project/{project_id}")
        token = await self._recaptcha(page, "UPLOAD_IMAGE")
        mime_type = _detect_mime(image_bytes)
        extension = {"image/png": "png", "image/webp": "webp"}.get(mime_type, "jpg")
        context = [
            None, 22, None, None, None, project_id, None, None, None, None,
            [token, 1],
        ]
        argument = [
            context,
            base64.b64encode(image_bytes).decode("ascii"),
            mime_type,
            1,
            None, None, None, None,
            f"psfb_{uuid.uuid4().hex[:12]}.{extension}",
            None,
            str(uuid.uuid4()).upper(),
            str(uuid.uuid4()).upper(),
        ]
        payload = await self._rpc(
            page, "maseQ", argument, f"/project/{project_id}"
        )
        media_url = _find_content_url(payload, "image")
        media_id = ""
        if media_url:
            match = re.search(r"/image/([0-9a-f-]{36})", media_url, re.I)
            media_id = match.group(1) if match else ""
        media_id = media_id or _find_uuid(payload, excluded={project_id})
        if not media_id:
            raise FlowRpcError("上传响应缺少 mediaId")
        return media_id

    async def generate_image(
        self,
        project_id: str,
        prompt: str,
        model_name: str,
        aspect_ratio: str,
        image_inputs: Optional[List[Dict[str, Any]]] = None,
    ) -> Tuple[Dict[str, Any], str]:
        page = await self._ensure_page(
            f"{FLOW_ORIGIN}/project/{project_id}", wait_editor=True
        )
        token = await self._recaptcha(page, "IMAGE_GENERATION")
        session_id = str(uuid.uuid4()).upper()
        aspect_code = ASPECT_RATIO_CODES.get(str(aspect_ratio).strip().upper(), 3)
        references = [
            [str(item.get("name") or item.get("mediaId") or "").strip(),
             None, None, None, 1]
            for item in image_inputs or []
            if isinstance(item, dict)
            and str(item.get("name") or item.get("mediaId") or "").strip()
        ]
        client_context = [
            None, 22, None, None, None, project_id, None, None, None, None,
            [token, 1],
        ]
        request = [
            None,
            None,
            references or None,
            random.randint(1, 2147483647),
            aspect_code,
            model_name,
            None,
            client_context,
            [[[prompt]]],
            None, None, None, None,
            session_id,
            str(uuid.uuid4()).upper(),
        ]
        payload = await self._rpc(
            page,
            "ogiZ0b",
            [None, [request], 1, client_context, [session_id]],
            f"/project/{project_id}",
        )
        media_items = (
            payload[0]
            if isinstance(payload, list) and payload and isinstance(payload[0], list)
            else []
        )
        media = []
        for item in media_items:
            if not isinstance(item, list) or not item:
                continue
            media_id = str(item[0] or "").strip()
            image_url = _find_content_url(item, "image")
            if media_id and image_url:
                media.append(
                    {
                        "name": media_id,
                        "image": {"generatedImage": {"fifeUrl": image_url}},
                    }
                )
        if not media:
            raise FlowRpcError("生成响应中没有可下载的图片")
        return {"media": media}, session_id

    async def get_media(self, project_id: str, media_id: str) -> Dict[str, Any]:
        page = await self._ensure_page(f"{FLOW_ORIGIN}/project/{project_id}")
        payload = await self._rpc(
            page, "as29s", [media_id], f"/project/{project_id}/edit/{media_id}"
        )
        url = _find_content_url(payload, "image") or _find_content_url(payload, "video")
        if not url:
            raise FlowRpcError("as29s 未返回下载地址")
        return {
            "name": media_id,
            "projectId": project_id,
            "image": {"generatedImage": {"fifeUrl": url}},
        }

    async def generate_image_native(
        self,
        project_id: str,
        prompt: str,
        model_name: Optional[str] = None,
        aspect_ratio: Optional[str] = None,
        reference_image: Optional[bytes] = None,
        timeout_seconds: int = 240,
        count: int = 1,
        reuse_reference: bool = False,
        references: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """走页面原生提交：用页面的 reCAPTCHA 上下文，观察它自己的 ogiZ0b 响应。

        实测：batchexecute 的 ogiZ0b 只接受页面自身上下文发出的 token，
        从 page.evaluate 里手动 execute() 拿到的 token 会被判为
        UNUSUAL_ACTIVITY（er code 5）。因此这里不自己发请求，只在页面里
        输入提示词并按 Enter 触发原生提交，然后读取 ogiZ0b 响应里的签名图 URL。

        注意：点发送按钮不生效，必须按 Enter。
        """
        async with (get_context_lock(self._context) if self._context is not None else self._native_lock):
            if count not in (1, 2, 3, 4):
                raise FlowPreSubmissionError("Unsupported generation count; generation not submitted")
            started = time.monotonic()
            timings = {}
            preparation_stage = '准备 Flow 页面'
            temp_path = None
            try:
                page = await self._ensure_page(
                    f"{FLOW_ORIGIN}/project/{project_id}", wait_editor=True
                )
                await page.evaluate(NATIVE_GENERATION_OBSERVER)
                timings['pageReadyMs'] = round((time.monotonic() - started) * 1000)
                preparation_stage = '确认生成设置'
                settings_started = time.monotonic()
                await self._select_generation_settings(page, model_name, aspect_ratio, count)
                timings['settingsMs'] = round((time.monotonic() - settings_started) * 1000)
                preparation_stage = '上传参考图'
                upload_started = time.monotonic()
                if references and len(references) > 0:
                    await self._attach_reference_images(page, references)
                elif reference_image:
                    temp_path = await self._attach_reference_image(page, reference_image, reuse_reference=True) if reuse_reference else await self._attach_reference_image(page, reference_image)
                    if temp_path:
                        try:os.unlink(temp_path)
                        except OSError:pass
                        temp_path = None
                else:
                    # Text-to-image must run on an empty composer. A reference
                    # chip left from a previous turn would silently turn this
                    # request into an edit of that stale image, so clear it here
                    # and refuse to submit unless the page confirms zero chips.
                    preparation_stage = '清除旧参考素材'
                    await self._clear_reference_chips(page)
                timings['referenceUploadMs'] = round((time.monotonic() - upload_started) * 1000) if (references or reference_image) else 0
                if reference_image:
                    try:
                        transfer = await page.evaluate('window.__psfbReferenceTransfer || {}')
                        if isinstance(transfer, dict) and transfer.get('method') in ('paste', 'file', 'reuse'):
                            timings['referenceMethod'] = transfer['method']
                    except Exception:
                        pass  # Optional diagnostics must never prevent submission.
                preparation_stage = '校验提示词'
                # Reference upload can replace the composer node or clear its text.
                # Write only after the attachment is confirmed, then read back the
                # current editor before allowing the single Enter submission.
                preparation_stage = '写入提示词'
                editor = page.locator(".ProseMirror:visible").last
                await editor.wait_for(state="visible", timeout=60000)
                await editor.fill(prompt)
                preparation_stage = '校验提示词'
                actual_text = await editor.inner_text()
                expected_normalized = _normalize_editor_text(prompt)
                actual_normalized = _normalize_editor_text(actual_text)
                if expected_normalized not in actual_normalized:
                    raise FlowPreSubmissionError(
                        f"提示词写入未确认，未提交生成（提示词 {len(expected_normalized)} 字符，编辑器回读 {len(actual_normalized)} 字符）"
                    )
                # Reference upload may leave an overlay above the editor. Enter
                # needs keyboard focus, not pointer hit-testing through that layer.
                preparation_stage = '确认输入焦点'
                await editor.focus(timeout=5000)
                if not await editor.evaluate('(node) => node.isContentEditable && node.ownerDocument.activeElement === node'):
                    raise FlowPreSubmissionError('提示词输入焦点未确认，未提交生成')
                # Pre-Enter DOM Gate: verify actual chip count and readiness against expectation
                preparation_stage = '核对参考素材就绪状态'
                expected_ref_count = len(references) if (references and len(references) > 0) else (1 if reference_image else 0)
                final_chip_state = await page.evaluate(REFERENCE_CHIP_STATE)
                actual_chip_count = final_chip_state.get("count", 0)
                if actual_chip_count != expected_ref_count:
                    raise FlowPreSubmissionError(f"生成前参考素材数量不匹配：期望 {expected_ref_count}，实际 {actual_chip_count}，未提交生成")
                if expected_ref_count > 0 and not final_chip_state.get("ready"):
                    raise FlowPreSubmissionError("生成前参考素材尚未完全就绪，未提交生成")
                try:
                    await page.evaluate(WEB_PROGRESS_START)
                except Exception:
                    pass  # Optional progress must not prevent submission.
            except FlowPreSubmissionError:
                raise
            except Exception as exc:
                raise FlowPreSubmissionError(f'{preparation_stage}失败，未提交生成：{type(exc).__name__}: {str(exc)[:240]}') from exc
            # Keep Enter outside the pre-submission guard: an interrupted key press
            # may already have submitted, so its errors must remain uncertain.
            set_transfer_progress(PROGRESS_TASK.get(), None)
            generation_started = time.monotonic()
            await editor.press("Enter")

            deadline = time.time() + timeout_seconds
            state: Dict[str, Any] = {}
            while time.time() < deadline:
                await sample_web_progress(page, count)
                state = await page.evaluate(
                    "window.__psfbNative || {}"  # noqa: E501
                ) or {}
                if state.get("done"):
                    break
                await asyncio.sleep(0.5)
            if not state.get("done"):
                raise FlowRpcError("页面原生生成超时，未收到 ogiZ0b 响应")
            if state.get("error"):
                raise FlowRpcError(f"页面原生生成失败: {state['error']}")
            text = str(state.get("text") or "")
            status = int(state.get("status") or 0)
            if status < 200 or status >= 300:
                raise FlowRpcError(f"页面原生生成 HTTP {status}: {text[:200]}")
            if "PUBLIC_ERROR_" in text:
                match = re.search(r"PUBLIC_ERROR_[A-Z_]+", text)
                raise FlowRpcError(
                    f"Flow 拒绝生成: {match.group(0) if match else 'UNKNOWN'}"
                )
            if temp_path:
                try:
                    os.unlink(temp_path)
                except OSError:
                    pass

            media = _media_from_ogi_response(text)
            if not media:
                media = _media_from_stream_ids(text)
            if not media:
                if state.get("rpcType") == "StreamChat":
                    media_ids = _extract_stream_media_ids(text)
                    for media_id in media_ids:
                        media.append(await self.get_media(project_id, media_id))
            if not media:
                raise FlowRpcError("页面原生生成结果无法解析为下载地址")
            timings['nativeGenerationMs'] = round((time.monotonic() - generation_started) * 1000)
            return {
                "media": media,
                "timings": timings,
                "frontendRpc": str(state.get("rpcType") or "ogiZ0b"),
                "requestLength": len(str(state.get("requestBody") or "")),
                "responseLength": len(text),
            }

    async def _select_generation_settings(self, page, model_name, aspect_ratio, count=1) -> None:
        """Read actual settings, change only mismatches, then verify before submit."""
        if count not in (1, 2, 3, 4):
            raise FlowPreSubmissionError("Unsupported generation count")
        ratio = {
            "IMAGE_ASPECT_RATIO_SQUARE": "1:1",
            "IMAGE_ASPECT_RATIO_LANDSCAPE": "16:9",
            "IMAGE_ASPECT_RATIO_PORTRAIT": "9:16",
            "IMAGE_ASPECT_RATIO_LANDSCAPE_FOUR_THREE": "4:3",
            "IMAGE_ASPECT_RATIO_PORTRAIT_THREE_FOUR": "3:4",
        }.get(str(aspect_ratio or '').upper(), str(aspect_ratio or ''))
        if ratio and ratio not in {'1:1', '16:9', '9:16', '4:3', '3:4'}:
            raise FlowPreSubmissionError(f"不支持的比例: {aspect_ratio}")
        patterns = {
            'NARWHAL': r'\bnano\s*banana\s*2(?:\.\d+)*\b',
            'GEM_PIX_2': r'\bnano\s*banana\s*(?:pro|2(?:\.\d+)*)\b',
            'GEM_PIX': r'^nano\s*banana\s*$',
            'IMAGEN_3_5': r'\bimagen\b',
        }
        pattern = patterns.get(str(model_name or '').upper())
        if model_name and pattern is None:
            raise FlowPreSubmissionError(f"不支持的模型: {model_name}")
        read_settings = r"""() => {
            const trigger = Array.from(document.querySelectorAll('button'))
                .filter(n => n.offsetParent !== null)
                .find(n => /设置触发器|settings trigger/i.test([
                    n.getAttribute('aria-label'), n.getAttribute('title'), n.innerText
                ].join(' ')));
            if (!trigger) return null;
            const text = [trigger.getAttribute('aria-label'), trigger.innerText].join(' ').replace(/\s+/g,' ');
            const match = text.match(/crop_(\d+)_(\d+)/);
            const model = (text.match(/(?:Nano\s*Banana|Imagen|Veo)(?:\s+(?:Pro|Fast|Ultra|Quality|\d+(?:\.\d+)*))*/i)||[''])[0];
            const countMatch=text.match(/(?:^|\s)[x×]\s*([1-4])\b|([1-4])\s*(?:张|images?|outputs?)(?=\s|$|[,，])|(?:output count|图片数量|输出数量|结果数量|张数)\s*[:：]?\s*([1-4])/i);
            const overlay=Array.from(document.querySelectorAll(
                'button,[role=radio],[role=option],[role=tab],[role=menuitem],[role=menuitemradio]'))
                .filter(n=>n.getClientRects().length && n.offsetParent!==null)
                .some(n=>{
                    const clone=n.cloneNode(true);
                    clone.querySelectorAll('mat-icon,flow-material-icon,[aria-hidden=true],[class*=material-symbol],[class*=material-icon],svg,[role=img]').forEach(icon=>icon.remove());
                    const label=[n.getAttribute('aria-label')||'',clone.textContent||''].join(' ').replace(/\s+/g,' ').trim();
                    return /^(?:x|×)?\s*[1-4]\s*(?:张(?:图片|图像)?|images?|outputs?|个结果)$/i.test(label) ||
                        (/^[1-4]$/.test(label) && Array.from(n.parentElement?n.parentElement.querySelectorAll('button,[role=radio],[role=option],[role=tab]'):[])
                            .filter(sib=>sib.getClientRects().length).length>=2);
                });
            return {model, aspect:match?match[1]+':'+match[2]:/crop_square/.test(text)?'1:1':'',
                count:countMatch?Number(countMatch[1]||countMatch[2]||countMatch[3]):0,
                expanded:overlay};
        }"""
        async def read():
            state = await page.evaluate(read_settings)
            for _ in range(60):
                if state and state.get('model'):
                    break
                await asyncio.sleep(0.5)
                state = await page.evaluate(read_settings)
            if not state or re.search('Veo', state.get('model', ''), re.I):
                raise FlowPreSubmissionError('未能读取 Flow 图像模型设置，未提交生成')
            return state
        # The trigger exposes no reliable aria-expanded attribute, so detect the
        # real popup. Clicking an already-open panel would toggle it shut and the
        # next run would find no count options.
        # The panel counts as open only when count options are actually visible.
        # Keying off the overlay alone is fragile across Flow's menu variants.
        is_panel_open_js = r'''() => {
            const overlay = document.querySelector('.cdk-overlay-pane');
            if (overlay && overlay.getClientRects().length) return true;
            
            const nodes = Array.from(document.querySelectorAll(
                'button,[role=radio],[role=option],[role=tab],[role=menuitem],[role=menuitemradio]'))
                .filter(n => n.getClientRects().length && n.offsetParent !== null);
                
            const labelsOf = n => {
                const clone = n.cloneNode(true);
                clone.querySelectorAll('mat-icon,flow-material-icon,[aria-hidden=true],[class*=material-symbol],[class*=material-icon],svg,[role=img]').forEach(icon=>icon.remove());
                const labelled=(n.getAttribute('aria-labelledby')||'').split(/\s+/).map(id=>document.getElementById(id)?.textContent||'').join(' ');
                return [n.getAttribute('aria-label')||'',labelled,clone.textContent||''].map(t=>t.replace(/\s+/g,' ').trim());
            };
            const parse = text => {
                const match=text.match(/^(?:x|×)?\s*([1-4])(?:\s*(?:张(?:图片|图像)?|images?|outputs?|个结果))?$/i);
                return match?Number(match[1]):0;
            };
            const countOf = n => {
                for(const text of labelsOf(n)) {
                    const value=parse(text);
                    if(!value)continue;
                    if(!/^[1-4]$/.test(text))return value;
                    const group=n.closest('[role=tablist],[role=group],fieldset')||n.parentElement;
                    const label=[group?.getAttribute('aria-label'),group?.getAttribute('data-testid'),group?.textContent].join(' ');
                    if(/model|模型|Nano|Banana|Imagen|Veo|ratio|比例/i.test(label))continue;
                    const siblings=group?[...group.querySelectorAll('button,[role=tab],[role=radio],[role=option]')]:[];
                    const values=new Set(siblings.flatMap(item=>labelsOf(item).map(parse)).filter(Boolean));
                    if(/outputs?|image count|图片数量|输出数量|结果数量|张数|生成数量/i.test(label)||values.size>=2)return value;
                }
                return 0;
            };
            
            return nodes.some(n => countOf(n) > 0 || 
                (/menu|listbox/.test(n.getAttribute('aria-haspopup')||'') && 
                 labelsOf(n).some(text=>/^(?:outputs?(?: count)?|number of images|图片数量|输出数量|结果数量|生成数量|张数)$/i.test(text))));
        }'''
        click_trigger = r"""() => {
            const n = Array.from(document.querySelectorAll('button')).find(n =>
                n.offsetParent !== null && /设置触发器|settings trigger/i.test([
                    n.getAttribute('aria-label'),n.getAttribute('title'),n.innerText].join(' ')));
            if (!n) return false; n.click(); return true;
        }"""
        async def open_settings():
            if await page.evaluate(is_panel_open_js):
                return
            opened = await page.evaluate(click_trigger)
            if not opened:
                raise FlowPreSubmissionError('未找到 Flow 设置入口，未提交生成')
            for _ in range(8):
                if await page.evaluate(is_panel_open_js):
                    return
                await asyncio.sleep(0.25)
            # One retry: the first click may have toggled a stale open panel shut.
            await page.evaluate(click_trigger)
            for _ in range(8):
                if await page.evaluate(is_panel_open_js):
                    return
                await asyncio.sleep(0.25)
            raise FlowPreSubmissionError('Flow 设置面板未打开，未提交生成')
        state = await read()
        if pattern and not re.search(pattern, state['model'], re.I):
            await open_settings()
            selected = await page.evaluate(r"""(pattern) => {
                const matches = new RegExp(pattern, 'i');
                const node = Array.from(document.querySelectorAll('button,[role=radio],[role=option]'))
                    .filter(n => n.offsetParent !== null)
                    .find(n => !/设置触发器|settings trigger/i.test(n.getAttribute('aria-label')||'') &&
                        matches.test((n.innerText||n.getAttribute('aria-label')||'').trim()));
                if (!node) return false; node.click(); return true;
            }""", pattern)
            if not selected:
                safe_print(f'提示: Flow 页面未找到指定模型 {model_name}，自动回退使用当前可用模型: {state.get("model")}')
            else:
                await asyncio.sleep(0.4)
                state = await read()
        if ratio and state['aspect'] != ratio:
            await open_settings()
            selected = await page.evaluate(r"""(wanted) => {
                const node = Array.from(document.querySelectorAll('button,[role=radio],[role=option]'))
                    .filter(n => n.offsetParent !== null)
                    .find(n => {
                        const text = [n.getAttribute('aria-label'),n.innerText].join(' ');
                        const match = text.match(/\b(\d+)\s*:\s*(\d+)\b/);
                        return match && match[1]+':'+match[2]===wanted;
                    });
                if (!node) return false; node.click(); return true;
            }""", ratio)
            if not selected:
                raise FlowPreSubmissionError(f'Flow 页面没有比例 {ratio}，未提交生成')
            await asyncio.sleep(0.4)
            state = await read()
        if state.get('count') != count:
            await open_settings()
            select_count = r"""(wanted) => {
                const nodes = Array.from(document.querySelectorAll(
                    'button,[role=radio],[role=option],[role=tab],[role=menuitem],[role=menuitemradio]'))
                    .filter(n => n.offsetParent !== null && !n.disabled && n.getAttribute('aria-disabled') !== 'true');
                const labelsOf = n => {
                    const clone = n.cloneNode(true);
                    clone.querySelectorAll('mat-icon,flow-material-icon,[aria-hidden=true],[class*=material-symbol],[class*=material-icon],svg,[role=img]').forEach(icon=>icon.remove());
                    const labelled=(n.getAttribute('aria-labelledby')||'').split(/\s+/).map(id=>document.getElementById(id)?.textContent||'').join(' ');
                    return [n.getAttribute('aria-label')||'',labelled,clone.textContent||''].map(t=>t.replace(/\s+/g,' ').trim());
                };
                const parse = text => {
                    const match=text.match(/^(?:x|×)?\s*([1-4])(?:\s*(?:张(?:图片|图像)?|images?|outputs?|个结果))?$/i);
                    return match?Number(match[1]):0;
                };
                const countOf = n => {
                    for(const text of labelsOf(n)) {
                        const value=parse(text);
                        if(!value)continue;
                        if(!/^[1-4]$/.test(text))return value;
                        // Bare numbers need a count-group, never a model tab.
                        const group=n.closest('[role=tablist],[role=group],fieldset')||n.parentElement;
                        const label=[group?.getAttribute('aria-label'),group?.getAttribute('data-testid'),group?.textContent].join(' ');
                        if(/model|模型|Nano|Banana|Imagen|Veo|ratio|比例/i.test(label))continue;
                        const siblings=group?[...group.querySelectorAll('button,[role=tab],[role=radio],[role=option]')]:[];
                        const values=new Set(siblings.flatMap(item=>labelsOf(item).map(parse)).filter(Boolean));
                        if(/outputs?|image count|图片数量|输出数量|结果数量|张数|生成数量/i.test(label)||values.size>=2)return value;
                    }
                    return 0;
                };
                const node=nodes.find(n=>countOf(n)===wanted && !/menu|listbox/.test(n.getAttribute('aria-haspopup')||''));
                if(node){node.click();return 'selected';}
                const trigger=nodes.find(n=>/menu|listbox/.test(n.getAttribute('aria-haspopup')||'') && n.getAttribute('aria-expanded')!=='true' &&
                    (countOf(n)||labelsOf(n).some(text=>/^(?:outputs?(?: count)?|number of images|图片数量|输出数量|结果数量|生成数量|张数)$/i.test(text))));
                if(trigger){trigger.click();return 'opened';}
                return 'missing';
            }"""
            selected = False
            for _ in range(10):
                outcome = await page.evaluate(select_count, count)
                if outcome == 'selected':
                    selected = True
                    break
                await asyncio.sleep(0.2)
            if not selected:
                raise FlowPreSubmissionError(f'未找到 x{count} 生成设置，未提交生成')
            await asyncio.sleep(0.4)
            state = await read()
        if state.get('count') != count:
            raise FlowPreSubmissionError(f'x{count} 生成设置未确认，未提交生成')
        if (ratio and state['aspect'] != ratio) or (pattern and not re.search(pattern, state['model'], re.I)):
            raise FlowPreSubmissionError('Flow 模型或比例未确认，未提交生成')
        if state.get('expanded') or await page.evaluate(is_panel_open_js):
            await page.keyboard.press('Escape')
            await asyncio.sleep(0.1)
            if await page.evaluate(is_panel_open_js):
                await page.keyboard.press('Escape')

    async def _clear_reference_chips(self, page, attempts: int = 12, delay: float = 0.1) -> None:
        """Remove every real reference chip and verify the composer is empty.

        Used by the text-to-image path, which must not inherit a reference from a
        previous turn. Only the reference chip's own `cancel` overlay is clicked;
        the neighbouring "add media" chip is never touched. A chip Flow refuses
        to remove is a hard pre-submission failure, so no Enter is ever sent.
        """
        await page.evaluate(CLEAR_REFERENCE_CHIPS)
        for _ in range(attempts):
            chip = await page.evaluate(REFERENCE_CHIP_STATE)
            if not chip.get("count"):
                return
            await page.evaluate(CLEAR_REFERENCE_CHIPS)
            await asyncio.sleep(delay)
        remaining = await page.evaluate(REFERENCE_CHIP_STATE)
        if remaining.get("count"):
            raise FlowPreSubmissionError("旧参考素材未成功移除，未提交生成")

    async def _attach_reference_images(self, page, references: List[Dict[str, Any]]) -> None:
        """Attach 1-4 ordered reference images using a single ClipboardEvent DataTransfer."""
        expected_count = len(references)
        if expected_count == 0:
            return
        if expected_count > 4:
            raise FlowPreSubmissionError("参考图数量不能超过 4 张，未提交生成")
        # Prepare payload and content digests before touching the page. A
        # rejected or unchanged job must leave the user's composer untouched.
        files_payload = []
        digests = []
        total_bytes = 0
        for idx, ref in enumerate(references):
            raw_bytes = ref["bytes"] if isinstance(ref, dict) and "bytes" in ref else (ref if isinstance(ref, bytes) else b"")
            total_bytes += len(raw_bytes)
            mime = ref.get("mime") if isinstance(ref, dict) and "mime" in ref else _detect_mime(raw_bytes)
            sha = hashlib.sha256(raw_bytes).hexdigest()
            digests.append(sha)
            ext = {"image/png":"png","image/webp":"webp"}.get(mime, "jpg")
            name = ref.get("name") if isinstance(ref, dict) and "name" in ref else f"psflow-ref-{sha[:8]}-{idx}.{ext}"
            files_payload.append({
                "data": base64.b64encode(raw_bytes).decode("ascii"),
                "mime": mime,
                "name": name,
            })

        page_key = id(page)
        scope = await page.evaluate("() => location.origin + location.pathname + '|' + String(performance.timeOrigin || '')")
        live = await page.evaluate(REFERENCE_CHIP_STATE)
        cached = _PAGE_REFERENCE_SEQUENCES.get(page_key)

        def same_identity(state):
            chips = state.get("chips") or []
            return (state.get("count") == expected_count and len(chips) == expected_count
                    and all(chip.get("signature") for chip in chips)
                    and [chip["signature"] for chip in chips] == cached.get("chips", []))

        reusable = bool(
            cached and cached.get("scope") == scope and cached.get("digests") == digests
            and same_identity(live)
        )
        if reusable:
            # The bytes and the live chip identities match, so re-uploading
            # would only churn the composer. A chip may still be settling;
            # wait briefly and never clear or paste on the reuse path.
            if live.get("ready"):
                return
            deadline = time.monotonic() + REFERENCE_ATTACH_TIMEOUT_SECONDS
            while time.monotonic() < deadline:
                await asyncio.sleep(0.15)
                settled = await page.evaluate(REFERENCE_CHIP_STATE)
                if not same_identity(settled):
                    raise FlowPreSubmissionError("Flow 参考素材已变化，未上传、未提交生成")
                if settled.get("ready"):
                    return
            raise FlowPreSubmissionError("Flow 参考素材尚未就绪，未上传、未提交生成")

        # Content, order, count, page or project changed (or Flow dropped the
        # chips): resynchronise from scratch and never reuse a stale cache.
        _PAGE_REFERENCE_SEQUENCES.pop(page_key, None)
        await self._clear_reference_chips(page)

        try:
            await page.evaluate(UPLOAD_OBSERVER_START, {"size": total_bytes, "mime": files_payload[0]["mime"]})
            set_transfer_progress(PROGRESS_TASK.get(), {"phase": "upload", "loaded": 0, "total": None, "percent": None, "completed": 0, "totalItems": expected_count, "source": "flow-upload"})

            # Single paste of all files, in the caller's order.
            pasted = await page.evaluate(PASTE_REFERENCE_IMAGES, files_payload)
            if not pasted.get("target"):
                raise FlowPreSubmissionError("编辑器未就绪，多参考图粘贴失败，未提交生成")

            # Wait for the exact count, every chip ready, and a stable identity
            # for every chip before caching anything.
            deadline = time.monotonic() + REFERENCE_ATTACH_TIMEOUT_SECONDS
            while time.monotonic() < deadline:
                state = await sample_upload_progress(page)
                chip = await page.evaluate(REFERENCE_CHIP_STATE)
                if state.get("failed"):
                    raise FlowPreSubmissionError("参考图上传失败，未提交生成")
                if chip.get("count") == expected_count and chip.get("ready") and not state.get("pending"):
                    # A chip may expose only its cancel overlay. That is still
                    # a successful, ready upload; without an identity it just
                    # cannot authorise reuse, so no cache entry is written.
                    identities = [item.get("signature") for item in chip.get("chips") or []]
                    if all(identities):
                        _PAGE_REFERENCE_SEQUENCES[page_key] = {
                            "scope": scope,
                            "digests": digests,
                            "chips": identities,
                        }
                    await page.evaluate("""({elapsedMs}) => {
                        if (window.__psfbUpload) window.__psfbUpload.active = false;
                        window.__psfbReferenceTransfer = {method: "paste", elapsedMs, attached: true};
                    }""", {"elapsedMs": 0})
                    return
                await asyncio.sleep(0.2)
            raise FlowPreSubmissionError(f"多参考图加载超时，未达到期望数量 {expected_count} 或未就绪，未提交生成")
        finally:
            try:
                await page.evaluate("if(window.__psfbUpload)window.__psfbUpload.active=false")
            except Exception:
                pass

    async def _attach_reference_image(self, page, image_bytes: bytes, reuse_reference: bool = False) -> Optional[str]:
        """Attach reference image; reuse existing chip or uploaded asset when reuse_reference=True."""
        started = time.monotonic()
        page_key = id(page)
        sha256 = hashlib.sha256(image_bytes).hexdigest()
        mime = _detect_mime(image_bytes)
        extension = {"image/png":"png","image/webp":"webp"}.get(mime,"jpg")
        stable_filename = f"psflow-{sha256[:16]}.{extension}"
        asset_key=reference_asset_key(page,sha256)
        known_name=reference_asset_name(asset_key)
        known_signature=reference_asset_signature(asset_key) or _PAGE_REFERENCE_SIGNATURE.get(page_key)

        async def finish_reuse(chip, expected_signature=None):
            signature = chip.get("signature")
            if chip.get("count") != 1 or not chip.get("ready") or not signature:
                return False
            if expected_signature and signature != expected_signature and expected_signature not in chip.get('identities',[]):
                return False
            # A library selection can attach immediately and leave a stale Add
            # button behind. Close the picker and verify the actual composer.
            await page.keyboard.press("Escape")
            attached = await page.evaluate(REFERENCE_CHIP_STATE)
            if attached.get("count") != 1 or not attached.get("ready") or attached.get("signature") != signature:
                return False
            _PAGE_REFERENCE_FINGERPRINT[page_key] = sha256
            _PAGE_REFERENCE_SIGNATURE[page_key] = signature
            if known_name:record_reference_asset(asset_key,known_name,signature)
            set_transfer_progress(PROGRESS_TASK.get(), None)
            await page.evaluate("""({elapsedMs}) => {
                if (window.__psfbUpload) window.__psfbUpload.active = false;
                window.__psfbReferenceTransfer = {method: "reuse", elapsedMs, attached: true};
            }""", {"elapsedMs": round((time.monotonic() - started) * 1000)})
            return True

        if reuse_reference:
            # Verify if identical reference is already bound in prompt box chip
            chip = await page.evaluate(REFERENCE_CHIP_STATE)
            if chip.get("count") == 1 and chip.get("ready") and chip.get("signature"):
                if _PAGE_REFERENCE_FINGERPRINT.get(page_key) == sha256 and _PAGE_REFERENCE_SIGNATURE.get(page_key)==chip["signature"]:
                    if await finish_reuse(chip, chip["signature"]):
                        return None

            # Library rendering is asynchronous; clicking an open trigger closes it.
            reason = "asset_record_missing"
            if known_name:
                reason = "library_trigger_missing"
                button = page.get_by_role("button", name=re.compile(r"添加参考素材|在提示框中添加素材|向提示词添加素材|add (?:media|assets?) to prompt", re.I)).first
                resource = page.locator("[role=option]:visible").filter(has_text=known_name)
                if await button.is_visible():
                    reason = "remove_current_reference"
                    try:
                        if chip.get("count"):
                            await page.evaluate(REMOVE_CURRENT_REFERENCE)
                            await page.wait_for_function("""() => {
                                const editors=[...document.querySelectorAll('.ProseMirror')].filter(n=>n.getClientRects().length&&n.offsetParent!==null);
                                const editor=editors.find(n=>n===document.activeElement)||editors[editors.length-1];
                                const root=editor&&(editor.closest('flow-base-prompt-box,flow-prompt-box')||editor.closest('.base-prompt-box'));
                                return root&&![...root.querySelectorAll('flow-image-ingredient-chip,button.chip-container')].some(n=>n.getClientRects().length&&n.offsetParent!==null);
                            }""", timeout=2000)
                        reason = "open_library"
                        if not await resource.first.is_visible() and await button.get_attribute("aria-expanded") != "true":
                            await button.click(timeout=2000)
                        reason = "wait_asset"
                        await resource.first.wait_for(state="visible", timeout=20000)
                        selected_signature=None
                        if known_signature or await resource.count() != 1:
                            chosen=await choose_reference_asset(page,resource,image_bytes,known_signature)
                            selected_signature=chosen['signature']
                            resource=resource.nth(chosen['index'])
                        reason = "select_asset"
                        await resource.first.click(timeout=3000)
                        selected_chip = await page.evaluate(REFERENCE_CHIP_STATE)
                        if await finish_reuse(selected_chip,selected_signature):
                            return None
                        add = page.get_by_role("button", name=re.compile(r"^(添加到提示|Add to prompt)$", re.I)).first
                        reason = "confirm_asset"
                        if await add.is_visible():
                            await add.click(timeout=3000)
                        reason = "attachment_not_ready"
                        deadline = time.monotonic() + 6
                        while time.monotonic() < deadline:
                            chip_after = await page.evaluate(REFERENCE_CHIP_STATE)
                            if await finish_reuse(chip_after,selected_signature):
                                return None
                            await asyncio.sleep(0.1)
                    except FlowPreSubmissionError:
                        raise
                    except Exception as exc:
                        # Do not repeat the click or upload. A timed-out stale
                        # confirmation is successful only with the same proven,
                        # ready composer chip; mismatches remain a hard failure.
                        if reason == "confirm_asset" and _PAGE_REFERENCE_FINGERPRINT.get(page_key) == sha256:
                            expected = _PAGE_REFERENCE_SIGNATURE.get(page_key)
                            if expected:
                                deadline = time.monotonic() + 3
                                while time.monotonic() < deadline:
                                    recovered_chip = await page.evaluate(REFERENCE_CHIP_STATE)
                                    if await finish_reuse(recovered_chip, expected):
                                        return None
                                    await asyncio.sleep(0.1)
                        reason += ":" + type(exc).__name__
                        failed_chip = await page.evaluate(REFERENCE_CHIP_STATE)
                        reason += ":chips=" + str(failed_chip.get("count")) + ",ready=" + str(failed_chip.get("ready")) + ",fingerprint=" + str(_PAGE_REFERENCE_FINGERPRINT.get(page_key)==sha256) + ",signature=" + str(bool(failed_chip.get("signature")) and _PAGE_REFERENCE_SIGNATURE.get(page_key)==failed_chip["signature"])
            raise FlowPreSubmissionError("复用素材恢复失败（" + reason + "），未上传、未提交生成")

        # Fresh upload: remove existing chips
        await page.evaluate(REMOVE_CURRENT_REFERENCE)
        for _ in range(12):
            if not (await page.evaluate(REFERENCE_CHIP_STATE))["count"]:
                break
            await asyncio.sleep(0.1)
        else:
            raise FlowPreSubmissionError("旧参考素材未成功移除，未提交生成")

        await page.evaluate(UPLOAD_OBSERVER_START, {"size": len(image_bytes), "mime": mime})
        set_transfer_progress(PROGRESS_TASK.get(), {"phase": "upload", "loaded": 0, "total": None, "percent": None, "completed": 0, "totalItems": 1, "source": "flow-upload"})
        pasted = await page.evaluate(PASTE_REFERENCE_IMAGE, {"data": base64.b64encode(image_bytes).decode("ascii"), "mime": mime, "name": stable_filename})
        observed = {}
        for _ in range(6):
            observed = await sample_upload_progress(page)
            chip = await page.evaluate(REFERENCE_CHIP_STATE)
            if chip["count"] or observed.get("requests"):
                break
            await asyncio.sleep(0.2)
        if pasted.get("prevented") and not (observed.get("requests") or chip["count"]):
            for _ in range(9):
                observed = await sample_upload_progress(page)
                chip = await page.evaluate(REFERENCE_CHIP_STATE)
                if chip["count"] or observed.get("requests"):
                    break
                await asyncio.sleep(0.2)
        accepted = observed.get("requests") or chip["count"]
        path = None
        method = "paste"
        if not accepted:
            method = "file"
            handle = tempfile.NamedTemporaryFile(prefix=f"psflow-{sha256[:16]}-", suffix="." + extension, delete=False)
            handle.write(image_bytes)
            handle.close()
            path = handle.name
            try:
                add_opened = await page.evaluate("""() => {
                    const composer = document.querySelector(".base-prompt-box,flow-prompt-box");
                    const buttons = [...(composer||document).querySelectorAll("button"),...document.querySelectorAll("button")];
                    const add = buttons.find(n => n.offsetParent !== null && (n.querySelector("mat-icon,.material-symbols-outlined")||{}).textContent?.trim() === "add");
                    if (!add) return false;
                    add.click();
                    return true;
                }""")
                if not add_opened:
                    raise FlowPreSubmissionError("Reference upload menu could not be opened; generation not submitted.")
                upload = page.locator('[role=menuitem]:visible:has-text("upload"),button:visible:has-text("upload"),[role=menuitem]:visible:has-text("上传"),button:visible:has-text("上传")').first
                await upload.wait_for(state="visible", timeout=5000)
                async with page.expect_file_chooser(timeout=10000) as info:
                    await upload.click(timeout=10000)
                await (await info.value).set_files(path)
            except BaseException:
                try:
                    os.unlink(path)
                except OSError:
                    pass
                raise
        try:
            deadline = time.monotonic() + REFERENCE_ATTACH_TIMEOUT_SECONDS
            attached_from_library = False
            while time.monotonic() < deadline:
                state = await sample_upload_progress(page)
                chip = await page.evaluate(REFERENCE_CHIP_STATE)
                if state.get("failed"):
                    raise FlowPreSubmissionError("参考图上传失败，未提交生成")
                if chip["ready"] and chip.get("signature") and not state.get("pending"):
                    _PAGE_REFERENCE_FINGERPRINT[page_key] = sha256
                    asset_name=os.path.basename(path) if path else stable_filename
                    _PAGE_REFERENCE_FILENAME[page_key] = asset_name
                    _PAGE_REFERENCE_SIGNATURE[page_key]=chip.get("signature","")
                    record_reference_asset(asset_key,asset_name,chip.get('signature'))
                    await page.evaluate("""({method,elapsedMs}) => { window.__psfbUpload.active = false; window.__psfbReferenceTransfer = {method, elapsedMs, attached: true}; }""", {"method": method, "elapsedMs": round((time.monotonic() - started) * 1000)})
                    return path
                if method == "file" and not attached_from_library and time.monotonic() - started > 2:
                    button = page.get_by_role("button", name=re.compile(r"添加参考素材|在提示框中添加素材|向提示词添加素材|add (?:media|assets?) to prompt", re.I)).first
                    if await button.is_visible():
                        await button.click(timeout=2000)
                        resource = page.locator("[role=option]").filter(has_text=os.path.basename(path)).first
                        await resource.click(timeout=3000)
                        await page.get_by_role("button", name=re.compile(r"^(添加到提示|Add to prompt)$", re.I)).first.click(timeout=3000)
                        attached_from_library = True
                await asyncio.sleep(0.2)
            raise FlowPreSubmissionError("参考图未确认关联至提示词，未提交生成；请避免自动重复上传")
        except BaseException:
            if path:
                try:
                    os.unlink(path)
                except OSError:
                    pass
            raise
        finally:
            try:
                await page.evaluate("if(window.__psfbUpload)window.__psfbUpload.active=false")
            except Exception:
                pass

def _detect_mime(image_bytes: bytes) -> str:
    if len(image_bytes) >= 4 and image_bytes[:4] == b"\x89PNG":
        return "image/png"
    if len(image_bytes) >= 3 and image_bytes[:3] == b"\xff\xd8\xff":
        return "image/jpeg"
    if len(image_bytes) >= 12 and image_bytes[:4] == b"RIFF" and image_bytes[8:12] == b"WEBP":
        return "image/webp"
    return "image/png"
