"use strict";

const https = require("node:https");
const SHARE_CODE = "a2de330f-df0b-412a-ba32-48383e3c055c";
const SOURCES = [
  "https://raw.githubusercontent.com/weizhi123sdo/quicker-dist/main/psflow/latest.json",
  "https://gitee.com/weizhiOWO/quicker-actions/raw/main/psflow/latest.json"
];

function versionParts(value) {
  if (typeof value !== "string" || !/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.test(value)) return null;
  const parts = value.split(".").map(Number);
  return parts.every(Number.isSafeInteger) ? parts : null;
}
function compareVersions(left, right) {
  const a = versionParts(left), b = versionParts(right);
  if (!a || !b) return null;
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return a[i] > b[i] ? 1 : -1;
  return 0;
}
function validateLatest(value) {
  if (!value || value.schema !== "psflowbridge.latest/1" || value.productId !== "PSFlowBridge"
      || value.channel !== "stable" || !versionParts(value.version)
      || !/^[a-f0-9]{16}$/.test(value.buildId || "")
      || value.mainActionShareCode !== SHARE_CODE) throw new Error("Invalid stable release descriptor");
  // Only identity is consumed. Remote descriptors cannot supply executable URLs.
  return { version: value.version, buildId: value.buildId, mainActionShareCode: SHARE_CODE };
}
function readLatest(url) {
  return new Promise((resolve, reject) => {
    const request = https.get(url, {headers: {Accept: "application/json", "User-Agent": "PSFlowBridge-update"}}, response => {
      if (response.statusCode !== 200) {
        response.resume();
        reject(new Error("Release descriptor unavailable"));
        return;
      }
      let size = 0;
      const chunks = [];
      response.on("data", chunk => {
        size += chunk.length;
        if (size > 32768) request.destroy(new Error("Release descriptor too large"));
        else chunks.push(chunk);
      });
      response.on("end", () => {
        try { resolve(JSON.parse(Buffer.concat(chunks).toString("utf8").replace(/^\uFEFF/, ""))); }
        catch (error) { reject(error); }
      });
      response.on("error", reject);
    });
    // A wall-clock deadline also bounds DNS/TLS and slow response bodies.
    const deadline = setTimeout(() => request.destroy(new Error("Release check timed out")), 2500);
    request.on("error", reject);
    request.on("close", () => clearTimeout(deadline));
  });
}
function createUpdateChecker({version, buildId, fetchLatest = readLatest, now = Date.now}) {
  let cached = null, expires = 0, pending = null;
  return function check() {
    if (cached && now() < expires) return Promise.resolve(cached);
    if (pending) return pending;
    pending = (async () => {
      const currentBuildId = typeof buildId === "function" ? buildId() : buildId;
      const current = {currentVersion: version, currentBuildId: currentBuildId || ""};
      for (const source of SOURCES) {
        try {
          const latest = validateLatest(await fetchLatest(source));
          cached = {ok: true, ...current, targetVersion: latest.version, targetBuildId: latest.buildId,
            available: /^[a-f0-9]{16}$/.test(current.currentBuildId) && compareVersions(latest.version, version) === 1,
            actionShareCode: SHARE_CODE, requiresComponents: false};
          expires = now() + 15 * 60 * 1000;
          return cached;
        } catch (_) { /* Try the second fixed distribution source. */ }
      }
      cached = {ok: false, ...current, available: false, code: "update_check_unavailable"};
      expires = now() + 60 * 1000;
      return cached;
    })().finally(() => { pending = null; });
    return pending;
  };
}

module.exports = {createUpdateChecker, validateLatest, compareVersions, SHARE_CODE};
