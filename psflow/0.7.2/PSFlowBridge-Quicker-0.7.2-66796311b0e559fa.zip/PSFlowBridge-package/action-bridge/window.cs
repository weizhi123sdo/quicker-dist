// Only the panel HWND returned by WebView2 may be controlled. Foreground lookup is read-only.
public class PsFlowPanelWindow
{
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool IsWindow(System.IntPtr hwnd);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern System.IntPtr GetAncestor(System.IntPtr hwnd, uint flags);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(System.IntPtr hwnd, out uint pid);
    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint="GetWindowLongW")] static extern int GetStyle(System.IntPtr hwnd, int index);
    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint="SetWindowLongW")] static extern int SetStyle(System.IntPtr hwnd, int index, int style);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool SetWindowPos(System.IntPtr hwnd, System.IntPtr after, int x, int y, int w, int h, uint flags);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ReleaseCapture();
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool PostMessage(System.IntPtr hwnd, uint message, System.IntPtr wp, System.IntPtr lp);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool ShowWindow(System.IntPtr hwnd, int command);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool GetWindowRect(System.IntPtr hwnd, out Rect rect);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetDpiForWindow(System.IntPtr hwnd);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern uint GetDpiForSystem();
    [System.Runtime.InteropServices.DllImport("user32.dll", EntryPoint="GetMonitorInfoW", CharSet=System.Runtime.InteropServices.CharSet.Unicode)] static extern bool GetMonitorInfo(System.IntPtr monitor, ref MonitorInfo info);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern System.IntPtr MonitorFromWindow(System.IntPtr hwnd, uint flags);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern System.IntPtr MonitorFromPoint(Point point, uint flags);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern bool GetCursorPos(out CursorPoint point);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern short GetAsyncKeyState(int key);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern System.IntPtr GetForegroundWindow();
    struct CursorPoint { public int X, Y; }
    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern System.IntPtr CreateRoundRectRgn(int left, int top, int right, int bottom, int ellipseWidth, int ellipseHeight);
    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern System.IntPtr CreateRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect);
    [System.Runtime.InteropServices.DllImport("gdi32.dll")] static extern bool DeleteObject(System.IntPtr value);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern int SetWindowRgn(System.IntPtr hwnd, System.IntPtr region, bool redraw);
    [System.Runtime.InteropServices.DllImport("user32.dll")] static extern int GetWindowRgn(System.IntPtr hwnd, System.IntPtr hRgn);
    [System.Runtime.InteropServices.DllImport("dwmapi.dll")] static extern int DwmSetWindowAttribute(System.IntPtr hwnd, int attribute, ref int value, int size);
    [System.Runtime.InteropServices.DllImport("dwmapi.dll")] static extern int DwmExtendFrameIntoClientArea(System.IntPtr hwnd, ref Margins margins);
    struct Rect { public int Left, Top, Right, Bottom; }
    struct Margins { public int Left, Right, Top, Bottom; }
    struct Point { public int X, Y; }
    [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
    struct MonitorInfo {
        public int Size; public Rect Monitor; public Rect Work; public uint Flags;
    }
    
    class PanelState {
        public System.Windows.Window Window;
        public System.Windows.Threading.DispatcherTimer Timer;
        public bool AutoCollapse, Collapsed;
        public double Left, Top, Width, Height;
        // Capsule position is remembered separately so expanding keeps the
        // capsule where the user left it instead of jumping to a stale corner.
        public double CollapsedLeft, CollapsedTop;
        public System.DateTime InteractionProtectedUntil;
        public System.IntPtr Handle;
        public System.DateTime OutsideSince, InsideSince, SettledAfter;
        public Quicker.Public.IStepContext Context;
    }
    static readonly System.Collections.Generic.Dictionary<long, PanelState> Panels = new System.Collections.Generic.Dictionary<long, PanelState>();

    // ---- DPI and work-area helpers -------------------------------------
    // WPF positions/sizes are device-independent pixels (DIPs). GetWindowRect,
    // GetMonitorInfo and SetWindowPos all speak physical pixels. The two must be
    // converted with the window's own DPI, otherwise a 150% monitor puts the
    // panel in the wrong place or reports a size that never matches the probe.
    static double DpiScale(System.IntPtr hwnd) {
        uint dpi = 0;
        try { dpi = GetDpiForWindow(hwnd); } catch { }
        if (dpi == 0) { try { dpi = GetDpiForSystem(); } catch { } }
        if (dpi == 0) dpi = 96;
        return dpi / 96.0;
    }
    static int DipToPx(System.IntPtr hwnd, double dip) { return (int)System.Math.Round(dip * DpiScale(hwnd)); }
    static double PxToDip(System.IntPtr hwnd, int px) { return px / DpiScale(hwnd); }
    static bool TryWorkArea(System.IntPtr hwnd, out Rect work) {
        work = new Rect();
        System.IntPtr monitor = System.IntPtr.Zero;
        try { monitor = MonitorFromWindow(hwnd, 2); } catch { } // MONITOR_DEFAULTTONEAREST
        if (monitor == System.IntPtr.Zero) return false;
        var info = new MonitorInfo();
        info.Size = System.Runtime.InteropServices.Marshal.SizeOf(typeof(MonitorInfo));
        if (!GetMonitorInfo(monitor, ref info)) return false;
        work = info.Work;
        return work.Right > work.Left && work.Bottom > work.Top;
    }
    // Keep a window inside a usable work area. Called after setup, after every
    // expand/collapse and when a monitor disappears: a window that was placed on
    // a disconnected monitor is pulled back instead of staying unreachable.
    static void ClampToWorkArea(PanelState state) {
        var w = state.Window;
        if (w == null || w.WindowState != System.Windows.WindowState.Normal) return;
        if (GetAsyncKeyState(1) < 0 || System.Windows.Input.Mouse.Captured != null ||
            System.DateTime.UtcNow < state.InteractionProtectedUntil) return;
        var source = System.Windows.PresentationSource.FromVisual(w) as System.Windows.Interop.HwndSource;
        if (source == null || source.Handle == System.IntPtr.Zero) return;
        System.IntPtr hwnd = source.Handle;
        Rect work;
        if (!TryWorkArea(hwnd, out work)) return;
        Rect current;
        if (!GetWindowRect(hwnd, out current)) return;
        int width = current.Right - current.Left, height = current.Bottom - current.Top;
        if (width < 1 || height < 1) return;
        // The panel's full bounding rectangle must stay entirely within the usable work area
        // so header buttons, close controls and edge margins are not clipped.
        int workWidth = work.Right - work.Left, workHeight = work.Bottom - work.Top;
        double dipWorkWidth = PxToDip(hwnd, workWidth), dipWorkHeight = PxToDip(hwnd, workHeight);
        if (width > workWidth) {
            w.MaxWidth = dipWorkWidth;
            w.Width = w.MaxWidth;
            width = workWidth;
        } else {
            w.MaxWidth = dipWorkWidth;
        }
        if (height > workHeight) {
            w.MaxHeight = dipWorkHeight;
            w.Height = w.MaxHeight;
            height = workHeight;
        } else {
            w.MaxHeight = dipWorkHeight;
        }
        int overlapX = System.Math.Min(current.Right, work.Right) - System.Math.Max(current.Left, work.Left);
        int overlapY = System.Math.Min(current.Bottom, work.Bottom) - System.Math.Max(current.Top, work.Top);
        bool visible = overlapX >= 40 && overlapY >= 24 && current.Right <= work.Right && current.Bottom <= work.Bottom && current.Left >= work.Left && current.Top >= work.Top;
        if (visible) return;
        int left = System.Math.Max(work.Left, System.Math.Min(current.Left, work.Right - width));
        int top = System.Math.Max(work.Top, System.Math.Min(current.Top, work.Bottom - height));
        // Write the corrected physical rect back through WPF DIPs so the next
        // SizeChanged/StateChanged pass sees a consistent position.
        double dipLeft = PxToDip(hwnd, left), dipTop = PxToDip(hwnd, top);
        w.Left = dipLeft; w.Top = dipTop;
        state.Left = dipLeft; state.Top = dipTop;
        if (state.Collapsed) { state.CollapsedLeft = dipLeft; state.CollapsedTop = dipTop; }
        SetWindowPos(hwnd, System.IntPtr.Zero, left, top, 0, 0, 0x0015); // NOSIZE | NOZORDER | NOACTIVATE
    }
    static bool PhotoshopIsForeground() {
        uint foregroundPid;
        GetWindowThreadProcessId(GetForegroundWindow(), out foregroundPid);
        try {
            using(var process=System.Diagnostics.Process.GetProcessById((int)foregroundPid))
                return string.Equals(process.ProcessName,"Photoshop",System.StringComparison.OrdinalIgnoreCase);
        } catch { return false; }
    }
    static void SetCollapsed(PanelState state, bool collapsed) {
        if (state.Collapsed == collapsed) return;
        var w=state.Window;
        if (collapsed) {
            if (w.WindowState != System.Windows.WindowState.Normal) return;
            state.Left=w.Left;state.Top=w.Top;state.Width=w.Width;state.Height=w.Height;
            state.Collapsed=true;
            w.MinWidth=0;w.MinHeight=0;w.Width=220;w.Height=48;
            // Keep the capsule anchored to the same right edge as the panel.
            w.Left=state.Left+state.Width-w.Width;
            state.CollapsedLeft=w.Left;state.CollapsedTop=w.Top;
        } else {
            // Preserve moves made while collapsed; restore around its current right edge.
            double right=w.Left+w.Width;
            state.Collapsed=false;w.Width=state.Width;w.Height=state.Height;
            w.Left=right-w.Width;
        }
        ClampToWorkArea(state);
        state.OutsideSince=state.InsideSince=System.DateTime.MinValue;
        state.SettledAfter=System.DateTime.UtcNow.AddMilliseconds(650);
        var source=System.Windows.PresentationSource.FromVisual(w) as System.Windows.Interop.HwndSource;
        if(source!=null)UpdateWindowRegion(source.Handle);
    }
    static PanelState ConfigurePanel(System.Windows.Window w, long handle, Quicker.Public.IStepContext context) {
        PanelState state;
        if(Panels.TryGetValue(handle,out state))return state;
        state=new PanelState {Window=w,Handle=new System.IntPtr(handle),Context=context,AutoCollapse=context.ReadState("panelAutoCollapse","true")=="true"};
        w.Topmost=context.ReadState("panelTopmost","false")=="true";
        state.Timer=new System.Windows.Threading.DispatcherTimer {Interval=System.TimeSpan.FromMilliseconds(50)};
        state.Timer.Tick+=(sender,args)=>{
            if(!w.IsVisible||w.WindowState!=System.Windows.WindowState.Normal)return;
            // Recover a panel left on a disconnected/changed monitor. This is a
            // cheap rect comparison and also covers DPI changes after a drag
            // between monitors with different scale factors.
            ClampToWorkArea(state);
            // Collapsed panels expand only on click, so they need no hover/foreground probes.
            if(!state.AutoCollapse||state.Collapsed){state.OutsideSince=System.DateTime.MinValue;return;}
            var now=System.DateTime.UtcNow;
            if(now<state.SettledAfter)return;
            Rect rect;CursorPoint cursor;
            if(!GetWindowRect(state.Handle,out rect)||!GetCursorPos(out cursor))return;
            // WebView2 owns child HWNDs: WPF IsMouseOver/MouseLeave are not reliable here.
            bool inside=cursor.X>=rect.Left-5&&cursor.X<rect.Right+5&&cursor.Y>=rect.Top-5&&cursor.Y<rect.Bottom+5;
            bool held=GetAsyncKeyState(1)<0||GetAsyncKeyState(2)<0||GetAsyncKeyState(4)<0||System.Windows.Input.Mouse.Captured!=null;
            if(inside){
                state.OutsideSince=System.DateTime.MinValue;
                if(state.InsideSince==System.DateTime.MinValue)state.InsideSince=now;
                // Hover no longer auto-expands; only click via panel-capsule expand.
            }else{
                state.InsideSince=System.DateTime.MinValue;
                if(held||now<state.InteractionProtectedUntil){
                    state.OutsideSince=System.DateTime.MinValue;return;
                }
                if(state.OutsideSince==System.DateTime.MinValue)state.OutsideSince=now;
                if(state.AutoCollapse&&!state.Collapsed&&(now-state.OutsideSince).TotalMilliseconds>=350)SetCollapsed(state,true);
            }
        };
        state.Timer.Start();
        w.Closed+=(sender,args)=>{state.Timer.Stop();Panels.Remove(handle);};
        Panels[handle]=state;
        // Keep one window owner across separately compiled setup and command scripts.
        w.Resources["PSFlowPanel.WindowCommand"] = new System.Func<Quicker.Public.IStepContext, object>(Exec);
        return state;
    }

    static void UpdateWindowRegion(System.IntPtr hwnd)
    {
        if (!IsWindow(hwnd)) return;
        Rect rect;
        if (!GetWindowRect(hwnd, out rect)) return;
        // CreateRoundRectRgn takes an exclusive right/bottom edge, exactly like
        // CreateRectRgn. Passing width + 1 leaves a 1px dark sliver on the
        // right and bottom edges of the capsule.
        int w = rect.Right - rect.Left;
        int h = rect.Bottom - rect.Top;
        if (w < 1 || h < 1) return;
        int diameter = (int)System.Math.Round(24.0 * GetDpiForWindow(hwnd) / 96.0);
        var region = CreateRoundRectRgn(0, 0, w, h, diameter, diameter);
        if (region != System.IntPtr.Zero && SetWindowRgn(hwnd, region, true) == 0) DeleteObject(region);
    }

    // Quicker's WebView2Window template nests Border/ContentPresenter/Grid/
    // Decorator containers between the window and the WebView2 control. Their
    // default insets expose the window background as a dark frame, so every
    // chrome container down to the WebView2 host must sit flush at 0.
    static void ZeroContainerInsets(System.Windows.DependencyObject root)
    {
        ZeroContainerInsets(root, 0);
    }

    static void ZeroContainerInsets(System.Windows.DependencyObject root, int depth)
    {
        if (root == null || depth > 64) return;
        try {
            var fe = root as System.Windows.FrameworkElement;
            if (fe != null) fe.Margin = new System.Windows.Thickness(0);
            var ctrl = root as System.Windows.Controls.Control;
            if (ctrl != null) {
                ctrl.Padding = new System.Windows.Thickness(0);
                ctrl.BorderThickness = new System.Windows.Thickness(0);
            }
            var bd = root as System.Windows.Controls.Border;
            if (bd != null) {
                bd.Padding = new System.Windows.Thickness(0);
                bd.BorderThickness = new System.Windows.Thickness(0);
                bd.CornerRadius = new System.Windows.CornerRadius(0);
            }
            var dec = root as System.Windows.Controls.Decorator;
            if (dec != null) dec.Margin = new System.Windows.Thickness(0);
            // The hosting window type is itself called WebView2Window, so a plain
            // name match would stop the walk at the root. Only the embedded
            // control counts, and only Control subclasses can be one.
            bool isWebView2Control = root is System.Windows.Controls.Control
                && !(root is System.Windows.Window)
                && root.GetType().Name.IndexOf("WebView2", System.StringComparison.Ordinal) >= 0;
            if (isWebView2Control) {
                try {
                    var prop = root.GetType().GetProperty("DefaultBackgroundColor");
                    if (prop != null && prop.CanWrite) {
                        var colorType = prop.PropertyType;
                        if (colorType == typeof(System.Windows.Media.Color)) {
                            prop.SetValue(root, System.Windows.Media.Color.FromRgb(38, 40, 43), null);
                        } else if (colorType.FullName == "System.Drawing.Color") {
                            // Resolved by name so this script needs no System.Drawing reference.
                            var fromArgb = colorType.GetMethod("FromArgb", new System.Type[] { typeof(int), typeof(int), typeof(int) });
                            if (fromArgb != null) prop.SetValue(root, fromArgb.Invoke(null, new object[] { 38, 40, 43 }), null);
                        }
                    }
                } catch { }
                return;
            }
            int count = System.Windows.Media.VisualTreeHelper.GetChildrenCount(root);
            for (int i = 0; i < count; i++) {
                System.Windows.DependencyObject child = null;
                try { child = System.Windows.Media.VisualTreeHelper.GetChild(root, i); } catch { }
                if (child != null) ZeroContainerInsets(child, depth + 1);
            }
        } catch { }
    }

    static void FitPanelContent(System.Windows.Window window) {
        // Keep Quicker's chrome object and handlers, but remove its template inset.
        window.ApplyTemplate();
        if (System.Windows.Media.VisualTreeHelper.GetChildrenCount(window) > 0) {
            var frame = System.Windows.Media.VisualTreeHelper.GetChild(window, 0) as System.Windows.FrameworkElement;
            if (frame != null) frame.Margin = new System.Windows.Thickness(0);
        }
        var layout = window.FindName("Layout") as System.Windows.FrameworkElement;
        if (layout != null) layout.Margin = new System.Windows.Thickness(0);
        // Walk the whole chrome chain so no nested Border/ContentPresenter/Grid
        // keeps a template inset that would show up as a dark ring.
        ZeroContainerInsets(window);
    }

    public static object Exec(Quicker.Public.IStepContext context)
    {
        string operation = "setup";
        try { operation = ((string)context.GetVarValue("operation")) ?? "setup"; } catch { }
        bool setup = operation == "setup";
        string handleText = setup ? ((string)context.GetVarValue("panelWindow")) : context.ReadState("panelWindow", null);
        long handle;
        if (!long.TryParse(handleText, out handle) || handle == 0) throw new System.Exception("面板窗口尚未就绪。");
        var hwnd = GetAncestor(new System.IntPtr(handle), 2);
        uint pid;
        GetWindowThreadProcessId(hwnd, out pid);
        if (!IsWindow(hwnd) || pid != (uint)System.Diagnostics.Process.GetCurrentProcess().Id)
            throw new System.Exception("面板窗口已关闭，请重新打开动作。");
        if (setup) {
            context.WriteState("panelWindow", hwnd.ToInt64().ToString());
            var source = System.Windows.Interop.HwndSource.FromHwnd(hwnd);
            var window = source == null ? null : source.RootVisual as System.Windows.Window;
            if (window != null) {
                // Quicker state-change handler needs this object; never detach it.
                var chrome = System.Windows.Shell.WindowChrome.GetWindowChrome(window);
                if (chrome != null) {
                    chrome.NonClientFrameEdges = System.Windows.Shell.NonClientFrameEdges.None;
                    chrome.CaptionHeight = 0;
                    chrome.GlassFrameThickness = new System.Windows.Thickness(0);
                    chrome.ResizeBorderThickness = new System.Windows.Thickness(0);
                    chrome.CornerRadius = new System.Windows.CornerRadius(12);
                }
                window.WindowStyle = System.Windows.WindowStyle.None;
                window.ResizeMode = System.Windows.ResizeMode.NoResize;
                window.MinWidth=0; window.MinHeight=0;
                window.Width = 380; window.Height = 680; // WPF DIPs, including 150% monitors.
                window.BorderThickness = new System.Windows.Thickness(0);
                window.Padding = new System.Windows.Thickness(0);
                window.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(38, 40, 43));
                
                var content = window.Content as System.Windows.FrameworkElement;
                if (content != null) {
                    content.Margin = new System.Windows.Thickness(0);
                }
                
                ConfigurePanel(window, hwnd.ToInt64(), context);
                window.SizeChanged -= Window_SizeChanged;
                window.StateChanged -= Window_StateChanged;
                window.SizeChanged += Window_SizeChanged;
                window.StateChanged += Window_StateChanged;
                // The initial placement may be off-screen on a mixed-DPI setup.
                ClampToWorkArea(ConfigurePanel(window, hwnd.ToInt64(), context));
            }
            SetStyle(hwnd, -16, GetStyle(hwnd, -16) & ~0x00C40000); // WS_CAPTION | WS_THICKFRAME
            SetWindowPos(hwnd, System.IntPtr.Zero, 0, 0, 0, 0, 0x0037); // FRAMECHANGED, no move/size/z-order/activate
            int preference = 2;
            try {
                DwmSetWindowAttribute(hwnd, 33, ref preference, 4);
                int borderColor = -2; // DWMWA_COLOR_NONE: suppress DWM light border.
                DwmSetWindowAttribute(hwnd, 34, ref borderColor, 4);
                var margins = new Margins();
                DwmExtendFrameIntoClientArea(hwnd, ref margins);
            } catch (System.EntryPointNotFoundException) { }
            
            if (window != null) { FitPanelContent(window); window.UpdateLayout(); }
            UpdateWindowRegion(hwnd);
            return true;
        }
        var panelSource=System.Windows.Interop.HwndSource.FromHwnd(hwnd);
        var panelWindow=panelSource==null?null:panelSource.RootVisual as System.Windows.Window;
        if (panelWindow != null) {
            var owner = panelWindow.Resources["PSFlowPanel.WindowCommand"] as System.Func<Quicker.Public.IStepContext, object>;
            if (owner != null && owner.Method.DeclaringType != typeof(PsFlowPanelWindow)) return owner(context);
        }
        PanelState panelState=null;
        if(panelWindow!=null)panelState=ConfigurePanel(panelWindow,hwnd.ToInt64(),context);
        if(operation=="toggle-topmost"&&panelWindow!=null){
            panelWindow.Topmost=!panelWindow.Topmost;
            context.WriteState("panelTopmost",panelWindow.Topmost?"true":"false");
        } else if(operation=="toggle-autocollapse"&&panelState!=null){
            panelState.AutoCollapse=!panelState.AutoCollapse;panelState.OutsideSince=System.DateTime.MinValue;
            context.WriteState("panelAutoCollapse",panelState.AutoCollapse?"true":"false");
            if(!panelState.AutoCollapse)SetCollapsed(panelState,false);
        } else if(operation=="collapse"&&panelState!=null)SetCollapsed(panelState,true);
        else if(operation=="expand"&&panelState!=null){SetCollapsed(panelState,false);}
        else if(operation=="protect"&&panelState!=null){
            panelState.InteractionProtectedUntil=System.DateTime.UtcNow.AddMilliseconds(1500);
            panelState.OutsideSince=System.DateTime.MinValue;
        }
        else if(operation=="unprotect"&&panelState!=null){
            panelState.InteractionProtectedUntil=System.DateTime.MinValue;
            panelState.OutsideSince=System.DateTime.MinValue;
        }
        else if (operation.StartsWith("drag:", System.StringComparison.Ordinal)) {
            var anchor = operation.Split(':');
            int offsetX, offsetY; CursorPoint cursor;
            if (anchor.Length != 3 || !int.TryParse(anchor[1], out offsetX) || !int.TryParse(anchor[2], out offsetY))
                throw new System.Exception("窗口拖动位置无效。");
            // Preserve the initial grab point even when the bridge runs after a quick release.
            if (GetCursorPos(out cursor))
                SetWindowPos(hwnd, System.IntPtr.Zero, cursor.X-DipToPx(hwnd,offsetX), cursor.Y-DipToPx(hwnd,offsetY), 0, 0, 0x0015);
            ReleaseCapture();
            if (GetAsyncKeyState(1) < 0) PostMessage(hwnd, 0x00A1, new System.IntPtr(2), System.IntPtr.Zero);
        }
        else if (operation == "drag") { ReleaseCapture(); PostMessage(hwnd, 0x00A1, new System.IntPtr(2), System.IntPtr.Zero); }
        else if (operation == "minimize") ShowWindow(hwnd, 6);
        else if (operation == "close") PostMessage(hwnd, 0x0010, System.IntPtr.Zero, System.IntPtr.Zero);
        else if (operation == "probe-state") { ShowWindow(hwnd, 6); ShowWindow(hwnd, 9); }
        else if (operation == "restore") { UpdateWindowRegion(hwnd); }
        else if (operation != "probe") throw new System.Exception("不支持的窗口操作。");
        
        bool hasRgn = false;
        System.IntPtr hRgn = CreateRectRgn(0, 0, 0, 0);
        if (hRgn != System.IntPtr.Zero) {
            if (GetWindowRgn(hwnd, hRgn) == 3) hasRgn = true; // COMPLEXREGION: a plain rectangle is not rounded.
            DeleteObject(hRgn);
        }

        Rect bounds;GetWindowRect(hwnd,out bounds);CursorPoint pointer;GetCursorPos(out pointer);
        bool cursorInside=pointer.X>=bounds.Left&&pointer.X<bounds.Right&&pointer.Y>=bounds.Top&&pointer.Y<bounds.Bottom;
        Rect work;bool hasWork=TryWorkArea(hwnd,out work);
        bool onWorkArea=hasWork&&bounds.Left>=work.Left&&bounds.Right<=work.Right
            &&bounds.Top>=work.Top&&bounds.Bottom<=work.Bottom;
        context.SetVarValue("response", "{\"ok\":true,\"frameless\":" +
            ((GetStyle(hwnd, -16) & 0x00C40000) == 0 ? "true" : "false") + ",\"rounded\":" +
            (hasRgn ? "true" : "false") + ",\"topmost\":"+(panelWindow!=null&&panelWindow.Topmost?"true":"false")+
            ",\"autoCollapse\":"+(panelState!=null&&panelState.AutoCollapse?"true":"false")+
            ",\"collapsed\":"+(panelState!=null&&panelState.Collapsed?"true":"false")+
            ",\"left\":"+bounds.Left+",\"top\":"+bounds.Top+",\"right\":"+bounds.Right+",\"bottom\":"+bounds.Bottom+
            ",\"cursorInside\":"+(cursorInside?"true":"false")+
            ",\"dpiScale\":"+DpiScale(hwnd).ToString(System.Globalization.CultureInfo.InvariantCulture)+
            ",\"onWorkArea\":"+(onWorkArea?"true":"false")+
            ",\"workArea\":"+(hasWork?("{\"left\":"+work.Left+",\"top\":"+work.Top+",\"right\":"+work.Right+",\"bottom\":"+work.Bottom+"}"):"null")+"}");
        return true;
    }
    
    private static void Window_SizeChanged(object sender, System.Windows.SizeChangedEventArgs e) {
        var window = sender as System.Windows.Window;
        if (window != null) {
            FitPanelContent(window);
            var source = System.Windows.PresentationSource.FromVisual(window) as System.Windows.Interop.HwndSource;
            if (source != null && source.Handle != System.IntPtr.Zero) UpdateWindowRegion(source.Handle);
        }
    }
    
    private static void Window_StateChanged(object sender, System.EventArgs e) {
        var window = sender as System.Windows.Window;
        if (window != null && window.WindowState == System.Windows.WindowState.Normal) {
            var source = System.Windows.PresentationSource.FromVisual(window) as System.Windows.Interop.HwndSource;
            if (source != null && source.Handle != System.IntPtr.Zero) UpdateWindowRegion(source.Handle);
        }
    }
}
