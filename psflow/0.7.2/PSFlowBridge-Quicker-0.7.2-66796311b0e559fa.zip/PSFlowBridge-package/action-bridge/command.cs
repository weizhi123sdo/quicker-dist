var commandOperation = "";
try {
// User-clicked update opens the fixed official action page. Quicker owns the
// installation confirmation; a remote release descriptor cannot change this URL.
var commandInput = Newtonsoft.Json.Linq.JObject.Parse((string)context.GetVarValue("request"));
commandOperation = (string)commandInput["op"] ?? "";
if (commandOperation == "open-app-update") {
    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo {
        FileName = "https://getquicker.net/Sharedaction?code=a2de330f-df0b-412a-ba32-48383e3c055c",
        UseShellExecute = true
    });
    context.SetVarValue("response", new Newtonsoft.Json.Linq.JObject {
        ["ok"] = true, ["confirmationRequired"] = true, ["opened"] = "official-action-page"
    }.ToString(Newtonsoft.Json.Formatting.None));
    return true;
}
var root = context.ReadState("packageRoot", null);
if (string.IsNullOrWhiteSpace(root)) {
    context.SetVarValue("response", "{\"ok\":false,\"error\":\"请先启动 PS Flow 侧边助手。\"}");
    return false;
}
    var configPath = System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData), "PSFlowBridge", "config.json");
    var config = Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(configPath));
    var token = (string)config["pairingToken"];
    if (string.IsNullOrWhiteSpace(token)) throw new System.Exception("本地连接尚未准备好，请重新打开动作。");
    var request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://127.0.0.1:47831/api/action-command");
    request.Proxy = null;
    request.Method = "POST";
    request.Timeout = 90000;
    request.ReadWriteTimeout = 90000;
    request.ContentType = "application/json; charset=utf-8";
    request.Headers["Authorization"] = "Bearer " + token;
    var bytes = new System.Text.UTF8Encoding(false).GetBytes(((string)context.GetVarValue("request")));
    request.ContentLength = bytes.Length;
    using (var stream = request.GetRequestStream()) stream.Write(bytes, 0, bytes.Length);
    using (var response = request.GetResponse())
    using (var reader = new System.IO.StreamReader(response.GetResponseStream(), System.Text.Encoding.UTF8)) {
        var result = reader.ReadToEnd();
        Newtonsoft.Json.Linq.JObject.Parse(result);
        context.SetVarValue("response", result);
    }
    return true;
} catch (System.Net.WebException error) {
    var code = "(连接失败)"; var body = "";
    try {
        using (var er = error.Response as System.Net.HttpWebResponse) {
            if (er != null) {
                code = ((int)er.StatusCode).ToString();
                using (var reader = new System.IO.StreamReader(er.GetResponseStream(), System.Text.Encoding.UTF8)) body = reader.ReadToEnd();
            }
        }
    } catch { }
    var detail = body.Length > 120 ? body.Substring(0, 120) : body;
    context.SetVarValue("response", new Newtonsoft.Json.Linq.JObject {
        ["ok"] = false, ["error"] = "操作请求失败（HTTP " + code + "，路径 /api/action-command）" + (string.IsNullOrEmpty(detail) ? "" : "：" + detail),
        ["uncertain"] = true
    }.ToString(Newtonsoft.Json.Formatting.None));
    return false;
} catch (System.Exception error) {
    context.SetVarValue("response", new Newtonsoft.Json.Linq.JObject {
        ["ok"] = false,
        ["error"] = commandOperation == "open-app-update"
            ? "无法打开官方更新页，请稍后重试。 " + error.Message
            : "操作结果尚未确认，请查询当前任务。 " + error.Message,
        ["uncertain"] = commandOperation != "open-app-update"
    }.ToString(Newtonsoft.Json.Formatting.None));
    return false;
}
