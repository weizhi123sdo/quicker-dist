var request=Newtonsoft.Json.Linq.JObject.Parse(((string)context.GetVarValue("request")));
var dataRoot=System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),"PSFlowBridge");
using(var gate=new System.Threading.Mutex(false,@"Local\PSFlowBridge.ManagedFlow")) {
 bool owned=false;
 try {
  try{owned=gate.WaitOne(0);}catch(System.Threading.AbandonedMutexException){owned=true;}
  if(!owned)throw new System.Exception("Flow 正在处理任务，请完成后再下载高清图。");
    var view=context.GetVarValue("managedView");if(view==null)throw new System.Exception("内置 Flow 窗口未打开。");
    var config=Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(System.IO.Path.Combine(dataRoot,"config.json")));
    var token=(string)config["pairingToken"];
    System.Func<string,string,byte[],string,string> api=(route,method,bytes,mime)=>{
        var req=(System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://127.0.0.1:47831/api"+route);
        req.Proxy=null;req.Method=method;req.Timeout=30000;req.ReadWriteTimeout=30000;req.Headers["Authorization"]="Bearer "+token;
        if(bytes!=null){req.ContentType=mime;req.ContentLength=bytes.Length;using(var stream=req.GetRequestStream())stream.Write(bytes,0,bytes.Length);}
        try{using(var res=req.GetResponse())using(var reader=new System.IO.StreamReader(res.GetResponseStream(),System.Text.Encoding.UTF8))return reader.ReadToEnd();}
        catch(System.Net.WebException we){
            var code="(连接失败)";var body="";
            try{using(var er=we.Response as System.Net.HttpWebResponse){if(er!=null){code=((int)er.StatusCode).ToString();using(var r=new System.IO.StreamReader(er.GetResponseStream(),System.Text.Encoding.UTF8))body=r.ReadToEnd();}}}catch{}
            throw new System.Exception("请求失败（HTTP "+code+"，路径 "+route+"）"+(string.IsNullOrEmpty(body)?"":"："+(body.Length>200?body.Substring(0,200):body)));
        }
    };
    System.Func<string,Newtonsoft.Json.Linq.JObject> get=route=>Newtonsoft.Json.Linq.JObject.Parse(api(route,"GET",null,null));
    System.Action<string,Newtonsoft.Json.Linq.JObject> post=(route,body)=>api(route,"POST",System.Text.Encoding.UTF8.GetBytes(body.ToString(Newtonsoft.Json.Formatting.None)),"application/json");
    var root=context.ReadState("packageRoot",null);
    if(string.IsNullOrWhiteSpace(root)||!System.IO.File.Exists(System.IO.Path.Combine(root,"action-bridge","managed-flow.js"))){
        var apps=System.IO.Path.Combine(dataRoot,"apps");var build=System.IO.File.ReadAllText(System.IO.Path.Combine(apps,"current")).Trim();
        if(!System.Text.RegularExpressions.Regex.IsMatch(build,"^[0-9a-f]{16}(?:-repair-[0-9a-f]+)?$"))throw new System.Exception("内置浏览器版本未就绪。");
        root=System.IO.Path.Combine(apps,build,"PSFlowBridge-package");
    }
    var script=System.IO.File.ReadAllText(System.IO.Path.Combine(root,"action-bridge","managed-flow.js"));
    var dispatcher=(System.Windows.Threading.Dispatcher)view.GetType().GetProperty("Dispatcher").GetValue(view);
    System.Func<string,string,string> cdp=(method,payload)=>{
        System.Threading.Tasks.Task<string> pending=null;
        dispatcher.Invoke(new System.Action(()=>{
            var core=view.GetType().GetProperty("CoreWebView2").GetValue(view);
            if(core==null)throw new System.Exception("内置浏览器尚未初始化。");
            pending=(System.Threading.Tasks.Task<string>)core.GetType().GetMethod("CallDevToolsProtocolMethodAsync",new System.Type[]{typeof(string),typeof(string)}).Invoke(core,new object[]{method,payload});
        }));
        if(!pending.Wait(60000))throw new System.Exception("网页读取超时；不会重新提交。");
        return pending.GetAwaiter().GetResult();
    };
    System.Func<string,Newtonsoft.Json.Linq.JObject,Newtonsoft.Json.Linq.JObject> page=(operation,arg)=>{
        var expression="(()=>{"+script+";return psfbManaged;})()("+Newtonsoft.Json.JsonConvert.SerializeObject(operation)+","+arg.ToString(Newtonsoft.Json.Formatting.None)+")";
        var raw=Newtonsoft.Json.Linq.JObject.Parse(cdp("Runtime.evaluate",new Newtonsoft.Json.Linq.JObject {["expression"]=expression,["returnByValue"]=true,["awaitPromise"]=true}.ToString(Newtonsoft.Json.Formatting.None)));
        if(raw["exceptionDetails"]!=null)throw new System.Exception(((string)raw["exceptionDetails"]["exception"]?["description"]??"网页执行失败").Substring(0,System.Math.Min(500,((string)raw["exceptionDetails"]["exception"]?["description"]??"网页执行失败").Length)));
        if(raw["error"]!=null)throw new System.Exception("内置浏览器通信失败。");
        return raw["result"]?["value"] as Newtonsoft.Json.Linq.JObject ?? new Newtonsoft.Json.Linq.JObject();
    };

    var id=(string)request["id"];
    if(!System.Text.RegularExpressions.Regex.IsMatch(id??"","^[0-9a-f-]{36}$"))throw new System.Exception("任务编号无效。");
    var job=get("/jobs/"+id)["job"];
    if((string)job["status"]!="ready"&&(string)job["status"]!="imported")throw new System.Exception("请等待结果就绪后再下载。");
    int index=(int)job["selectedIndex"];
    if((int?)request["index"]!=index)throw new System.Exception("所选图片已变化，请重新选择。");
    Newtonsoft.Json.Linq.JToken selected=null;
    foreach(var image in (Newtonsoft.Json.Linq.JArray)job["images"])if((int)image["index"]==index)selected=image;
    if(selected==null||(string)selected["sha256"]!=(string)request["sha256"])throw new System.Exception("图片预览已变化，请刷新后重试。");
    var asset=(string)selected["flowAssetKey"];var project=(string)selected["flowProject"];
    if(string.IsNullOrEmpty(asset)||string.IsNullOrEmpty(project))throw new System.Exception("这条历史记录缺少 Flow 原图定位，请在 Flow 中选择原图下载。新生成的结果会自动支持高清下载。");
    if((bool?)get("/health")["busy"]==true)throw new System.Exception("请等待当前任务处理完成后再下载。");
    var info=page("probe",new Newtonsoft.Json.Linq.JObject());
    if((string)info["project"]!=project){
        page("hdOpenProject",new Newtonsoft.Json.Linq.JObject{["project"]=project});
        var deadline=System.DateTime.UtcNow.AddSeconds(25);
        do{System.Threading.Thread.Sleep(500);info=page("probe",new Newtonsoft.Json.Linq.JObject());}while((string)info["project"]!=project&&System.DateTime.UtcNow<deadline);
        System.Threading.Thread.Sleep(1000);
    }
    var arg=new Newtonsoft.Json.Linq.JObject{["assetKey"]=asset,["resolution"]=request["resolution"]};
    var operation=(string)request["operation"]=="download"?"hdDownload":"hdCapabilities";
    Newtonsoft.Json.Linq.JObject result;
    if(operation=="hdCapabilities")result=page(operation,arg);
    else {
        object core=null,downloadOperation=null;System.Reflection.EventInfo downloadEvent=null;System.Delegate handler=null;
        string downloadPath=null,downloadError=null;
        using(var started=new System.Threading.ManualResetEventSlim(false)) {
            System.Action<object> callback=eventArgs=>{
                try {
                var folder=System.IO.Path.Combine(dataRoot,"cache","hd-incoming");
                System.IO.Directory.CreateDirectory(folder);
                var suggested=(string)eventArgs.GetType().GetProperty("ResultFilePath").GetValue(eventArgs);
                var extension=System.IO.Path.GetExtension(suggested);if(string.IsNullOrEmpty(extension))extension=".png";
                downloadPath=System.IO.Path.Combine(folder,"PSFlow-"+id.Substring(0,8)+"-"+index+"-"+(string)request["resolution"]+"-"+System.Guid.NewGuid().ToString("N").Substring(0,6)+extension);
                eventArgs.GetType().GetProperty("ResultFilePath").SetValue(eventArgs,downloadPath);
                eventArgs.GetType().GetProperty("Handled").SetValue(eventArgs,true);
                downloadOperation=eventArgs.GetType().GetProperty("DownloadOperation").GetValue(eventArgs);started.Set();
                }catch(System.Exception error){downloadError=error.Message;started.Set();}
            };
            try {
                dispatcher.Invoke(new System.Action(()=>{
                    core=view.GetType().GetProperty("CoreWebView2").GetValue(view);
                    downloadEvent=core.GetType().GetEvent("DownloadStarting");
                    if(downloadEvent==null)throw new System.Exception("当前 WebView2 不支持下载，请更新运行环境。");
                    var parameters=downloadEvent.EventHandlerType.GetMethod("Invoke").GetParameters();
                    var sender=System.Linq.Expressions.Expression.Parameter(parameters[0].ParameterType,"sender");
                    var args=System.Linq.Expressions.Expression.Parameter(parameters[1].ParameterType,"args");
                    var body=System.Linq.Expressions.Expression.Call(System.Linq.Expressions.Expression.Constant(callback),callback.GetType().GetMethod("Invoke"),System.Linq.Expressions.Expression.Convert(args,typeof(object)));
                    handler=System.Linq.Expressions.Expression.Lambda(downloadEvent.EventHandlerType,body,new[]{sender,args}).Compile();
                    downloadEvent.AddEventHandler(core,handler);
                }));
                result=page(operation,arg);
                if(!started.Wait(120000))throw new System.Exception("Flow 尚未开始下载，请在网页核对；未重复请求高清处理。");
                if(downloadError!=null)throw new System.Exception("无法保存高清下载："+downloadError);
                var deadline=System.DateTime.UtcNow.AddMinutes(3);string downloadState="";
                do {
                    dispatcher.Invoke(new System.Action(()=>downloadState=downloadOperation.GetType().GetProperty("State").GetValue(downloadOperation).ToString()));
                    if(downloadState=="Completed"||downloadState=="Interrupted")break;
                    System.Threading.Thread.Sleep(300);
                }while(System.DateTime.UtcNow<deadline);
                if(downloadState!="Completed")throw new System.Exception("高清下载尚未完成，已保留下载记录，请查看 Flow 下载状态。");
                if(!System.IO.File.Exists(downloadPath)||new System.IO.FileInfo(downloadPath).Length==0)throw new System.Exception("未确认下载文件，请检查下载目录。");
                result=Newtonsoft.Json.Linq.JObject.Parse(api("/jobs/"+id+"/hd-upload?index="+index+"&sha256="+System.Uri.EscapeDataString((string)selected["sha256"])+"&resolution="+System.Uri.EscapeDataString((string)request["resolution"]),"POST",System.IO.File.ReadAllBytes(downloadPath),"application/octet-stream"));
                try{System.IO.File.Delete(downloadPath);}catch{}
            }finally{if(handler!=null)dispatcher.Invoke(new System.Action(()=>downloadEvent.RemoveEventHandler(core,handler)));}
        }
    }
    result["ok"]=true;context.SetVarValue("response",result.ToString(Newtonsoft.Json.Formatting.None));
 } catch(System.Exception error){context.SetVarValue("response",new Newtonsoft.Json.Linq.JObject{["ok"]=false,["error"]=error.Message}.ToString(Newtonsoft.Json.Formatting.None));}
 finally{if(owned)gate.ReleaseMutex();}
}
return true;
