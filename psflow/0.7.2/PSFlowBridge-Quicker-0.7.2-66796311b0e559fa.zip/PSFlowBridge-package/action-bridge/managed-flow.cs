// One background tick. The panel schedules ticks serially; a named mutex also
// excludes other panels. Job receipts are persisted before native input.
var dataRoot=System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),"PSFlowBridge");
var responseValue=new Newtonsoft.Json.Linq.JObject {["ok"]=true};
var id="";var armed=false;var owned=false;var phase="probe";
using(var gate=new System.Threading.Mutex(false,@"Local\PSFlowBridge.ManagedFlow")){
try {
    try {owned=gate.WaitOne(0);}catch(System.Threading.AbandonedMutexException){owned=true;}
    if(!owned){context.SetVarValue("response","{\"ok\":true,\"busy\":true}");return true;}
    // Missing or damaged settings use the same built-in defaults as the launcher.
    string savedMode=null,savedBrowser=null;
    try { savedMode=(string)Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(System.IO.Path.Combine(dataRoot,"mode.json")))["mode"]; } catch { }
    try { savedBrowser=(string)Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(System.IO.Path.Combine(dataRoot,"browser.json")))["browser"]; } catch { }
    if(savedMode=="local"||savedBrowser=="edge"||savedBrowser=="chrome"){context.SetVarValue("response","{\"ok\":true,\"inactive\":true}");return true;}
    var view=context.GetVarValue("managedView");if(view==null)throw new System.Exception("内置 Flow 窗口未打开。");
    var config=Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(System.IO.Path.Combine(dataRoot,"config.json")));
    var token=(string)config["pairingToken"];
    System.Func<string,string,byte[],string,string> api=(route,method,bytes,mime)=>{
        var req=(System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://127.0.0.1:47831/api"+route);
        req.Proxy=null;req.Method=method;req.Timeout=30000;req.ReadWriteTimeout=30000;req.Headers["Authorization"]="Bearer "+token;
        if(bytes!=null){req.ContentType=mime;req.ContentLength=bytes.Length;using(var stream=req.GetRequestStream())stream.Write(bytes,0,bytes.Length);}
        try{using(var res=req.GetResponse())using(var reader=new System.IO.StreamReader(res.GetResponseStream(),System.Text.Encoding.UTF8))return reader.ReadToEnd();}
        catch(System.Net.WebException we){
            var code="(连接失败)";var body="";
            try{using(var er=we.Response as System.Net.HttpWebResponse){if(er!=null){code=((int)er.StatusCode).ToString();using(var r=new System.IO.StreamReader(er.GetResponseStream(),System.Text.Encoding.UTF8))body=r.ReadToEnd();}}}catch{}
            throw new System.Exception("请求失败（HTTP "+code+"，路径 "+route+"）"+(string.IsNullOrEmpty(body)?"":"："+(body.Length>200?body.Substring(0,200):body)));
        }
    };
    System.Func<string,Newtonsoft.Json.Linq.JObject> get=route=>Newtonsoft.Json.Linq.JObject.Parse(api(route,"GET",null,null));
    System.Action<string,Newtonsoft.Json.Linq.JObject> post=(route,body)=>api(route,"POST",System.Text.Encoding.UTF8.GetBytes(body.ToString(Newtonsoft.Json.Formatting.None)),"application/json");
    var root=context.ReadState("packageRoot",null);
    if(string.IsNullOrWhiteSpace(root)||!System.IO.File.Exists(System.IO.Path.Combine(root,"action-bridge","managed-flow.js"))){
        var apps=System.IO.Path.Combine(dataRoot,"apps");var build=System.IO.File.ReadAllText(System.IO.Path.Combine(apps,"current")).Trim();
        if(!System.Text.RegularExpressions.Regex.IsMatch(build,"^[0-9a-f]{16}(?:-repair-[0-9a-f]+)?$"))throw new System.Exception("内置浏览器版本未就绪。");
        root=System.IO.Path.Combine(apps,build,"PSFlowBridge-package");
    }
    var script=System.IO.File.ReadAllText(System.IO.Path.Combine(root,"action-bridge","managed-flow.js"));
    var dispatcher=(System.Windows.Threading.Dispatcher)view.GetType().GetProperty("Dispatcher").GetValue(view);
    System.Func<string,string,string> cdp=(method,payload)=>{
        System.Threading.Tasks.Task<string> pending=null;
        dispatcher.Invoke(new System.Action(()=>{
            var core=view.GetType().GetProperty("CoreWebView2").GetValue(view);
            if(core==null)throw new System.Exception("内置浏览器尚未初始化。");
            pending=(System.Threading.Tasks.Task<string>)core.GetType().GetMethod("CallDevToolsProtocolMethodAsync",new System.Type[]{typeof(string),typeof(string)}).Invoke(core,new object[]{method,payload});
        }));
        if(!pending.Wait(60000))throw new System.Exception("网页读取超时；不会重新提交。");
        return pending.GetAwaiter().GetResult();
    };
    System.Func<string,Newtonsoft.Json.Linq.JObject,Newtonsoft.Json.Linq.JObject> page=(operation,arg)=>{
        var expression="(()=>{"+script+";return psfbManaged;})()("+Newtonsoft.Json.JsonConvert.SerializeObject(operation)+","+arg.ToString(Newtonsoft.Json.Formatting.None)+")";
        var raw=Newtonsoft.Json.Linq.JObject.Parse(cdp("Runtime.evaluate",new Newtonsoft.Json.Linq.JObject {["expression"]=expression,["returnByValue"]=true,["awaitPromise"]=true,["userGesture"]=operation=="submit"}.ToString(Newtonsoft.Json.Formatting.None)));
        if(raw["exceptionDetails"]!=null)throw new System.Exception(((string)raw["exceptionDetails"]["exception"]?["description"]??"网页执行失败").Substring(0,System.Math.Min(500,((string)raw["exceptionDetails"]["exception"]?["description"]??"网页执行失败").Length)));
        if(raw["error"]!=null)throw new System.Exception("内置浏览器通信失败。");
        return raw["result"]?["value"] as Newtonsoft.Json.Linq.JObject ?? new Newtonsoft.Json.Linq.JObject();
    };
    var empty=new Newtonsoft.Json.Linq.JObject();
    System.Action<Newtonsoft.Json.Linq.JObject,string> report=(v,stage)=>post("/flow-state",new Newtonsoft.Json.Linq.JObject{
        ["client"]="flow-tab-qkmanaged",["visible"]=true,["version"]="managed-1",["project"]=v["project"],["model"]=v["model"],["aspect"]=v["aspect"],
        ["dom"]=new Newtonsoft.Json.Linq.JObject{["editorFound"]=(bool?)v["editorFound"]==true},
        ["transferStage"]=v["transferStage"],["completedItems"]=v["completedItems"],["stage"]=stage,["percent"]=v["percent"],["jobID"]=string.IsNullOrEmpty(id)?null:id,["submissionSent"]=armed,["generationConfirmed"]=armed&&((int?)v["requests"]>0||(bool?)v["submitLocked"]==true||(int?)v["outputs"]>0)
    });
    var current=page("probe",empty);
    if((bool?)current["editorFound"]!=true){context.WriteState("managedLoginPending","true");page("enterProject",empty);responseValue["waitingProject"]=true;context.SetVarValue("response",responseValue.ToString(Newtonsoft.Json.Formatting.None));return true;}
    if(context.ReadState("managedLoginPending","true")=="true") {
        dispatcher.Invoke(new System.Action(()=>{
            var window=System.Windows.Window.GetWindow(view as System.Windows.DependencyObject);
            if(window!=null)window.Hide();
        }));
        context.WriteState("managedLoginPending","false");responseValue["loginHidden"]=true;
    }
    report(current,"ready");
    var health=get("/health");if((bool?)health["draining"]==true){context.SetVarValue("response","{\"ok\":true,\"draining\":true}");return true;}
    // Recovery for a job stranded in "unknown" (e.g. Flow took longer than the
    // submit poll window). The page still holds this client's last job and its
    // baseline; if every expected output is now on screen we harvest them only.
    // This path never attaches assets, never reconfigures and never clicks
    // generate, so a stranded job can never be submitted twice.
    var strandedId=(string)current["jobID"];
    // A page or panel reload clears window.__psfbManaged, so jobID is null exactly
    // when recovery matters most. Fall back to the one-shot submit receipts the
    // page persisted; they still carry the pre-submit baseline that readResults and
    // queryResults use, so harvesting remains possible without ever re-submitting.
    if(string.IsNullOrEmpty(strandedId)){
        // Discovery is also best-effort. A page that cannot list receipts (script
        // not yet re-injected after a navigation, helper briefly unreachable) must
        // not abort the tick, because the same tick goes on to claim new work
        // below; failing here is exactly how a healthy job stayed queued forever.
        try{
            var listed=page("pendingReceipts",empty);
            var candidates=listed["ids"] as Newtonsoft.Json.Linq.JArray;
            if(candidates!=null)foreach(var candidate in candidates){
                var value=(string)candidate;
                if(!System.Text.RegularExpressions.Regex.IsMatch(value??"","^[0-9a-f-]{36}$"))continue;
                var candidateRecord=get("/jobs/"+value)["job"];
                if(candidateRecord==null)continue;
                if((string)candidateRecord["status"]!="unknown")continue;
                if((string)candidateRecord["browserClient"]!="flow-tab-qkmanaged")continue;
                if((bool?)candidateRecord["submissionSent"]!=true)continue;
                // A stranded job whose Flow project differs from the project this
                // built-in browser currently shows can never be harvested here:
                // queryResults must refuse to read another project's images. Skip it
                // instead of letting the refusal abort the whole tick, which would
                // stop this client from ever claiming new work.
                var candidateProject=(string)candidateRecord["flow"]?["project"]??"";
                var liveProject=(string)current["project"]??"";
                if(!string.IsNullOrEmpty(candidateProject)&&!string.IsNullOrEmpty(liveProject)&&candidateProject!=liveProject)continue;
                strandedId=value;break;
            }
        }catch(System.Exception discoveryError){responseValue["discoverySkipped"]=discoveryError.Message;}
    }
    if(!string.IsNullOrEmpty(strandedId)&&System.Text.RegularExpressions.Regex.IsMatch(strandedId,"^[0-9a-f-]{36}$")){
        // Recovery is best-effort. A stranded job whose receipt is gone, or whose Flow
        // project no longer matches, cannot be harvested from here; that must never
        // abort the tick, because the tick also claims brand-new queued work below.
        try{
        var probe=page("queryResults",new Newtonsoft.Json.Linq.JObject{["id"]=strandedId});
        if((bool?)probe["complete"]==true){
            var record=get("/jobs/"+strandedId)["job"];
            if(record!=null&&(string)record["status"]=="unknown"&&(string)record["browserClient"]=="flow-tab-qkmanaged"&&(bool?)record["submissionSent"]==true){
                id=strandedId;armed=true;responseValue["recovered"]=true;
                var recoveredAspect=(string)record["transform"]?["aspect"]??(string)record["browserInput"]?["aspect"]??"";
                var total=(int?)record["count"]??1;
                for(var i=0;i<total;i++){
                    current["transferStage"]="reading";current["completedItems"]=i;report(current,"generating");
                    var item=new Newtonsoft.Json.Linq.JObject{["id"]=id,["index"]=i,["prompt"]="",["aspect"]=recoveredAspect,["recovered"]=true};
                    var output=page("readResults",item);
                    var bytes=System.Convert.FromBase64String((string)output["base64"]);
                    if(bytes.Length==0||bytes.Length>64*1024*1024)throw new System.Exception("生成图片大小无效。");
                    current["transferStage"]="transferring";report(current,"generating");
                    api("/jobs/"+id+"/result-upload?index="+i+"&aspect="+System.Uri.EscapeDataString(recoveredAspect)+"&assetKey="+System.Uri.EscapeDataString((string)output["assetKey"]??"")+"&project="+System.Uri.EscapeDataString((string)output["project"]??""),"POST",bytes,"image/png");
                }
                report(current,"complete");responseValue["jobID"]=id;responseValue["completed"]=true;
                context.SetVarValue("response",responseValue.ToString(Newtonsoft.Json.Formatting.None));return true;
            }
        }
        }catch(System.Exception recoveryError){responseValue["recoverySkipped"]=recoveryError.Message;}
    }
    var job=get("/jobs/next?client=flow-tab-qkmanaged")["job"] as Newtonsoft.Json.Linq.JObject;
    if(job==null){context.SetVarValue("response","{\"ok\":true,\"idle\":true}");return true;}
    id=(string)job["id"];if((bool?)job["submissionSent"]==true)throw new System.Exception("PSFB_ALREADY_SUBMITTED");
    System.Action checkCancelled=()=>{
        var latest=get("/jobs/"+id)["job"];
        if((string)latest["status"]=="cancelled"||(bool?)latest["waitingStopped"]==true)throw new System.OperationCanceledException("已停止本地等待，原结果仍可恢复。");
    };
    // Pure text generation has no captured selection: the aspect ratio comes from
    // the job itself instead of a crop ratio, and no reference image is attached.
    var kind=(string)job["kind"]??"image2image";
    var isText=kind=="text2image";
    var ratios=new[]{"1:1","16:9","9:16","4:3","3:4"};
    string chosenRatio;
    if(isText){
        var declared=(string)job["aspectRatio"]??(string)job["aspect"]??"1:1";
        chosenRatio=System.Array.IndexOf(ratios,declared)>=0?declared:"1:1";
    }else{
        var target=job["aspectTarget"]??job["source"];var ratio=(double)target["width"]/(double)target["height"];
        var values=new[]{1.0,16.0/9,9.0/16,4.0/3,3.0/4};var best=0;
        for(var i=1;i<values.Length;i++)if(System.Math.Abs(System.Math.Log(ratio/values[i]))<System.Math.Abs(System.Math.Log(ratio/values[best])))best=i;
        chosenRatio=ratios[best];
    }
    var prepared=Newtonsoft.Json.Linq.JObject.Parse(api("/jobs/"+id+"/browser-input","POST",System.Text.Encoding.UTF8.GetBytes(new Newtonsoft.Json.Linq.JObject{["aspect"]=chosenRatio}.ToString(Newtonsoft.Json.Formatting.None)),"application/json"));
    var arg=new Newtonsoft.Json.Linq.JObject{["id"]=id,["prompt"]=prepared["prompt"],["model"]=job["model"],["count"]=job["count"],["aspect"]=prepared["aspect"]};
    var hasExtra=false;
    if(isText){
        // The helper returns base64:null for text jobs; never fabricate an image.
        arg["kind"]="text2image";
        arg["hasExtraImage"]=false;
    }else{
        var source=System.Convert.FromBase64String((string)prepared["base64"]);
        if(source.Length==0||source.Length>64*1024*1024)throw new System.Exception("参考图大小无效。");
        arg["base64"]=System.Convert.ToBase64String(source);
        if(prepared["extraBase64"]!=null){arg["extraBase64"]=(string)prepared["extraBase64"];}
        hasExtra=prepared["extraBase64"]!=null;
    }
    var references=prepared["references"] as Newtonsoft.Json.Linq.JArray;
    if(references!=null)arg["references"]=references.DeepClone();
    var expectedRefs=(isText?0:(hasExtra?2:1))+(references==null?0:references.Count);
    if(expectedRefs>4)throw new System.Exception("参考图不能超过 4 张，未提交生成。");
    checkCancelled();page("attach",arg);arg.Remove("base64");arg.Remove("extraBase64");arg.Remove("references");
    // Text jobs must end with zero reference chips; image jobs keep 1 (or 2 with
    // an extra reference). A leftover chip from a previous job must fail loudly.
    arg["hasExtraImage"]=hasExtra;
    // A reference chip can exist while it is still uploading, so the count is
    // only half the gate: every chip must also report settled.
    var deadline=System.DateTime.UtcNow.AddSeconds(90);
    var referencesReady=false;
    do {
        checkCancelled();current=page("probe",empty);report(current,"ready");
        referencesReady=(bool?)current["referencesReady"]==true;
        if((int?)current["references"]==expectedRefs&&(expectedRefs==0||referencesReady))break;
        System.Threading.Thread.Sleep(500);
    }while(System.DateTime.UtcNow<deadline);
    if((int?)current["references"]!=expectedRefs||(expectedRefs>0&&!referencesReady))
        throw new System.Exception("Flow 未确认参考图或素材未就绪，未提交生成。");
    checkCancelled();phase="configure";page("configure",arg);checkCancelled();phase="arm";page("arm",arg);armed=true;
    // Persist uncertain submission BEFORE input. A crash from now on cannot
    // requeue this job and cannot trigger a second generation.
    post("/jobs/"+id+"/status",new Newtonsoft.Json.Linq.JObject{["status"]="unknown",["submissionSent"]=true,["error"]="已准备提交，等待 Flow 确认；不会自动重复提交。"});
    checkCancelled();
    // Flow ignores untrusted synthetic clicks, so ask the page for the send
    // button centre and dispatch a real CDP mouse event there. This preserves
    // the one-shot receipt above: the button locks itself after the first click.
    // A hidden window can occasionally swallow the synthesised click before Flow
    // reacts. Retry only while the page still proves nothing was submitted: the
    // one-shot receipt exists, the prompt is still in the editor, the button is
    // enabled and no watched request has been seen. Anything else aborts instead
    // of risking a second generation.
    var requested=false;var submitDeadline=System.DateTime.UtcNow.AddSeconds(45);
    // A hidden owner window can leave the renderer without focus, which makes
    // Chromium drop the first synthesised input. Focus emulation is a no-op for
    // the page's own logic but keeps input delivery reliable; ignore hosts that
    // do not expose the method.
    try{cdp("Emulation.setFocusEmulationEnabled",new Newtonsoft.Json.Linq.JObject{["enabled"]=true}.ToString(Newtonsoft.Json.Formatting.None));}catch(System.Exception){}
    for(var attempt=0;attempt<5&&!requested&&System.DateTime.UtcNow<submitDeadline;attempt++){
        Newtonsoft.Json.Linq.JObject point;
        // A transient disabled state (Flow re-validating the prompt/reference) makes
        // Material swallow the click silently. Wait briefly and re-check instead of
        // abandoning the job; the guard below still refuses to click twice.
        try{point=page("submitPoint",arg);}
        catch(System.Exception){
            System.Threading.Thread.Sleep(900);
            current=page("probe",empty);report(current,"ready");
            if((int?)current["requests"]>0)requested=true;
            continue;
        }
        var px=(double?)point["x"];
        var py=(double?)point["y"];
        if(px==null||py==null)throw new System.Exception("生成按钮不可见，未提交生成。");
        cdp("Input.dispatchMouseEvent",new Newtonsoft.Json.Linq.JObject{["type"]="mouseMoved",["x"]=px,["y"]=py,["button"]="none",["clickCount"]=0}.ToString(Newtonsoft.Json.Formatting.None));
        System.Threading.Thread.Sleep(120);
        cdp("Input.dispatchMouseEvent",new Newtonsoft.Json.Linq.JObject{["type"]="mousePressed",["x"]=px,["y"]=py,["button"]="left",["buttons"]=1,["clickCount"]=1}.ToString(Newtonsoft.Json.Formatting.None));
        System.Threading.Thread.Sleep(80);
        cdp("Input.dispatchMouseEvent",new Newtonsoft.Json.Linq.JObject{["type"]="mouseReleased",["x"]=px,["y"]=py,["button"]="left",["buttons"]=0,["clickCount"]=1}.ToString(Newtonsoft.Json.Formatting.None));
        var confirmDeadline=System.DateTime.UtcNow.AddSeconds(12);
        do{
            checkCancelled();current=page("probe",empty);report(current,"ready");
            // Treat the button locking itself as acceptance even before the network
            // counter ticks: Flow disables it the moment it takes the click, so a
            // locked button means another dispatch would be a real second submit.
            // A fresh output image equally proves acceptance when the endpoint sniffer
            // misses a changed Flow URL.
            if((int?)current["requests"]>0||(bool?)current["submitLocked"]==true||(int?)current["outputs"]>0){requested=true;break;}
            System.Threading.Thread.Sleep(700);
        }while(System.DateTime.UtcNow<confirmDeadline);
        if(!requested)System.Threading.Thread.Sleep(600);
    }
    // Nothing on the wire proved Flow accepted the click. Waiting five minutes for
    // outputs that were never requested only makes the panel claim "generating"
    // while nothing is happening, so end this tick now. The one-shot receipt and
    // the unknown status posted above stand: the job can still be harvested if the
    // click did land late, and it will never be clicked a second time.
    if(!requested)throw new System.Exception("Flow 提交无响应，等待 Flow 确认；不会自动重新提交。");
    try{post("/jobs/"+id+"/status",new Newtonsoft.Json.Linq.JObject{["status"]="generating",["submissionSent"]=true,["error"]=null});}catch{}
    deadline=System.DateTime.UtcNow.AddMinutes(5);
    do {
        checkCancelled();current=page("probe",empty);
        var outputs=(int?)current["outputs"]??0;
        var reqCount=(int?)current["requests"]??0;
        var stage=outputs>0||reqCount>0||(bool?)current["submitLocked"]==true?"generating":"ready";
        report(current,stage);
        // Flow shows a blocked/failed attempt as an error tile that never becomes an
        // image. Once every requested slot is resolved (image or error) there is
        // nothing left to wait for; without this the loop would burn the full five
        // minutes and then report a misleading "结果待确认".
        if((int?)current["failures"]>0&&(outputs+((int?)current["failures"]??0))>=(int?)job["count"])break;
        var responses=current["responses"] as Newtonsoft.Json.Linq.JArray;
        if(responses!=null&&responses.Count>0){
            foreach(var result in responses)if((int?)result["status"]!=200||!string.IsNullOrEmpty((string)result["error"]))throw new System.Exception("Flow 返回生成错误，请核对现有任务；不会重新提交。");
        }
        if(outputs>=(int?)job["count"])break;
        System.Threading.Thread.Sleep(1000);
    }while(System.DateTime.UtcNow<deadline);
    // Flow resolved this job with at least one error tile. Upload whatever images did
    // come back, then surface the terminal failure so the panel can say what happened
    // instead of parking the job in a dead "unknown". The code decides whether the
    // attempt is safe to retry (Flow says a policy block is not billed).
    var freshFailures=(int?)current["failures"]??0;
    if(freshFailures>0){
        var available=System.Math.Min((int?)current["outputs"]??0,(int?)job["count"]??0);
        for(int i=0;i<available;i++){
            checkCancelled();
            current["transferStage"]="reading";current["completedItems"]=i;report(current,"generating");
            arg["index"]=i;var partial=page("readResults",arg);
            var partialBytes=System.Convert.FromBase64String((string)partial["base64"]);
            if(partialBytes.Length==0||partialBytes.Length>64*1024*1024)throw new System.Exception("生成图片大小无效。");
            current["transferStage"]="transferring";report(current,"generating");
            api("/jobs/"+id+"/result-upload?index="+i+"&aspect="+System.Uri.EscapeDataString((string)arg["aspect"])+"&assetKey="+System.Uri.EscapeDataString((string)partial["assetKey"]??"")+"&project="+System.Uri.EscapeDataString((string)partial["project"]??""),"POST",partialBytes,"image/png");
        }
        var code=(string)current["failureCode"];if(string.IsNullOrEmpty(code))code="generation_failed";
        var detail=((string)current["failureText"]??"").Replace("\n"," ");
        throw new System.Exception("PSFB_GENERATION_FAILED:"+code+":"+available+":"+detail);
    }
    if((int?)current["outputs"]!=(int?)job["count"])throw new System.Exception("Flow 结果待确认；查询不会重新生成。");
    for(int i=0;i<(int)job["count"];i++){
        checkCancelled();
        current["transferStage"]="reading";current["completedItems"]=i;report(current,"generating");
        arg["index"]=i;var output=page("readResults",arg);
        var bytes=System.Convert.FromBase64String((string)output["base64"]);
        if(bytes.Length==0||bytes.Length>64*1024*1024)throw new System.Exception("生成图片大小无效。");
        current["transferStage"]="transferring";report(current,"generating");
        api("/jobs/"+id+"/result-upload?index="+i+"&aspect="+System.Uri.EscapeDataString((string)arg["aspect"])+"&assetKey="+System.Uri.EscapeDataString((string)output["assetKey"]??"")+"&project="+System.Uri.EscapeDataString((string)output["project"]??""),"POST",bytes,"image/png");
    }
    report(current,"complete");responseValue["jobID"]=id;responseValue["completed"]=true;
}catch(System.Exception error){
    if(error.Message.Contains("PSFB_ALREADY_SUBMITTED"))armed=true;
    if(!string.IsNullOrEmpty(id)&&!(error is System.OperationCanceledException)){
        try{
            var cfg=Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(System.IO.Path.Combine(dataRoot,"config.json")));
            var req=(System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://127.0.0.1:47831/api/jobs/"+id+"/status");
            req.Proxy=null;req.Method="POST";req.Timeout=10000;req.ContentType="application/json";req.Headers["Authorization"]="Bearer "+(string)cfg["pairingToken"];
            // A resolved generation failure is a real terminal state, not an uncertain
            // submission: the controller only throws this after the page showed Flow's
            // own error tile and every slot was accounted for. Report it as failed with
            // the code so the helper can decide whether a retry is safe (Flow states a
            // policy block is not billed) instead of parking the job in "unknown".
            var body=new Newtonsoft.Json.Linq.JObject();
            if(error.Message.StartsWith("PSFB_GENERATION_FAILED:",System.StringComparison.Ordinal)){
                var parts=error.Message.Split(new[]{':'},4);
                var code=parts.Length>1?parts[1]:"generation_failed";
                var saved=parts.Length>2?parts[2]:"0";
                var detail=parts.Length>3?parts[3]:"";
                var charged=code!="policy_rejected";
                body["status"]="failed";body["submissionSent"]=true;body["failureCode"]=code;body["charged"]=charged;
                body["error"]=(code=="policy_rejected"
                    ? "Flow 判定该提示词违反政策，未生成图片，本次生成不计费。请修改提示词后重试。"
                    : "Flow 生成失败，未返回图片。请在 Flow 中确认后再决定是否重新生成。")
                    +"（已完成 "+saved+" 张）"+(string.IsNullOrEmpty(detail)?"":" Flow 提示："+detail);
            }else{
                body["status"]=armed?"unknown":"failed";body["submissionSent"]=armed;body["error"]=error.Message;
                if(!armed&&phase=="configure")body["failureCode"]="pre_submission_configuration";
            }
            var bytes=System.Text.Encoding.UTF8.GetBytes(body.ToString(Newtonsoft.Json.Formatting.None));req.ContentLength=bytes.Length;
            using(var stream=req.GetRequestStream())stream.Write(bytes,0,bytes.Length);
            try{using(var res=req.GetResponse()){}}
            catch(System.Net.WebException){ /* 终端状态上报失败不影响主流程 */ }
        }catch{}
    }
    responseValue["ok"]=false;responseValue["error"]=error.Message;responseValue["jobID"]=string.IsNullOrEmpty(id)?null:id;responseValue["submissionSent"]=armed;
}finally{if(owned)gate.ReleaseMutex();}
}
context.SetVarValue("response",responseValue.ToString(Newtonsoft.Json.Formatting.None));
return true;
