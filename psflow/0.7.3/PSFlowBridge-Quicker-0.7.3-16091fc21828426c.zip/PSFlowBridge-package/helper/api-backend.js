"use strict";

const fs = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");
const sharp = require("sharp");
const { processResult } = require("./result-geometry");
const {selectionReference,outlineReference,projectMaskSupport,guidedPrompt}=require("./reference-input");
const { getOrPrepareReference } = require("./prepared-reference-cache");
const extraImageInput = require("./extra-image");
const contextInput=require("./context-input");

const MAX_BYTES = 64 * 1024 * 1024;
const MAX_PIXELS = 25000000;

function problem(message, code = "backend_error") {
  return Object.assign(new Error(message), { code });
}

async function configuration(dataDir) {
  let value;
  try { value = JSON.parse(await fs.readFile(path.join(dataDir, "backend.json"), "utf8")); }
  catch (error) {
    if (error.code === "ENOENT") return null;
    throw problem("Flow 配置无法读取，请从启动入口检查连接。", "configuration");
  }
  if (!value.enabled) return null;
  const base = new URL(value.baseUrl);
  if (base.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(base.hostname) || base.username || base.password || base.search || base.hash || base.pathname !== "/") {
    throw problem("Flow 后端必须是本机服务地址。", "configuration");
  }
  if (typeof value.apiKey !== "string" || value.apiKey.length < 16) throw problem("Flow 本地连接配置不完整。", "configuration");
  return {
    base: base.origin,
    key: value.apiKey,
    model: typeof value.model === "string" ? value.model : "gemini-3.1-flash-image",
    flowHost: value.flowHost === "flow.google.com" ? value.flowHost : "",
    aspects: Array.isArray(value.aspects) && value.aspects.length ? value.aspects.filter(a => /^(?:[1-9]|[1-9]\d):(?:[1-9]|[1-9]\d)$/.test(a)) : ["1:1", "16:9", "9:16"],
    timeout: Math.max(10000, Math.min(600000, Number(value.timeoutMs) || 300000)),
  };
}

async function boundedBody(response, onProgress) {
  const clHeader = response.headers.get("content-length");
  const contentLength = clHeader !== null && /^\d+$/.test(clHeader.trim()) ? parseInt(clHeader.trim(), 10) : null;
  if (contentLength !== null && contentLength > MAX_BYTES) throw problem("Flow 返回的图片过大。", "result_error");
  if (typeof onProgress === "function") onProgress({ type: "start", loaded: 0, total: contentLength });
  let size = 0;
  const chunks = [];
  for await (const chunk of response.body) {
    size += chunk.length;
    if (size > MAX_BYTES) throw problem("Flow 返回的图片过大。", "result_error");
    chunks.push(Buffer.from(chunk));
    if (typeof onProgress === "function") onProgress({ type: "chunk", loaded: size, total: contentLength, chunkLength: chunk.length });
  }
  if (typeof onProgress === "function") onProgress({ type: "end", loaded: size, total: contentLength !== null ? contentLength : size });
  return Buffer.concat(chunks);
}

async function status(dataDir) {
  let config;
  try { config = await configuration(dataDir); }
  catch (error) { return { configured: false, online: false, loginRequired: false, mode: "browser", model: "", message: error.message }; }
  if (!config) return { configured: false, online: false, loginRequired: false, mode: "browser", model: "", message: "点击 PS Flow 助手，准备生成服务。" };
  const result = { configured: true, online: false, loginRequired: false, mode: "api", model: config.model, message: "点击 PS Flow 助手，启动生成服务。" };
  try {
    const health = await fetch(config.base + "/health", { signal: AbortSignal.timeout(2000), redirect: "error" });
    const identity = await health.json();
    if (!health.ok || identity.app !== "PSFlowBridge-FlowAPI") return { ...result, message: "生成端口不是 PS Flow 服务，请检查启动入口。" };
    result.online = true;
    const login = await fetch(config.base + "/setup/status", { signal: AbortSignal.timeout(65000), redirect: "error" });
    const body = await login.json();
    const modern = (body.flow_host || config.flowHost) === "flow.google.com";
    const hasSession = typeof body.session_ready === "boolean" ? body.session_ready
      : modern && body.browser_open === false ? false
      : body.live_login_detected === true || body.has_st === true;
    result.browserOpen = body.browser_open === true;
    result.browserVisible = body.browser_visible === true;
    result.sessionReady = login.ok && hasSession;
    result.projectReady = body.project_ready === true;
    result.sessionState = body.session_state || (hasSession ? "ready" : result.browserOpen ? "login_required" : "browser_closed");
    result.sessionCheckActive = body.session_check_active === true;
    result.sessionCheckPhase = typeof body.session_check_phase === "string" ? body.session_check_phase : "";
    result.sessionCheckElapsedMs = Number.isFinite(body.session_check_elapsed_ms) ? body.session_check_elapsed_ms : 0;
    result.sessionCheckDurationMs = Number.isFinite(body.session_check_duration_ms) ? body.session_check_duration_ms : 0;
    result.runtimeBuildId = identity.runtimeBuildId || "";
    const unconfirmed = !login.ok || ["unknown", "unverified", "checking","restoring","restore_failed","error"].includes(result.sessionState);
    result.sessionUnconfirmed=unconfirmed;
    result.loginRequired = !unconfirmed ? (!hasSession || (!modern && !body.project_ready)) : (!login.ok);
    if (unconfirmed) {
      result.sessionReady = false;
      if (!login.ok) result.sessionState = "unknown";
      result.message = typeof body.session_message === "string" && body.session_message
        ? body.session_message
        : result.sessionCheckActive ? "正在通过 Flow 只读接口确认登录状态；这次查询不会创建项目或提交生成。"
        : "连接状态暂时无法确认，请保留当前任务后稍后查询。";
      return result;
    }
    if (result.loginRequired) {
      result.message = body.session_message || (!login.ok ? "连接状态暂时无法确认，请重新查询。"
        : result.browserOpen ? "Flow 窗口已打开，但登录会话尚未就绪。请点击「连接 Flow」完成登录。"
        : "Flow 登录窗口尚未连接，请点击「连接 Flow」恢复会话。");
    } else {
      result.message = body.session_message || (body.project_ready ? "已连接，可以提交生成任务。"
        : "会话已连接，项目将在首次生成时准备。");
    }
    return result;
  } catch {
    result.loginRequired = false;
    result.sessionReady = false;
    result.sessionState = "unknown";
    result.message = result.online ? "连接状态暂时无法确认，请保留当前任务后重新查询。" : "生成服务尚未连接，请重新打开动作。";
  }
  return result;
}

async function waitForSession(dataDir, {timeoutMs = 8000, pollMs = 250} = {}) {
  const deadline = Date.now() + timeoutMs;
  let connection = await status(dataDir);
  while (connection.online && !connection.sessionReady && connection.sessionCheckActive && Date.now() < deadline) {
    await new Promise(resolve => setTimeout(resolve,Math.min(pollMs,Math.max(0,deadline-Date.now()))));
    connection = await status(dataDir);
  }
  return connection;
}

function chooseAspect(target, aspects) {
  // Photoshop sends the un-padded selection/canvas size as aspectTarget;
  // fall back only for legacy queued jobs.
  return aspects.reduce((best, aspect) => {
    const [w, h] = aspect.split(":").map(Number);
    const score = Math.abs(Math.log((target.width / target.height) / (w / h)));
    return !best || score < best.score ? { aspect, score, ratio: w / h } : best;
  }, null);
}

function normalizeDownloadArgs(jobId, onProgress) {
  if (typeof jobId === "function") return { jobId: "", onProgress: jobId };
  if (typeof jobId === "object" && jobId !== null) return { jobId: jobId.jobId || jobId.id || "", onProgress: jobId.onProgress || onProgress };
  return { jobId: typeof jobId === "string" ? jobId : "", onProgress };
}

async function downloadResult(config, url, jobId, onProgress) {
  const norm = normalizeDownloadArgs(jobId, onProgress);
  const address = new URL(url);
  if (address.origin !== config.base || !/^\/v1\/files\/[a-zA-Z0-9_.-]+$/.test(address.pathname) || address.search || address.hash) {
    throw problem("Flow 返回了不支持的结果地址，任务已保留。", "result_error");
  }
  const headers = { Authorization: "Bearer " + config.key };
  if (norm.jobId) headers["X-PSFB-Job-ID"] = norm.jobId;
  const response = await fetch(address, { headers, signal: AbortSignal.timeout(30000), redirect: "error" });
  if (!response.ok) throw problem("结果下载失败，稍后可以重新取图。", "result_error");
  return boundedBody(response, norm.onProgress);
}

async function prepareInput(config, job, directory, options = {}) {
  const source = await fs.readFile(path.join(directory, "source.png"));
  const model = job.model || config.model;
  const aspects = config.aspects.filter(aspect => aspect !== "21:9" || /^nano-banana-2(?:-|$)/.test(model));
  const selected = chooseAspect(job.aspectTarget || job.source, aspects);
  if (!selected) throw problem("没有可用的图片比例。", "configuration");
  const scale = Math.min(1, 2048 / Math.max(job.source.width, job.source.height));
  const width = Math.max(1, Math.round(job.source.width * scale)), height = Math.max(1, Math.round(job.source.height * scale));

  let maskBytes = null;
  if (job.mask) {
    try {
      maskBytes = await fs.readFile(path.join(directory, "mask.png"));
    } catch (err) {
      throw problem("选区蒙版无法读取，任务已保留。", "result_error");
    }
  }

  const result = await getOrPrepareReference({
    cacheDir: options.cacheDir,
    dataDir: options.dataDir,
    directory,
    job,
    config,
    source,
    maskBytes,
    model,
    selected,
    scale,
    width,
    height,
    computeFn: async () => {
      if (job.referencePolicy === 'selection-outline') {
        const margin = 12, paddedW = Math.max(width + margin * 2, Math.ceil((height + margin * 2) * selected.ratio)), paddedH = Math.max(height + margin * 2, Math.ceil((width + margin * 2) / selected.ratio));
        const left = Math.floor((paddedW - width) / 2), top = Math.floor((paddedH - height) / 2);
        const image = await sharp(source).resize(width, height, { fit: 'fill' }).flatten({ background: '#ffffff' }).removeAlpha().extend({ left, right: paddedW - width - left, top, bottom: paddedH - height - top, extendWith: 'copy' }).png().toBuffer();
        const support = maskBytes ? projectMaskSupport(await sharp(maskBytes).removeAlpha().extractChannel(0).toColourspace('b-w').raw().toBuffer(), job.source.width, job.source.height, width, height) : Buffer.alloc(width * height, 255);
        const mask = await sharp(support, { raw: { width, height, channels: 1 } }).toColourspace('b-w').png().toBuffer();
        const paddedMask = await sharp(mask).extend({ left, right: paddedW - width - left, top, bottom: paddedH - height - top, background: '#000000' }).toColourspace('b-w').png().toBuffer();
        const reference = await outlineReference(image, paddedMask, paddedW, paddedH);
        const r = job.editRegion;
        return {
          model,
          padded: reference.image,
          hasReferencePng: true,
          transform: {
            width, height, paddedW, paddedH, left, top,
            aspect: selected.aspect,
            guideColor: reference.color,
            guideInnerColor: reference.innerColor,
            hasPreservedIslands: reference.hasPreservedIslands,
            referencePolicy: 'selection-outline',
            guideGapPx: reference.gapPx,
            guideLinePx: reference.linePx,
            guidePixels: reference.guidePixels,
            editRegion: r ? { left: left + r.left * scale, top: top + r.top * scale, width: r.width * scale, height: r.height * scale } : null
          }
        };
      }
      const paddedW = Math.max(width, Math.ceil(height * selected.ratio)), paddedH = Math.max(height, Math.ceil(width / selected.ratio));
      const left = Math.floor((paddedW - width) / 2), top = Math.floor((paddedH - height) / 2);
      const guided = job.referencePolicy === "selection-contrast";
      const reference = guided ? await selectionReference(source, maskBytes, width, height, { contextRegion: job.geometryVersion === 2 && job.editRegion ? { left: job.editRegion.left * scale, top: job.editRegion.top * scale, width: job.editRegion.width * scale, height: job.editRegion.height * scale } : null }) : null;
      const background = reference ? reference.hex : "#ffffff";
      const image = reference ? reference.image : await sharp(source).resize(width, height).flatten({ background }).png().toBuffer();
      const padded = await sharp(image).extend({ left, right: paddedW - width - left, top, bottom: paddedH - height - top, background }).png().toBuffer();
      return {
        model,
        padded,
        hasReferencePng: false,
        transform: {
          width, height, paddedW, paddedH, left, top,
          aspect: selected.aspect,
          ...(reference ? { guideColor: reference.color, referencePolicy: "selection-contrast" } : {})
        }
      };
    }
  });

  if (result.hasReferencePng || result.transform?.referencePolicy === 'selection-outline') {
    await fs.writeFile(path.join(directory, 'reference.png'), result.padded);
  }

  return {
    model: result.model,
    padded: result.padded,
    transform: {...result.transform,hasGlobalContext:job.hasGlobalContext===true,hasExtraImage:job.hasExtraImage===true},
    fromCache: Boolean(result.fromCache),
    key: result.key
  };
}
// Submit the whole batch with one native Flow request. The provider generates all
// requested images at once; the helper only downloads the returned URLs, so a
// retry after a download failure never triggers another generation.
async function submitBatch(dataDir, config, job, directory, preparedRef, onStage) {
  const timings = job.timings || (job.timings = {});
  if (job.kind === "text2image") {
    const connectionStarted = Date.now();
    const health = await waitForSession(dataDir);
    timings.connectionMs = Date.now() - connectionStarted;
    if (!health.online) throw problem(health.message, "offline");
    if (health.loginRequired) throw problem(health.message, "login_required");
    if (health.sessionReady === false) throw problem("Flow 登录状态仍待确认，请稍后查询；本次未提交生成。", "connection_unconfirmed");
    await onStage("generating");
    if (job.status === "cancelled" || job.waitingStopped) throw problem("任务已取消，未提交生成。", "cancelled");
    const references = [];
    if (Array.isArray(job.references) && job.references.length > 0) {
      if (job.references.length > 4) {
        job.submissionSent = false; job.submissionState = "not_submitted";
        throw problem("参考图数量不能超过 4 张，未提交生成。", "rejected");
      }
      for (let index = 0; index < job.references.length; index++) {
        const refFile = path.join(directory, `reference-${index}.png`);
        try {
          const buf = await fs.readFile(refFile);
          await extraImageInput.validate(buf, sharp, { purpose: "reference" });
          references.push({
            base64: buf.toString("base64"),
            name: (job.references[index] && job.references[index].name) || `reference-${index}.png`
          });
        } catch (err) {
          job.submissionSent = false; job.submissionState = "not_submitted";
          throw problem(err.code === "ENOENT"
            ? `参考图缺失或读取失败 (reference-${index}.png)，未提交生成。`
            : `参考图无效 (reference-${index}.png)：${err.message || "无法解码"}`, "rejected");
        }
      }
    }
    job.submissionSent = true; job.submissionState = "unknown"; job.submittedAt = new Date().toISOString();
    await onStage("generating");
    if (job.waitingStopped || job.status === "cancelled") {
      job.submissionSent = false; job.submissionState = "not_submitted"; job.waitingStopped = false; job.status = "cancelled";
      if (job.cancellation) job.cancellation.mode = "cancel_queue";
      throw problem("任务已取消，未提交生成。", "cancelled");
    }
    const payload = {
      prompt: job.prompt,
      model: job.model || config.model,
      aspect_ratio: job.aspectRatio || "1:1",
      quality: "standard",
      n: Number(job.count || 1),
      response_format: "url"
    };
    if (references.length > 0) payload.references = references;
    if (typeof job.flowProjectId === "string" && job.flowProjectId) payload.project_id = job.flowProjectId;
    let response;
    const backendStarted = Date.now();
    try {
      response = await fetch(config.base + "/v1/images/generations", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: "Bearer " + config.key, "X-PSFB-Job-ID": job.id },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(config.timeout),
        redirect: "error"
      });
    } catch {
      throw problem("生成请求已发送，但暂未确认结果。请检查 Flow，避免重复生成。", "uncertain");
    } finally {
      timings.backendRequestMs = Date.now() - backendStarted;
    }
    if (!response.ok) {
      let errmsg = "", failure;
      try { errmsg = (await boundedBody(response)).toString("utf8"); failure = JSON.parse(errmsg); } catch (_) {}
      if (failure?.submissionSent === false && failure?.error?.code === "generation_not_submitted") {
        job.submissionSent = false; job.submissionState = "not_submitted";
        if (typeof failure.projectId === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(failure.projectId)) job.flowProjectId = failure.projectId;
        throw problem(failure.error.message || "Flow 设置未确认，本次未提交生成。", "rejected");
      }
      if ([400, 401, 403, 422].includes(response.status)) throw problem(response.status === 401 || response.status === 403 ? "Flow 登录或连接已失效，请重新登录。" : "Flow 拒绝了生成参数，请检查模型。", "rejected");
      throw problem(`Flow 返回 HTTP ${response.status}，未确认生成结果。`, "uncertain");
    }
    let body;
    try { body = JSON.parse((await boundedBody(response)).toString("utf8")); }
    catch { throw problem("Flow 返回的结果无法确认，请检查网页。", "uncertain"); }
    if (typeof body.projectId === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.projectId)) {
      job.flowProjectId = body.projectId;
    }
    for (const key of ["pageReadyMs", "settingsMs", "referenceUploadMs", "nativeGenerationMs"]) {
      const value = body.timings?.[key];
      if (typeof value === "number" && Number.isFinite(value) && value >= 0) timings[key] = Math.round(value);
    }
    const items = Array.isArray(body.data) ? body.data.filter(item => item && typeof item.url === "string") : [];
    if (!items.length) throw problem("Flow 未返回图片地址，请检查网页。", "uncertain");
    return items.map(item => item.url);
  }
  if (!preparedRef.value) {
    const connectionStarted = Date.now();
    const health = await waitForSession(dataDir);
    timings.connectionMs = Date.now() - connectionStarted;
    if (!health.online) throw problem(health.message, "offline");
    if (health.loginRequired) throw problem(health.message, "login_required");
    if (health.sessionReady === false) throw problem("Flow 登录状态仍待确认，请稍后查询；本次未提交生成。", "connection_unconfirmed");
    const preparationStarted = Date.now();
    preparedRef.value = await prepareInput(config, job, directory, { dataDir });
    timings.referenceCacheHit=preparedRef.value.fromCache;
    job.preparedReferenceKey=preparedRef.value.key;
    timings.prepareMs = Date.now() - preparationStarted;
  }
  const { padded, model, transform } = preparedRef.value;
  job.transform = transform;
  // Multi-reference edit: Flow replaces the composer chips wholesale, so the
  // prepared base image travels as reference #1 followed by the ordered extras.
  // Files are read and validated before the request boundary; an unreadable or
  // oversized set must never reach fetch (which would look like a submission).
  let editReferences;
  try{editReferences=await contextInput.references(job,directory);}
  catch(error){job.submissionSent=false;job.submissionState='not_submitted';throw error;}
  // The prepared base is the edit source; validating it here keeps a corrupt
  // base from being submitted with otherwise-valid extra references.
  try {
    await extraImageInput.validate(padded, sharp, { purpose: "source" });
  } catch (err) {
    job.submissionSent = false; job.submissionState = "not_submitted";
    throw problem(`精修基底图无效：${err.message || "无法解码"}，未提交生成。`, "rejected");
  }
  const form = new FormData();
  form.append("image", new Blob([padded], { type: "image/png" }), "source.png");
  // The provider receives editing intent; job.prompt remains the user's exact text.
  form.append("prompt",guidedPrompt(job.prompt,transform,job.editMode));
  form.append("model", model);
  form.append("aspect_ratio", transform.aspect);
  form.append("quality", "standard");
  form.append("n", String(job.count));
  form.append("response_format", "url");
  if(job.documentName)form.append("document_name",job.documentName);
  if(job.documentPath)form.append("document_path",job.documentPath);
  if(job.documentID)form.append("document_id",String(job.documentID));
  if(job.documentSession)form.append("document_session",job.documentSession);
  if(typeof job.flowProjectId === "string" && job.flowProjectId) form.append("project_id", job.flowProjectId);
  form.append("reuse_reference",editReferences.length === 0 && job.baseJobId&&!job.referenceRefreshReason&&job.base!=='result'?"true":"false");
  if (editReferences.length > 0) form.append("references", JSON.stringify(editReferences));
  await onStage("generating");
  if(job.status==='cancelled'||job.waitingStopped)throw problem('任务已取消，未提交生成。','cancelled');
  // Persist the send boundary before issuing HTTP. A restarted helper may only
  // recover this attempt, never send the same task a second time.
  job.submissionSent=true;job.submissionState='unknown';job.submittedAt=new Date().toISOString();
  await onStage('generating');
  if(job.waitingStopped||job.status==='cancelled'){
    job.submissionSent=false;job.submissionState='not_submitted';job.waitingStopped=false;job.status='cancelled';
    if(job.cancellation)job.cancellation.mode='cancel_queue';
    throw problem('任务已取消，未提交生成。','cancelled');
  }
  let response;
  const backendStarted = Date.now();
  let progressRunning = true;
  const progressLoop = (async () => {
    while (progressRunning) {
      try {
        const reply = await fetch(config.base + "/setup/generation-progress/" + job.id, {headers:{Authorization:"Bearer " + config.key},signal:AbortSignal.timeout(2000),redirect:"error"});
        if (reply.ok) {
          const body = await reply.json();
          if (progressRunning) {
            job.webProgress = body.webProgress || null;
            if (body.transferProgress) {
              const tp = body.transferProgress;
              job.transferProgress = {
                phase: tp.phase || "upload",
                loaded: Number(tp.loaded) || 0,
                total: tp.total !== null && Number.isFinite(tp.total) ? Number(tp.total) : null,
                percent: tp.percent !== null && Number.isFinite(tp.percent) ? Math.max(0, Math.min(100, Math.round(tp.percent))) : null,
                completed: Number(tp.completed) || 0,
                totalItems: Number(tp.totalItems) || 1,
                source: tp.source || "flow-upload"
              };
            } else if (job.transferProgress && job.transferProgress.phase === "upload") {
              job.transferProgress = null;
            }
            await onStage(job.transferProgress && job.transferProgress.phase === "upload" ? "uploading" : "generating");
          }
        } else if (progressRunning) {
          job.webProgress = null;
          if (job.transferProgress && job.transferProgress.phase === "upload") {
            job.transferProgress = null;
            await onStage("generating");
          }
        }
      } catch (_) {
        if (progressRunning) {
          job.webProgress = null;
          if (job.transferProgress && job.transferProgress.phase === "upload") {
            job.transferProgress = null;
            await onStage("generating");
          }
        }
      }
      if (progressRunning) await new Promise(resolve => setTimeout(resolve,500));
    }
  })();
  try {
    response = await fetch(config.base + "/v1/images/edits", { method: "POST", headers: { Authorization: "Bearer " + config.key, "X-PSFB-Job-ID":job.id }, body: form, signal: AbortSignal.timeout(config.timeout), redirect: "error" });
  } catch { throw problem("生成请求已发送，但暂未确认结果。请检查 Flow，避免重复生成。", "uncertain"); }
  finally {
    progressRunning = false;
    await progressLoop;
    job.webProgress = null;
    if (job.transferProgress && job.transferProgress.phase === "upload") {
      job.transferProgress = null;
    }
    timings.backendRequestMs = Date.now() - backendStarted;
  }
  if (!response.ok) {
    let errmsg = "", failure;
    try { errmsg = (await boundedBody(response)).toString("utf8"); failure = JSON.parse(errmsg); } catch (_) {}
    if (failure?.submissionSent === false && failure?.error?.code === "generation_not_submitted") {
      job.submissionSent=false;job.submissionState='not_submitted';
      if(typeof failure.projectId==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(failure.projectId))job.flowProjectId=failure.projectId;
      throw problem(failure.error.message || "Flow 设置未确认，本次未提交生成。", "rejected");
    }
    if ([400, 401, 403, 422].includes(response.status)) throw problem(response.status === 401 || response.status === 403 ? "Flow 登录或连接已失效，请重新登录。" : "Flow 拒绝了生成参数，请检查模型。", "rejected");
    throw problem(`Flow 返回 HTTP ${response.status}，未确认生成结果。${errmsg.slice(0,200)}`, "uncertain");
  }
  let body;
  try { body = JSON.parse((await boundedBody(response)).toString("utf8")); }
  catch { throw problem("Flow 返回的结果无法确认，请检查网页。", "uncertain"); }
  if (typeof body.projectId === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.projectId)) {
    job.flowProjectId = body.projectId;
  }
  // Only copy measured phase durations; provider payloads never overwrite local
  // timings or persist arbitrary fields in the user's task record.
  for (const key of ["pageReadyMs", "settingsMs", "referenceUploadMs", "nativeGenerationMs"]) {
    const value = body.timings?.[key];
    if (typeof value === "number" && Number.isFinite(value) && value >= 0) timings[key] = Math.round(value);
  }
  if (["paste", "file", "reuse"].includes(body.timings?.referenceMethod)) timings.referenceMethod = body.timings.referenceMethod;
  const items = Array.isArray(body.data) ? body.data.filter(item => item && typeof item.url === "string") : [];
  if (!items.length) throw problem("Flow 未返回图片地址，请检查网页。", "uncertain");
  // Fewer URLs than requested is never auto-corrected: we keep what Flow
  // returned and report the shortfall after downloading, so the batch is never
  // submitted twice.
  return items.map(item => item.url);
}

async function generate(dataDir, job, directory, onStage) {
  const config = await configuration(dataDir);
  if (!config) throw problem("请先点击 PS Flow 助手准备生成服务。", "configuration");
  const count = Number(job.count) || 1;
  if (![1, 2, 3, 4].includes(count)) throw problem("生成数量不支持。", "rejected");
  job.count = count;
  const images = Array.isArray(job.images) ? [...job.images] : [];
  if (images.some((image, index) => image.index !== index)) throw problem("任务图片顺序无法恢复，请保留原任务。", "result_error");
  job.images = images;
  const timings = job.timings = { ...(job.timings || {}) };

  // Any persisted batch URLs confirm a submission, even when Flow returned fewer
  // than requested. Only migrate legacy URLs when no batch URLs are available.
  if (!Array.isArray(job.batchResultUrls) || !job.batchResultUrls.length) {
    if (typeof job.backendResultUrl === "string" && job.backendResultUrl) job.batchResultUrls = [job.backendResultUrl];
    else if (job.pendingImageDownload && typeof job.pendingImageDownload.url === "string") job.batchResultUrls = [job.pendingImageDownload.url];
    else if (Array.isArray(job.batchResultUrls)) delete job.batchResultUrls;
  }

  if (!Array.isArray(job.batchResultUrls) || !job.batchResultUrls.length) {
    if(job.submissionSent===true)throw problem('原任务已提交但结果地址待确认；查询不会重新生成。','uncertain');
    const urls = await submitBatch(dataDir, config, job, directory, { value: null }, onStage);
    job.batchResultUrls = urls;
    job.submissionSent=true;job.submissionState='confirmed';
    delete job.backendResultUrl;
    delete job.pendingImageDownload;
    // Persist the confirmed URLs before any download so a later failure can only re-download.
    await onStage("downloading");
  }

  // Start every download at once so the local Flow API can fetch from Google in
  // parallel, then surface each result in index order for incremental previews.
  const first = images.length;
  const available = Math.min(count, job.batchResultUrls.length);

  if (first < available) {
    job.transferProgress = null;
    const items = [];
    for (let i = 0; i < count; i++) {
      if (i < first) {
        let prevSize = 0;
        try {
          const stat = await fs.stat(path.join(directory, images[i].path));
          prevSize = stat.size;
        } catch (_) {}
        items.push({ loaded: prevSize, total: prevSize > 0 ? prevSize : null, done: true });
      } else {
        items.push({ loaded: 0, total: null, done: false });
      }
    }

    function computeLocalProgress() {
      let loaded = 0;
      let total = 0;
      let allTotalsKnown = true;
      let completed = 0;
      for (let i = 0; i < count; i++) {
        const item = items[i];
        loaded += item.loaded;
        if (item.done) completed++;
        if (item.total !== null && Number.isFinite(item.total)) {
          total += item.total;
        } else {
          allTotalsKnown = false;
        }
      }
      const hasTotal = allTotalsKnown && total > 0;
      const percent = hasTotal ? Math.max(0, Math.min(100, Math.round((loaded / total) * 100))) : null;
      return {
        phase: "download",
        loaded,
        total: hasTotal ? total : null,
        percent,
        completed,
        totalItems: count,
        source: "file-response"
      };
    }

    let downloadProgressRunning = true;
    let remoteDownloadActive = false;
    let lastStageNotify = 0;
    let stageNotifyPromise = Promise.resolve();

    function notifyDownloadStage(force = false) {
      const now = Date.now();
      if (force || now - lastStageNotify >= 50) {
        lastStageNotify = now;
        stageNotifyPromise = stageNotifyPromise
          .catch(() => {})
          .then(() => onStage("downloading").catch(() => {}));
      }
    }

    function updateLocalProgress(forceStage = false) {
      const local = computeLocalProgress();
      if (!remoteDownloadActive) {
        job.transferProgress = local;
      }
      notifyDownloadStage(forceStage);
    }

    const downloadProgressLoop = (async () => {
      while (downloadProgressRunning) {
        try {
          const reply = await fetch(config.base + "/setup/generation-progress/" + job.id, {
            headers: { Authorization: "Bearer " + config.key },
            signal: AbortSignal.timeout(2000),
            redirect: "error"
          });
          if (reply.ok) {
            const body = await reply.json();
            const remote = body ? body.transferProgress : null;
            if (downloadProgressRunning) {
              if (remote && remote.phase === "download" && remote.source === "flow-download") {
                const totalItems = Number(remote.totalItems) || count;
                const completed = Number(remote.completed) || 0;
                if (totalItems > 0 && completed >= totalItems) {
                  remoteDownloadActive = false;
                  job.transferProgress = computeLocalProgress();
                  notifyDownloadStage(true);
                } else {
                  remoteDownloadActive = true;
                  job.transferProgress = {
                    phase: "download",
                    loaded: Number(remote.loaded) || 0,
                    total: remote.total !== null && Number.isFinite(remote.total) ? Number(remote.total) : null,
                    percent: remote.percent !== null && Number.isFinite(remote.percent) ? Math.max(0, Math.min(100, Math.round(remote.percent))) : null,
                    completed,
                    totalItems,
                    source: "flow-download"
                  };
                  notifyDownloadStage(true);
                }
              } else if (remoteDownloadActive) {
                remoteDownloadActive = false;
                job.transferProgress = computeLocalProgress();
                notifyDownloadStage(true);
              }
            }
          } else if (downloadProgressRunning && remoteDownloadActive) {
            remoteDownloadActive = false;
            job.transferProgress = computeLocalProgress();
            notifyDownloadStage(true);
          }
        } catch (_) {
          if (downloadProgressRunning && remoteDownloadActive) {
            remoteDownloadActive = false;
            job.transferProgress = computeLocalProgress();
            notifyDownloadStage(true);
          }
        }
        if (downloadProgressRunning) await new Promise(resolve => setTimeout(resolve, 500));
      }
    })();

    job.transferProgress = computeLocalProgress();
    await onStage("downloading");

    const downloads = [];
    try {
      for (let index = first; index < available; index++) {
        const downloadStarted = Date.now();
        downloads.push(
          downloadResult(config, job.batchResultUrls[index], job.id, event => {
            if (event.type === "start") {
              items[index].total = event.total;
              updateLocalProgress(false);
            } else if (event.type === "chunk") {
              items[index].loaded = event.loaded;
              if (event.total !== null && items[index].total === null) items[index].total = event.total;
              updateLocalProgress(false);
            } else if (event.type === "end") {
              items[index].loaded = event.loaded;
              items[index].total = event.total;
              items[index].done = true;
              updateLocalProgress(true);
            }
          }).then(
            bytes => ({ bytes, downloadMs: Date.now() - downloadStarted }),
            error => ({ error, downloadMs: Date.now() - downloadStarted }))
        );
      }
      for (let index = first; index < available; index++) {
        const started = Date.now();
        const settled = await downloads[index - first];
        timings.downloadsMs = [...(timings.downloadsMs || []), settled.downloadMs];
        if (settled.error) throw settled.error;
        const processingStarted = Date.now();
        let processed;
        try {
          processed = await processResult(settled.bytes, job, directory);
        } catch (error) {
          throw problem(error && error.message ? error.message : "生成结果无法用于回贴，任务和下载地址已保留。", (error && error.code) || "result_error");
        }
        const { output, alignment } = processed;
        timings.processingMs = [...(timings.processingMs || []), Date.now() - processingStarted];
        const fileName = count === 1 ? "result.png" : "result-" + index + ".png";
        const temporaryOutput = path.join(directory, fileName + ".part");
        try {
          await fs.writeFile(temporaryOutput, output);
          await fs.rename(temporaryOutput, path.join(directory, fileName));
        } catch (error) {
          await fs.unlink(temporaryOutput).catch(() => {});
          throw error;
        }
        const imgWidth = (job.kind === "text2image" || !job.source) ? (processed.width || 0) : job.source.width;
        const imgHeight = (job.kind === "text2image" || !job.source) ? (processed.height || 0) : job.source.height;
        images.push({ index, path: fileName, id: "main", mime: "image/png", width: imgWidth, height: imgHeight,
          sha256: crypto.createHash("sha256").update(output).digest("hex"), alignment });
        job.images = images;
        if (!job.selectedByUser || !images.some(image => image.index === job.selectedIndex)) job.selectedIndex = index;
        const chosen = images.find(image => image.index === job.selectedIndex);
        const { index: unusedIndex, path: unusedPath, ...result } = chosen;
        job.result = result;
        job.progress = { done: images.length, total: count };
        timings.imagesMs = [...(timings.imagesMs || []), Date.now() - started];
        await onStage("downloading");
      }
    } finally {
      downloadProgressRunning = false;
      await downloadProgressLoop;
      await stageNotifyPromise;
      if (job.transferProgress && job.transferProgress.phase === "download") {
        job.transferProgress = null;
      }
    }
  }
  if (job.batchResultUrls.length < count) {
    // Download whatever Flow produced, but surface the shortfall as an
    // unconfirmed result instead of quietly generating a second batch.
    throw problem(`Flow 只返回了 ${job.batchResultUrls.length}/${count} 张图片，任务已保留；查询不会重新生成。`, "uncertain");
  }
  // A completed batch must not leave a stale URL that a later recovery could re-download.
  delete job.batchResultUrls;
  delete job.backendResultUrl;
  delete job.pendingImageDownload;
  job.transferProgress = null;
  return job.result;
}

async function queryRecovery(dataDir, job) {
  let config;
  try {
    config = await configuration(dataDir);
  } catch (error) {
    job.recoveryState = "attention_required";
    job.error = (error && error.message) || "本地 API 配置异常，无法查询原任务；本次查询未重新生成。";
    return { active: false };
  }
  if (!config) {
    job.recoveryState = "attention_required";
    job.error = "本地 API 未启用，无法自动恢复原结果；请打开 Flow 网页核对，本次查询未重新生成。";
    return { active: false };
  }
  try {
    const reply = await fetch(config.base + "/setup/generation-progress/" + encodeURIComponent(job.id), {
      headers: { Authorization: "Bearer " + config.key },
      signal: AbortSignal.timeout(3000),
      redirect: "error"
    });
    if (reply.ok) {
      const body = await reply.json().catch(() => null);
      const hasWeb = !!(body && body.webProgress);
      const hasTransfer = !!(body && body.transferProgress);
      if (hasWeb || hasTransfer) {
        job.webProgress = body.webProgress || null;
        if (body.transferProgress) {
          const tp = body.transferProgress;
          job.transferProgress = {
            phase: tp.phase || "upload",
            loaded: Number(tp.loaded) || 0,
            total: tp.total !== null && Number.isFinite(tp.total) ? Number(tp.total) : null,
            percent: tp.percent !== null && Number.isFinite(tp.percent) ? Math.max(0, Math.min(100, Math.round(tp.percent))) : null,
            completed: Number(tp.completed) || 0,
            totalItems: Number(tp.totalItems) || 1,
            source: tp.source || "flow-upload"
          };
        }
        job.recoveryState = "waiting";
        job.error = null;
        return { active: true };
      }
    }
  } catch {
    // Fall through to attention_required below.
  }
  job.recoveryState = "attention_required";
  job.error = "本地 API 未找到该任务的已完成结果地址；请打开 Flow 网页核对，本次查询未重新生成。";
  return { active: false };
}

module.exports = { status, waitForSession, generate, configuration, downloadResult, prepareInput, queryRecovery };

