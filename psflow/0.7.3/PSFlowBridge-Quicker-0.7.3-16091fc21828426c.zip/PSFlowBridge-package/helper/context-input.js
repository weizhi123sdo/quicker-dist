'use strict';
const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto');
const sharp=require('sharp'),extra=require('./extra-image');
const MAX_BYTES=16*1024*1024;
function invalid(message,status=400){return Object.assign(new Error(message),{status,code:'rejected',field:'contextSource',submissionSent:false});}
function declaration(input){
  const mode=input.contextMode===undefined?'auto':input.contextMode;
  if(!['auto','surrounding','full'].includes(mode))throw invalid('参考范围无效。');
  const has=input.hasGlobalContext===true,source=input.contextSource||null;
  if(has!==Boolean(source)||has&&mode==='surrounding'||mode==='full'&&!has)throw invalid('全图参考声明与参考范围不一致。');
  if (source && (!Number.isInteger(source.width) || !Number.isInteger(source.height) || source.width < 1 || source.height < 1 || Math.max(source.width, source.height) > 1280 || !/^[a-f0-9]{64}$/.test(source.sha256 || ''))) throw invalid('全图参考身份无效。');
  const contextSource = source ? {width: source.width, height: source.height, sha256: source.sha256} : null;
  return {contextMode: mode, hasGlobalContext: has, contextSource};
}
async function validate(bytes,expected){
  try{
    if(!Buffer.isBuffer(bytes)||bytes.length>MAX_BYTES)throw invalid('全图参考超过大小限制。');
    const decoder=sharp(bytes,{limitInputPixels:1280*1280,failOn:'warning'}),meta=await decoder.metadata();
    if(meta.format!=='png'||!meta.width||!meta.height||Math.max(meta.width,meta.height)>1280||(meta.pages||1)!==1)throw invalid('全图参考必须是最长边不超过 1280 的静态 PNG。');
    await decoder.clone().raw().toBuffer();
    const metadata={width:meta.width,height:meta.height,sha256:crypto.createHash('sha256').update(bytes).digest('hex')};
    if(!expected||['width','height','sha256'].some(key=>expected[key]!==metadata[key]))throw invalid('全图参考与原快照不一致。',409);
    return {bytes,metadata};
  }catch(error){if(error.field==='contextSource')throw error;throw invalid('全图参考无法完整读取或解码，未提交生成。');}
}
function ready(job){return !job.hasGlobalContext||job.contextReady===true;}
async function read(job,directory){
  if(!job.hasGlobalContext)return null;
  return validate(await fs.readFile(path.join(directory,'context.png')).catch(()=>{throw invalid('全图参考缺失，未提交生成。',409);}),job.contextSource);
}
// One ordering and validation boundary for browser and API consumers.
async function references(job,directory){
  const count=1+(job.hasGlobalContext?1:0)+(job.hasExtraImage?1:0)+(job.references||[]).length;
  if(count>4)throw invalid('局部底图、全图与参考图合计不能超过 4 张，未提交生成。');
  const refs=[],context=await read(job,directory);
  if(context)refs.push({base64:context.bytes.toString('base64'),name:'context.png'});
  if(job.hasExtraImage){
    const bytes=await fs.readFile(path.join(directory,'extra.png')).catch(()=>{throw invalid('用户参考图缺失，未提交生成。',409);});
    const checked=await extra.validate(bytes,sharp,{purpose:job.extraImage?.purpose||'reference'});
    if(!extra.matches(job.extraImage,checked.metadata))throw invalid('用户参考图与原快照不一致。',409);
    refs.push({base64:bytes.toString('base64'),name:'extra.png'});
  }
  for(let i=0;i<(job.references||[]).length;i++){
    const filename=`reference-${i}.png`;
    const bytes=await fs.readFile(path.join(directory,filename)).catch(()=>{throw invalid(`${filename} 参考图缺失，未提交生成。`,409);});
    let checked;
    try { checked=await extra.validate(bytes,sharp); }
    catch(error) { throw invalid(`${filename} 参考图无法解码，未提交生成。`); }
    if(!extra.matches(job.references[i],checked.metadata))throw invalid('参考图与原快照不一致。',409);
    refs.push({base64:bytes.toString('base64'),name:job.references[i].name||`reference-${i}.png`});
  }
  return refs;
}
module.exports={MAX_BYTES,invalid,declaration,validate,ready,read,references};
