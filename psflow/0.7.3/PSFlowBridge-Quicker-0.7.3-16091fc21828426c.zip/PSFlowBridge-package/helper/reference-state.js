"use strict";
const crypto=require("node:crypto");
// Describes a captured snapshot; this is not evidence of a Flow attachment or
// evidence that Photoshop's current selection still matches the snapshot.
function referenceSnapshot(job){
 const bounds=job.editBounds||job.bounds||null;
 const sourceHash=job.source?.sha256||null,maskHash=job.mask?.sha256||null;
 const fingerprint=sourceHash&&(!job.mask||maskHash)?crypto.createHash('sha256').update(JSON.stringify([sourceHash,maskHash,job.bounds,job.editBounds,job.editRegion,job.geometryVersion,job.referencePolicy,job.contextMode||"auto",job.contextSource?.sha256||null])).digest('hex'):null;
 return {documentName:job.documentName||null,bounds,captureBounds:job.bounds||null,width:job.source?.width||null,height:job.source?.height||null,contextMode:job.contextMode||"auto",hasGlobalContext:job.hasGlobalContext===true,contextSource:job.contextSource||null,capturedAt:job.sourceCapturedAt||job.createdAt||null,fingerprint,reused:!!job.baseJobId,sourceLabel:job.baseJobId?'沿用上次快照':'捕获参考图',scope:job.scope||'selection',policy:job.referencePolicy||null,refreshReason:job.referenceRefreshReason||null,prepared:job.transform?.referencePolicy==='selection-outline'&&job.transform.guidePixels>0};
}
module.exports={referenceSnapshot};
