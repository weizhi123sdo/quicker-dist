const LIMITS=require("../shared/parameter-limits.cjs");
﻿"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const http = require("node:http");
const os = require("node:os");
const path = require("node:path");
const zlib = require("node:zlib");
const { pipeline } = require("node:stream/promises");

const HOST = "127.0.0.1";
const PORT = Number(process.env.PSFB_PORT) || 47831;
const DATA_DIR = process.env.PSFB_DATA_DIR || path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local"), "PSFlowBridge");
const userStateStore=require('../shared/user-state-store.cjs').createUserStateStore({file:path.join(DATA_DIR,'user-state.json')});
// Take over console output once the data directory is known. This writes to
// DATA_DIR/logs/helper*.log and never touches the protocol stdout channel.
// A failure here (read-only disk, invalid path) is non-fatal by design.
const consoleLogger = require("../shared/rolling-log.cjs").installConsoleLogger({
  directory: path.join(DATA_DIR, "logs"), name: "helper"
});
const apiBackend = require("./api-backend");
const browserRouting = require("../action-bridge/browser-routing.cjs");
const managedClient = "flow-tab-qkmanaged";
const usesManagedBrowser = () => runtimeMode()==="browser" && browserRouting.preference(DATA_DIR)==="quicker";
const selectedFlowClient = value => usesManagedBrowser() ? value.client===managedClient : value.client!==managedClient;

// 运行模式：local 走本机 Python 后端；browser 由浏览器扩展托管生成，不调用
// Python 后端，也不需要它存在。缺省回退 local，保持老机器行为。
function runtimeMode() {
  try {
    const raw = require("node:fs").readFileSync(path.join(DATA_DIR, "mode.json"), "utf8").replace(/^\uFEFF/, "");
    const parsed = JSON.parse(raw);
    return parsed && parsed.mode === "local" ? "local" : "browser";
  } catch { return "browser"; }
}
const {referenceSnapshot}=require("./reference-state");
const {captureTimings,recoveryFor,lifecycleSnapshot,validEditMode,mayHaveSubmitted,cancelJob}=require("./job-lifecycle");
const {moveToTrash,restoreFromTrash,listTrash,inspectTrashRecord}=require("./trash-store");
const {checkCleanup}=require("./history-cleanup");
const {shareSnapshot}=require("./immutable-snapshot");
const sharp = require("sharp");
const extraImageInput=require('./extra-image');
const extraUploads=new Set(),contextUploads=new Set();
const contextInput=require('./context-input');
const { processResult } = require("./result-geometry");
const { createDataHealth, readJobStore } = require("./job-store-health");
const { createJobPersister } = require("./job-persistence");
const JOBS_DIR = path.join(DATA_DIR, "jobs");
const CONFIG_PATH = path.join(DATA_DIR, "config.json");
const MAX_PIXELS = 25000000;
const MAX_RAW_BYTES = 120 * 1024 * 1024;
const jobs = new Map();
// Last successfully persisted snapshot per job, used to roll memory back when a
// durable write fails so memory can never pose as a newer, saved state.
const committedJobs = new Map();
const dataHealth = createDataHealth();
const jobPersister = createJobPersister({
  jobs, committedJobs, dataHealth,
  write: (job, snapshot) => require("./atomic-file").writeTextAtomically(path.join(jobDir(job.id), "job.json"), snapshot)
});
const inflightRegenerations = new Map();
const inflightCreations = new Set();
const browserClients = new Map();
const flowStates = new Map();
const allowedOrigins = new Set([
  "null",
  "uxp://com.weizhi.psflowbridge",
  "https://flow.google.com",
  "https://labs.google"
]);

let pairingToken = "";
let workerBusy = false;
let actionBridge = null;
let draining = false;
let activeRequests = 0;
function activeTaskCount() {
  // Background durable writes must keep the helper "busy" so a package upgrade
  // or drain cannot proceed while a job snapshot is still being committed.
  return activeRequests + Number(workerBusy) + Number(jobPersister.pendingCount() > 0) +
    Number([...jobs.values()].some(job => ["uploading","queued","attaching","waiting_user","generating","downloading","importing"].includes(job.status) ||
      (job.status === "unknown" && !job.waitingStopped && job.recoveryState !== "attention_required")));
}

function json(res, status, value) {
  const body = Buffer.from(JSON.stringify(value));
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Content-Length": body.length,
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function cors(req, res) {
  const origin = req.headers.origin || "";
  const isExtension = /^chrome-extension:\/\/[a-p]{32}$/.test(origin);
  if (allowedOrigins.has(origin) || isExtension) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Authorization, Content-Type, X-PSFB-Client");
    res.setHeader("Access-Control-Max-Age", "600");
    res.setHeader("Access-Control-Allow-Private-Network", "true");
  }
}

// 构建身份由启动方注入；缺省 dev 只用于手动直跑源码目录的场景。
const buildId = String(process.env.PSFB_BUILD_ID || "dev").trim() || "dev";
// 版本号以 package.json 为单一数据源，避免与启动器的身份校验漂移。
const helperVersion = String(require("./package.json").version || "0.0.0");

function isSafeLoopback(req) {
  const host = String(req.headers.host || "").toLowerCase();
  const remote = req.socket.remoteAddress || "";
  return (host === "127.0.0.1:" + PORT || host === "localhost:" + PORT) &&
    (remote === "127.0.0.1" || remote === "::ffff:127.0.0.1" || remote === "::1");
}

function authorized(req) {
  const match = /^Bearer (.+)$/.exec(String(req.headers.authorization || ""));
  if (!match) return false;
  const actual = Buffer.from(match[1]);
  const expected = Buffer.from(pairingToken);
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

async function readJson(req, maxBytes = 1024 * 1024) {
  const declared = Number(req.headers["content-length"] || 0);
  if (declared > maxBytes) throw Object.assign(new Error("请求内容过大。"), { status: 413 });
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw Object.assign(new Error("请求内容过大。"), { status: 413 });
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw Object.assign(new Error("请求不是有效 JSON。"), { status: 400 });
  }
}

function safeId(id) {
  return /^[0-9a-f-]{36}$/i.test(id || "");
}

function jobDir(id) {
  if (!safeId(id)) throw Object.assign(new Error("任务编号无效。"), { status: 400 });
  return path.join(JOBS_DIR, id);
}

// browser 模式下 Flow 结果由扩展抓取后回传；用素材宽高与 Flow 实际输出的比例
// 换算出与本地后端一致的居中填充框，回贴前再裁回捕获区域，避免拉伸变形。
function browserTransform(job, aspect) {
  const match = /^(\d{1,2}):(\d{1,2})$/.exec(String(aspect || ""));
  let ratio = match ? Number(match[1]) / Number(match[2]) : NaN;
  if (!Number.isFinite(ratio) || ratio <= 0) {
    const target = job.aspectTarget || job.source;
    ratio = target && target.width && target.height ? target.width / target.height : 1;
  }
  const width = job.source.width, height = job.source.height;
  const paddedW = Math.max(width, Math.ceil(height * ratio));
  const paddedH = Math.max(height, Math.ceil(width / ratio));
  return {
    width, height, paddedW, paddedH,
    left: Math.floor((paddedW - width) / 2),
    top: Math.floor((paddedH - height) / 2),
    aspect: match ? match[1] + ":" + match[2] : ""
  };
}

async function readImageBody(req, maxBytes) {
  const declared = Number(req.headers["content-length"] || 0);
  if (Number.isSafeInteger(declared) && declared > maxBytes) {
    throw Object.assign(new Error("生成结果过大。"), { status: 413 });
  }
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw Object.assign(new Error("生成结果过大。"), { status: 413 });
    chunks.push(chunk);
  }
  if (!size) throw Object.assign(new Error("生成结果为空。"), { status: 400 });
  return Buffer.concat(chunks);
}

function publicJob(job) {
  const { internalError, backendResultUrl, pendingImageDownload, batchResultUrls, ...safe } = job;
  return {...safe,kind:job.kind||'image2image',standalone:standalone(job),reference:job.kind==='text2image'?null:referenceSnapshot(job),lifecycle:lifecycleSnapshot(job),recovery:recoveryFor(job)};
}

function standalone(job) { return job.kind === 'text2image' || job.standalone === true; }
function textOptions(input) {
  const model=input.model===undefined?'gemini-3.1-flash-image':input.model;
  const count=input.count===undefined?1:Number(input.count);
  const aspectRatio=input.aspectRatio===undefined?'1:1':input.aspectRatio;
  if(!['gemini-3.1-flash-image','gemini-3.0-pro-image'].includes(model)||![1,2,3,4].includes(count)||!['1:1','4:3','3:4','16:9','9:16'].includes(aspectRatio))
    throw Object.assign(new Error('生成模型、张数或比例无效，未提交生成。'),{status:400});
  return {model,count,aspectRatio};
}
async function createStandalone(input, prompt, editMode, baseJob=null, base='source') {
  const {model,count,aspectRatio}=textOptions(input);
  const provider=input.provider==='api'?'api':'browser';
  if(input.operationId!==undefined&&!safeId(input.operationId))throw Object.assign(new Error('生成编号无效。'),{status:400});
  const id=input.operationId||crypto.randomUUID(),kind=baseJob&&baseJob.kind!=='text2image'||base==='result'?'image2image':'text2image';
  let references=await extraImageInput.validateReferences(input.references,sharp);
  if(input.references===undefined&&baseJob?.references?.length){
    references=[];
    for(let index=0;index<baseJob.references.length;index++){
      const bytes=await fsp.readFile(path.join(jobDir(baseJob.id),`reference-${index}.png`));
      const checked=await extraImageInput.validate(bytes,sharp,{purpose:'reference'});
      if(!extraImageInput.matches(baseJob.references[index],checked.metadata))throw extraImageInput.invalid('历史参考图已变化，未提交生成。',409);
      references.push({...checked,name:baseJob.references[index].name});
    }
  }
  // Standalone/capture regeneration has no full-frame context and no extra
  // slot: the only images are the base plus references. The cap is 1 + refs,
  // checked after inheritance and decoding so inherited refs count too.
  if(kind!=='text2image'&&1+references.length>4)throw extraImageInput.invalid('局部底图与参考图合计不能超过 4 张，未提交生成。');
  let sourceFile=null,source=null;
  if(kind==='image2image'){
    const index=input.index===undefined?Number(baseJob.selectedIndex||0):input.index;
    if(base==='result'){
      const image=(baseJob.images||[]).find(item=>item.index===index);
      if(!image)throw Object.assign(new Error('结果编号无效。'),{status:400});
      sourceFile=path.join(jobDir(baseJob.id),resultFileName(baseJob,index));
      const actual=crypto.createHash('sha256').update(await fsp.readFile(sourceFile)).digest('hex');
      if(actual!==image.sha256)throw Object.assign(new Error('结果图片已变化，未创建精修任务。'),{status:409});
    }else sourceFile=path.join(jobDir(baseJob.id),'source.png');
    const meta=await sharp(sourceFile,{limitInputPixels:MAX_PIXELS}).metadata();
    source={width:meta.width,height:meta.height,components:meta.hasAlpha?4:3,colorProfile:'sRGB IEC61966-2.1'};
  }
  const signature=crypto.createHash('sha256').update(JSON.stringify([kind,prompt,editMode,model,count,aspectRatio,provider,baseJob?.id,base,input.index,source,references.map(item=>item.metadata.sha256)])).digest('hex');
  if(jobs.has(id)){
    const existing=jobs.get(id);if(existing.createSignature!==signature)throw Object.assign(new Error('生成编号已属于不同请求，请查询原任务。'),{status:409});
    return {job:existing,idempotent:true};
  }
  if(inflightCreations.has(id))throw Object.assign(new Error('原任务正在创建，请查询原任务。'),{status:409});
  inflightCreations.add(id);
  try{
    await fsp.mkdir(jobDir(id),{recursive:true});
    if(sourceFile)await require('./immutable-snapshot').shareSnapshot(sourceFile,path.join(jobDir(id),'source.png'));
    for(let index=0;index<references.length;index++)await fsp.writeFile(path.join(jobDir(id),`reference-${index}.png`),references[index].bytes);
    const stamp=new Date().toISOString();
    const job={id,operationId:id,createSignature:signature,schemaVersion:1,kind,standalone:true,hasCapture:false,
      model,count,aspectRatio,prompt,editMode,provider,status:'queued',createdAt:stamp,updatedAt:stamp,
      documentID:null,documentName:null,documentPath:null,documentSession:null,canvas:null,bounds:null,mask:null,source,
      sourceReady:true,maskReady:true,extraReady:true,hasExtraImage:false,extraImage:null,transform:null,browserClient:null,error:null,
      geometryVersion:1,aspectTarget:source?{width:source.width,height:source.height}:null};
    job.references=references.map(item=>({...item.metadata,name:item.name}));
    if(baseJob)Object.assign(job,{baseJobId:baseJob.id,parentJobId:baseJob.id,rootJobId:baseJob.rootJobId||baseJob.id,version:(Number(baseJob.version)||1)+1,base,resultIndex:base==='result'?(input.index??baseJob.selectedIndex??0):undefined});
    await saveJob(job);jobs.set(id,job);if(job.provider==='api')scheduleWorker();return {job,idempotent:false};
  }finally{inflightCreations.delete(id);}
}

function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1));
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const name = Buffer.from(type, "ascii");
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length, 0);
  const check = Buffer.alloc(4);
  check.writeUInt32BE(crc32(Buffer.concat([name, data])), 0);
  return Buffer.concat([length, name, data, check]);
}

function rawToPng(raw, width, height, components) {
  if (!Number.isInteger(width) || !Number.isInteger(height) ||
      width < 1 || height < 1 || width * height > MAX_PIXELS) {
    throw new Error("像素尺寸超出允许范围。");
  }
  if (![1, 3, 4].includes(components) || raw.length !== width * height * components) {
    throw new Error("像素数据与声明尺寸不匹配。");
  }

  const rowBytes = width * components;
  const filtered = Buffer.allocUnsafe((rowBytes + 1) * height);
  for (let y = 0; y < height; y++) {
    const dst = y * (rowBytes + 1);
    filtered[dst] = 0;
    raw.copy(filtered, dst + 1, y * rowBytes, (y + 1) * rowBytes);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = components === 1 ? 0 : (components === 3 ? 2 : 6);
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    pngChunk("IHDR", ihdr),
    pngChunk("IDAT", zlib.deflateSync(filtered)),
    pngChunk("IEND", Buffer.alloc(0))
  ]);
}

async function loadConfig() {
  await fsp.mkdir(JOBS_DIR, { recursive: true });
  async function readToken() {
    try {
      const config = JSON.parse(await fsp.readFile(CONFIG_PATH, "utf8"));
      if (typeof config.pairingToken === "string" && config.pairingToken.length >= 32) {
        return config.pairingToken;
      }
    } catch {
      // Missing or damaged config is repaired below.
    }
    return "";
  }

  async function writeDurableFile(filePath, text, exclusive) {
    const handle = await fsp.open(filePath, exclusive ? "wx" : "w");
    try {
      await handle.writeFile(text);
      await handle.sync();
    } finally {
      await handle.close();
    }
  }

  for (let attempt = 0; attempt < 3 && !pairingToken; attempt++) {
    const token = crypto.randomBytes(24).toString("base64url");
    try {
      await writeDurableFile(CONFIG_PATH, JSON.stringify({ pairingToken: token }, null, 2), true);
      pairingToken = token;
    } catch (error) {
      if (error.code !== "EEXIST") throw error;
      pairingToken = await readToken();
      if (!pairingToken) {
        // An existing but cleared/damaged file must be replaced atomically.
        const temporary = CONFIG_PATH + "." + crypto.randomUUID() + ".tmp";
        await writeDurableFile(temporary, JSON.stringify({ pairingToken: token }, null, 2), false);
        await fsp.rename(temporary, CONFIG_PATH);
        pairingToken = await readToken();
      }
    }
  }
  if (!pairingToken) throw new Error("无法初始化本地配对码文件：" + CONFIG_PATH);
  if (pairingToken === (await readToken()) && pairingToken.length >= 32) {
    console.log("PS Flow Bridge local pairing is ready; credentials are stored locally.");
  }

  // Startup must never silently skip an unreadable job. Every failure is
  // classified into dataHealth instead, and the original file is left in place.
  let scan;
  try {
    scan = await readJobStore(JOBS_DIR);
  } catch (error) {
    console.error("PS Flow 任务目录暂时无法访问，未加载任务记录。", error);
    dataHealth.recordIssue(null, "inaccessible");
    scan = { scanned: 0, records: [], issues: [] };
  }
  dataHealth.recordScan(scan);
  for (const issue of scan.issues) {
    console.error("PS Flow 任务记录未加载：" + issue.category + "（" + (issue.jobId || "jobs-dir") + "）");
  }
  for (const record of scan.records) {
    const { id, data, raw } = record;
    try {
      // Memory must start from what is actually on disk, so a failed migration
      // write can roll back to a state that still matches the file.
      committedJobs.set(id, raw);
      const before = JSON.stringify(data);
      if(data.status==='cancelled'&&mayHaveSubmitted(data)){data.status='unknown';data.waitingStopped=true;data.cancellation=data.cancellation||{mode:'stop_waiting',requestedAt:data.updatedAt||new Date().toISOString()};}
      const interruptedFlowUpload = data.status === "uploading" && data.sourceReady && data.maskReady && (!data.hasExtraImage || data.extraReady) && contextInput.ready(data);
      if (data.provider === "api" && (["generating", "downloading"].includes(data.status) || interruptedFlowUpload)) {
        const hasResultUrls = !!data.backendResultUrl || (Array.isArray(data.batchResultUrls) && data.batchResultUrls.length > 0);
        data.status = hasResultUrls ? "queued" : "unknown";
        data.error = hasResultUrls ? null : "服务曾中断，生成结果待确认，请先检查 Flow。";
      }
      // The Quicker built-in Flow controller does not survive a helper restart.
      // Leaving an interrupted job of its own in a process state would both pin
      // activeTaskCount() above zero (deferring every future package upgrade) and
      // leave it invisible to /jobs/next, which only ever claims "queued" work.
      // Requeue what provably never submitted; anything that may have reached Flow
      // is parked as unknown so it can only be harvested, never resubmitted.
      // Extension (flow-tab-*) jobs are deliberately excluded: their browser
      // outlives the helper, so the old behaviour is kept for that flow.
      if (data.provider === "browser" && data.browserClient === managedClient &&
          ["attaching", "waiting_user", "generating"].includes(data.status)) {
        if (data.submissionSent === true || data.browserInput) {
          data.status = "unknown";
          data.submissionSent = true;
          data.submissionState = "unknown";
          data.error = data.error || "助手曾中断，生成结果待确认；查询不会重新生成。";
        } else {
          data.status = "queued";
          data.browserClient = null;
          data.submissionSent = false;
          data.submissionState = "not_submitted";
          data.error = null;
        }
      }
      jobs.set(id, data);
      if (JSON.stringify(data) !== before) {
        // A migration is only a rewrite of a readable record. If it cannot be
        // persisted, saveJob rolls memory back and reports persist_failed; the
        // on-disk record is preserved either way.
        await saveJob(data).catch(() => {});
      }
    } catch (error) {
      console.error("PS Flow 任务记录处理失败，已保留原文件：" + id, error);
      dataHealth.recordIssue(id, "invalid_record");
    }
  }
}

function requireJob(id) {
  const job = jobs.get(id);
  if (!job) throw Object.assign(new Error("找不到这个任务。"), { status: 404 });
  return job;
}

// A browser job is owned by whichever Flow client claimed it. That owner is a
// WebView2 page inside Quicker, so it can disappear without ever telling the
// helper (window closed, page navigated, panel reloaded mid-tick). When that
// happens the job stays in a process state forever: it pins activeTaskCount()
// above zero, which makes /api/health report busy:true and makes
// bootstrap.ps1 refuse every package upgrade. This reaper must therefore run on
// its own timer, never from inside /api/jobs/next - a client that sees busy:true
// stops calling that route, and the watchdog would then never fire again.
// Overridable so tests can exercise a real reap without waiting minutes.
const positiveMs = (value, fallback) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
};
const ATTACH_STALL_MS = positiveMs(process.env.PSFB_ATTACH_STALL_MS, 180000);
const GENERATING_STALL_MS = positiveMs(process.env.PSFB_GENERATING_STALL_MS, 15 * 60 * 1000);
const REAP_INTERVAL_MS = positiveMs(process.env.PSFB_REAP_INTERVAL_MS, 15000);
const UNKNOWN_ATTENTION_MS = positiveMs(process.env.PSFB_UNKNOWN_ATTENTION_MS, 30 * 60 * 1000);
async function reapStalledBrowserJobs() {
  const now = Date.now();
  for (const job of jobs.values()) {
    if(job.status==='unknown'){
      const since=job.unknownSince||job.updatedAt||job.createdAt;
      if(!job.unknownSince||(!job.recoveryState&&since)||now-Date.parse(since)>UNKNOWN_ATTENTION_MS&&job.recoveryState!=='attention_required'){
        job.unknownSince=since;job.recoveryState=now-Date.parse(since)>UNKNOWN_ATTENTION_MS?'attention_required':'waiting';await saveJob(job);
      }
    }
    if (job.provider !== "browser") continue;
    // Scope: only jobs owned by the Quicker built-in Flow controller. Extension
    // (flow-tab-*) jobs are driven by a browser extension that manages its own
    // attach/retry rhythm, so reclassifying them on a timer would silently change
    // that flow's semantics. This reaper exists solely because the built-in
    // controller is the one owner that can vanish without a word.
    if (job.browserClient !== managedClient) continue;
    const idle = now - Date.parse(job.updatedAt);
    if (!Number.isFinite(idle)) continue;
    // An attaching job can already carry submissionSent=true: the browser client
    // reports the click as soon as it happens, and the job only advances to
    // "generating" once the page confirms a request landed. Such a job must be
    // parked too, or a client that dies between click and confirmation would
    // strand it in "attaching" - the same deadlock this reaper exists to remove.
    if (job.status === "attaching" && idle > ATTACH_STALL_MS) {
      // Never silently requeue. `browserInput` exists only once the reference
      // image and the guided prompt were prepared, which is the last step before
      // the controller arms and clicks; a job that got that far may already have
      // been submitted even though the receipt write did not land. Requeueing it
      // would let a second client attach and generate again. Park it as unknown
      // so it can only ever be harvested, never resubmitted.
      if (job.submissionSent === true || job.browserInput) {
        job.status = "unknown";
        job.submissionSent = true;
        job.submissionState = "unknown";
        job.error = "内置浏览器准备超时，结果待确认；查询不会重新生成。";
      } else {
        job.status = "queued";
        job.browserClient = null;
        job.submissionSent = false;
        job.submissionState = "not_submitted";
      }
      await saveJob(job);
      continue;
    }
    if (["waiting_user", "generating"].includes(job.status) && idle > GENERATING_STALL_MS) {
      // Past this point the browser client is gone for good. A job that may have
      // reached Flow is parked as unknown so the recovery path can harvest it;
      // it is never resubmitted and stops blocking upgrades.
      job.status = "unknown";
      job.submissionSent = true;
      job.submissionState = "unknown";
      job.error = job.error || "内置浏览器长时间未回报，结果待确认；查询不会重新生成。";
      await saveJob(job);
    }
  }
}

async function saveJob(job) {
  // The persister owns the in-flight map; activeTaskCount() and the delete
  // guards read it directly so they cannot drift from the real write state.
  return jobPersister.save(job);
}

async function runWorker() {
  if (workerBusy || draining) return;
  workerBusy = true;
  try {
    for (;;) {
      const job = [...jobs.values()].find(item => item.provider === "api" && item.status === "queued" && item.sourceReady && item.maskReady && (!item.hasExtraImage || item.extraReady) && contextInput.ready(item));
      if (runtimeMode() === "browser") break;
      if (!job) break;
      try {
        job.result = await apiBackend.generate(DATA_DIR, job, jobDir(job.id), async stage => {
          if (job.status === "cancelled") throw Object.assign(new Error("任务已取消。"), { code: "cancelled" });
          job.status = job.waitingStopped ? 'unknown' : stage;
          job.updatedAt = new Date().toISOString();
          await saveJob(job);
        });
        if (job.status !== "cancelled") {job.status = "ready";job.recoveryState='resolved';job.waitingStopped=false;}
        job.error = null;
      } catch (error) {
        if (job.status !== "cancelled") job.status = job.waitingStopped || error.code === "uncertain" ? "unknown" : "failed";
        job.error = error.message;
        job.failureCode = error.code || "unknown";
        job.retrySafe = ["configuration", "offline", "login_required", "connection_unconfirmed", "rejected", "result_error", "result_ratio"].includes(error.code);
        job.submissionState = error.code === "uncertain" || job.waitingStopped ? "unknown" : job.retrySafe && !mayHaveSubmitted(job) ? "not_submitted" : "unconfirmed";
      }
      job.updatedAt = new Date().toISOString();
      await saveJob(job);
    }
  } finally { workerBusy = false; }
}

function scheduleWorker() {
  setImmediate(() => runWorker().catch(() => console.error("PS Flow 任务处理异常，请检查任务状态。")));
}

async function sendFile(res, filePath, contentType) {
  const stat = await fsp.stat(filePath);
  res.writeHead(200, {
    "Content-Type": contentType,
    "Content-Length": stat.size,
    "Cache-Control": "no-store"
  });
  await pipeline(fs.createReadStream(filePath), res);
}

function resultFileName(job, index) {
  if (index === undefined) return "result.png";
  if (!Array.isArray(job.images)) throw Object.assign(new Error("这个任务只有一张结果图。"), { status: 404 });
  const image = job.images.find((item) => item.index === index);
  if (!image) throw Object.assign(new Error("图片编号无效。"), { status: 400 });
  return image.path;
}

function selectResult(job, index) {
  if (index === undefined) return false;
  if (!Array.isArray(job.images)) {
    if (index !== 0) return false;
    job.images = [{ index: 0, path: "result.png", ...job.result }];
    job.selectedIndex = 0;
    return true;
  }
  const image = job.images.find((item) => item.index === index);
  if (!image) return false;
  job.selectedIndex = index;
  const {index:unusedIndex,path:unusedPath,...result} = image;
  job.result = result;
  return true;
}

async function writeRawUpload(req, job, kind) {
  if (job.status !== "uploading") {
    throw Object.assign(new Error("任务已取消或状态已改变。"), { status: 409 });
  }
  const meta = kind === "source" ? job.source : job.mask;
  if (!meta) throw Object.assign(new Error("该任务不需要这类素材。"), { status: 404 });
  if (String(req.headers['content-type']||'').split(';')[0] === 'image/png') {
    const started=Date.now(),declared=Number(req.headers['content-length']);
    if(!Number.isSafeInteger(declared)||declared<8||declared>64*1024*1024) throw Object.assign(new Error('Invalid PNG upload size.'),{status:413});
    const chunks=[];let size=0;
    for await(const chunk of req){size+=chunk.length;if(size>declared)throw Object.assign(new Error('Upload exceeds declared size.'),{status:400});chunks.push(chunk);}
    if(size!==declared)throw Object.assign(new Error('Incomplete PNG upload.'),{status:400});
    const bytes=Buffer.concat(chunks),info=await sharp(bytes,{limitInputPixels:MAX_PIXELS}).metadata();
    if(info.format!=='png'||info.width!==meta.width||info.height!==meta.height)throw Object.assign(new Error('PNG geometry mismatch.'),{status:400});
    await fsp.writeFile(path.join(jobDir(job.id),kind+'.png'),bytes);
    meta.sha256=crypto.createHash('sha256').update(bytes).digest('hex');
    if(kind==='mask')await fsp.writeFile(path.join(jobDir(job.id),'mask.raw'),await sharp(bytes).removeAlpha().extractChannel(0).raw().toBuffer());
    if(job.status==='cancelled') throw Object.assign(new Error('任务已取消。'),{status:409});
    job[kind==='source'?'sourceReady':'maskReady']=true;
    job.timings={...(job.timings||{}),[kind+'UploadMs']:Date.now()-started};
    await saveJob(job);return;
  }
  const file = path.join(jobDir(job.id), kind + ".raw");
  const declared = Number(req.headers["content-length"] || 0);
  if (declared !== meta.bytes || declared > MAX_RAW_BYTES) {
    throw Object.assign(new Error("素材大小与任务声明不符。"), { status: 400 });
  }
  await fsp.rm(file, { force: true });
  await pipeline(req, fs.createWriteStream(file, { flags: "wx" }));
  const stat = await fsp.stat(file);
  if (stat.size !== meta.bytes) {
    await fsp.rm(file, { force: true });
    throw Object.assign(new Error("素材上传不完整。"), { status: 400 });
  }
  const raw = await fsp.readFile(file);
  const png = rawToPng(raw, meta.width, meta.height, meta.components);
  await fsp.writeFile(path.join(jobDir(job.id), kind + ".png"), png);
  meta.sha256=crypto.createHash('sha256').update(png).digest('hex');
  if(job.status==="cancelled") throw Object.assign(new Error("任务已取消。"),{status:409});
  job[kind === "source" ? "sourceReady" : "maskReady"] = true;
  await saveJob(job);
}

async function route(req, res) {
  if (!isSafeLoopback(req)) return json(res, 403, { error: "仅允许从本机访问。" });
  cors(req, res);
  if (req.method === "OPTIONS") {
    res.writeHead(204);
    return res.end();
  }

  const url = new URL(req.url, "http://" + HOST + ":" + PORT);
  if (url.pathname === "/api/pair" && req.method === "POST") {
    const origin = String(req.headers.origin || "");
    const client = req.headers["x-psfb-client"];
    const extension = client === "extension" && /^chrome-extension:\/\/[a-p]{32}$/.test(origin);
    const panel = client === "photoshop" && ["", "null", "uxp://com.weizhi.psflowbridge"].includes(origin);
    if (!extension && !panel) return json(res, 403, { error: "仅允许本机插件自动配对。" });
    return json(res, 200, { pairingToken });
  }
  if (url.pathname === "/api/health" && req.method === "GET") {
    if (!authorized(req)) return json(res, 401, { error: "配对码错误。" });
    const activeTasks = activeTaskCount();
    const effMode = runtimeMode();
    return json(res, 200, {
      ok: true,
      app: "PSFlowBridge",
      version: helperVersion,
      buildId,
      runtimeId: process.env.PSFB_RUNTIME_ID || null,
      runtimeRoot: process.env.PSFB_DEPENDENCY_ROOT || null,
      pid: process.pid,
      protocolVersion: 2,
      effectiveMode: effMode,
      mode: effMode,
      capabilities: ["action-command","binary-preview","partial-results","lifecycle-drain","native-batch","composite-preview","alignment-guard"],
      busy: activeTasks > 0 || !!(actionBridge && actionBridge.isBusy()),
      activeTasks,
      draining,
      // Frozen cross-module contract: counts + safe {jobId, code, stage,
      // retryable} only. Never paths, stacks, credentials or prompts.
      dataHealth: dataHealth.snapshot()
    });
  }
  if (!url.pathname.startsWith("/api/")) return json(res, 404, { error: "没有这个接口。" });
  if (!authorized(req)) return json(res, 401, { error: "配对码错误。" });
  if (url.pathname === "/api/lifecycle/drain" && req.method === "POST") {
    const activeTasks = activeTaskCount();
    if (activeTasks || (actionBridge && actionBridge.isBusy())) return json(res,409,{ok:false,deferred:true,activeTasks,error:"任务仍在处理中，升级已延后。"});
    draining = true;
    if (actionBridge) actionBridge.close();
    return json(res,200,{ok:true,drained:true,activeTasks:0,draining:true});
  }
  if (url.pathname === "/api/lifecycle/resume" && req.method === "POST") {
    draining = false;
    scheduleWorker();
    return json(res,200,{ok:true,drained:true,activeTasks:0,draining:false});
  }
  if (draining && (req.method !== "GET" || url.pathname === "/api/jobs/next")) return json(res,503,{error:"助手正在升级，请稍后重试。",code:"draining"});

  if (url.pathname === "/api/action-command" && req.method === "POST") {
    const input = await readJson(req, 64 * 1024 * 1024);
    if(input.op==='user-state-read'||input.op==='user-state-write'){
      try{return json(res,200,input.op==='user-state-read'?await userStateStore.read():await userStateStore.save(input));}
      catch(error){return json(res,200,{ok:false,code:error.code||'user_state_unavailable',error:error.message});}
    }
    if (!actionBridge) actionBridge = require("../action-bridge/host.cjs");
    try {
      return json(res, 200, await actionBridge.dispatch({preview:false,...input}));
    } catch(error) {
      return json(res, 200, {ok:false,error:error.message,code:error.code,field:error.field,submissionSent:error.submissionSent,loginRequired:error.loginRequired,connection:error.connection,
        job:error.job || undefined,uncertain:error.uncertain || undefined});
    }
  }

  if (url.pathname === "/api/backend/status" && req.method === "GET") {
    // browser 模式没有 Python 后端；把在线状态改由已配对的浏览器扩展证明。
    if (runtimeMode() === "browser") {
      const now = Date.now();
      const activeStates = [...flowStates.values()].filter(v => now - v.seen < 15000 && selectedFlowClient(v));
      const paired = activeStates.length > 0;
      // Managed Flow configures and verifies model/aspect before arming submission.
      const projectReady = activeStates.some(v => v.client===managedClient
        ? Boolean(v.project) && v.dom?.editorFound===true
        : /Nano\s*Banana|Imagen/i.test(v.model) && !/Veo/i.test(v.model) && Boolean(v.aspect) && Boolean(v.project));
      return json(res, 200, {
        online: paired,
        loginRequired: !paired,
        sessionReady: paired,
        projectReady,
        mode: "browser",
        message: usesManagedBrowser() ? (paired ? "QK 内置 Flow 已连接。" : "请打开 QK 内置 Flow 并完成登录。") : paired
          ? "浏览器扩展已连接。生成任务会送到你打开的 Flow 页面。"
          : "未检测到浏览器扩展。请打开 Flow 页面，并确认已加载 PS Flow Bridge 扩展。"
      });
    }
    return json(res, 200, await (url.searchParams.get("confirm") === "1" ? apiBackend.waitForSession(DATA_DIR) : apiBackend.status(DATA_DIR)));
  }

  if (url.pathname === "/api/flow-state" && req.method === "POST") {
    const input = await readJson(req, 8192);
    if (!/^flow-tab-[a-z0-9]{1,16}$/.test(input.client || "")) return json(res, 400, {error:"浏览器编号无效。"});
    const now = Date.now();
    for (const [id, value] of flowStates) if (now-value.seen>300000) flowStates.delete(id);
    if (flowStates.size>=100 && !flowStates.has(input.client)) return json(res, 429, {error:"浏览器数量过多。"});
    const value = {client:input.client,seen:now,visible:input.visible===true,version:String(input.version||"").slice(0,20),
      project:String(input.project||"").slice(0,120),model:String(input.model||"").slice(0,80),
      aspect:/^\d{1,2}:\d{1,2}$/.test(input.aspect||"")?input.aspect:"",
      resolution:String(input.resolution||"").slice(0,30),
      stage:["idle","ready","generating","complete","error"].includes(input.stage)?input.stage:"idle",
      transferStage:["reading","transferring"].includes(input.transferStage)?input.transferStage:null,
      percent:Number.isFinite(input.percent)?Math.max(0,Math.min(100,input.percent)):null,
      startedAt:Number.isFinite(input.startedAt)?input.startedAt:null,updatedAt:new Date(now).toISOString()};
    if(input.dom&&typeof input.dom==='object'){
      const clean=value=>String(value||'').replace(/\s+/g,' ').trim().slice(0,80);
      value.dom={editorFound:input.dom.editorFound===true,composerFound:input.dom.composerFound===true,
        editorTag:clean(input.dom.editorTag),editorClass:clean(input.dom.editorClass),editorTextLength:Number.isInteger(input.dom.editorTextLength)?Math.min(4000,Math.max(0,input.dom.editorTextLength)):null,contentEditable:input.dom.contentEditable===true,focused:input.dom.focused===true,
        composerTag:clean(input.dom.composerTag),composerClass:clean(input.dom.composerClass),
        buttons:(Array.isArray(input.dom.buttons)?input.dom.buttons:[]).slice(0,12).map(button=>({tag:clean(button?.tag),class:clean(button?.class),label:clean(button?.label),title:clean(button?.title),type:clean(button?.type),role:clean(button?.role),text:clean(button?.text),disabled:button?.disabled===true,ariaDisabled:clean(button?.ariaDisabled),selected:button?.selected===true}))};
    }
    flowStates.set(input.client,value); browserClients.set(input.client,now);
    const job=jobs.get(input.jobID);
    if (job && job.provider==="browser" && job.browserClient===input.client &&
        ["attaching","waiting_user","generating","unknown"].includes(job.status)) {
      if (input.submissionSent===true) {
        job.submissionSent = true;
        job.submissionState = job.images?.length ? "confirmed" : "unknown";
        // A click attempt advances local progress; it does not confirm Google's acceptance.
        if (!job.waitingStopped && value.stage==="generating" && (["attaching","waiting_user"].includes(job.status) || (job.status==="unknown" && input.client===managedClient && input.generationConfirmed===true))) {
          job.status="generating";
          // Reaching this branch means generation is confirmed (the managed client
          // only reports stage=generating once a request landed). Clear the stale
          // "waiting for Flow" notice for any client; otherwise a job that is
          // demonstrably generating keeps showing "待确认" text.
          job.error=null;
        }
      } else if (input.submissionSent===false && !job.submissionSent) {
        job.submissionSent = false;
        job.submissionState = "not_submitted";
      }
      job.flow={...value}; delete job.flow.seen;
      job.webProgress = value.stage==="generating" ? {
        source:"flow-dom",percent:value.percent,stage:value.transferStage,items:[],updatedAt:value.updatedAt
      } : null;
      job.updatedAt = new Date(now).toISOString();
      await saveJob(job);
    }
    return json(res,200,{ok:true});
  }
  if (url.pathname === "/api/flow-state" && req.method === "GET") {
    const active=[...flowStates.values()].filter(v=>Date.now()-v.seen<15000 && selectedFlowClient(v)).sort((a,b)=>Number(b.visible)-Number(a.visible)||Number(b.stage==='generating')-Number(a.stage==='generating')||b.seen-a.seen);
    const state=active[0]||null;
    return json(res,200,{connected:!!state,state});
  }

  if (url.pathname === "/api/browser-status" && req.method === "GET") {
    const now = Date.now();
    const clients = [...browserClients.entries()].filter(([id])=>selectedFlowClient({client:id})).map(([id, lastSeen]) => ({
      id, lastSeen: new Date(lastSeen).toISOString(), active: now - lastSeen < 15000
    }));
    return json(res, 200, { connected: clients.some((client) => client.active), clients });
  }

  if (url.pathname === "/api/jobs" && req.method === "POST") {
    const input = await readJson(req, 64 * 1024 * 1024);
    const prompt = String(input.prompt || "").trim();
    const editMode=validEditMode(input.editMode);
    if (!prompt || prompt.length > LIMITS.promptMax) throw Object.assign(new Error("请填写 1 到 4000 字的提示词。"), { status: 400 });
    if(input.kind!==undefined&&!['image2image','text2image'].includes(input.kind))throw Object.assign(new Error('生成类型无效。'),{status:400});
    if(input.kind==='text2image'){
      if(['source','mask','bounds','canvas','documentID','documentSession','documentPath','psSession','extraImage','contextSource','contextMode'].some(key=>input[key]!=null)||input.hasExtraImage===true||input.hasGlobalContext===true)
        throw Object.assign(new Error('文本生成不能携带文档或参考图，未提交生成。'),{status:400});
      const result=await createStandalone(input,prompt,editMode);
      return json(res,result.idempotent?200:201,{job:publicJob(result.job),idempotent:result.idempotent});
    }
    // The image entry accepts one user reference through extraImage only.
    // Same shape rule as extra-image.validateReferences: undefined or [] is
    // fine, anything else is refused here (before any job dir) instead of
    // being dropped silently. A non-empty array has a dedicated message.
    if(input.references!==undefined&&!Array.isArray(input.references))
      throw extraImageInput.invalid('参考图片格式无效，未提交生成。');
    if(Array.isArray(input.references)&&input.references.length)
      throw extraImageInput.invalid('改图请使用已有附加参考图入口。');
    const context=contextInput.declaration(input);
    const source = input.source || {};
    const expectedBytes = source.width * source.height * source.components;
    if (!Number.isSafeInteger(expectedBytes) || source.width < 1 || source.height < 1 || source.width * source.height > MAX_PIXELS ||
        ![3, 4].includes(source.components) || expectedBytes > MAX_RAW_BYTES) {
      throw Object.assign(new Error("素材尺寸过大或像素格式不支持。"), { status: 413 });
    }
    const bounds = input.bounds || {};
    const canvas = input.canvas || {};
    const documentID = Number(input.documentID);
    if (!Number.isInteger(source.width) || !Number.isInteger(source.height) ||
        !Number.isInteger(documentID) || documentID < 1 ||
        !Number.isInteger(bounds.left) || !Number.isInteger(bounds.top) ||
        !Number.isInteger(bounds.right) || !Number.isInteger(bounds.bottom) ||
        !Number.isInteger(bounds.width) || !Number.isInteger(bounds.height) ||
        bounds.width !== source.width || bounds.height !== source.height ||
        bounds.right - bounds.left !== bounds.width || bounds.bottom - bounds.top !== bounds.height ||
        bounds.left < 0 || bounds.top < 0 ||
        !Number.isInteger(canvas.width) || !Number.isInteger(canvas.height) ||
        canvas.width < 1 || canvas.height < 1 ||
        bounds.right > canvas.width || bounds.bottom > canvas.height) {
      throw Object.assign(new Error("文档尺寸或回贴位置无效。"), { status: 400 });
    }
    const mask = input.mask || null;
    if (mask && (!Number.isInteger(mask.width) || !Number.isInteger(mask.height) ||
        mask.width !== source.width || mask.height !== source.height ||
        !Number.isSafeInteger(mask.width * mask.height * mask.components) ||
        mask.width * mask.height > MAX_PIXELS || mask.components !== 1 ||
        mask.width * mask.height * mask.components > MAX_RAW_BYTES)) {
      throw Object.assign(new Error("选区蒙版数据不合法。"), { status: 400 });
    }
    if(input.operationId !== undefined && !safeId(input.operationId))throw Object.assign(new Error("生成编号无效。"),{status:400});
    const id = input.operationId || crypto.randomUUID();
    const extraIdentity=input.extraImage?{width:input.extraImage.width,height:input.extraImage.height,sha256:input.extraImage.sha256,purpose:input.extraImage.purpose||'reference'}:null;
    if(extraIdentity&&(!input.hasExtraImage||!Number.isInteger(extraIdentity.width)||!Number.isInteger(extraIdentity.height)||extraIdentity.width<1||extraIdentity.height<1||extraIdentity.width*extraIdentity.height>MAX_PIXELS||!/^[a-f0-9]{64}$/.test(extraIdentity.sha256||'')||typeof extraIdentity.purpose!=='string'||extraIdentity.purpose.length>50))throw extraImageInput.invalid('附加参考图身份声明无效。');
    const createSignature = crypto.createHash("sha256").update(JSON.stringify([prompt,editMode,input.model,input.count,input.documentID,input.documentPath,input.documentSession,source,bounds,canvas,mask,input.editRegion,input.referencePolicy,Boolean(input.hasExtraImage),extraIdentity,context])).digest("hex");
    if(jobs.has(id)) {
      const existing=jobs.get(id);
      if(existing.createSignature !== createSignature) return json(res,409,{error:"生成编号已属于不同请求，请查询原任务。"});
      return json(res,200,{job:publicJob(existing),idempotent:true});
    }
    if(inflightCreations.has(id))return json(res,409,{error:"原任务正在创建，请查询原任务。"});
    const editRegion=input.editRegion;
    if(input.geometryVersion===2 && (!editRegion || !['left','top','width','height'].every(k=>Number.isInteger(editRegion[k])) || editRegion.left<0 || editRegion.top<0 || editRegion.width<1 || editRegion.height<1 || editRegion.left+editRegion.width>source.width || editRegion.top+editRegion.height>source.height))throw Object.assign(new Error('Invalid edit context geometry.'),{status:400});
    inflightCreations.add(id);
    try {
    await fsp.mkdir(jobDir(id), { recursive: true });
    const job = {
      id,
      operationId:id,createSignature,schemaVersion:1,editMode,...context,contextReady:!context.hasGlobalContext,
      provider: input.provider === "api" ? "api" : "browser",
      count: [1, 2, 3, 4].includes(Number(input.count)) ? Number(input.count) : 1,
      model: typeof input.model === "string" ? input.model.slice(0, 120) : "",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: "uploading",
      prompt,
      matchAspect:input.matchAspect===true,
      aspectTarget:input.aspectTarget && Number.isInteger(input.aspectTarget.width) && Number.isInteger(input.aspectTarget.height) && input.aspectTarget.width>0 && input.aspectTarget.height>0 && input.aspectTarget.width*input.aspectTarget.height<=MAX_PIXELS ? {width:input.aspectTarget.width,height:input.aspectTarget.height} : {width:source.width,height:source.height},
      scope: input.scope === "canvas" ? "canvas" : "selection",
      documentName: typeof input.documentName === "string" ? input.documentName.slice(0, 260) : undefined,
      documentPath: typeof input.documentPath === "string" ? input.documentPath.slice(0, 1024) : undefined,
      documentSession: typeof input.documentSession === "string" ? input.documentSession.slice(0, 260) : (typeof input.psSession === "string" ? input.psSession.slice(0, 260) : undefined),
      resultMaskMode: input.resultMaskMode === "external" ? "external" : undefined,
      referencePolicy:["selection-contrast","selection-outline"].includes(input.referencePolicy)?input.referencePolicy:undefined,
      documentID,
      bounds,
      canvas,
      geometryVersion:input.geometryVersion===2?2:1,editRegion:input.editRegion,editBounds:input.editBounds,
      timings:captureTimings(input.timings),
      source: {
        width: source.width,
        height: source.height,
        components: source.components,
        bytes: expectedBytes,
        colorProfile: String(source.colorProfile || "sRGB IEC61966-2.1").slice(0, 100)
      },
      mask: mask ? {
        width: mask.width,
        height: mask.height,
        components: 1,
        bytes: mask.width * mask.height,
        colorProfile: "Gray Gamma 2.2"
      } : null,
      hasExtraImage: Boolean(input.hasExtraImage),
      extraReady: !input.hasExtraImage,
      extraImage: input.extraImage && typeof input.extraImage === "object" ? {
        width: Number(input.extraImage.width) || undefined,
        height: Number(input.extraImage.height) || undefined,
        sha256: typeof input.extraImage.sha256 === "string" ? input.extraImage.sha256 : undefined,
        purpose: typeof input.extraImage.purpose === "string" ? input.extraImage.purpose : "reference"
      } : null,
      sourceReady: false,
      maskReady: !mask,
      browserClient: null,
      error: null
    };
    jobs.set(id, job);
    await saveJob(job);
    return json(res, 201, { job: publicJob(job) });
    } finally {inflightCreations.delete(id);}
  }

  if (url.pathname === "/api/jobs" && req.method === "GET") {
    const list = [...jobs.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if(url.searchParams.size){const filtered=require('./history-query').filterHistory(list,Object.fromEntries(url.searchParams));return json(res,200,{...filtered,items:filtered.items.map(publicJob),jobs:filtered.items.map(publicJob)});}
    return json(res, 200, { jobs: list.map(publicJob) });
  }

  if (url.pathname === "/api/jobs/next" && req.method === "GET") {
    const now = Date.now();
    const clientId = String(url.searchParams.get("client") || "");
    if(usesManagedBrowser() !== (clientId===managedClient)) return json(res,200,{job:null});
    if (/^flow-tab-[a-z0-9]{1,16}$/.test(clientId)) {
      for (const [id, lastSeen] of browserClients) {
        if (now - lastSeen > 300000) browserClients.delete(id);
      }
      if (browserClients.size < 100 || browserClients.has(clientId)) browserClients.set(clientId, now);
    }
    const job = [...jobs.values()]
      .filter((item) => item.provider !== "api" && item.status === "queued" && item.sourceReady && item.maskReady && (item.hasExtraImage ? item.extraReady : true) && contextInput.ready(item))
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))[0];
    if (!job) return json(res, 200, { job: null });
    job.status = "attaching";
    job.browserClient = String(url.searchParams.get("client") || "flow-tab").slice(0, 80);
    job.updatedAt = new Date().toISOString();
    await saveJob(job);
    return json(res, 200, { job: publicJob(job) });
  }

  const regenMatch = /^\/api\/jobs\/([0-9a-f-]{36})\/regenerate$/.exec(url.pathname);
  if (regenMatch && req.method === "POST") {
    const [, baseId] = regenMatch;
    const baseJob = requireJob(baseId);
    if (baseJob.status === "unknown") throw Object.assign(new Error("任务状态待确认，不能再次生成。"), { status: 409 });
    // A resolved failure that Flow did not bill may be re-sent with an edited
    // prompt. It becomes a brand-new job id, so the old attempt's one-shot submit
    // receipt cannot block it and cannot be re-used to double-submit.
    const retryableFailure = baseJob.status === "failed" && baseJob.retrySafe === true;
    if (!["ready", "imported"].includes(baseJob.status) && !retryableFailure) throw Object.assign(new Error("只有已完成、已回贴或确认未计费失败的任务可以再次生成。"), { status: 409 });
    if (!baseJob.sourceReady) throw Object.assign(new Error("原任务素材不完整，无法再次生成。"), { status: 409 });
    if (baseJob.mask && !baseJob.maskReady) throw Object.assign(new Error("原任务选区蒙版不完整，无法再次生成。"), { status: 409 });

    const input = await readJson(req, 16 * 1024);
    const base=input.base===undefined?'source':input.base;
    if(!['source','result'].includes(base))throw Object.assign(new Error('再次生成的输入类型无效。'),{status:400});
    const resultIndex=input.index===undefined?Number(baseJob.selectedIndex||0):input.index;
    if(input.index!==undefined&&(!Number.isInteger(resultIndex)||resultIndex<0))throw Object.assign(new Error('结果图片编号无效。'),{status:400});
    const baseImage=base==='result'?(baseJob.images||[]).find(image=>image.index===resultIndex):null;
    if(base==='result'&&(!['ready','imported'].includes(baseJob.status)||!baseJob.result||baseJob.images&&!baseImage))throw Object.assign(new Error('没有可用于再次生成的选中结果。'),{status:409});

    // Model validation: if provided, must be string and in allowed models; reject invalid models with 400
    let model = baseJob.model;
    if (input.model !== undefined) {
      if (typeof input.model !== "string" || !["gemini-3.1-flash-image", "gemini-3.0-pro-image"].includes(input.model)) {
        throw Object.assign(new Error("模型不支持。"), { status: 400 });
      }
      model = input.model;
    }

    // Count validation: if provided, must be in [1, 2, 3, 4]; reject invalid count with 400
    let count = baseJob.count || 1;
    if (input.count !== undefined) {
      const parsedCount = Number(input.count);
      if (![1, 2, 3, 4].includes(parsedCount)) {
        throw Object.assign(new Error("生成数量仅支持 1 到 4 张。"), { status: 400 });
      }
      count = parsedCount;
    }

    const prompt = (typeof input.prompt === "string" && input.prompt.trim()) ? input.prompt.trim() : baseJob.prompt;
    const editMode=validEditMode(input.editMode === undefined?baseJob.editMode:input.editMode);
    if (!prompt || prompt.length > LIMITS.promptMax) throw Object.assign(new Error("请填写 1 到 4000 字的提示词。"), { status: 400 });
    if(standalone(baseJob)){
      const result=await createStandalone({...input,model,count,provider:baseJob.provider,aspectRatio:input.aspectRatio??baseJob.aspectRatio??'1:1'},prompt,editMode,baseJob,base);
      return json(res,result.idempotent?200:201,{job:publicJob(result.job),idempotent:result.idempotent});
    }

    // Idempotency support: client can supply operationId (UUID)
    const operationId = typeof input.operationId === "string" && safeId(input.operationId) ? input.operationId : null;
    if(input.operationId !== undefined && !operationId)throw Object.assign(new Error("再次生成编号无效。"),{status:400});
    if(operationId && jobs.has(operationId) && jobs.get(operationId).baseJobId !== baseId)throw Object.assign(new Error("再次生成编号已属于其他任务。"),{status:409});
    const opKey = operationId;

    if (opKey && inflightRegenerations.has(opKey)) {
      // Concurrent duplicate request with the same operationId in-flight: return 409 conflict
      throw Object.assign(new Error("已有相同的再次生成请求正在执行。"), { status: 409 });
    }

    if (operationId) {
      const existing = [...jobs.values()].find(j => j.operationId === operationId && j.baseJobId === baseId);
      if (existing) {
        if((existing.base||'source')!==base||(base==='result'&&existing.resultIndex!==resultIndex))throw Object.assign(new Error('同编号再次生成的输入快照不同。'),{status:409});
        return json(res, 200, { job: publicJob(existing), idempotent: true });
      }
    }

    if (opKey) inflightRegenerations.set(opKey, Date.now());

    try {
      const newId = operationId || crypto.randomUUID();
      const baseDir = jobDir(baseId);
      const newDir = jobDir(newId);
      await fsp.mkdir(newDir, { recursive: true });
      let nextSource={...baseJob.source};
      if(base==='result'){
        const bytes=await fsp.readFile(path.join(baseDir,resultFileName(baseJob,baseJob.images?resultIndex:undefined)));
        const meta=await sharp(bytes,{limitInputPixels:MAX_PIXELS}).metadata();
        if(meta.width!==baseJob.source.width||meta.height!==baseJob.source.height)throw Object.assign(new Error('结果尺寸与原捕获区域不一致，未创建下一轮输入。'),{status:409});
        // An external mask is applied once to build the actual next-round
        // context. Original document coordinates and mask stay unchanged.
        const snapshot=baseJob.mask&&baseJob.resultMaskMode==='external'?await require('./result-geometry').makeComposite(bytes,baseJob,baseDir):await sharp(bytes).ensureAlpha().png().toBuffer();
        const sourcePath=path.join(newDir,'source.png');
        if(fs.existsSync(sourcePath)){
          if(!snapshot.equals(await fsp.readFile(sourcePath)))throw Object.assign(new Error('中断任务的结果快照不同，未覆盖。'),{status:409});
        }else await fsp.writeFile(sourcePath,snapshot,{flag:'wx'});
        nextSource={...nextSource,components:4,bytes:nextSource.width*nextSource.height*4,sha256:crypto.createHash('sha256').update(snapshot).digest('hex')};
      }else await shareSnapshot(path.join(baseDir, "source.png"), path.join(newDir, "source.png"));
      if (baseJob.mask) {
        const maskPng = path.join(baseDir, "mask.png");
        const maskRaw = path.join(baseDir, "mask.raw");
        if (fs.existsSync(maskPng)) await shareSnapshot(maskPng, path.join(newDir, "mask.png"));
        if (fs.existsSync(maskRaw)) await shareSnapshot(maskRaw, path.join(newDir, "mask.raw"));
      }
      const baseExtraPng = path.join(baseDir, "extra.png");
      if (baseJob.hasExtraImage && !fs.existsSync(baseExtraPng)) {
        throw Object.assign(new Error("原任务附加参考图文件缺失，无法继承再次生成。"), { status: 409 });
      }
      let inheritedExtraImage = null;
      const hasExtraInherited = fs.existsSync(baseExtraPng);
      if (hasExtraInherited) {
        if (baseJob.extraImage?.sha256) {
          const actualBytes = await fsp.readFile(baseExtraPng);
          const actualSha = crypto.createHash("sha256").update(actualBytes).digest("hex");
          if (actualSha !== baseJob.extraImage.sha256) {
            throw Object.assign(new Error("原任务附加参考图内容已变化，无法继承再次生成。"), { status: 409 });
          }
        }
        await shareSnapshot(baseExtraPng, path.join(newDir, "extra.png"));
        inheritedExtraImage = baseJob.extraImage ? { ...baseJob.extraImage } : null;
      }
      const inheritedContext=await contextInput.read(baseJob,baseDir);
      if(inheritedContext)await shareSnapshot(path.join(baseDir,'context.png'),path.join(newDir,'context.png'));
      const newJob = {
        contextMode:baseJob.contextMode||'auto',hasGlobalContext:!!inheritedContext,contextReady:true,contextSource:inheritedContext?.metadata||null,
        id: newId,
        baseJobId: baseId,
        parentJobId:baseId,rootJobId:baseJob.rootJobId||baseId,version:(Number(baseJob.version)||1)+1,
        base,resultIndex:base==='result'?resultIndex:undefined,parentResultSha256:base==='result'?(baseImage?.sha256||baseJob.result.sha256):undefined,
        sourceCapturedAt:base==='result'?new Date().toISOString():baseJob.sourceCapturedAt||baseJob.createdAt,
        hasExtraImage: hasExtraInherited,
        extraReady: hasExtraInherited,
        extraImage: inheritedExtraImage,
        flowProjectId:baseJob.flowProjectId,
        operationId: operationId || undefined,
        editMode,
        provider: baseJob.provider === "api" ? "api" : "browser",
        count,
        model,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: "queued",
        prompt,
        matchAspect: baseJob.matchAspect === true,
        aspectTarget: baseJob.aspectTarget ? { ...baseJob.aspectTarget } : undefined,
        scope: baseJob.scope,
        resultMaskMode: "external",
        referencePolicy:baseJob.referencePolicy==='selection-contrast'?'selection-outline':baseJob.referencePolicy,
        referenceRefreshReason:base==='result'?'result_base':baseJob.referencePolicy==='selection-contrast'?'outline_upgrade':undefined,
        documentID: baseJob.documentID,
        documentName: baseJob.documentName,
        documentPath: baseJob.documentPath,
        documentSession: baseJob.documentSession,
        bounds: { ...baseJob.bounds },
        canvas: { ...baseJob.canvas },
        geometryVersion: baseJob.geometryVersion,
        editRegion: baseJob.editRegion ? { ...baseJob.editRegion } : undefined,
        editBounds: baseJob.editBounds ? { ...baseJob.editBounds } : undefined,
        timings: { captureMs: 0 },
        source: nextSource,
        mask: baseJob.mask ? { ...baseJob.mask } : null,
        sourceReady: true,
        maskReady: !baseJob.mask || baseJob.maskReady,
        browserClient: null,
        error: null
      };
      jobs.set(newId, newJob);
      await saveJob(newJob);
      if (newJob.provider === "api") scheduleWorker();
      return json(res, 201, { job: publicJob(newJob) });
    } finally {
      if (opKey) inflightRegenerations.delete(opKey);
    }
  }

    if (url.pathname === '/api/trash' && req.method === 'GET') {
      const list = await listTrash(DATA_DIR);
      const items = [];
      const issues = [];
      for (const id of list.jobs) {
        const resRecord = await inspectTrashRecord(DATA_DIR, id, 'jobs');
        if (!resRecord.ok) {
          issues.push(resRecord.issue);
          continue;
        }
        items.push({ id, kind: 'jobs', deletedAt: resRecord.deletedAt, job: publicJob(resRecord.record) });
      }
      return json(res, 200, { ok: true, items, issues, issueCount: issues.length });
    }
    const restoreMatch = /^\/api\/trash\/([0-9a-f-]{36})\/restore$/.exec(url.pathname);
    if (restoreMatch && req.method === 'POST') {
      const id = restoreMatch[1];
      if (jobs.has(id)) return json(res, 409, { ok: false, code: 'already_exists', error: '同编号记录已存在，未覆盖。' });
      const liveDir = path.join(DATA_DIR, 'jobs', id);
      try {
        await fsp.access(liveDir);
        return json(res, 409, { ok: false, code: 'already_exists', error: '同编号记录已存在，未覆盖。' });
      } catch (e) {
        if (e.code !== 'ENOENT') throw e;
      }
      const inspectRes = await inspectTrashRecord(DATA_DIR, id, 'jobs');
      if (!inspectRes.ok) {
        if (inspectRes.issue.code === 'missing_file') {
          return json(res, 404, { ok: false, code: 'not_found', error: '回收站记录不存在。' });
        }
        if (inspectRes.issue.code === 'inaccessible') {
          return json(res, 500, { ok: false, code: 'inaccessible', error: '该记录的部分数据暂时无法读取，未恢复。' });
        }
        return json(res, 409, { ok: false, code: inspectRes.issue.code || 'trash_unreadable', error: '该记录的部分数据暂时无法读取，未恢复。' });
      }
      const record = inspectRes.record;
      if (!['ready', 'imported', 'failed', 'cancelled'].includes(record.status)) {
        return json(res, 409, { ok: false, code: 'invalid_status', error: '回收站记录状态无效，未恢复。' });
      }
      try {
        await restoreFromTrash(DATA_DIR, id, 'jobs');
      } catch (err) {
        if (err.code === 'ENOENT') return json(res, 404, { ok: false, code: 'not_found', error: '回收站记录不存在。' });
        if (err.code === 'EEXIST') return json(res, 409, { ok: false, code: 'already_exists', error: '同编号记录已存在，未覆盖。' });
        return json(res, 500, { ok: false, code: 'restore_io_error', error: '恢复记录时发生底层文件错误。' });
      }
      committedJobs.set(id, JSON.stringify(record, null, 2));
      jobs.set(id, record);
      return json(res, 200, { ok: true, restored: id, job: publicJob(record) });
    }
  const match = /^\/api\/jobs\/([0-9a-f-]{36})(?:\/(source|source\.png|reference\.png|browser-input|context|context\.png|extra|extra\.png|hd-result|mask|mask\.png|status|retry|recover|complete-upload|result|composite|thumbnail|select|favorite|import-start|import-complete|import-abort|cancel))?$/.exec(url.pathname);
  const hdUpload = /^\/api\/jobs\/([0-9a-f-]{36})\/hd-upload$/.exec(url.pathname);
  if (hdUpload && req.method === "POST") {
    const job=requireJob(hdUpload[1]),index=Number(url.searchParams.get('index')),baseHash=url.searchParams.get('sha256'),resolution=url.searchParams.get('resolution');
    const image=(job.images||[]).find(item=>item.index===index);
    const valid=()=>['ready','imported'].includes(job.status)&&job.selectedIndex===index&&image&&image.sha256===baseHash;
    if(!valid())return json(res,409,{error:'所选图片已变化或正在回贴，未关联高清图。'});
    if(!['1K','2K','4K'].includes(resolution))return json(res,400,{error:'高清尺寸无效。'});
    const bytes=await readImageBody(req,64*1024*1024),{prepareHd,saveOriginal,hash}=require('./hd-assets');
    const prepared=await prepareHd(bytes,job,jobDir(job.id));
    if(!valid())return json(res,409,{error:'下载期间所选图片已变化，未替换回贴文件。'});
    const saved=await saveOriginal(bytes,job,DATA_DIR,index,resolution,prepared.extension);
    const pasteSha256=hash(prepared.output),pastePath=path.join(jobDir(job.id),'hd-'+index+'-'+pasteSha256+'.png');
    await fsp.writeFile(pastePath,prepared.output);
    if(!valid())return json(res,409,{error:'所选图片已变化，高清原图已保存但未关联回贴。',path:saved.path});
    image.hd={...saved,resolution,width:prepared.width,height:prepared.height,sha256:hash(bytes),pasteSha256,pastePath,baseSha256:baseHash,alignment:prepared.alignment};
    await saveJob(job);
    return json(res,200,{ok:true,downloaded:true,path:saved.path,location:saved.location,hd:image.hd,job:publicJob(job)});
  }
  const resultUpload = /^\/api\/jobs\/([0-9a-f-]{36})\/result-upload$/.exec(url.pathname);
  if (resultUpload && req.method === "POST") {
    const job = requireJob(resultUpload[1]);
    if (job.provider !== "browser") return json(res, 409, { error: "本地后端任务的生成结果由助手管理。" });
    if (!job.sourceReady) return json(res, 409, { error: "任务素材尚未就绪。" });
    if (job.status === "importing") return json(res, 409, { error: "回贴期间不能替换生成结果。" });
    if (!["queued", "attaching", "waiting_user", "generating", "unknown", "ready", "imported", "failed"].includes(job.status)) {
      return json(res, 409, { error: "任务状态已变化，未保存生成结果。" });
    }
    const index = Number(url.searchParams.get("index"));
    if(url.searchParams.has('index')&&(!Number.isInteger(index)||index<0||index>=Number(job.count||1)))return json(res,400,{error:'结果图片编号无效。'});
    const position = url.searchParams.has('index')?index:0;
    // Receiving a result proves this attempt reached the provider. Set the
    // receipt before reading the body so cancellation cannot discard a late image.
    job.submissionSent=true;job.submissionState='confirmed';
    const bytes = await readImageBody(req, 64 * 1024 * 1024);
    // 每次回传都以扩展上报的 Flow 比例为准重算裁切框，避免复用上一张的比例。
    const reportedAspect = decodeURIComponent(String(url.searchParams.get("aspect") || ""));
    if (job.browserInput && reportedAspect !== (job.kind==='text2image'?job.aspectRatio:job.transform?.aspect))
      return json(res, 409, { error: "生成比例与线框参考图不一致，已保留结果，未裁切回贴。" });
    const transform = job.kind==='text2image'?null:job.browserInput ? job.transform : reportedAspect ? browserTransform(job, reportedAspect) : (job.transform || browserTransform(job, ""));
    let processed;
    try {
      processed = await processResult(bytes, { ...job, transform }, jobDir(job.id));
    } catch (error) {
      return json(res, 422, { error: (error && error.message) || "Flow 生成结果无法用于回贴。" });
    }
    if(job.status==="cancelled") return json(res,409,{error:"任务已取消，未保存结果。"});
    job.transform = transform;
    const fileName = (Number(job.count) || 1) === 1 ? "result.png" : "result-" + position + ".png";
    try {
      const temporary=path.join(jobDir(job.id),fileName+'.'+crypto.randomUUID()+'.part');
      try{await fsp.writeFile(temporary,processed.output);await fsp.rename(temporary,path.join(jobDir(job.id),fileName));}
      finally{await fsp.rm(temporary,{force:true}).catch(()=>{});}
    } catch (error) {
      await fsp.rm(path.join(jobDir(job.id), fileName + ".part"), { force: true }).catch(() => {});
      throw Object.assign(new Error("生成结果保存失败，请重试。"), { status: 500 });
    }
    if(job.status === "cancelled") return json(res,409,{error:"任务已取消，未登记结果。"});
    job.submissionSent=true;job.submissionState="confirmed";
    const images = Array.isArray(job.images) ? job.images.filter((image) => image.index !== position) : [];
    images.push({
      index: position, path: fileName, id: "main", mime: "image/png",
      width: job.kind==='text2image'?processed.width:job.source.width, height: job.kind==='text2image'?processed.height:job.source.height,
      sha256: crypto.createHash("sha256").update(processed.output).digest("hex"),
      flowAssetKey:(()=>{try{const u=new URL(url.searchParams.get("assetKey")||"");return u.protocol==="https:"&&["flow.google.com","flow-content.google"].includes(u.hostname)&&u.href.length<=2048?u.href:null;}catch{return null;}})(),
      flowProject:/^[0-9a-f-]{36}$/i.test(url.searchParams.get("project")||"")?url.searchParams.get("project"):null,
      alignment: processed.alignment
    });
    images.sort((a, b) => a.index - b.index);
    job.images = images;
    if (!job.selectedByUser || !images.some((image) => image.index === job.selectedIndex)) job.selectedIndex = position;
    const chosen = images.find((image) => image.index === job.selectedIndex) || images[0];
    const { index: unusedIndex, path: unusedPath, ...result } = chosen;
    job.result = result;
    job.progress = { done: images.length, total: Number(job.count) || 1 };
    if (job.status !== "cancelled") {
      job.status = images.length >= (Number(job.count) || 1) ? "ready" : (job.status === "failed" ? "failed" : job.status);
      if(job.status==="ready"){job.error=null;job.recoveryState='resolved';job.waitingStopped=false;}
    }
    job.updatedAt = new Date().toISOString();
    await saveJob(job);
    return json(res, 200, { ok: true, job: publicJob(job) });
  }
  if (match) {
    const [, id, action] = match;
    const job = requireJob(id);
    if(standalone(job)&&['import-start','import-complete','import-abort'].includes(action))return json(res,409,{error:'独立图片未绑定 Photoshop 文档，请作为新文档打开。'});
    if(job.kind==='text2image'&&['source','source.png','reference.png','mask','mask.png','extra','extra.png','context','context.png','composite'].includes(action))return json(res,409,{error:'此文本生成任务没有参考图或选区蒙版。'});
    if(action==='context'&&req.method==='PUT'){
      if(job.status!=='uploading'||!job.hasGlobalContext)throw contextInput.invalid('当前任务不接受全图参考变更。',409);
      if(contextUploads.has(id))throw contextInput.invalid('全图参考正在上传。',409);
      contextUploads.add(id);
      try{
        const checked=await contextInput.validate(await readImageBody(req,contextInput.MAX_BYTES),job.contextSource);
        if(job.status!=='uploading')throw contextInput.invalid('任务状态已改变，未覆盖全图。',409);
        const target=path.join(jobDir(id),'context.png'),temp=target+'.'+crypto.randomUUID()+'.tmp';
        await fsp.writeFile(temp,checked.bytes);await fsp.rename(temp,target);
        job.contextReady=true;await saveJob(job);return json(res,200,{ok:true,contextReady:true});
      }finally{contextUploads.delete(id);}
    }
    if(['context','context.png'].includes(action)&&req.method==='GET'){
      const checked=await contextInput.read(job,jobDir(id));
      if(!checked)return json(res,404,{error:'此任务没有全图参考。'});
      return sendFile(res,path.join(jobDir(id),'context.png'),'image/png');
    }
    if (action === "extra" && req.method === "PUT") {
      if(job.status!=='uploading'||!job.hasExtraImage)throw extraImageInput.invalid('当前任务不接受附加参考图变更。',409);
      if(extraUploads.has(id))throw extraImageInput.invalid('附加参考图正在上传，请查询原任务。',409);
      extraUploads.add(id);
      try {
        const started=Date.now();
        let bytes;
        try{bytes=await readImageBody(req,extraImageInput.MAX_BYTES);}catch(error){throw extraImageInput.invalid(error.message,error.status||400);}
        const checked=await extraImageInput.validate(bytes,sharp,{purpose:job.extraImage?.purpose||'reference'});
        if(!extraImageInput.matches(job.extraImage,checked.metadata))throw extraImageInput.invalid('附加参考图与原任务身份不一致，未提交生成。',409);
        if(job.status!=='uploading')throw extraImageInput.invalid('任务状态已变化，未覆盖参考图。',409);
        const target=path.join(jobDir(id),'extra.png'),temp=target+'.'+crypto.randomUUID()+'.tmp';
        await fsp.writeFile(temp,checked.bytes);await fsp.rename(temp,target);
        job.extraImage=checked.metadata;job.extraReady=true;
        job.timings={...(job.timings||{}),extraUploadMs:Date.now()-started};
        await saveJob(job);return json(res,200,{ok:true,extraReady:true});
      }finally{extraUploads.delete(id);}
    }

    if ((action === "extra" || action === "extra.png") && req.method === "GET") {
      const extraPath = path.join(jobDir(id), "extra.png");
      if (!fs.existsSync(extraPath)) return json(res, 404, { error: "无附加参考图。" });
      return sendFile(res, extraPath, "image/png");
    }
    if (req.method === "POST" && action === "browser-input") {
      if (job.provider !== "browser" || !job.sourceReady || !job.maskReady || !contextInput.ready(job) || (job.hasExtraImage&&!job.extraReady) || job.submissionSent || !["queued", "attaching", "waiting_user"].includes(job.status))
        return json(res, 409, { error: "任务不能重新准备参考图，未提交生成。" });
      const input = await readJson(req, 4096);
      if (!["1:1", "16:9", "9:16", "4:3", "3:4"].includes(input.aspect))
        return json(res, 400, { error: "参考图比例不支持，未提交生成。" });
      if (job.browserInput && job.browserInput.aspect !== input.aspect)
        return json(res, 409, { error: "任务已按原比例准备线框，未更换参考图。" });
      if(job.kind==='text2image'){
        if(input.aspect!==job.aspectRatio)return json(res,409,{error:'文本生成比例与任务不一致，未提交生成。'});
        job.browserInput={kind:'text2image',aspect:job.aspectRatio};await saveJob(job);
        const references=[];
        for(let index=0;index<(job.references||[]).length;index++)references.push({base64:(await fsp.readFile(path.join(jobDir(id),`reference-${index}.png`))).toString('base64'),name:job.references[index].name});
        return json(res,200,{kind:'text2image',prompt:job.prompt,aspect:job.aspectRatio,base64:null,extraBase64:null,references,transform:null});
      }
      // Share the exact local image/outline/coordinate prompt preparation.
      const prepared = await apiBackend.prepareInput({model:job.model,aspects:[input.aspect]}, job, jobDir(id), {dataDir:DATA_DIR});
      if (job.status === "cancelled" || job.submissionSent)
        return json(res, 409, { error: "任务状态已变化，未提交生成。" });
      const prompt = require("./reference-input").guidedPrompt(job.prompt, {...prepared.transform, hasExtraImage: Boolean(job.hasExtraImage), hasGlobalContext: job.hasGlobalContext === true}, job.editMode);
      job.transform = prepared.transform;
      job.browserInput = {sha256:crypto.createHash("sha256").update(prepared.padded).digest("hex"),aspect:prepared.transform.aspect};
      await saveJob(job);
      const ordered=await contextInput.references(job,jobDir(id));
      const contextBase64=job.hasGlobalContext?ordered.shift().base64:undefined;
      const extraBase64=job.hasExtraImage?ordered.shift().base64:undefined;
      return json(res,200,{prompt,aspect:prepared.transform.aspect,transform:prepared.transform,sha256:job.browserInput.sha256,base64:prepared.padded.toString('base64'),contextBase64,extraBase64,references:ordered});
    }
    if (req.method === "DELETE" && !action) {
      const deletion = Number(req.headers["content-length"] || 0) > 0 || req.headers["transfer-encoding"] ? await readJson(req, 4096) : {};
      if (deletion.cleanup) {
        try { checkCleanup(job, deletion.cleanup); }
        catch (error) { return json(res, error.status, { error:error.message, code:error.code }); }
      }
      const permitted = ["ready", "imported", "failed", "cancelled"];
      if (!permitted.includes(job.status)) {
        return json(res, 409, { error: "任务正在处理中或状态待确认，无法删除。" });
      }
      if (jobPersister.isPending(job.id)) {
        return json(res, 409, { error: "任务正在保存中，无法删除。" });
      }
      if (workerBusy && job.provider === "api" && job.status === "cancelled") {
        return json(res, 409, { error: "任务正在由后台处理中，无法删除。" });
      }
      await moveToTrash(DATA_DIR,id,'jobs');
      committedJobs.delete(id);
      jobs.delete(id);
      return json(res, 200, { ok: true, removed: id,recoverable:true });
    }
    if (req.method === "GET" && !action) return json(res, 200, { job: publicJob(job) });
    if(req.method==='POST'&&action==='favorite'){
      const input=await readJson(req,4096);if(typeof input.favorite!=='boolean')return json(res,400,{error:'收藏状态无效。'});
      job.favorite=input.favorite;await saveJob(job);return json(res,200,{ok:true,job:publicJob(job)});
    }
    if (req.method === "GET" && action === "hd-result") {
      const index=Number(url.searchParams.get('index')),image=(job.images||[]).find(item=>item.index===index);
      if(!image?.hd||image.hd.baseSha256!==image.sha256||url.searchParams.get('hdSha256')!==image.hd.pasteSha256)return json(res,409,{error:'高清图片已变化，请刷新预览。'});
      return sendFile(res,image.hd.pastePath,'image/png');
    }
    if (req.method === "GET" && action === "result") {
      if (!job.result && !(Array.isArray(job.images) && job.images.length)) return json(res, 409, { error: "图片尚未下载完成。" });
      const requestedIndex = url.searchParams.has("index") ? Number(url.searchParams.get("index")) : Number(job.selectedIndex || 0);
      const fileName = resultFileName(job, requestedIndex);
      return sendFile(res, path.join(jobDir(id), fileName), "image/png");
    }
    if(req.method==='GET' && action==='composite') {
      const index=url.searchParams.has('index')?Number(url.searchParams.get('index')):Number(job.selectedIndex||0);
      const name=resultFileName(job,index),item=(job.images||[]).find(image=>image.index===index);
      const source=item?.hd&&item.hd.baseSha256===item.sha256?item.hd.pastePath:path.join(jobDir(id),name),output=source.replace(/\.png$/i,'.composite.png');
      if(!fs.existsSync(output)||fs.statSync(output).mtimeMs<fs.statSync(source).mtimeMs) {
        const {makeComposite}=require('./result-geometry');
        await fsp.writeFile(output,await makeComposite(await fsp.readFile(source),job,jobDir(id)));
      }
      return sendFile(res,output,'image/png');
    }
    if (req.method === "GET" && action === "thumbnail") {
      if (!job.result && !(Array.isArray(job.images) && job.images.length)) return json(res, 409, { error: "图片尚未下载完成。" });
      const requestedIndex = url.searchParams.has("index") ? Number(url.searchParams.get("index")) : Number(job.selectedIndex || 0);
      const fileName = resultFileName(job, requestedIndex);
      const source = path.join(jobDir(id), fileName);
      const thumb = source.replace(/\.png$/i, ".thumb.jpg");
      if (!fs.existsSync(thumb) || fs.statSync(thumb).mtimeMs < fs.statSync(source).mtimeMs) {
        await sharp(source, { limitInputPixels: 25000000 }).resize(96, 96, { fit: "cover" }).jpeg({ quality: 80 }).toFile(thumb);
      }
      return sendFile(res, thumb, "image/jpeg");
    }
    if (req.method === "POST" && action === "select") {
      const input = await readJson(req, 4096);
      if (!["api", "browser"].includes(job.provider) || !job.result) return json(res, 409, { error: "没有可选择的生成结果。" });
      // 仅回贴进行中锁定换图；已贴回后允许换图再贴（每次贴回生成新图层）。
      if (job.status === "importing" && input.index !== job.selectedIndex)
        return json(res,409,{error:"回贴中的图片不能更换，请保留原任务。"});
      if (!selectResult(job, input.index)) return json(res, 400, { error: "图片编号无效。" });
      job.selectedByUser = true;
      job.updatedAt = new Date().toISOString();
      await saveJob(job);
      return json(res, 200, { job: publicJob(job) });
    }
    if (req.method === "POST" && ["import-start", "import-complete", "import-abort"].includes(action)) {
      const input = await readJson(req, 4096);
      const importId = String(input.importId || "");
      if (!/^[a-zA-Z0-9_-]{8,100}$/.test(importId)) return json(res, 400, { error: "回贴编号无效。" });
      if (!["api", "browser"].includes(job.provider) || !job.result) return json(res, 409, { error: "没有可回贴的生成结果。" });
      if (action === "import-start") {
        let batch=null;
        if(input.batch!==undefined){
          const value=input.batch,indexes=value?.indexes,hashes=value?.hashes;
          if(!Array.isArray(indexes)||!indexes.length||indexes.length>4||indexes.some(index=>!Number.isInteger(index)||index<0)||new Set(indexes).size!==indexes.length||!indexes.includes(value.preferredIndex)||!Array.isArray(hashes)||hashes.length!==indexes.length||new Set(hashes.map(h=>h?.index)).size!==hashes.length||hashes.some(h=>!indexes.includes(h?.index))||!Number.isFinite(value.maskFeatherPx)||value.maskFeatherPx<LIMITS.featherMin||value.maskFeatherPx>LIMITS.featherMax)
            return json(res,400,{error:'批量回贴的图片、首选图或蒙版参数无效。'});
          for(const index of indexes){
            const image=(job.images||[]).find(image=>image.index===index),hash=hashes.find(item=>item.index===index);
            if(!image||hash.sha256!==image.sha256||(hash.hdSha256||'')!==(image.hd?.pasteSha256||'')||image.hd&&image.hd.baseSha256!==image.sha256)return json(res,409,{error:'批量回贴的图片或高清文件已变化，请重新预览。'});
          }
          batch={indexes:[...indexes],hashes:indexes.map(index=>({...hashes.find(item=>item.index===index)})),preferredIndex:value.preferredIndex,maskFeatherPx:value.maskFeatherPx};
        }
        if (input.index !== undefined && (input.index !== job.selectedIndex || (input.sha256 && input.sha256 !== job.result.sha256))) return json(res,409,{error:"预览图片已变化，请重新选择后贴回。"});
        const image=(job.images||[]).find(item=>item.index===job.selectedIndex);
        if(input.hdSha256!==undefined&&input.hdSha256!==(image?.hd?.pasteSha256||''))return json(res,409,{error:'高清文件已变化，请重新预览后回贴。'});
        if (job.status === "importing" && job.importId === importId) {
          if(JSON.stringify(job.importBatch||null)!==JSON.stringify(batch))return json(res,409,{error:'同编号回贴的批次内容不同。'});
          return json(res, 200, { job: publicJob(job) });
        }
        if (job.status === "imported" && job.importId === importId) {
          if(JSON.stringify(job.importBatch||null)!==JSON.stringify(batch))return json(res,409,{error:'同编号回贴的批次内容不同。'});
          return json(res, 200, { job: publicJob(job),idempotent:true });
        }
        // 「imported」允许再次回贴：每次回贴使用新的 importId 就会新建图层。
        if (!["ready", "imported"].includes(job.status)) return json(res, 409, { error: "结果已被回贴或正在回贴。" });
        job.importPrevious={status:job.status,importId:job.importId,layerID:job.layerID,groupID:job.groupID,layerIDs:job.layerIDs,indexes:job.indexes,importBatch:job.importBatch};
        if (job.status === "imported") {delete job.layerID;delete job.groupID;delete job.layerIDs;delete job.indexes;}
        job.status = "importing";
        job.importId = importId;
        if(batch)job.importBatch=batch;else delete job.importBatch;
      } else {
        if (job.importId !== importId) return json(res, 409, { error: "回贴编号与任务不一致。" });
        if (action === "import-complete") {
          if (Number(input.documentID) !== job.documentID || !Number.isInteger(input.layerID) || input.layerID < 1) return json(res, 400, { error: "回贴文档或图层无效。" });
          if(job.importBatch){
            const indexes=job.importBatch.indexes;
            if(!Number.isInteger(input.groupID)||input.groupID<1||!Array.isArray(input.indexes)||JSON.stringify(input.indexes)!==JSON.stringify(indexes)||!Array.isArray(input.layerIDs)||input.layerIDs.length!==indexes.length||input.layerIDs.some(id=>!Number.isInteger(id)||id<1)||new Set(input.layerIDs).size!==input.layerIDs.length||input.layerIDs.includes(input.groupID)||input.layerID!==input.layerIDs[indexes.indexOf(job.importBatch.preferredIndex)])return json(res,400,{error:'批量回贴的组、图层与图片回执不一致。'});
          }else if(input.layerIDs!==undefined||input.groupID!==undefined||input.indexes!==undefined)return json(res,400,{error:'当前任务没有对应的批量回贴合同。'});
          if (job.status === "imported" && job.layerID === input.layerID) {
            if(job.importBatch&&(job.groupID!==input.groupID||JSON.stringify(job.layerIDs)!==JSON.stringify(input.layerIDs)))return json(res,409,{error:'同编号回贴的完成回执不同。'});
            return json(res, 200, { job: publicJob(job) });
          }
          if (job.status !== "importing") return json(res, 409, { error: "回贴状态已变化。" });
          job.status = "imported";
          job.layerID = input.layerID;
          if(job.importBatch){job.groupID=input.groupID;job.layerIDs=[...input.layerIDs];job.indexes=[...input.indexes];}
          delete job.importPrevious;
          // The result reached Photoshop; a stale pre-import notice must not
          // keep leaking through publicJob on a completed job.
          job.error = null;
        } else {
          if (job.status !== "importing" || job.layerID) return json(res, 409, { error: "无法取消已完成的回贴。" });
          const previous=job.importPrevious||{status:'ready'};
          for(const key of ['status','importId','layerID','groupID','layerIDs','indexes','importBatch']){if(previous[key]===undefined)delete job[key];else job[key]=previous[key];}
          job.error = null;
          delete job.importPrevious;
        }
      }
      job.updatedAt = new Date().toISOString();
      await saveJob(job);
      return json(res, 200, { job: publicJob(job) });
    }
    if (req.method === "POST" && action === "cancel") {
      if (["imported", "importing"].includes(job.status)) return json(res, 409, { error: "回贴期间不能取消任务。" });
      cancelJob(job);
      await saveJob(job);
      return json(res, 200, { job: publicJob(job) });
    }
    if(req.method==='POST'&&action==='recover'){
      if(job.status==='importing'||['ready','imported'].includes(job.status))return json(res,200,{job:publicJob(job),idempotent:true,submissionSent:false});
      const urls=!!job.backendResultUrl||!!job.batchResultUrls?.length||!!job.pendingImageDownload;
      if(!mayHaveSubmitted(job))return json(res,409,{error:'该任务尚未提交，没有可查询的原结果。',submissionSent:false});
      job.recoveryRequestedAt=new Date().toISOString();job.recoveryAttempts=(Number(job.recoveryAttempts)||0)+1;
      job.waitingStopped=false;job.recoveryState='query_requested';job.error=null;
      job.status=job.provider==='api'&&urls?'queued':'unknown';
      if(job.provider==='api'&&!urls&&typeof apiBackend.queryRecovery==='function'){
        await apiBackend.queryRecovery(DATA_DIR,job);
      }
      job.updatedAt=new Date().toISOString();await saveJob(job);
      if(job.provider==='api'&&urls)scheduleWorker();
      return json(res,200,{job:publicJob(job),queryOnly:true,submissionSent:false});
    }
    if (req.method === "PUT" && (action === "source" || action === "mask")) {
      await writeRawUpload(req, job, action);
      return json(res, 200, { ok: true });
    }
    if (req.method === "GET" && action === "source.png") {
      return sendFile(res, path.join(jobDir(id), "source.png"), "image/png");
    }
    if (req.method === "GET" && action === "reference.png") {
      return sendFile(res, path.join(jobDir(id), "reference.png"), "image/png");
    }
    if (req.method === "GET" && action === "mask") {
      if (!job.mask) return json(res, 404, { error: "没有选区蒙版。" });
      return sendFile(res, path.join(jobDir(id), "mask.raw"), "application/octet-stream");
    }
    if(req.method==='GET'&&action==='mask.png'){
      if(!job.mask)return json(res,404,{error:'没有选区蒙版。'});
      const {width,height,components}=job.mask;
      if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width*height>MAX_PIXELS||components!==1||width!==job.source?.width||height!==job.source?.height)return json(res,409,{error:'选区蒙版尺寸与捕获区域不一致。'});
      let raw;
      try{raw=await fsp.readFile(path.join(jobDir(id),'mask.raw'));}catch(error){if(error.code==='ENOENT')return json(res,404,{error:'选区蒙版文件缺失。'});throw error;}
      if(raw.length!==width*height)return json(res,409,{error:'选区蒙版文件尺寸不完整。'});
      const png=await sharp(raw,{raw:{width,height,channels:1}}).png().toBuffer();
      res.writeHead(200,{'Content-Type':'image/png','Content-Length':png.length,'Cache-Control':'no-store'});
      return res.end(png);
    }
    if (req.method === "POST" && action === "complete-upload") {
      if (job.status !== "uploading") return json(res, 409, { error: "任务已取消或状态已改变。" });
      if(job.hasExtraImage&&!job.extraReady)throw extraImageInput.invalid('附加参考图尚未上传完成，未提交生成。',409);
      if (!job.sourceReady || !job.maskReady || !contextInput.ready(job)) return json(res, 409, { error: "素材尚未全部上传。",submissionSent:false });
      await contextInput.references(job,jobDir(id));
      job.status = "queued";
      job.updatedAt = new Date().toISOString();
      await saveJob(job);
      if (job.provider === "api") scheduleWorker();
      return json(res, 200, { job: publicJob(job) });
    }
    if (req.method === "POST" && action === "status") {
      const input = await readJson(req, 16 * 1024);
      let nextStatus = String(input.status || "");
      if(nextStatus==='cancelled'&&job.status==='importing')return json(res,409,{error:'回贴期间不能取消任务。'});
      // Flow's own error tile is a resolved terminal state, not an uncertain
      // submission. The controller only reports it after the page accounted for
      // every requested slot, so it must not be rewritten to "unknown" (which
      // would deadlock the job out of both retry and clear messaging). The code
      // carries whether the attempt is safe to retry: Flow states a policy block
      // is not billed, so that one is retrySafe; any other error stays unconfirmed.
      const resolvedFailure = job.provider === "browser" && nextStatus === "failed" && input.submissionSent === true &&
        typeof input.failureCode === "string" && /^[a-z_]{3,40}$/.test(input.failureCode);
      if(job.provider === "browser" && nextStatus === "failed" && input.submissionSent===true && !resolvedFailure) nextStatus="unknown";
      if (job.provider === "api" && nextStatus !== "cancelled") return json(res, 409, { error: "生成任务状态由本地助手管理。" });
      if (job.provider === "api" && job.status === "importing") return json(res, 409, { error: "回贴期间不能取消任务。" });
      if (!["waiting_user", "failed", "unknown", "imported", "cancelled"].includes(nextStatus)) {
        return json(res, 400, { error: "不支持的任务状态。" });
      }
      const permitted =
        (nextStatus === "waiting_user" && job.status === "attaching") ||
        (nextStatus === "failed" && (["uploading", "queued", "attaching"].includes(job.status) || (job.status==="waiting_user" && input.submissionSent===false && job.submissionSent!==true))) ||
        (nextStatus === "failed" && resolvedFailure && ["attaching","waiting_user","generating","unknown"].includes(job.status)) ||
        (nextStatus === "unknown" && job.provider==="browser" && ["attaching","waiting_user","generating","unknown"].includes(job.status) && input.submissionSent===true) ||
        (nextStatus === "imported" && job.status === "waiting_user") ||
        (nextStatus === "cancelled" && !["imported", "cancelled"].includes(job.status));
      if (!permitted) return json(res, 409, { error: "任务状态已变化，请刷新任务列表。" });
      if(job.provider==="browser" && typeof input.submissionSent==="boolean") {
        if(input.submissionSent===true){job.submissionSent=true;job.submissionState="unknown";}
        else if(!job.submissionSent){job.submissionSent=false;job.submissionState="not_submitted";job.retrySafe=nextStatus==="failed";}
      }
      if(job.provider==='browser'&&nextStatus==='failed'&&input.submissionSent===false&&job.submissionSent!==true&&input.failureCode==='pre_submission_configuration'){
        job.failureCode='pre_submission_configuration';job.submissionState='not_submitted';job.retrySafe=true;
      }
      if(resolvedFailure){
        job.failureCode = input.failureCode;
        // The submission itself was confirmed; only the outcome failed. Flow tells
        // us whether the attempt was billed, which is what decides retry safety.
        job.submissionState = "confirmed";
        job.retrySafe = input.charged === false;
      }
      if(nextStatus==='cancelled')cancelJob(job);
      else job.status = nextStatus;
      job.error = ["failed","unknown"].includes(nextStatus) ? String(input.error || "浏览器扩展无法处理该任务。").slice(0, 500) : null;
      job.updatedAt = new Date().toISOString();
      await saveJob(job);
      return json(res, 200, { job: publicJob(job) });
    }
    if (req.method === "POST" && action === "retry") {
      if (job.status !== "failed") return json(res, 409, { error: "只有失败任务可以重试。" });
      if(mayHaveSubmitted(job)&&!job.backendResultUrl&&!job.batchResultUrls?.length&&!job.pendingImageDownload)return json(res,409,{error:'原任务可能已提交，请查询原结果，不能重新排队。'});
      if (job.provider === "api" && !job.retrySafe && !job.backendResultUrl && !(Array.isArray(job.batchResultUrls) && job.batchResultUrls.length)) return json(res, 409, { error: "结果待确认，请先检查 Flow，避免重复生成。" });
      job.status = "queued";
      job.error = null;
      delete job.failureCode;
      job.webProgress=null;job.transferProgress=null;
      job.browserClient = null;
      job.updatedAt = new Date().toISOString();
      await saveJob(job);
      if (job.provider === "api") scheduleWorker();
      return json(res, 200, { job: publicJob(job) });
    }
  }

  if (url.pathname === "/api/jobs/finished" && req.method === "DELETE") {
    const removable = [...jobs.values()].filter((job) =>
      ["imported", "failed", "cancelled"].includes(job.status) && !jobPersister.isPending(job.id) &&
      !(workerBusy && job.provider === "api" && job.status === "cancelled"));
    for (const job of removable) {
      if(!actionBridge)actionBridge=require('../action-bridge/host.cjs');
      await actionBridge.dispatch({op:'delete-job',id:job.id});
    }
    return json(res, 200, { removed: removable.length,recoverable:true });
  }
  return json(res, 404, { error: "没有这个接口。" });
}

async function main() {
  await loadConfig();
  scheduleWorker();
  // Independent of every client request: see reapStalledBrowserJobs().
  setInterval(() => { reapStalledBrowserJobs().catch((error) => console.error(error)); }, REAP_INTERVAL_MS).unref();
  const server = http.createServer((req, res) => {
    const pathname = new URL(req.url,"http://127.0.0.1").pathname;
    const tracked = !["/api/health","/api/lifecycle/drain","/api/lifecycle/resume"].includes(pathname) && req.method !== "OPTIONS";
    if (tracked) activeRequests++;
    route(req, res).catch((error) => {
      if (res.headersSent) return res.destroy(error);
      const status = Number(error.status) || 500;
      if (status >= 500) console.error(error);
      json(res, status, { error: status >= 500 ? "本地助手发生错误，请查看本机终端。" : error.message,field:error.field,code:error.code,submissionSent:error.submissionSent });
    }).finally(() => { if (tracked) activeRequests--; });
  });
  server.listen(PORT, HOST, () => {
    console.log("PS Flow Bridge 已运行：http://" + HOST + ":" + PORT);
    console.log("此助手只监听本机回环地址，不接受局域网连接。按 Ctrl+C 可停止。");
  });
}

process.once("exit", () => { if(actionBridge) actionBridge.close(); });
main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
