"use strict";
const fs = require("node:fs/promises");
const crypto = require("node:crypto");

function contextMode(value) {
  if (value === undefined) return "auto";
  if (!["auto", "surrounding", "full"].includes(value)) {
    throw Object.assign(new Error("参考范围无效，未提交生成。"), { field: "contextMode", submissionSent: false });
  }
  return value;
}

// Decode the complete image, not only its header. The digest binds the uploaded
// global view to the same persisted snapshot used by retry and regeneration.
async function readContext(capture, sharp, expected) {
  if (!capture.contextImagePath) {
    if (capture.hasGlobalContext || capture.contextSource) throw new Error("全图参考快照缺失，请重新捕获。");
    return null;
  }
  const bytes = await fs.readFile(capture.contextImagePath);
  if (bytes.length > 16 * 1024 * 1024) throw new Error("全图参考过大，请重新捕获。");
  const decoder = sharp(bytes, { limitInputPixels: 1280 * 1280, failOn: "warning" });
  const info = await decoder.metadata();
  if (info.format !== "png" || !info.width || !info.height || Math.max(info.width, info.height) > 1280 || (info.pages || 1) !== 1) {
    throw new Error("全图参考尺寸或格式无效，请重新捕获。");
  }
  await decoder.clone().raw().toBuffer();
  const metadata = {
    width: info.width, height: info.height,
    sha256: crypto.createHash("sha256").update(bytes).digest("hex")
  };
  const identity = expected || capture.contextSource;
  if (identity && ["width", "height", "sha256"].some(key => identity[key] !== undefined && identity[key] !== metadata[key])) {
    throw new Error("全图参考与原快照不一致，未提交生成。");
  }
  return { bytes, metadata };
}

module.exports = { contextMode, readContext };
