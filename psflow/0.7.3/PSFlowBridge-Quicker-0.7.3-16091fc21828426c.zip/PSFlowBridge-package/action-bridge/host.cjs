"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const { createRequire } = require("node:module");

const browserRouting = require('./browser-routing.cjs');
const LIMITS = require('../shared/parameter-limits.cjs');
const RESOURCE_LIMITS=require('./preview-resources.cjs').LIMITS;
const {assertFileBudget}=require('./preview-resources.cjs');
const verifiedMetaCache=new Map();
function getVerifiedMeta(sha256){
  if(!sha256)return null;
  const meta=verifiedMetaCache.get(sha256);
  if(meta){verifiedMetaCache.delete(sha256);verifiedMetaCache.set(sha256,meta);}
  return meta||null;
}
function setVerifiedMeta(sha256,meta){
  if(!sha256||!meta)return;
  verifiedMetaCache.set(sha256,{width:meta.width,height:meta.height});
  while(verifiedMetaCache.size>256)verifiedMetaCache.delete(verifiedMetaCache.keys().next().value);
}
const runtimeInstall = require('./runtime-install.cjs');
const {prepareUpload}=require('./prepare-upload.cjs');
const contextSnapshot=require('./context-snapshot.cjs');
const ROOT = __dirname;
const HELPER_PACKAGE = path.join(ROOT, "..", "helper", "package.json");
const checkAppUpdate = require("./app-update.cjs").createUpdateChecker({
  version: require(HELPER_PACKAGE).version,
  buildId: () => process.env.PSFB_BUILD_ID || "dev"
});
const PS_RUN = path.join(ROOT, "ps-run.ps1");
const DATA_DIR = process.env.PSFB_DATA_DIR || path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local"), "PSFlowBridge");
const CONFIG_PATH = path.join(DATA_DIR, "config.json");
const BACKEND_PATH = path.join(DATA_DIR, "backend.json");
function helperBase() { return "http://127.0.0.1:" + (Number(process.env.PSFB_PORT) || 47831); }
const CAPTURE_DIR = path.join(DATA_DIR, "action-jobs");
const PS_TIMEOUT_MS = 60000;
const MAX_PIXELS = 25000000;
const ALLOWED_MODELS = new Set(["gemini-3.1-flash-image", "gemini-3.0-pro-image"]);
// Pure text generation has no captured selection, so the aspect ratio is chosen
// by the user instead of derived from a document crop.
const ASPECT_RATIOS = new Set(["1:1", "4:3", "3:4", "16:9", "9:16"]);
const DEFAULT_ASPECT_RATIO = "1:1";

const { createPsWorker } = require("./ps-worker.cjs");
const {validEditMode}=require("../helper/job-lifecycle");
const {filterHistory}=require("../helper/history-query");
const {moveToTrash,restoreFromTrash,listTrash,inspectTrashRecord}=require("../helper/trash-store");
const {checkCleanup}=require("../helper/history-cleanup");
const {shareSnapshot}=require("../helper/immutable-snapshot");
const {decodeRawMask}=require('./raw-mask.cjs');
const {writeBufferAtomically}=require("../helper/atomic-file");
const {saveResult}=require("../helper/result-save");
const psWorker = createPsWorker({
  executable: process.env.WINDIR + "\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
  args: ["-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", PS_RUN, "-Serve"],
  timeoutMs: PS_TIMEOUT_MS,idleMs:180000
});
let psStatusCache = null;
let psStatusPending = null;
let actionMutation = false;
const stoppedJobs = new Set();
function assertNotStopped(id) { if(stoppedJobs.has(id)) throw fail("任务已强制终止，未继续提交。",{code:"cancelled"}); }
process.once("exit", () => psWorker.close());

function fail(message, extra = {}) {
  return Object.assign(new Error(message), extra);
}

// Photoshop 扩展脚本（ps.jsx，纯 ASCII）会抛出英文守卫错误。这里映射成可操作的
// 中文提示，避免最关键的“结果保留、需要人工处理”场景只透传英文原文。
// 未命中的消息原样返回，未知错误不会被掩盖。
function psMessage(message) {
  const text = String(message || "");
  const map = [
    [/captured document is no longer open/i, "原捕获的文档已不在 Photoshop 中打开，生成结果已保留。请重新打开该文档后再次回贴，或改为向当前文档重新捕获。"],
    [/Photoshop restarted after capture/i, "Photoshop 在捕获后重启过，无法确认原文档会话。生成结果已保留，请重新捕获后再回贴。"],
    [/Use an RGB\/8-bit document/i, "请在 RGB / 8 位文档上使用本功能。"],
    [/Open a document in Photoshop first/i, "请先在 Photoshop 中打开一个文档。"],
    [/Invalid or oversized capture area/i, "捕获区域无效或过大，请缩小选区后重试。"],
    [/Selection context is too large/i, "选区加上下文边距过大，请选择更小的区域。"],
    [/canvas changed after capture/i, "文档画布尺寸在捕获后发生变化，结果已保留。请恢复到原画布尺寸，或重新捕获后再回贴。"],
    [/Mask feather must be between/i, "蒙版羽化仅支持 0 到 250 像素。"],
    [/geometry does not match/i, "生成结果或蒙版的尺寸与捕获区域不一致，已停止回贴并保留结果。"],
    [/Invalid or oversized preview area/i, "预览区域无效或过大，已停止准确预览。请重新框选较小的区域。"],
    [/Preview area is too large/i, "预览区域超过 2500 万像素上限，已停止准确预览。请缩小选区后重试。"],
    [/Preview area is outside the captured canvas/i, "预览区域超出捕获时的画布范围，已停止准确预览。请重新捕获后再试。"],
    [/preview image file is missing/i, "预览图片文件不存在，已停止准确预览。请刷新任务后重试。"],
    [/preview mask file is missing/i, "预览蒙版文件不存在，已停止准确预览。请重新捕获后再试。"],
  ];
  for (const [pattern, replacement] of map) if (pattern.test(text)) return replacement;
  return text;
}

async function readJsonFile(file, fallback = null) {
  try { return JSON.parse(await fsp.readFile(file, "utf8")); }
  catch (error) { if (error.code === "ENOENT") return fallback; throw fail("Local task record is unreadable. Preserve it and check the file."); }
}

async function readPairingToken() {
  const config = await readJsonFile(CONFIG_PATH, {});
  const token = config && typeof config.pairingToken === "string" ? config.pairingToken : "";
  if (!token) throw fail("PS Flow 本地配对码不存在，请先启动 PS Flow 助手。", { code: "configuration" });
  return token;
}

function normalizeMode(rawMode) {
  if (rawMode === "local" || rawMode === "api") return "local";
  return "browser";
}

function runtimeMode() {
  try {
    const value = fs.readFileSync(path.join(DATA_DIR, "mode.json"), "utf8").replace(/^\uFEFF/, "");
    const parsed = JSON.parse(value);
    if (parsed && parsed.mode === "local") {
      if (runtimeInstall.inspect(DATA_DIR).installed) return "local";
      return "browser";
    }
    return "browser";
  } catch (error) { return "browser"; }
}

function isModeConfigured() {
  try {
    const value = fs.readFileSync(path.join(DATA_DIR, "mode.json"), "utf8").replace(/^\uFEFF/, "");
    const parsed = JSON.parse(value);
    return Boolean(parsed && (parsed.configured === true || parsed.mode === "browser" || parsed.mode === "local"));
  } catch (error) { return true; }
}

async function readBackendConfig() {
  const value = await readJsonFile(BACKEND_PATH, {});
  if (!value || value.enabled !== true) throw fail("生成服务未启用，请先启动 PS Flow 助手。", { code: "configuration" });
  const base = new URL(String(value.baseUrl || ""));
  if (base.protocol !== "http:" || !["127.0.0.1", "localhost"].includes(base.hostname) || base.pathname !== "/" || base.search || base.hash) {
    throw fail("生成服务地址无效。", { code: "configuration" });
  }
  if (typeof value.apiKey !== "string" || value.apiKey.length < 16) throw fail("生成服务配置不完整。", { code: "configuration" });
  return {
    base: base.origin,
    key: value.apiKey,
    model: typeof value.model === "string" ? value.model : "gemini-3.1-flash-image",
    timeout: Math.max(10000, Math.min(600000, Number(value.timeoutMs) || 300000))
  };
}

async function requestJson(url, options = {}, timeoutMs = 5000) {
  let response;
  try {
    response = await fetch(url, { redirect: "error", ...options, signal: AbortSignal.timeout(timeoutMs) });
  } catch (error) {
    throw fail(`服务请求失败：${error && error.message ? error.message : "unknown"}`, { code: "network" });
  }
  const raw = await response.text();
  let body = null;
  try { body = raw ? JSON.parse(raw) : null; } catch { body = { raw }; }
  if (!response.ok) {
    const message = body && body.error ? body.error : `HTTP ${response.status}`;
    throw fail(message, { code: response.status >= 500 ? "remote" : "rejected", status: response.status,field:body?.field,submissionSent:body?.submissionSent });
  }
  return body;
}

async function sharpRequire() {
  const helperRequire = createRequire(HELPER_PACKAGE);
  return helperRequire("sharp");
}

// Hash a file by streaming it instead of reading the whole thing into a Buffer.
// The accurate preview only needs the digest, so this avoids keeping a second
// full-size copy resident next to sharp's decode buffers.
async function hashFile(file) {
  const hash = crypto.createHash("sha256");
  const stream = fs.createReadStream(file);
  for await (const chunk of stream) hash.update(chunk);
  return hash.digest("hex");
}

function safeId(id) {
  return typeof id === "string" && /^[0-9a-f-]{36}$/i.test(id);
}

async function loadCapture(id) {
  if (!safeId(id)) throw fail("任务编号无效。", { status: 400 });
  const file = path.join(CAPTURE_DIR, id, "capture.json");
  const value = await readJsonFile(file, null);
  if (!value) throw fail("找不到这个任务。", { status: 404 });
  return value;
}

async function saveCapture(job, patch = {}) {
  Object.assign(job, patch);
  await atomicJson(path.join(CAPTURE_DIR, job.id, "capture.json"), job);
}

// A job is standalone when it never belonged to a live Photoshop selection:
// pure text generation, or any record without a captured document identity.
// Standalone jobs must not pretend to own document coordinates, otherwise the
// panel would offer an in-place paste that can never be valid.
function jobKind(job) { return job && job.kind === "text2image" ? "text2image" : "image2image"; }
// An explicit flag always wins; otherwise only a record that never got a
// document identity counts as standalone. Image jobs mark themselves
// `standalone:false` while capturing so a mid-capture query is not misread.
function isStandaloneJob(job) {
  if (jobKind(job) === "text2image") return true;
  if (job && job.standalone === true) return true;
  if (job && job.standalone === false) return false;
  return !job.documentID;
}

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

// Read-only recovery for a captured selection whose helper task was never
// created. The helper image route requires a live job, so a cancelled or
// unconfirmed capture keeps its source.png on disk but cannot be served there.
// This operation only reads the fixed capture path and never touches the
// capture record, so the record stays a capture, not a generation task.
async function captureSource(input = {}) {
  const id = String(input.id || "");
  if (!safeId(id)) throw fail("任务编号无效。", { status: 400 });

  const capture = await loadCapture(id);
  if (isStandaloneJob(capture)) throw fail("该记录没有捕获原图。", { status: 409 });

  const file = path.join(CAPTURE_DIR, id, "source.png");
  let stat;
  try {
    stat = await fsp.stat(file);
  } catch (error) {
    if (error.code === "ENOENT") throw fail("捕获原图不存在。", { status: 404 });
    throw error;
  }
  if (!stat.isFile()) throw fail("捕获原图不存在。", { status: 404 });
  if (stat.size > RESOURCE_LIMITS.sourceFileMaxBytes) {
    throw fail("捕获原图超过 96 MB 上限。", { status: 413 });
  }

  const bytes = await fsp.readFile(file);
  if (bytes.length < 8 || !bytes.subarray(0, 8).equals(PNG_SIGNATURE)) {
    throw fail("捕获原图不是有效的 PNG。", { status: 415 });
  }

  return {
    ok: true,
    id,
    bytes: bytes.length,
    dataUrl: "data:image/png;base64," + bytes.toString("base64")
  };
}

function publicJob(job) {
  const kind = jobKind(job), standalone = isStandaloneJob(job);
  const source = !standalone && job.source ? {
    width: job.source.width,
    height: job.source.height,
    components: job.source.components,
    colorProfile: job.source.colorProfile
  } : null;
  const value = {
    id: job.id, status: job.status, provider: runtimeMode()==="browser"?"browser":"api", prompt: job.prompt, model: job.model,editMode:job.editMode||'auto',
    kind, standalone, aspectRatio: job.aspectRatio || null,
    count: Number(job.count) || 1, selectedIndex: Number(job.selectedIndex) || 0,
    images: Array.isArray(job.images) ? job.images.map(image => ({ ...image })) : [],
    documentID: standalone ? null : job.documentID,
    documentName: kind === "text2image" ? null : job.documentName,
    documentPath: kind === "text2image" ? null : (job.documentPath || null),
    documentSession: standalone ? null : (job.documentSession || job.psSession || null),
    hasExtraImage: job.hasExtraImage === true, extraImage: job.extraImage || null,references:job.references||[],
    contextMode:job.contextMode||"auto",hasGlobalContext:job.hasGlobalContext===true,contextSource:job.contextSource||null,
    canvas: standalone ? null : job.canvas, bounds: standalone ? null : job.bounds, scope: job.scope,
    source, aspectTarget: job.aspectTarget,
    reference: job.reference || null,
    geometryVersion: job.geometryVersion, editBounds: job.editBounds, editRegion: job.editRegion,
    mask: standalone ? null : ((job.maskPath || job.mask) ? {
      width: (job.source && job.source.width) || (job.mask && job.mask.width),
      height: (job.source && job.source.height) || (job.mask && job.mask.height),
      components: 1
    } : null),
    createdAt: job.createdAt, updatedAt: job.updatedAt, error: job.error || null,
    hasCapture: standalone ? false : job.captureReady !== false,favorite:job.favorite===true
  };
  // Real result dimensions for jobs that never went through a selection crop.
  if (Number.isInteger(job.resultWidth) && Number.isInteger(job.resultHeight)) {
    value.resultWidth = job.resultWidth;
    value.resultHeight = job.resultHeight;
  }
  if (job.result) value.result = job.result;
  if (job.importId) value.importId = job.importId;
  if (job.layerID) value.layerID = job.layerID;
  if (job.progress) value.progress = job.progress;
  if (job.webProgress) value.webProgress = job.webProgress;
  for(const key of ["transferProgress","timings","lifecycle","recovery","parentJobId","rootJobId","version","base","resultIndex","importBatch","groupID","layerIDs","indexes","waitingStopped","cancellation","submissionSent","submissionState","retrySafe","failureCode","unknownSince","recoveryState"]) if(job[key]!==undefined) value[key]=job[key];
  return value;
}

function publicJobFromRemote(remote) {
  const kind = jobKind(remote), standalone = isStandaloneJob(remote);
  const source = !standalone && remote.source ? {
    width: remote.source.width,
    height: remote.source.height,
    components: remote.source.components,
    colorProfile: remote.source.colorProfile
  } : null;
  const value = {
    id: remote.id,
    status: remote.status,
    provider: remote.provider || "api",
    prompt: remote.prompt,
    editMode:remote.editMode||'auto',
    kind, standalone, aspectRatio: remote.aspectRatio || null,
    model: remote.model,
    count: Number(remote.count) || 1,
    selectedIndex: Number(remote.selectedIndex) || 0,
    images: Array.isArray(remote.images) ? remote.images.map(image => ({ ...image })) : [],
    documentID: standalone ? null : remote.documentID,
    documentName: kind === "text2image" ? null : remote.documentName,
    documentPath: kind === "text2image" ? null : (remote.documentPath || null),
    documentSession: standalone ? null : (remote.documentSession || remote.psSession || null),
    hasExtraImage: remote.hasExtraImage === true, extraImage: remote.extraImage || null,references:remote.references||[],
    contextMode:remote.contextMode||"auto",hasGlobalContext:remote.hasGlobalContext===true,contextSource:remote.contextSource||null,
    canvas: standalone ? null : remote.canvas,
    bounds: standalone ? null : remote.bounds,
    scope: remote.scope,
    source,
    aspectTarget: remote.aspectTarget,
    reference: remote.reference || null,
    geometryVersion: remote.geometryVersion,
    editBounds: remote.editBounds,
    editRegion: remote.editRegion,
    mask: standalone ? null : (remote.mask ? {
      width: remote.mask.width || (remote.source && remote.source.width),
      height: remote.mask.height || (remote.source && remote.source.height),
      components: 1
    } : null),
    createdAt: remote.createdAt,
    updatedAt: remote.updatedAt,
    error: remote.error || null,
    hasCapture: false,favorite:remote.favorite===true
  };
  if (Number.isInteger(remote.resultWidth) && Number.isInteger(remote.resultHeight)) {
    value.resultWidth = remote.resultWidth;
    value.resultHeight = remote.resultHeight;
  }
  if (remote.result) value.result = remote.result;
  if (remote.importId) value.importId = remote.importId;
  if (remote.layerID) value.layerID = remote.layerID;
  if (remote.progress) value.progress = remote.progress;
  if (remote.webProgress) value.webProgress = remote.webProgress;
  for(const key of ["transferProgress","timings","lifecycle","recovery","parentJobId","rootJobId","version","base","resultIndex","importBatch","groupID","layerIDs","indexes","waitingStopped","cancellation","submissionSent","submissionState","retrySafe","failureCode","unknownSince","recoveryState"]) if(remote[key]!==undefined) value[key]=remote[key];
  return value;
}

async function attachThumbnails(job) {
  if (!job) return;
  let token = null;
  try { token = await readPairingToken(); } catch { return; }
  if (!token) return;

  if (Array.isArray(job.images) && job.images.length > 0) {
    const results = await Promise.all(job.images.map(async image => {
      if (image.dataUrl) return image;
      try {
        const response = await fetch(helperBase() + "/api/jobs/" + job.id + "/thumbnail?index=" + image.index, {
          headers: { Authorization: "Bearer " + token }, redirect: "error", signal: AbortSignal.timeout(5000)
        });
        if (!response.ok) return null;
        const thumb = Buffer.from(await response.arrayBuffer());
        return { index: image.index, dataUrl: "data:image/jpeg;base64," + thumb.toString("base64") };
      } catch { return null; }
    }));
    job.images = job.images.map(image => ({
      ...image, ...(results.find(t => t && t.index === image.index) || {})
    }));
  } else if (job.result && !job.thumbnailDataUrl) {
    try {
      const response = await fetch(helperBase() + "/api/jobs/" + job.id + "/thumbnail", {
        headers: { Authorization: "Bearer " + token }, redirect: "error", signal: AbortSignal.timeout(5000)
      });
      if (response.ok) {
        const thumb = Buffer.from(await response.arrayBuffer());
        job.thumbnailDataUrl = "data:image/jpeg;base64," + thumb.toString("base64");
      }
    } catch {}
  }
}
async function runPs(request, timeoutMs = PS_TIMEOUT_MS) {
  if (request.op !== "status") psStatusCache = null;
  return psWorker.invoke(request, timeoutMs);
}
async function cachedPsStatus() {
  if (psStatusCache && Date.now() - psStatusCache.at < 2000) return psStatusCache.value;
  if (!psStatusPending) {
    psStatusPending = runPs({op:"status"}).then(value => {
      psStatusCache = {at:Date.now(),value}; return value;
    }).finally(() => { psStatusPending = null; });
  }
  return psStatusPending;
}


async function atomicJson(file,value) {
  const temporary=file+"."+crypto.randomUUID()+".tmp";
  await fsp.writeFile(temporary,JSON.stringify(value,null,2),"utf8");
  await fsp.rename(temporary,file);
}
async function helperRequest(route,{method="GET",body,headers:extraHeaders={},timeoutMs}={}) {
  const token=await readPairingToken();
  const headers={Authorization:`Bearer ${token}`};
  if(body!==undefined) headers["Content-Type"]=Buffer.isBuffer(body)?"application/octet-stream":"application/json";
  Object.assign(headers,extraHeaders);
  return requestJson(helperBase()+route,{method,headers,
    body:body===undefined?undefined:Buffer.isBuffer(body)?body:JSON.stringify(body)},timeoutMs||(route==="/api/backend/status"?70000:10000));
}
async function resultPathFor(capture,index) {
  const name=Array.isArray(capture.images)&&capture.images.length
    ?(capture.images.find(image=>image.index===index)||{}).path
    :(index===0?"result.png":null);
  if(!name)throw fail("图片编号无效。",{status:400});
  return path.join(CAPTURE_DIR,capture.id,name);
}
// Validate a cached result file without loading it into memory: stat first so
// the byte budget can refuse an oversized asset, then stream the hash.
async function verifyCachedResult(resultPath,expectedHash,label){
  const stat=await fsp.stat(resultPath);
  assertFileBudget(stat.size,RESOURCE_LIMITS.sourceFileMaxBytes,label||"生成结果");
  const hash=await hashFile(resultPath);
  if(expectedHash&&hash!==expectedHash)return null;
  return {size:stat.size,sha256:hash};
}
// `options.fileOnly` returns {path,size,sha256} instead of the bytes so a caller
// that only needs the path (the formal paste lane) never allocates the whole
// image. The default still returns bytes for existing callers.
async function downloadResult(capture,index=Number(capture.selectedIndex)||0,options={}) {
  const fileOnly=options.fileOnly===true;
  const resultPath=await resultPathFor(capture,index);
  capture.resultPath=resultPath;
  const expectedHash=(Array.isArray(capture.images)?(capture.images.find(image=>image.index===index)||{}).sha256:"")
    ||(capture.result&&capture.result.sha256)||"";
  if(fs.existsSync(resultPath)){
    const verified=await verifyCachedResult(resultPath,expectedHash);
    if(verified){
      if(fileOnly)return {path:resultPath,size:verified.size,sha256:verified.sha256};
      return await fsp.readFile(resultPath);
    }
  }
  const token=await readPairingToken();
  const response=await fetch(`${helperBase()}/api/jobs/${capture.id}/result?index=${index}`,{
    headers:{Authorization:`Bearer ${token}`},redirect:"error",signal:AbortSignal.timeout(15000)});
  if(!response.ok) throw fail("生成结果尚无法获取，请保留任务并刷新。");

  if(fileOnly){
    const temporary=resultPath+"."+crypto.randomUUID()+".tmp";
    let size=0;
    const hash=crypto.createHash("sha256");
    try{
      const handle=await fsp.open(temporary,"w");
      try{
        for await(const chunk of response.body){
          size+=chunk.length;
          if(size>RESOURCE_LIMITS.sourceFileMaxBytes)throw fail("生成结果过大。");
          hash.update(chunk);
          await handle.writeFile(chunk);
        }
      }finally{await handle.close();}
      const fileHash=hash.digest("hex");
      if(expectedHash&&fileHash!==expectedHash)throw fail("生成结果数据与记录不一致，已停止操作，请刷新任务列表后重试。");
      const sharp=await sharpRequire();
      const info=await sharp(temporary,{limitInputPixels:MAX_PIXELS}).metadata();
      if(capture.standalone||capture.kind==="text2image"||!capture.bounds){
        capture.resultWidth=info.width;capture.resultHeight=info.height;
      }else if(info.width!==capture.bounds.width||info.height!==capture.bounds.height){
        throw fail("结果尺寸与捕获区域不一致，已停止回贴。");
      }
      await fsp.rename(temporary,resultPath);
      capture.resultPath=resultPath;
      setVerifiedMeta(fileHash,info);
      return {path:resultPath,size,sha256:fileHash};
    }catch(error){
      await fsp.rm(temporary,{force:true}).catch(()=>{});
      throw error;
    }
  }

  let size=0;const chunks=[];
  for await(const chunk of response.body) {size+=chunk.length;if(size>RESOURCE_LIMITS.sourceFileMaxBytes)throw fail("生成结果过大。");chunks.push(Buffer.from(chunk));}
  const bytes=Buffer.concat(chunks),sharp=await sharpRequire();
  const info=await sharp(bytes,{limitInputPixels:MAX_PIXELS}).metadata();
  if(capture.standalone||capture.kind==="text2image"||!capture.bounds){
    capture.resultWidth=info.width;capture.resultHeight=info.height;
  }else if(info.width!==capture.bounds.width||info.height!==capture.bounds.height){
    throw fail("结果尺寸与捕获区域不一致，已停止回贴。");
  }
  const fileHash=crypto.createHash("sha256").update(bytes).digest("hex");
  if(expectedHash&&fileHash!==expectedHash)throw fail("生成结果数据与记录不一致，已停止操作，请刷新任务列表后重试。");
  const temporary=resultPath+"."+crypto.randomUUID()+".tmp";
  try{
    await fsp.writeFile(temporary,bytes);
    await fsp.rename(temporary,resultPath);
  }catch(error){
    await fsp.rm(temporary,{force:true}).catch(()=>{});
    throw error;
  }
  capture.resultPath=resultPath;
  setVerifiedMeta(fileHash,info);
  return bytes;
}
async function currentJob(id,preview=false) {
  const capture=await loadCapture(id),remote=(await helperRequest(`/api/jobs/${id}`)).job;
  if(!remote)throw fail("找不到这个任务。",{status:404});
  if(remote.id!==id)throw fail("任务文档信息不匹配。",{status:409});
  // Only the local capture decides whether this record is standalone: it must be
  // an explicit text job (or an explicit standalone record) AND have no document
  // binding. A remote flag alone may never downgrade a bound capture, otherwise a
  // stale or foreign job could silently turn a document-bound record independent.
  const standalone=(capture.standalone===true||capture.kind==="text2image")&&!capture.documentID;
  if(standalone){
    if(jobKind(remote)!==jobKind(capture)||remote.standalone===false||remote.documentID||remote.documentSession)throw fail("任务类型不一致，已停止查询。",{status:409});
  }else{
    if(remote.kind==="text2image"||remote.standalone===true)throw fail("任务类型不一致，已停止查询。",{status:409});
    if(remote.documentID!==capture.documentID)throw fail("任务文档信息不匹配。");
  }
  Object.assign(capture,{status:remote.status,updatedAt:remote.updatedAt,error:remote.error,
    result:remote.result,layerID:remote.layerID||capture.layerID,
    favorite:remote.favorite===true,progress:remote.progress||null,
    webProgress:remote.webProgress||null,
    editMode:remote.editMode||'auto',transferProgress:remote.transferProgress||null,timings:remote.timings||null,lifecycle:remote.lifecycle||null,recovery:remote.recovery||null,
    reference:remote.reference||null,hasExtraImage:remote.hasExtraImage===true,extraImage:remote.extraImage||capture.extraImage||null,
    contextMode:remote.contextMode||capture.contextMode||"auto",hasGlobalContext:remote.hasGlobalContext===true,contextSource:remote.contextSource||capture.contextSource||null,
    images:remote.images||null,count:remote.count||capture.count,selectedIndex:Number(remote.selectedIndex||0)});
  if(remote.kind)capture.kind=jobKind(remote);
  if(remote.aspectRatio)capture.aspectRatio=remote.aspectRatio;
  if(remote.standalone!==undefined)capture.standalone=standalone;
  for(const key of ['parentJobId','rootJobId','version','base','resultIndex','importId','importBatch','groupID','layerIDs','indexes','waitingStopped','cancellation','submissionSent','submissionState','retrySafe','failureCode','unknownSince','recoveryState'])if(remote[key]!==undefined)capture[key]=remote[key];
  const value=publicJob(capture);
  if(preview&&remote.result&&["ready","importing","imported"].includes(remote.status))
    value.resultDataUrl="data:image/png;base64,"+(await downloadResult(capture)).toString("base64");
  if(preview&&Array.isArray(remote.images)&&remote.images.length){
    const token=await readPairingToken();
    // 并行取缩略图：4 图任务若串行，每次查询可能超过面板轮询/超时，表现为“查询没反应”。
    const results=await Promise.all(remote.images.map(async image=>{
      try{
        const response=await fetch(`${helperBase()}/api/jobs/${capture.id}/thumbnail?index=${image.index}`,{
          headers:{Authorization:`Bearer ${token}`},redirect:"error",signal:AbortSignal.timeout(8000)});
        if(!response.ok)return null;
        const thumb=Buffer.from(await response.arrayBuffer());
        return {index:image.index,dataUrl:"data:image/jpeg;base64,"+thumb.toString("base64")};
      }catch{return null;}
    }));
    value.images = (remote.images || []).map(image => ({
      ...image, ...(results.find(thumb => thumb && thumb.index === image.index) || {})
    }));
  }
  return {capture,remote,value};
}
async function downloadHdResult(capture,item,allowUncertain=false){
  const hd=item?.hd;
  if(!hd||hd.baseSha256!==item.sha256)return false;
  if(hd.alignment?.status==='uncertain'&&!allowUncertain)throw fail('高清图与原图对齐不足，请核对复核预览后再回贴。',{code:'alignment_uncertain'});
  const target=path.join(CAPTURE_DIR,capture.id,'hd-'+item.index+'-'+hd.pasteSha256+'.png');
  if(fs.existsSync(target)){
    const stat=await fsp.stat(target);
    assertFileBudget(stat.size,RESOURCE_LIMITS.sourceFileMaxBytes,'高清结果');
    const fileHash=await hashFile(target);
    if(fileHash===hd.pasteSha256){
      let meta=getVerifiedMeta(fileHash);
      if(!meta){
        const sharp=await sharpRequire(),info=await sharp(target,{limitInputPixels:MAX_PIXELS}).metadata();
        meta={width:info.width,height:info.height};
        setVerifiedMeta(fileHash,meta);
      }
      if(meta.width===hd.width&&meta.height===hd.height){capture.resultPath=target;return true;}
    }
  }
  const token=await readPairingToken();
  const response=await fetch(`${helperBase()}/api/jobs/${capture.id}/hd-result?index=${item.index}&hdSha256=${hd.pasteSha256}`,{headers:{Authorization:`Bearer ${token}`},signal:AbortSignal.timeout(30000),redirect:'error'});
  if(!response.ok)throw fail('高清结果尚无法获取，请保留任务重试高清生成。');
  const temporary=target+'.'+crypto.randomUUID()+'.tmp';
  let size=0;
  const hash=crypto.createHash('sha256');
  try{
    const handle=await fsp.open(temporary,'w');
    try{
      for await(const chunk of response.body){
        size+=chunk.length;
        if(size>RESOURCE_LIMITS.sourceFileMaxBytes)throw fail('高清结果过大。');
        hash.update(chunk);
        await handle.writeFile(chunk);
      }
    }finally{await handle.close();}
    const fileHash=hash.digest('hex');
    if(fileHash!==hd.pasteSha256)throw fail('高清文件与预期不一致，已停止回贴。');
    const sharp=await sharpRequire(),meta=await sharp(temporary,{limitInputPixels:MAX_PIXELS}).metadata();
    if(meta.width!==hd.width||meta.height!==hd.height)throw fail('高清文件与预期不一致，已停止回贴。');
    await fsp.rename(temporary,target);
    setVerifiedMeta(fileHash,meta);
  }catch(error){await fsp.rm(temporary,{force:true}).catch(()=>{});throw error;}
  capture.resultPath=target;return true;
}
async function status(input = {}) {
  const psPromise = cachedPsStatus().catch(error => ({ok:false,documents:0,error:error.message}));
  // dataHealth is a frozen cross-module contract published by helper /api/health.
  // The host passes it through unchanged; it never rewrites counts or issues.
  let dataHealth = null;
  const backendPromise = (async () => {
    const identity = await helperRequest("/api/health");
    if(identity.app!=="PSFlowBridge")throw fail("助手身份不匹配。");
    if(identity.dataHealth&&typeof identity.dataHealth==="object")dataHealth=identity.dataHealth;
    return helperRequest("/api/backend/status");
  })().catch(error => ({online:false,loginRequired:false,message:error.message}));
  const lastJobPromise = (async () => {
    const last = await readJsonFile(path.join(DATA_DIR,"action-last.json"));
    if(!last||!safeId(last.id))return null;
    try{return (await currentJob(last.id,input.preview === true)).value;}
    catch(error){return {id:last.id,status:"unknown",error:error.message};}
  })();
  const [ps,backend,lastJob] = await Promise.all([psPromise,backendPromise,lastJobPromise]);
  const effMode = normalizeMode(backend.effectiveMode || backend.mode || runtimeMode());
  return {ok:true,version:require(HELPER_PACKAGE).version,buildId:process.env.PSFB_BUILD_ID||"dev",online:backend.online,loginRequired:backend.loginRequired,message:backend.message,connection:backend,ps,lastJob,dataHealth,configured:isModeConfigured(),runtimeMode:effMode,effectiveMode:effMode};
}
async function statusLocal(input = {}) {
  const last=await readJsonFile(path.join(DATA_DIR,"action-last.json"));
  let lastJob=null;
  if(last&&safeId(last.id)) {
    try{lastJob=(await job({id:last.id,preview:input.preview===true})).job;}
    catch(error){const capture=await readJsonFile(path.join(CAPTURE_DIR,last.id,"capture.json"));lastJob=capture?publicJob(capture):{id:last.id,status:"unknown",error:error.message};}
  }
  const mode = runtimeMode();
  // Health arrives with phase-two status. Never add a helper round trip to
  // the local first-paint path when the helper is restarting or unavailable.
  const dataHealth=null;
  return {ok:true,version:require(HELPER_PACKAGE).version,buildId:process.env.PSFB_BUILD_ID||"dev",ps:psStatusCache?.value||{checking:true,documents:0,documentName:null},lastJob,dataHealth,connectionPending:true,runtimeMode:mode,effectiveMode:mode,configured:isModeConfigured()};
}
async function photoshopStatus(){return {ok:true,ps:await cachedPsStatus().catch(error=>({ok:false,documents:0,error:error.message}))};}
async function connection() {
  const [connection,health]=await Promise.all([
    helperRequest("/api/backend/status"),
    helperRequest("/api/health",{timeoutMs:300}).catch(()=>null)
  ]);
  const effMode = normalizeMode(connection.effectiveMode || connection.mode || runtimeMode());
  return {ok:true,connection,dataHealth:health?.app==='PSFlowBridge'&&health.dataHealth&&typeof health.dataHealth==='object'?health.dataHealth:null,online:connection.online,loginRequired:connection.loginRequired,message:connection.message,browser:browserRouting.preference(DATA_DIR),runtimeMode:effMode,effectiveMode:effMode,configured:isModeConfigured()};
}
async function withMutation(fn) {
  if(actionMutation)throw fail("已有操作正在执行，请等待当前任务。");
  actionMutation=true;
  const file=path.join(CAPTURE_DIR,"mutation.lock"),temporary=file+"."+crypto.randomUUID()+".tmp";let owned=false;
  try {
    await fsp.mkdir(CAPTURE_DIR,{recursive:true});
    await fsp.writeFile(temporary,JSON.stringify({pid:process.pid,createdAt:new Date().toISOString()}),{flag:"wx"});
    try{await fsp.link(temporary,file);owned=true;}
    catch(error){
      if(error.code!=="EEXIST")throw error;
      const recoveryLock=file+'.recovery';
      try{await fsp.link(temporary,recoveryLock);}catch{throw fail('操作锁正在恢复，请查询原任务。');}
      try{
      const prior=await readJsonFile(file,{});let alive=false;
      try{if(prior.pid){process.kill(prior.pid,0);alive=true;}}catch{}
      if(alive||!prior.pid)throw fail("已有操作正在执行或锁状态待确认，请查询原任务。");
      await fsp.unlink(file);await fsp.link(temporary,file);owned=true;
      }finally{await fsp.rm(recoveryLock,{force:true});}
    }
    return await fn();
  }finally{try{await fsp.rm(temporary,{force:true});if(owned)await fsp.rm(file,{force:true});}finally{actionMutation=false;}}
}
async function generate(input) {
  return withMutation(async()=>{
    if(input.operationId !== undefined&&!safeId(input.operationId))throw fail("生成编号无效。");
    const operationId=input.operationId||crypto.randomUUID();
    const editMode=validEditMode(input.editMode);
    // Pure text generation: no Photoshop capture at all. Validate everything the
    // helper will need, then hand the job straight to the helper as "queued".
    // An explicit but unsupported kind is rejected; only an omitted kind falls
    // back to the legacy image2image default.
    if(input.kind!==undefined&&input.kind!=="text2image"&&input.kind!=="image2image")
      throw fail("生成类型无效，仅支持 text2image 或 image2image。",{field:"kind",submissionSent:false});
    const kind=input.kind==="text2image"?"text2image":"image2image";
    const contextMode=kind==="text2image"?"auto":contextSnapshot.contextMode(input.contextMode);
    // Same rule for the ratio: an omitted value defaults, an explicit invalid one
    // is refused before anything is submitted.
    if(kind==="text2image"&&input.aspectRatio!==undefined&&!ASPECT_RATIOS.has(input.aspectRatio))
      throw fail("图片比例仅支持 1:1、4:3、3:4、16:9、9:16。",{field:"aspectRatio",submissionSent:false});
    const aspectRatio=kind==="text2image"?(input.aspectRatio===undefined?DEFAULT_ASPECT_RATIO:input.aspectRatio):null;
    const references=await require('../helper/extra-image').validateReferences(input.references,await sharpRequire());
    if(kind!=="text2image"&&references.length)throw fail("改图请使用已有附加参考图入口。",{submissionSent:false});
    const prior=await readJsonFile(path.join(CAPTURE_DIR,operationId,"capture.json"));
    if(prior) {
      if(kind!=="text2image"&&(prior.contextMode||"auto")!==contextMode)throw fail("生成编号已属于不同参考范围，请查询原任务。",{submissionSent:false});
      if(JSON.stringify((prior.references||[]).map(item=>item.sha256))!==JSON.stringify(references.map(item=>item.metadata.sha256)))throw fail("生成编号已属于不同参考图片，请查询原任务。",{submissionSent:false});
      if(prior.prompt!==String(input.prompt||"").trim()||prior.model!==String(input.model||"gemini-3.1-flash-image")||prior.count!==Number(input.count||1)||(prior.editMode||'auto')!==editMode||jobKind(prior)!==kind||(kind==="text2image"&&(prior.aspectRatio||DEFAULT_ASPECT_RATIO)!==aspectRatio))throw fail("生成编号已属于不同请求，请查询原任务。");
      try{return {ok:true,job:(await job({id:operationId})).job,idempotent:true};}
      catch(error){throw fail("原操作已记录，请查询原任务，避免再次框选或生成。",{job:publicJob(prior),uncertain:true});}
    }
    const prompt=String(input.prompt||"").trim(),model=String(input.model||"gemini-3.1-flash-image");
    const count=Number(input.count||1);
    if(![1,2,3,4].includes(count))throw fail("生成数量仅支持 1 到 4 张。",{submissionSent:false});
    if(prompt.includes("\uFFFD"))throw fail("提示词编码损坏，请重新输入后再提交。",{submissionSent:false});
    if(!prompt||prompt.length>LIMITS.promptMax)throw fail("请填写 1 到 4000 字的提示词。",{submissionSent:false});
    if(!ALLOWED_MODELS.has(model))throw fail("模型不支持。",{submissionSent:false});

    // 先检查既有未完成/待确认任务，即使登录暂失或离线也能立即恢复原任务
    const last = await readJsonFile(path.join(DATA_DIR, "action-last.json"));
    const LAST_PENDING = ["uploading", "queued", "attaching", "waiting_user", "generating", "downloading", "importing", "unknown"];
    if (last && safeId(last.id)) {
      try {
        let old = null;
        try {
          old = (await helperRequest("/api/jobs/" + last.id)).job;
        } catch {
          const cap = await readJsonFile(path.join(CAPTURE_DIR, last.id, "capture.json"));
          if (cap) old = publicJob(cap);
        }
        if (old && LAST_PENDING.includes(old.status) && !(old.status === "unknown" && old.waitingStopped === true)) {
          let jobVal;
          try { jobVal = (await currentJob(last.id, false)).value; }
          catch { jobVal = publicJobFromRemote(old); }
          throw fail("上一个任务结果仍待确认，已恢复原任务；本次没有提交生成。", {
            code: "previous_job_pending",
            job: jobVal
          });
        }
      } catch (err) {
        if (err.code === "previous_job_pending") throw err;
      }
    }

    const TRULY_ACTIVE = ["uploading", "queued", "attaching", "waiting_user", "generating", "downloading", "importing"];
    try {
      const { jobs: allJobs } = await helperRequest("/api/jobs");
      const activeJob = (allJobs || []).find(j => TRULY_ACTIVE.includes(j.status));
      if (activeJob) {
        let jobVal;
        try { jobVal = (await currentJob(activeJob.id, false)).value; }
        catch { jobVal = publicJobFromRemote(activeJob); }
        throw fail("存在正在执行中的任务，已恢复该任务；本次没有提交生成。", {
          code: "previous_job_pending",
          job: jobVal
        });
      }
    } catch (err) {
      if (err.code === "previous_job_pending") throw err;
      if (err.status !== 404) throw err;
    }

    // 后检查后端健康与登录状态
    const health = await helperRequest("/api/backend/status?confirm=1");
    if (runtimeMode() === "browser" && health.sessionReady === true && health.projectReady !== true) throw fail("请先在常用浏览器打开 Flow 图像项目。未提交生成。", { code: "project_not_ready", submissionSent: false });
    if (!health.online || health.loginRequired || health.sessionReady === false) throw fail(health.message || "请先连接 Flow。", { code: health.loginRequired ? "login_required" : "connection_unconfirmed", loginRequired: health.loginRequired === true, connection: health });

    // Pure text generation: the job never touches Photoshop. There is no
    // capture, no selection mask and no document identity to fabricate; the
    // helper creates it directly in "queued" for the selected provider.
    if (kind === "text2image") {
      const temporary = path.join(CAPTURE_DIR, operationId);
      await fsp.mkdir(temporary, { recursive: true });
      const provisional = {
        id: operationId, operationId, kind: "text2image", standalone: true, hasCapture: false,
        aspectRatio, prompt, model, count, editMode, status: "submitting", captureReady: false,
        createdAt: new Date().toISOString()
      };
      provisional.references=references.map(item=>({...item.metadata,name:item.name}));
      for(let index=0;index<references.length;index++)await fsp.writeFile(path.join(temporary,`reference-${index}.png`),references[index].bytes);
      await saveCapture(provisional);
      await atomicJson(path.join(DATA_DIR, "action-last.json"), { id: operationId });
      assertNotStopped(operationId);
      const mode = runtimeMode();
      let created;
      try {
        created = (await helperRequest("/api/jobs", { method: "POST", body: {
          operationId, kind: "text2image", standalone: true, hasCapture: false,
          aspectRatio, prompt, model, count, editMode,
          references:references.map(item=>({base64:item.bytes.toString('base64'),name:item.name})),
          provider: mode === "browser" ? "browser" : "api"
        } })).job;
      } catch (error) {
        await saveCapture(provisional, { status: "unknown", error: "本地任务创建待确认，请查询原任务。" });
        throw fail("任务提交未确认。请刷新并检查原任务，避免重复生成。", { job: publicJob(provisional), uncertain: true, submissionSent: false });
      }
      if (!created || !safeId(created.id)) throw fail("本地助手未返回有效任务。");
      if (created.id !== operationId) throw fail("本地助手返回了不同生成编号，请查询原任务。", { job: publicJob(provisional), uncertain: true });
      await saveCapture(provisional, {
        status: created.status || "queued", createdAt: created.createdAt || provisional.createdAt,
        updatedAt: created.updatedAt, lifecycle: { schemaVersion: 1, phase: created.status || "queued", operationId, submission: "not_submitted" },
        recovery: null
      });
      await atomicJson(path.join(DATA_DIR, "action-last.json"), { id: operationId });
      return { ok: true, job: publicJob(provisional) };
    }

    const temporary=path.join(CAPTURE_DIR,operationId);await fsp.mkdir(temporary,{recursive:true});
    const provisional={id:operationId,operationId,prompt,model,count,editMode,contextMode,status:"capturing",captureReady:false,createdAt:new Date().toISOString()};
    await saveCapture(provisional);await atomicJson(path.join(DATA_DIR,"action-last.json"),{id:operationId});
    const captureStart=Date.now();
    let capture,extraMeta=null;
    try {
      if(input.referenceDraftId){
        if(!safeId(input.referenceDraftId))throw fail("快照编号无效。",{submissionSent:false});
        const draft=await readJsonFile(path.join(DATA_DIR,"reference-drafts",input.referenceDraftId,"draft.json"));
        if(!draft)throw fail("选区快照已丢失，请刷新选区。",{submissionSent:false});
        if((draft.contextMode||"auto")!==contextMode)throw fail("参考范围已改变，请刷新选区快照。",{submissionSent:false});
        capture={...draft};
        await fsp.copyFile(draft.imagePath,path.join(temporary,"source.png"));
        capture.imagePath=path.join(temporary,"source.png");
        if(draft.maskPath){await fsp.copyFile(draft.maskPath,path.join(temporary,"mask.png"));capture.maskPath=path.join(temporary,"mask.png");}
        if(draft.contextImagePath){await fsp.copyFile(draft.contextImagePath,path.join(temporary,"context.png"));capture.contextImagePath=path.join(temporary,"context.png");}
      }else capture=await runPs({op:"capture",includeContext:true,contextMode,contextImagePath:path.join(temporary,"context.png"),externalRectangleMask:true,externalRawMask:true,imagePath:path.join(temporary,"source.png"),maskPath:path.join(temporary,"mask.png")});
    }
    catch(error){const message=psMessage(error.message);await saveCapture(provisional,{status:"failed",error:message,lifecycle:{phase:"capture",submission:"not_submitted"},recovery:{action:"recapture",label:"重新框选",submissionSafe:true}});throw fail(message,{job:publicJob(provisional)});}
    assertNotStopped(operationId);
    let source,mask,extraBuffer=null,globalContext=null;
    try {
    if(capture.maskRectangle) {
      const sharp=await sharpRequire(), r=capture.maskRectangle;
      const white=await sharp({create:{width:r.width,height:r.height,channels:3,background:"#fff"}}).png().toBuffer();
      await sharp({create:{width:capture.source.width,height:capture.source.height,channels:3,background:"#000"}})
        .composite([{input:white,left:r.left,top:r.top}]).removeAlpha().png().toFile(capture.maskPath);
    }
    if(capture.maskRaw){
      const expected=capture.maskPath+'.raw';if(capture.maskRaw.path!==expected)throw fail('选区通道路径不匹配，未提交生成。');
      const start=Date.now(),sharp=await sharpRequire();const pixels=decodeRawMask(await fsp.readFile(expected),capture.maskRaw,capture.source);
      await sharp(pixels,{raw:{width:capture.source.width,height:capture.source.height,channels:1}}).toColourspace('b-w').png().toFile(capture.maskPath);
      await fsp.rm(expected,{force:true});capture.captureTimings.maskEncodeMs=Date.now()-start;delete capture.maskRaw;
    }
    const uploadSharp=await sharpRequire();
    globalContext=await contextSnapshot.readContext(capture,uploadSharp);
    capture.contextMode=contextMode;capture.hasGlobalContext=Boolean(globalContext);capture.contextSource=globalContext?.metadata||null;
    if(contextMode==="full"&&!globalContext)throw fail("全图参考快照未完成，请重新捕获。",{submissionSent:false});
    source=await prepareUpload(capture.imagePath,uploadSharp);
    mask=capture.maskPath?await prepareUpload(capture.maskPath,uploadSharp):null;
    extraBuffer = null;
    extraMeta = null;
    if (input.extraImage !== undefined && input.extraImage !== null) {
      const extra=require('../helper/extra-image');
      const validated=await extra.validate(extra.fromBase64(input.extraImage),uploadSharp,{resize:true,purpose:input.extraImage.purpose||'reference'});
      extraBuffer=validated.bytes;extraMeta=validated.metadata;
      await fsp.writeFile(path.join(temporary,'extra.png'),extraBuffer);
    }
    }catch(error){await saveCapture(provisional,{status:'failed',error:error.message,lifecycle:{phase:'capture',submission:'not_submitted'},recovery:{action:'recapture',label:'重新框选',submissionSafe:true}});throw fail(error.message,{field:error.field,code:error.code,status:error.status,submissionSent:false,job:publicJob(provisional)});}
    const captureMs=Date.now()-captureStart;
    const record={...capture,id:operationId,operationId,prompt,model,count,editMode,hasExtraImage:Boolean(extraBuffer),extraImage:extraMeta,status:"uploading",createdAt:provisional.createdAt};
    await saveCapture(record);
    assertNotStopped(operationId);
    const mode=runtimeMode();
    let created;
    try {created=(await helperRequest("/api/jobs",{method:"POST",body:{operationId,prompt,model,editMode,provider:mode==="browser"?"browser":"api",documentID:capture.documentID,
      canvas:capture.canvas,bounds:capture.bounds,scope:capture.scope,source:capture.source,aspectTarget:capture.aspectTarget,count,
      geometryVersion:capture.geometryVersion,editBounds:capture.editBounds,editRegion:capture.editRegion,resultMaskMode:"external",referencePolicy:"selection-outline",
      documentName:capture.documentName||null,
      documentPath:capture.documentPath||null,documentSession:capture.psSession,
      timings:{captureMs,...capture.captureTimings},
      hasExtraImage:Boolean(extraBuffer),
      contextMode,hasGlobalContext:Boolean(globalContext),contextSource:globalContext?.metadata||null,
      extraImage:extraMeta,
      mask:mask?{width:capture.source.width,height:capture.source.height,components:1}:null}})).job;}
    catch(error){await saveCapture(record,{status:"unknown",error:"本地任务创建待确认，请查询原任务。"});throw fail(record.error,{job:publicJob(record),uncertain:true});}
    if(!created||!safeId(created.id))throw fail("本地助手未返回有效任务。");
    const id=created.id,dir=path.join(CAPTURE_DIR,id);
    if(id!==operationId)throw fail("本地助手返回了不同生成编号，请查询原任务。",{job:publicJob(record),uncertain:true});
    Object.assign(record,{status:created.status,createdAt:created.createdAt,imagePath:path.join(dir,"source.png"),maskPath:mask?path.join(dir,"mask.png"):null,extraPath:extraBuffer?path.join(dir,"extra.png"):null,hasExtraImage:Boolean(extraBuffer)});
    await saveCapture(record);await atomicJson(path.join(DATA_DIR,"action-last.json"),{id});
    try{
      await Promise.all([
        helperRequest(`/api/jobs/${id}/source`,{method:"PUT",headers:{"Content-Type":"image/png"},body:source}),
        mask?helperRequest(`/api/jobs/${id}/mask`,{method:"PUT",headers:{"Content-Type":"image/png"},body:mask}):Promise.resolve(),
        extraBuffer?helperRequest(`/api/jobs/${id}/extra`,{method:"PUT",headers:{"Content-Type":"image/png"},body:extraBuffer}):Promise.resolve(),
        globalContext?helperRequest(`/api/jobs/${id}/context`,{method:"PUT",headers:{"Content-Type":"image/png"},body:globalContext.bytes}):Promise.resolve()
      ]);
      assertNotStopped(id);
      const queued=(await helperRequest(`/api/jobs/${id}/complete-upload`,{method:"POST",body:{}})).job;
      await saveCapture(record,{status:queued.status,updatedAt:queued.updatedAt});return {ok:true,job:publicJob(record)};
    }catch(error){throw fail("任务提交未确认。请刷新并检查原任务，避免重复生成。",{job:publicJob(record)});}
  });
}
async function regenerate(input) {
  return withMutation(async () => {
    const base=input.base===undefined?'source':input.base;
    if(!['source','result'].includes(base))throw fail('再次生成的基底无效。');
    if(input.index!==undefined&&(!Number.isInteger(input.index)||input.index<0||input.index>3))throw fail('结果编号无效。');
    const prompt = typeof input.prompt === "string" ? input.prompt.trim() : "";
    if (prompt && prompt.length > LIMITS.promptMax) throw fail("请填写 1 到 4000 字的提示词。");
    if (prompt.includes("\uFFFD")) throw fail("提示词编码损坏，请重新输入后再提交。");
    const model = typeof input.model === "string" ? input.model : undefined;
    if (model && !ALLOWED_MODELS.has(model)) throw fail("模型不支持。");
    const count = input.count !== undefined ? Number(input.count) : undefined;
    if (count !== undefined && ![1, 2, 3, 4].includes(count)) throw fail("生成数量仅支持 1 到 4 张。");

    const health = await helperRequest("/api/backend/status?confirm=1");
    if(runtimeMode()==="browser" && health.sessionReady===true && health.projectReady!==true)throw fail("请先在常用浏览器打开 Flow 图像项目。未提交生成。",{code:"project_not_ready",submissionSent:false});
    if (!health.online || health.loginRequired || health.sessionReady === false) {
      // browser 模式下等待用户把任务导入 Flow，不需要 Python 登录会话。
      throw fail(health.message || "请先连接 Flow。", {
        code: health.loginRequired ? "login_required" : "connection_unconfirmed",
        loginRequired: health.loginRequired === true,
        connection: health
      });
    }

    const last = await readJsonFile(path.join(DATA_DIR, "action-last.json"));
    const baseId = String(input.id || (last && last.id) || "");
    if (!safeId(baseId)) throw fail("找不到原任务或任务编号无效。", { status: 400 });
    if(input.operationId !== undefined && !safeId(input.operationId))throw fail("再次生成编号无效。");
    const LAST_PENDING = ["uploading", "queued", "attaching", "waiting_user", "generating", "downloading", "importing", "unknown"];
    if (last && last.id !== baseId) {
      const latestCapture = await readJsonFile(path.join(CAPTURE_DIR, last.id, "capture.json"), null);
      if (latestCapture && latestCapture.operationId === input.operationId && latestCapture.baseJobId === baseId)
        return { ok: true, job: (await currentJob(last.id, false)).value };
      try {
        const latest = (await helperRequest("/api/jobs/" + last.id)).job;
        if (LAST_PENDING.includes(latest.status)) {
          let jobVal;
          try { jobVal = (await currentJob(last.id, false)).value; }
          catch { jobVal = publicJobFromRemote(latest); }
          throw fail("上一个任务仍待确认，请查询原任务。", { job: jobVal });
        }
      } catch (err) {
        if (err.job) throw err;
      }
    }

    const TRULY_ACTIVE = ["uploading", "queued", "attaching", "waiting_user", "generating", "downloading", "importing"];
    try {
      const { jobs: allJobs } = await helperRequest("/api/jobs");
      const activeJob = (allJobs || []).find(j => j.id !== baseId && TRULY_ACTIVE.includes(j.status));
      if (activeJob) {
        const c = await readJsonFile(path.join(CAPTURE_DIR, activeJob.id, "capture.json"), null);
        if (c && c.operationId === input.operationId && c.baseJobId === baseId) {
          return { ok: true, job: (await currentJob(activeJob.id, false)).value };
        }
        let jobVal;
        try { jobVal = (await currentJob(activeJob.id, false)).value; }
        catch { jobVal = publicJobFromRemote(activeJob); }
        throw fail("存在正在执行中的任务，请查询该任务。", { job: jobVal });
      }
    } catch (err) {
      if (err.job) throw err;
      if (err.status !== 404) throw err;
    }

    const { capture: oldCapture, remote: oldRemote } = await currentJob(baseId, false);
    // Pure text jobs (and any standalone record) have no captured source to
    // copy. "base: source" simply re-sends the same prompt, so it must not
    // require a source.png snapshot that was never produced.
    // currentJob already refused any remote that contradicts the capture, so the
    // local capture is the single source of truth for this decision.
    const standalone = isStandaloneJob(oldCapture);
    const kind = jobKind(oldRemote) === "text2image" || jobKind(oldCapture) === "text2image" ? "text2image" : "image2image";
    const aspectRatio = kind === "text2image" ? (oldRemote.aspectRatio || oldCapture.aspectRatio || DEFAULT_ASPECT_RATIO) : null;
    const editMode=validEditMode(input.editMode===undefined?oldRemote.editMode:input.editMode);
    if (oldRemote.status === "unknown") throw fail("任务状态待确认，不能再次生成。", { status: 409 });
    if (!["ready", "imported"].includes(oldRemote.status)) {
      throw fail("只有已完成或已回贴的任务可以再次生成。", { status: 409 });
    }
    if(standalone){
      const newId=input.operationId||crypto.randomUUID(),dir=path.join(CAPTURE_DIR,newId);
      if(!safeId(newId))throw fail('再次生成编号无效。',{submissionSent:false});
      const existing=await readJsonFile(path.join(dir,'capture.json'));
      if(existing){
        if(existing.baseJobId!==baseId)throw fail('生成编号已属于不同请求。',{status:409});
        return {ok:true,job:(await currentJob(newId,false)).value,idempotent:true};
      }
      const record={id:newId,operationId:newId,baseJobId:baseId,kind:base==='result'?'image2image':kind,standalone:true,captureReady:false,
        prompt:prompt||oldRemote.prompt,model:model||oldRemote.model,count:count??oldRemote.count??1,editMode,
        aspectRatio:oldRemote.aspectRatio||oldCapture.aspectRatio||'1:1',status:'submitting',createdAt:new Date().toISOString()};
      await fsp.mkdir(dir,{recursive:true});
      await saveCapture(record);await atomicJson(path.join(DATA_DIR,'action-last.json'),{id:newId});
      try{
        const created=(await helperRequest(`/api/jobs/${baseId}/regenerate`,{method:'POST',body:{operationId:newId,base,index:input.index??oldRemote.selectedIndex,prompt:record.prompt,model:record.model,count:record.count,editMode,aspectRatio:record.aspectRatio}})).job;
        if(!created||created.id!==newId||created.kind!==record.kind||created.standalone!==true||created.documentID)throw fail('新任务身份未确认，请查询原任务。');
        Object.assign(record,{status:created.status,source:created.source||null,parentJobId:created.parentJobId,rootJobId:created.rootJobId,version:created.version,base:created.base,resultIndex:created.resultIndex});
        await saveCapture(record);return {ok:true,job:publicJob(record)};
      }catch(error){await saveCapture(record,{status:'unknown',error:'新任务创建待确认，请查询原任务。'});throw fail(error.message,{job:publicJob(record),uncertain:true});}
    }

    // 预分配任务编号并与 operationId 统一：保证断线后 action-last 已指向新任务，可安全查询恢复而不会误查旧任务
    const newId = typeof input.operationId === "string" && safeId(input.operationId) ? input.operationId : crypto.randomUUID();
    const operationId = newId;
    const newDir = path.join(CAPTURE_DIR, newId);
    if(fs.existsSync(path.join(newDir,"capture.json")))throw fail("该再次生成编号已存在，请查询原任务。");
    await fsp.mkdir(newDir, { recursive: true });

    // Standalone jobs never captured a source image; their first round is the
    // prompt alone, so there is nothing to share into the new version.
    if (!standalone && oldCapture.imagePath && fs.existsSync(oldCapture.imagePath)) {
      await shareSnapshot(oldCapture.imagePath, path.join(newDir, "source.png"));
    }
    let newMaskPath = null;
    if (!standalone && oldCapture.maskPath && fs.existsSync(oldCapture.maskPath)) {
      newMaskPath = path.join(newDir, "mask.png");
      await shareSnapshot(oldCapture.maskPath, newMaskPath);
    }
    let newExtraPath = null;
    let newContextPath = null;
    if(oldCapture.hasGlobalContext||oldRemote.hasGlobalContext){
      const checked=await contextSnapshot.readContext(oldCapture,await sharpRequire(),oldRemote.contextSource||oldCapture.contextSource);
      if(!checked)throw fail("原任务全图参考缺失，无法再次生成。",{submissionSent:false});
      newContextPath=path.join(newDir,"context.png");
      await shareSnapshot(oldCapture.contextImagePath,newContextPath);
    }
    let newHasExtraImage = false;
    if (oldCapture.hasExtraImage || oldRemote.hasExtraImage) {
      const oldExtraPath = oldCapture.extraPath || path.join(CAPTURE_DIR, baseId, "extra.png");
      if (!fs.existsSync(oldExtraPath)) {
        throw fail("原任务附加参考图文件缺失，无法继承再次生成。", { field: "extraImage", status: 409 });
      }
      const extra=require('../helper/extra-image'),checked=await extra.validate(await fsp.readFile(oldExtraPath),await sharpRequire(),{purpose:oldRemote.extraImage?.purpose||'reference'});
      if(!extra.matches(oldRemote.extraImage||oldCapture.extraImage,checked.metadata))throw extra.invalid('原附加参考图身份已变化，无法继承。',409);
      newExtraPath = path.join(newDir, "extra.png");
      await shareSnapshot(oldExtraPath, newExtraPath);
      newHasExtraImage = true;
    }

    const effectivePrompt = prompt || oldRemote.prompt || oldCapture.prompt;
    const effectiveModel = model || oldRemote.model || oldCapture.model;
    const effectiveCount = count !== undefined ? count : (oldRemote.count || oldCapture.count || 1);

    const newRecord = {
      ...oldCapture,
      id: newId,
      operationId,
      baseJobId: baseId,
      editMode,
      prompt: effectivePrompt,
      model: effectiveModel,
      count: effectiveCount,
      status: "queued",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      imagePath: path.join(newDir, "source.png"),
      maskPath: newMaskPath,
      extraPath: newExtraPath,
      contextImagePath:newContextPath,
      hasExtraImage: newHasExtraImage,
      resultPath: undefined,
      result: undefined,
      images: undefined,
      selectedIndex: 0,
      progress:{done:0,total:effectiveCount},webProgress:null,transferProgress:null,timings:{captureMs:0},recovery:null,
      lifecycle:{schemaVersion:1,phase:'queued',operationId,submission:'unconfirmed'},
      importId: undefined,
      importIndex: undefined,
      layerID: undefined,
      receipt: undefined,
      error: null
    };

    // 先落地新 capture 与 action-last：即使 HTTP 中断，查询状态也能找到并恢复新任务
    await saveCapture(newRecord);
    await atomicJson(path.join(DATA_DIR, "action-last.json"), { id: newId });

    try {
      const regenBody = { operationId,editMode,base };
      if(input.index!==undefined)regenBody.index=input.index;
      if (prompt) regenBody.prompt = prompt;
      if (model) regenBody.model = model;
      if (count !== undefined) regenBody.count = count;

      const res = await helperRequest(`/api/jobs/${baseId}/regenerate`, {
        method: "POST",
        body: regenBody
      });
      const created = res.job;
      if (!created || !safeId(created.id)) throw fail("本地助手未返回有效新任务。");
      if(base==='result') {
        const token=await readPairingToken();
        const response=await fetch(`${helperBase()}/api/jobs/${created.id}/source.png`,{headers:{Authorization:`Bearer ${token}`},redirect:'error',signal:AbortSignal.timeout(15000)});
        if(!response.ok)throw fail('新版本素材尚未同步，请恢复该任务。',{uncertain:true});
        const bytes=Buffer.from(await response.arrayBuffer()),temporary=newRecord.imagePath+'.'+crypto.randomUUID()+'.tmp';
        await fsp.writeFile(temporary,bytes);await fsp.rename(temporary,newRecord.imagePath);
      }
      await saveCapture(newRecord, {
        parentJobId:created.parentJobId,rootJobId:created.rootJobId,version:created.version,base:created.base,resultIndex:created.resultIndex,
        status: created.status,
        createdAt: created.createdAt,
        updatedAt: created.updatedAt,
        prompt: created.prompt,
        model: created.model,
        count: created.count
      });
      return { ok: true, job: publicJob(newRecord) };
    } catch (error) {
      if(error.code === "rejected") {
        await atomicJson(path.join(DATA_DIR,"action-last.json"),{id:baseId});
        throw fail(error.message,{code:error.code,job:publicJob(oldCapture)});
      }
      throw fail("任务提交未确认。请刷新并检查新任务状态，避免重复生成。", { job: publicJob(newRecord), uncertain: true });
    }
  });
}

async function job(input) {
  const id = String((input && input.id) || "");
  if (!safeId(id)) throw fail("任务编号无效。", { status: 400 });
  const preview = input && input.preview === true;

  let capture = null;
  try {
    capture = await loadCapture(id);
  } catch (err) {
    if (err.status !== 404) throw err;
  }

  if (capture) {
    // Standalone jobs have no local capture file, but they still have a live
    // helper task whose status must be refreshed; only a job that is still
    // capturing (or a bound job missing its snapshot) may answer from disk.
    if(!isStandaloneJob(capture)&&(!capture.imagePath||capture.captureReady===false))return {ok:true,job:publicJob(capture)};
    try {
      return { ok: true, job: (await currentJob(id, preview)).value };
    } catch (error) {
      // A standalone record survives a helper restart or a lost local task; the
      // local record is still the best answer, so report it rather than failing
      // the whole query. Identity mismatches stay loud.
      const remoteGone = ["network", "remote", "rejected"].includes(error.code) || error.status === 404;
      if (!isStandaloneJob(capture) || !remoteGone) throw error;
      return { ok: true, job: publicJob(capture), remoteUnavailable: true };
    }
  }

  const remoteRes = await helperRequest("/api/jobs/" + id);
  const remote = remoteRes && remoteRes.job;
  if (!remote) throw fail("找不到这个任务。", { status: 404 });
  const value = publicJobFromRemote(remote);
  if (preview) {
    await attachThumbnails(value);
  }
  return { ok: true, job: value };
}

async function resume(input) {
  return withMutation(async()=>{
    const id=String(input.id||"");if(!safeId(id))throw fail("任务编号无效。");
    const remote=(await helperRequest("/api/jobs/"+id)).job;
    if(!["failed","uploading"].includes(remote.status)||remote.recovery?.action!=="resume"||remote.recovery?.submissionSafe!==true)throw fail("当前任务只能查询，不能继续提交。",{status:409});
    if(remote.recovery.phase==="upload") {
      const capture=await loadCapture(id);
      if(!capture.imagePath)throw fail("原素材未捕获完成，请重新框选。");
      if(!remote.sourceReady)await helperRequest(`/api/jobs/${id}/source`,{method:"PUT",headers:{"Content-Type":"image/png"},body:await prepareUpload(capture.imagePath,await sharpRequire())});
      if(remote.mask&&!remote.maskReady)await helperRequest(`/api/jobs/${id}/mask`,{method:"PUT",headers:{"Content-Type":"image/png"},body:await prepareUpload(capture.maskPath,await sharpRequire())});
      if(remote.hasGlobalContext&&!remote.contextReady){
        const checked=await contextSnapshot.readContext(capture,await sharpRequire(),remote.contextSource);
        if(!checked)throw fail("全图参考丢失，请重新捕获。",{submissionSent:false});
        await helperRequest(`/api/jobs/${id}/context`,{method:"PUT",headers:{"Content-Type":"image/png"},body:checked.bytes});
      }
      if(remote.hasExtraImage&&!remote.extraReady){
        const extraFile = capture.extraPath || path.join(CAPTURE_DIR, id, "extra.png");
        if(!fs.existsSync(extraFile))throw fail("附加参考图丢失，请重新选择并上传。", { field: "extraImage", submissionSafe: true });
        const extraBytes = await fsp.readFile(extraFile);
        const extra=require('../helper/extra-image');
        const checked=await extra.validate(extraBytes,await sharpRequire(),{purpose:remote.extraImage?.purpose||'reference'});
        if(!extra.matches(remote.extraImage,checked.metadata))throw extra.invalid('原附加参考图身份已变化，未恢复提交。',409);
        await helperRequest(`/api/jobs/${id}/extra`,{method:"PUT",headers:{"Content-Type":"image/png"},body:extraBytes});
      }
      await helperRequest(`/api/jobs/${id}/complete-upload`,{method:"POST",body:{}});
    }else await helperRequest(`/api/jobs/${id}/retry`,{method:"POST",body:{}});
    await atomicJson(path.join(DATA_DIR,"action-last.json"),{id});
    return {ok:true,job:(await job({id})).job};
  });
}
async function select(input) {
  const id = String((input && input.id) || "");
  if (!safeId(id)) throw fail("任务编号无效。", { status: 400 });
  const index = Number(input && input.index);

  let capture = null;
  try {
    capture = await loadCapture(id);
  } catch (err) {
    if (err.status !== 404) throw err;
  }

  if (capture) {
    const { remote } = await currentJob(id, false);
    if (remote.status !== "ready" && !remote.result) throw fail("任务尚未生成完成，不能选择图片。");
    await helperRequest("/api/jobs/" + id + "/select", { method: "POST", body: { index } });
    return { ok: true, job: (await currentJob(id, input && input.preview === true)).value };
  }

  const selectedRes = await helperRequest("/api/jobs/" + id + "/select", { method: "POST", body: { index } });
  const remote = (selectedRes && selectedRes.job) || (await helperRequest("/api/jobs/" + id)).job;
  const value = publicJobFromRemote(remote);
  if (input && input.preview === true) {
    await attachThumbnails(value);
  }
  return { ok: true, job: value };
}

async function paste(input) {
  return withMutation(async()=>{
    const featherPx=input.maskFeatherPx === undefined ? 3 : Number(input.maskFeatherPx);
    if(!Number.isFinite(featherPx)||featherPx<LIMITS.featherMin||featherPx>LIMITS.featherMax)throw fail("蒙版羽化仅支持 0 到 250 像素。");
    const id = String(input.id || "");
    let capture = null;
    try { capture = await loadCapture(id); }
    catch { throw fail("该任务没有本地捕获信息，无法回贴到 Photoshop。"); }
    if (capture.standalone === true || capture.kind === "text2image" || !capture.documentID || !capture.psSession)
      throw fail("当前为纯文本生成或独立结果，未绑定 Photoshop 文档，无法原位贴回。可作为新文档打开或导出文件。", { code: "standalone_job", status: 409 });
    const { capture: currentCapture, remote } = await currentJob(id, false);
    if (isStandaloneJob(currentCapture) || isStandaloneJob(remote))
      throw fail("当前为纯文本生成或独立结果，未绑定 Photoshop 文档，无法原位贴回。可作为新文档打开或导出文件。", { code: "standalone_job", status: 409 });
    if(remote.status==='importing'&&remote.importBatch)throw fail('当前是整组回贴，请使用整组回贴恢复。',{uncertain:true});
    capture = currentCapture;
    if(!["ready","importing","imported"].includes(remote.status))throw fail("任务尚未生成完成，不能回贴。");
    const selectedIndex = Number(remote.selectedIndex) || 0;
    if(input.index !== undefined && (!Number.isInteger(input.index) || input.index !== selectedIndex))
      throw fail("预览与当前选中图片不一致，请重新选择后回贴。",{code:"selection_changed"});
    const selectedImage = (remote.images || []).find(image => image.index === selectedIndex);
    if(selectedImage && selectedImage.alignment && selectedImage.alignment.status === "uncertain" && input.allowUnaligned !== true && input.allowUncertainAlignment !== true)
      throw fail("生成内容与原图对齐不足，请先查看合成效果。",{code:"alignment_uncertain"});
    if(input.sha256 && (!selectedImage || input.sha256 !== selectedImage.sha256))
      throw fail("预览图片已变化，请刷新后回贴。",{code:"selection_changed"});
    if(remote.status === "importing" && capture.importIndex !== undefined && capture.importIndex !== selectedIndex)
      throw fail("回贴图片已变化，请保留任务并确认原回贴。",{uncertain:true});
    if(!capture.psSession)throw fail("缺少捕获时的 Photoshop 会话信息，已保留结果。");
    // 每次回贴都用新的 importId：Photoshop 侧按 importId 命名图层并据此去重，
    // 新的 importId 才会真正新建图层，从而支持同一张图多次贴回或换图再贴。
    // importing 中的同一操作仍复用现有 importId，避免重复插入。
    const importId = remote.status==="importing" && remote.importId ? remote.importId : crypto.randomUUID();
    if(remote.status==="importing"&&remote.importId&&remote.importId!==importId)throw fail("该任务已有其他回贴操作，请保留结果并核对。");
    if(input.hdSha256!==undefined&&input.hdSha256!==(selectedImage?.hd?.pasteSha256||''))throw fail('高清预览已变化，请重新打开后回贴。',{code:'selection_changed'});
    const usesHd=await downloadHdResult(capture,selectedImage,input.allowUnaligned===true||input.allowUncertainAlignment===true);
    if(!usesHd)await downloadResult(capture,selectedIndex,{fileOnly:true});
    await saveCapture(capture,{importId,importIndex:selectedIndex});
    if(remote.status!=="importing")await helperRequest(`/api/jobs/${capture.id}/import-start`,{method:"POST",body:{importId,index:selectedIndex,sha256:selectedImage && selectedImage.sha256,hdSha256:usesHd?selectedImage.hd.pasteSha256:''}});
    // 只有本次操作自己发起的插入才记录 receipt；再次回贴必须重新插入，
    // 不能复用上一次的 layerID，否则会误判为“已贴回”。
    let receipt=remote.status==="importing" && remote.importId===importId && capture.receipt && capture.receipt.importId===importId ? capture.receipt : null;
    if(!receipt){
      try{
        const placed=await runPs({op:"paste",expectedSession:capture.psSession,documentID:capture.documentID,
          canvas:capture.canvas,bounds:capture.bounds,imagePath:capture.resultPath,maskPath:capture.maskPath,importId,
          highResolution:usesHd,imagePixelWidth:usesHd?selectedImage.hd.width:undefined,imagePixelHeight:usesHd?selectedImage.hd.height:undefined,
          smartObject:usesHd||input.smartObject !== false,maskFeatherPx:featherPx});
        receipt={importId,documentID:placed.documentID,layerID:placed.layerID};
        await saveCapture(capture,{receipt,layerID:placed.layerID});
      }catch(error){
        if(!error.uncertain)await helperRequest(`/api/jobs/${capture.id}/import-abort`,{method:"POST",body:{importId}}).catch(()=>{});
        throw fail(error.uncertain?"回贴结果尚未确认。请恢复当前任务，勿另建回贴编号。":psMessage(error.message),{uncertain:error.uncertain});
      }
    }
    try{await helperRequest(`/api/jobs/${capture.id}/import-complete`,{method:"POST",body:receipt});}
    catch{throw fail("图片已回贴，但完成回执未确认。请恢复当前任务，避免重复插入。",{uncertain:true});}
    return {ok:true,job:(await currentJob(capture.id,input.preview === true)).value};
  });
}
async function pasteBatch(input) {
  return withMutation(async()=>{
    const id=String(input.id||'');if(!safeId(id))throw fail('任务编号无效。');
    const indexes=input.indexes,preferredIndex=input.preferredIndex,feather=input.maskFeatherPx===undefined?3:input.maskFeatherPx;
    if(!Array.isArray(indexes)||indexes.length<1||indexes.length>4||new Set(indexes).size!==indexes.length||indexes.some(i=>!Number.isInteger(i)||i<0||i>3)||!indexes.includes(preferredIndex))throw fail('整组回贴的结果编号或首选版本无效。');
    if(typeof feather!=='number'||!Number.isFinite(feather)||feather<LIMITS.featherMin||feather>LIMITS.featherMax)throw fail('蒙版羽化仅支持 0 到 250 像素。');
    const {capture,remote}=await currentJob(id,false);
    if(isStandaloneJob(capture)||isStandaloneJob(remote))throw fail('当前为纯文本生成或独立结果，未绑定 Photoshop 文档，无法整组回贴。可作为新文档打开或导出文件。',{code:'standalone_job',status:409});
    if(!['ready','imported','importing'].includes(remote.status))throw fail('任务尚未生成完成，不能整组回贴。');
    if(!capture.psSession)throw fail('缺少捕获时的 Photoshop 会话信息，已保留结果。');
    const hashes=indexes.map(index=>{
      const image=remote.images?.find(x=>x.index===index),expected=input.hashes?.find(x=>x.index===index);
      if(!image||!expected||expected.sha256!==image.sha256||expected.hdSha256!==(image.hd?.baseSha256===image.sha256?image.hd.pasteSha256:''))throw fail('整组预览已变化，请刷新结果后回贴。',{code:'selection_changed'});
      if((image.alignment?.status==='uncertain'||image.hd?.alignment?.status==='uncertain')&&input.allowUncertainAlignment!==true)throw fail('部分版本对齐不足，请先核对合成效果。',{code:'alignment_uncertain'});
      return {index,sha256:image.sha256,hdSha256:expected.hdSha256};
    });
    const batch={indexes,hashes,preferredIndex,maskFeatherPx:feather};
    if(remote.status==='importing'&&(!remote.importBatch||JSON.stringify(remote.importBatch)!==JSON.stringify(batch)))throw fail('该任务已有不同的回贴操作，请恢复原操作。',{uncertain:true});
    if(input.operationId!==undefined&&!safeId(input.operationId))throw fail('整组回贴编号无效。');
    if(remote.status==='importing'&&input.operationId&&input.operationId!==remote.importId)throw fail('已有整组回贴待恢复，请保留原编号。',{uncertain:true});
    const importId=remote.status==='importing'?remote.importId:(input.operationId||crypto.randomUUID());
    const previousImport=capture.batchImports?.[importId];
    if(previousImport){
      if(JSON.stringify(previousImport.batch)!==JSON.stringify(batch))throw fail('该回贴编号已用于不同的整组结果。',{code:'selection_changed'});
      if(previousImport.completed)return {ok:true,job:publicJob(capture),receipt:previousImport.receipt,idempotent:true};
    }
    if(remote.status==='imported'&&remote.importId===importId){
      if(JSON.stringify(remote.importBatch)!==JSON.stringify(batch))throw fail('该回贴编号已用于不同的整组结果。',{code:'selection_changed'});
      return {ok:true,job:publicJob(capture),receipt:capture.receipt,idempotent:true};
    }
    if(!importId)throw fail('原回贴编号缺失，已保留结果。',{uncertain:true});
    const items=[];
    for(const index of indexes){const image=remote.images.find(x=>x.index===index),local={...capture};const highResolution=await downloadHdResult(local,image,input.allowUncertainAlignment===true);if(!highResolution)await downloadResult(local,index,{fileOnly:true});items.push({index,imagePath:local.resultPath,highResolution,imagePixelWidth:image.hd?.width,imagePixelHeight:image.hd?.height});}
    await saveCapture(capture,{importId,importBatch:batch});
    if(remote.status!=='importing')await helperRequest(`/api/jobs/${id}/import-start`,{method:'POST',body:{importId,index:remote.selectedIndex,sha256:remote.result.sha256,batch}});
    let receipt=remote.status==='importing'&&capture.receipt?.importId===importId?capture.receipt:null;
    if(!receipt){
      try{const placed=await runPs({op:'paste-batch',expectedSession:capture.psSession,documentID:capture.documentID,canvas:capture.canvas,bounds:capture.bounds,maskPath:capture.maskPath,importId,items,indexes,preferredIndex,maskFeatherPx:feather});receipt={importId,documentID:placed.documentID,layerID:placed.layerID,groupID:placed.groupID,layerIDs:placed.layerIDs,indexes:placed.indexes};await saveCapture(capture,{receipt,layerID:placed.layerID,groupID:placed.groupID,layerIDs:placed.layerIDs});}
      catch(error){if(!error.uncertain)await helperRequest(`/api/jobs/${id}/import-abort`,{method:'POST',body:{importId}}).catch(()=>{});throw fail(psMessage(error.message),{uncertain:error.uncertain});}
    }
    try{await helperRequest(`/api/jobs/${id}/import-complete`,{method:'POST',body:receipt});}catch{throw fail('整组已回贴，完成回执尚未确认。请恢复当前整组回贴。',{uncertain:true});}
    await saveCapture(capture,{batchImports:{...(capture.batchImports||{}),[importId]:{batch,receipt,completed:true}}});
    return {ok:true,job:(await currentJob(id,false)).value,receipt};
  });
}
async function recover(input) {
  return withMutation(async()=>{
    const id=String(input.id||'');if(!safeId(id))throw fail('任务编号无效。');
    await helperRequest(`/api/jobs/${id}/recover`,{method:'POST',body:{}});
    return {ok:true,job:(await job({id,preview:input.preview===true})).job};
  });
}
async function forceStop(input) {
  const id=String(input?.id||'');
  if(!safeId(id)) throw fail("任务编号无效。",{status:400});
  let remote;
  try { remote=(await helperRequest('/api/jobs/'+id)).job; }
  catch(error) { if(error.status!==404) throw error; }
  const capture=await loadCapture(id).catch(()=>null);
  if(!remote&&!capture) throw fail("找不到这个任务。",{status:404});
  if(['importing','imported'].includes(remote?.status||capture?.status)) throw fail("回贴期间不能强制中断，请先核对 Photoshop 图层。",{status:409});
  if(remote) remote=(await helperRequest('/api/jobs/'+id+'/cancel',{method:'POST',body:{}})).job;
  if((remote?.status||'cancelled')==='cancelled')stoppedJobs.add(id);
  else stoppedJobs.delete(id);
  if(capture) await saveCapture(capture,{status:remote?.status||'cancelled',waitingStopped:remote?.waitingStopped,cancellation:remote?.cancellation,recovery:remote?.recovery,lifecycle:remote?.lifecycle,updatedAt:remote?.updatedAt});
  return {ok:true,job:remote?publicJobFromRemote(remote):publicJob(capture),message:remote?.status==='cancelled'?'已取消未提交任务并保留记录。':'已停止本地等待。已提交到 Flow 的生成可能继续，请恢复查询；不会自动重试。'};
}
async function endWait(input) {
  return withMutation(async () => {
    const last = await readJsonFile(path.join(DATA_DIR, "action-last.json"), null);
    const id = String((input && input.id) || (last && last.id) || "");
    if (!safeId(id)) throw fail("找不到原任务或任务编号无效。", { status: 400 });

    const remoteRes = await helperRequest("/api/jobs/" + id);
    const remote = remoteRes && remoteRes.job;
    if (!remote) throw fail("找不到这个任务。", { status: 404 });
    if (remote.status !== "unknown") throw fail("任务状态已改变，请查询后再操作。");

    const cancelledRes = await helperRequest("/api/jobs/" + id + "/cancel", { method: "POST", body: {} });
    const cancelledRemote = cancelledRes && cancelledRes.job;
    if(!cancelledRemote)throw fail("停止等待尚未确认，请查询原任务。",{uncertain:true});
    if(cancelledRemote.status==="cancelled")stoppedJobs.add(id);else stoppedJobs.delete(id);

    let jobVal = null;
    let capture = null;
    try {
      capture = await loadCapture(id);
    } catch {}

    if (capture) {
      await saveCapture(capture, { status: cancelledRemote.status, waitingStopped:cancelledRemote.waitingStopped,cancellation:cancelledRemote.cancellation,recovery:cancelledRemote.recovery,lifecycle:cancelledRemote.lifecycle,updatedAt: cancelledRemote.updatedAt });
      jobVal = publicJob(capture);
      jobVal.hasCapture = jobVal.standalone !== true;
    } else {
      jobVal = publicJobFromRemote(cancelledRemote);
      jobVal.hasCapture = false;
    }

    return {
      ok: true,
      job: jobVal,
      message: cancelledRemote.status === "cancelled" ? "已取消未提交任务，原任务记录和素材已保留。" : "已停止本地等待，原任务记录和素材已保留。已提交生成可能继续，请恢复查询；不会自动重试。"
    };
  });
}
async function login() {
  if(runtimeMode()==="browser") return browserRouting.open(DATA_DIR);
  const config=await readBackendConfig();
  const result=await requestJson(config.base+"/setup/open-login",{method:"POST",headers:{Authorization:`Bearer ${config.key}`}},30000);
  if(!result.success)throw fail(result.message||"Flow 登录窗口打开失败。");return {ok:true,message:result.message};
}
// Toggle the headed Flow window that the backend keeps for login. If the window
// is not open yet, open it; otherwise flip its visibility. This is the embedded
// entry point the panel's "打开 Flow 窗口" button calls.
async function flowWindow() {
  if(runtimeMode()==="browser") return browserRouting.open(DATA_DIR);
  const config=await readBackendConfig();
  const toggled=await requestJson(config.base+"/setup/toggle-browser",{method:"POST",headers:{Authorization:`Bearer ${config.key}`}},30000);
  if(toggled&&toggled.success)return {ok:true,visible:toggled.visible===true,message:toggled.message||"Flow 窗口状态已更新。"};
  const opened=await requestJson(config.base+"/setup/open-login",{method:"POST",headers:{Authorization:`Bearer ${config.key}`}},30000);
  if(!opened.success)throw fail(opened.message||"Flow 窗口打开失败。");
  return {ok:true,message:opened.message||"已打开 Flow 登录窗口。"};
}
// Explicit show/hide for the persistent generation browser. The panel's
// "显示 / 隐藏 Flow 窗口" button uses this so the same Playwright context that
// generates is the one the user sees, instead of a second browser window.
async function flowVisible(input) {
  if(runtimeMode()==="browser") return input?.visible===false ? {ok:true,message:"浏览器托管模式请在浏览器中管理窗口。"} : browserRouting.open(DATA_DIR);
  const config=await readBackendConfig();
  const desired=input&&typeof input.visible==="boolean"?input.visible:null;
  const current=await requestJson(config.base+"/setup/status",{method:"GET",headers:{Authorization:`Bearer ${config.key}`}},10000);
  if(desired===null)return flowWindow();
  if(current.browser_open && current.browser_visible===desired)return {ok:true,visible:desired,message:"Flow 窗口状态已确认。"};
  const toggled=await requestJson(config.base+"/setup/toggle-browser",{method:"POST",headers:{Authorization:`Bearer ${config.key}`}},30000);
  if(!toggled||!toggled.success)throw fail(toggled&&toggled.message?toggled.message:"Flow 窗口状态切换失败。");
  return {ok:true,visible:toggled.visible===true,message:toggled.message||"Flow 窗口状态已更新。"};
}


async function history(input = {}) {
  const remoteRes = await helperRequest("/api/jobs");
  const remoteJobs = Array.isArray(remoteRes && remoteRes.jobs) ? remoteRes.jobs : [];

  const seenIds = new Set();
  const jobsList = [];

  for (const remote of remoteJobs) {
    if (!safeId(remote.id)) continue;
    seenIds.add(remote.id);
    let capture = null;
    try {
      capture = await loadCapture(remote.id);
    } catch {}

    if (capture) {
      Object.assign(capture, {
        status: remote.status,
        kind: remote.kind === "text2image" ? "text2image" : (capture.kind === "text2image" ? "text2image" : "image2image"),
        aspectRatio: remote.aspectRatio || capture.aspectRatio || null,
        standalone: remote.standalone === true || remote.kind === "text2image" || capture.standalone === true || !capture.documentID,
        favorite:remote.favorite===true,editMode:remote.editMode||'auto',recovery:remote.recovery||null,lifecycle:remote.lifecycle||null,timings:remote.timings||null,transferProgress:remote.transferProgress||null,
        ...Object.fromEntries(['parentJobId','rootJobId','version','base','resultIndex','importId','importBatch','groupID','layerIDs','indexes','waitingStopped','cancellation','submissionSent','submissionState','retrySafe','failureCode','unknownSince','recoveryState'].filter(key=>remote[key]!==undefined).map(key=>[key,remote[key]])),
        documentName:remote.documentName||capture.documentName,
        updatedAt: remote.updatedAt,
        error: remote.error,
        result: remote.result,
        layerID: remote.layerID || capture.layerID,
        progress: remote.progress || null,
        webProgress: remote.webProgress || null,
        reference: remote.reference || null,
        images: remote.images || null,
        count: remote.count || capture.count,
        selectedIndex: Number(remote.selectedIndex || 0)
      });
      jobsList.push(publicJob(capture));
    } else {
      jobsList.push(publicJobFromRemote(remote));
    }
  }

  try {
    const entries = await fsp.readdir(CAPTURE_DIR, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.isDirectory() && safeId(entry.name) && !seenIds.has(entry.name)) {
        try {
          const localCapture = await loadCapture(entry.name);
          seenIds.add(entry.name);
          jobsList.push(publicJob(localCapture));
        } catch {}
      }
    }
  } catch {}

  jobsList.sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));

  let filtered = jobsList;

  if (input.capturedOnly === true || input.hasCapture === true) {
    filtered = filtered.filter(j => j.hasCapture === true);
  }
  if (input.documentID !== undefined && input.documentID !== null && input.documentID !== "") {
    filtered = filtered.filter(j => j.documentID === Number(input.documentID));
  }
  const paged=filterHistory(filtered, ['q','status','favoritesOnly','offset','limit','documentName','document'].some(k=>input[k]!==undefined)?input:undefined);
  filtered=paged.items;

  const previewJobId = input.previewJobId || input.id || null;
  if (previewJobId && safeId(previewJobId)) {
    const target = filtered.find(j => j.id === previewJobId);
    if (target) {
      if (target.hasCapture) {
        try {
          const { value: full } = await currentJob(previewJobId, true);
          Object.assign(target, full, { hasCapture: true });
        } catch {}
      } else {
        await attachThumbnails(target);
      }
    }
  } else if (input.preview === true) {
    await Promise.all(filtered.slice(0, 20).map(j => attachThumbnails(j)));
  }

  return { ok: true, jobs: filtered,total:paged.total,offset:Math.max(0,Number(input.offset)||0),hasMore:paged.hasMore };
}
async function favorite(input){
  return withMutation(async()=>{
    const id=String(input.id||'');if(!safeId(id)||typeof input.favorite!=='boolean')throw fail('收藏参数无效。');
    try{await helperRequest(`/api/jobs/${id}/favorite`,{method:'POST',body:{favorite:input.favorite}});return {ok:true,job:(await job({id})).job};}
    catch(error){if(error.status!==404)throw error;const capture=await loadCapture(id);await saveCapture(capture,{favorite:input.favorite});return {ok:true,job:publicJob(capture)};}
  });
}
async function trash(){
  const remote=await helperRequest('/api/trash'),local=await listTrash(DATA_DIR);
  const items=new Map((remote.items||[]).map(x=>[x.id,x]));
  const issues=[...(remote.issues||[])];
  for(const id of local['action-jobs']){
    const resRecord=await inspectTrashRecord(DATA_DIR,id,'action-jobs');
    if(!resRecord.ok){
      issues.push(resRecord.issue);
      continue;
    }
    if(!items.has(id))items.set(id,{id,kind:'action-jobs',deletedAt:resRecord.deletedAt,job:publicJob(resRecord.record)});
  }
  return {
    ok:true,
    items:[...items.values()].sort((a,b)=>String(b.deletedAt).localeCompare(String(a.deletedAt))),
    issues,
    issueCount:issues.length
  };
}
async function restoreJob(input){
  return withMutation(async () => {
    const id = String(input.id || '');
    if (!safeId(id)) throw fail('任务编号无效。');
    const local = await listTrash(DATA_DIR), remote = await helperRequest('/api/trash');
    const remoteIssue = (remote.issues || []).find(x => x.id === id);
    if (remoteIssue) throw fail('该记录的部分数据暂时无法读取，未恢复。', { code: remoteIssue.code || 'trash_unreadable', status: 409 });
    const hasLocal = local['action-jobs'].includes(id), hasRemote = (remote.items || []).some(x => x.id === id);
    if (!hasLocal && !hasRemote) throw fail('回收站没有该记录。');
    if (hasLocal && fs.existsSync(path.join(CAPTURE_DIR, id))) throw fail('本地同编号记录已存在，未覆盖。');
    if (hasLocal) {
      const insp = await inspectTrashRecord(DATA_DIR, id, 'action-jobs');
      if (!insp.ok) throw fail('该记录的部分数据暂时无法读取，未恢复。', { code: insp.issue?.code || 'trash_unreadable', status: 409 });
    }
    if (hasRemote) await helperRequest(`/api/trash/${id}/restore`, { method: 'POST', body: {} });
    try {
      if (hasLocal) await restoreFromTrash(DATA_DIR, id, 'action-jobs');
    } catch (error) {
      if (hasRemote) await helperRequest('/api/jobs/' + id, { method: 'DELETE' }).catch(() => {});
      throw error;
    }
    return { ok: true, restored: id };
  });
}

async function deleteJob(input) {
  return withMutation(async () => {
    const id = String((input && input.id) || "");
    if (!safeId(id)) throw fail("任务编号无效。", { status: 400 });

    // Captures may carry a newer favorite flag than the helper snapshot. Check
    // it before moving either half of the record to the recycle bin.
    let localCapture = null;
    if (input.cleanup) {
      try { localCapture = await loadCapture(id); }
      catch (error) { if (error.code !== "ENOENT" && error.status !== 404) throw error; }
      if (localCapture && (localCapture.favorite === true || localCapture.isFavorite === true))
        throw fail("收藏记录已跳过，请先取消收藏再批量清理。", {code:"favorite_protected",status:409});
    }
    let helperDeleted = false;
    try {
      const res = await helperRequest("/api/jobs/" + id, { method: "DELETE", body: input.cleanup ? { cleanup: input.cleanup } : undefined });
      if (res && res.ok) helperDeleted = true;
    } catch (err) {
      if (err.status === 404) {
        helperDeleted = false;
      } else {
        throw err;
      }
    }

    const captureDir = path.join(CAPTURE_DIR, id);
    let localExisted = false;
    try {
      await fsp.access(captureDir);
      localExisted = true;
    } catch {}

    if (!helperDeleted && !localExisted) {
      throw fail("找不到这个任务。", { status: 404 });
    }

    if (!helperDeleted) {
      const local = localCapture || await loadCapture(id);
      if (!["ready", "imported", "failed", "cancelled"].includes(local.status))
        throw fail("本地记录仍待确认，不能删除。", { status: 409 });
      if (input.cleanup) {
        checkCleanup(local, input.cleanup);
      }
    }

    if (localExisted) {
      try{await moveToTrash(DATA_DIR,id,'action-jobs');}
      catch(error){if(helperDeleted)await helperRequest(`/api/trash/${id}/restore`,{method:'POST',body:{}}).catch(()=>{});throw error;}
    }

    const lastFile = path.join(DATA_DIR, "action-last.json");
    const last = await readJsonFile(lastFile, null);
    if (last && last.id === id) {
      const TRULY_ACTIVE = ["uploading", "queued", "attaching", "waiting_user", "generating", "downloading", "importing"];
      let nextActiveId = null;
      try {
        const { jobs: allJobs } = await helperRequest("/api/jobs");
        const remainingActive = (allJobs || []).filter(j => j.id !== id && TRULY_ACTIVE.includes(j.status));
        if (remainingActive.length > 0) {
          remainingActive.sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")));
          nextActiveId = remainingActive[0].id;
        }
      } catch {}

      if (nextActiveId) {
        await atomicJson(lastFile, { id: nextActiveId });
      } else {
        await fsp.rm(lastFile, { force: true });
      }
    }

    return { ok: true, removed: id,recoverable:true };
  });
}

async function setBrowser(input) {
  if(!browserRouting.choices.includes(input?.browser)) throw fail("不支持的浏览器。",{status:400});
  await atomicJson(path.join(DATA_DIR,"browser.json"),{browser:input.browser});
  return {ok:true,browser:input.browser};
}
async function setMode(input) {
  return withMutation(async () => {
    const targetMode = input && input.mode;
    if (targetMode !== "browser" && targetMode !== "local") {
      throw fail("目标模式无效，仅支持 browser 或 local。", { code: "invalid_mode", status: 400 });
    }

    let runtimeStatus = null;
    if (targetMode === "local") {
      runtimeStatus = await runtimeInstall.check(DATA_DIR, { force: true });
      if (!runtimeStatus.installed || runtimeStatus.checkState !== "ready") {
        const code = runtimeStatus.checkState === "missing" ? "runtime_missing" : "runtime_unconfirmed";
        const error = runtimeStatus.checkState === "missing"
          ? "未检测到完整本机环境，请先安装，或继续使用浏览器托管。"
          : "本机环境探测未通过（" + (runtimeStatus.reason || "probe_timeout") + "），暂无法切换为本机模式。";
        return { ok: false, code, error, runtime: runtimeStatus };
      }
    }

    let all = [];
    try {
      const res = await helperRequest("/api/jobs");
      all = (res && res.jobs) || [];
    } catch (err) {
      throw fail("任务状态未确认，暂无法切换模式。请确保 PS Flow 服务正常运行后再试。", { code: "tasks_status_unconfirmed", status: 503 });
    }
    const hasActiveTasks = all.some(job =>
      ["uploading", "queued", "attaching", "waiting_user", "generating", "downloading", "importing"].includes(job.status) ||
      (job.status === "unknown" && !job.waitingStopped)
    );
    if (hasActiveTasks) {
      throw fail("仍有任务等待处理，请先完成任务或停止等待后切换模式。", { code: "active_tasks_busy", status: 409 });
    }

    await atomicJson(path.join(DATA_DIR, "mode.json"), {
      mode: targetMode,
      configured: true,
      updatedAt: new Date().toISOString()
    });
    await atomicJson(path.join(DATA_DIR, "browser.json"), { browser: "quicker" });
    return { ok: true, mode: targetMode, restartRequired: true, runtime: runtimeStatus };
  });
}

async function openDistribute() {
  const distDir = path.resolve("E:/code/output/psflow-distribute");
  const target = fs.existsSync(distDir) ? distDir : DATA_DIR;
  require("node:child_process").spawn("explorer.exe", [target], { detached: true, stdio: "ignore" }).unref();
  return { ok: true, path: target };
}

// Read-only diagnostic snapshot for the panel's collapsible diagnostics block.
// Only /api/health and /api/jobs are read; no raw job, prompt, path or error
// text ever reaches the summary. The shared module whitelists every value, so a
// helper that misbehaves still cannot leak anything through these fields.
// Mirrors helper activeTaskCount(): a stopped ("waitingStopped") job is parked
// in "unknown" and must not be counted active, otherwise the summary would
// contradict health.activeTasks === 0.
const ACTIVE_STATUSES = ["uploading", "queued", "attaching", "waiting_user", "generating", "importing"];
const COMPLETED_STATUSES = ["ready", "imported"];
async function diagnosticSummary() {
  const { buildDiagnosticSummary, formatDiagnosticSummaryText } = require("../shared/diagnostic-summary.cjs");
  const started = Date.now();
  const version = require(HELPER_PACKAGE).version;
  const buildId = process.env.PSFB_BUILD_ID || "dev";
  const mode = runtimeMode();
  let errorCode = null, healthy = false, runtimeReady = false;
  let health = null, jobs = null;
  let helperProbeMs = null;

  // Health probe: identity mismatch and draining are distinct machine codes.
  const probeStart = Date.now();
  try {
    health = await helperRequest("/api/health");
    helperProbeMs = Date.now() - probeStart;
    if (health.app !== "PSFlowBridge") errorCode = "HELPER_IDENTITY_MISMATCH";
    else if (health.draining === true) errorCode = "HELPER_DRAINING";
    else healthy = health.ok === true;
  } catch (error) {
    helperProbeMs = Date.now() - probeStart;
    errorCode = error.code === "network" ? "HELPER_UNAVAILABLE" : "HELPER_PROBE_FAILED";
  }

  // Task statistics only; statuses are counted and the job bodies are dropped.
  const counts = { total: 0, completed: 0, failed: 0, active: 0 };
  if (healthy) {
    try {
      const listed = await helperRequest("/api/jobs");
      jobs = Array.isArray(listed && listed.jobs) ? listed.jobs : [];
      for (const item of jobs) {
        counts.total += 1;
        const status = item && item.status;
        if (COMPLETED_STATUSES.includes(status)) counts.completed += 1;
        else if (status === "failed") counts.failed += 1;
        // "unknown" only means work is still in flight when it is not a
        // deliberately stopped wait; cancelled jobs are terminal too.
        else if (ACTIVE_STATUSES.includes(status) || (status === "unknown" && item.waitingStopped !== true)) counts.active += 1;
      }
    } catch (error) {
      errorCode = errorCode || (error.code === "network" ? "JOBS_UNAVAILABLE" : "JOBS_PROBE_FAILED");
      healthy = false;
    }
  }

  // Runtime readiness is mode-specific and read from local state only.
  if (mode === "local") {
    try { runtimeReady = runtimeInstall.inspect(DATA_DIR).installed === true; }
    catch { runtimeReady = false; }
    if (!runtimeReady && !errorCode) errorCode = "RUNTIME_MISSING";
  } else {
    runtimeReady = healthy;
  }

  const totalMs = Date.now() - started;
  const probeDurations = { totalMs };
  if (Number.isFinite(helperProbeMs)) probeDurations.helperProbeMs = helperProbeMs;
  const summary = buildDiagnosticSummary({
    version, buildId, mode,
    taskCounts: counts,
    errorCode,
    probeDurations,
    healthy,
    runtimeReady,
    // dataHealth carries the frozen helper contract, but the shared module
    // reduces it to three numeric counts. Job ids, stages and codes are never
    // exported; the full safe schema stays on status/status-local for the UI.
    dataHealth: health?.dataHealth || null
  });
  return { ok: true, summary, text: formatDiagnosticSummaryText(summary) };
}

async function openResult(input) {
  return withMutation(async () => {
    const {capture,remote}=await currentJob(input.id,false);
    const item=(remote.images||[]).find(image=>image.index===input.index);
    if(!['ready','imported'].includes(remote.status)||!item||!input.sha256||item.sha256!==input.sha256||input.hdSha256!==(item.hd?.pasteSha256||'')) {
      throw fail('图片版本已变化，请重新选择结果。',{code:'selection_changed',status:409});
    }
    const hd=await downloadHdResult(capture,item,true);
    const bytes=hd?await fsp.readFile(capture.resultPath):await downloadResult(capture,item.index);
    const expected=hd?item.hd.pasteSha256:item.sha256;
    if(crypto.createHash('sha256').update(bytes).digest('hex')!==expected)throw fail('图片校验失败，未打开 Photoshop。');
    // Opening a result creates a separate document; it never rebinds the old capture.
    const result=await runPs({op:'open-result',imagePath:capture.resultPath});
    return {ok:true,documentID:result.documentID,documentName:result.documentName};
  });
}

// Export writes the verified result bytes to the user-chosen path. When the
// caller supplies `path`, that exact location is used (parent directory must
// exist and be writable); there is no silent fallback to a default folder so
// that a Save dialog that was cancelled or dismissed never produces a stray
// file in Documents. Without `path` the historic default behaviour applies:
// Save verified output beside its PSD, or to the user's chosen destination.
// Text generation asks once and remembers the chosen directory.
async function exportResult(input) {
  const id=String(input.id||'');if(!safeId(id))throw fail('任务编号无效。',{status:400});
  const {capture,remote}=await currentJob(id,false);
  const item=(remote.images||[]).find(image=>image.index===input.index);
  if(!['ready','imported'].includes(remote.status)||!item||!input.sha256||item.sha256!==input.sha256||input.hdSha256!==(item.hd?.pasteSha256||'')) {
    throw fail('图片版本已变化，请重新选择结果。',{code:'selection_changed',status:409});
  }
  const hd=await downloadHdResult(capture,item,true);
  const bytes=hd?await fsp.readFile(capture.resultPath):await downloadResult(capture,item.index);
  const expected=hd?item.hd.pasteSha256:item.sha256;
  if(crypto.createHash('sha256').update(bytes).digest('hex')!==expected)throw fail('图片校验失败，未导出文件。');

  return saveResult({
    bytes,capture,id,index:item.index,expectedHash:expected,
    dataDir:DATA_DIR,path:input.path,sharpInstance:await sharpRequire()
  });
}

async function refreshReference(input={}){
  const contextMode=contextSnapshot.contextMode(input.contextMode);
  const id=crypto.randomUUID(),dir=path.join(DATA_DIR,"reference-drafts",id);
  await fsp.mkdir(dir,{recursive:true});
  try{
    const capture=await runPs({op:"capture",requireSelection:true,includeContext:true,contextMode,contextImagePath:path.join(dir,"context.png"),
      imagePath:path.join(dir,"source.png"),maskPath:path.join(dir,"mask.png")});
    const context=await contextSnapshot.readContext(capture,await sharpRequire());
    if(contextMode==="full"&&!context)throw fail("全图参考未捕获，请重试。",{submissionSent:false});
    Object.assign(capture,{contextMode,hasGlobalContext:Boolean(context),contextSource:context?.metadata||null});
    const draft={...capture,id,createdAt:new Date().toISOString()};
    await atomicJson(path.join(dir,"draft.json"),draft);
    const preview=await (await sharpRequire())(capture.imagePath).resize(768,768,{fit:"inside",withoutEnlargement:true}).png().toBuffer();
    return {ok:true,referenceDraft:{id,width:capture.source.width,height:capture.source.height,bounds:capture.bounds,
      maskPath:capture.maskPath,documentID:capture.documentID,documentName:capture.documentName,createdAt:draft.createdAt,
      contextMode,hasGlobalContext:capture.hasGlobalContext,contextSource:capture.contextSource},
      dataUrl:"data:image/png;base64,"+preview.toString("base64")};
  }catch(error){await fsp.rm(dir,{recursive:true,force:true});throw fail(psMessage(error.message),{submissionSent:false});}
}
async function dispatch(input) {
  if(input?.op==="check-app-update")return checkAppUpdate();
  if(input?.op==="refresh-reference")return refreshReference(input);
  if(input?.op==='native-preview'||input?.op==='cancel-native-preview'){
    return {ok:false,code:'feature_removed',error:'PS 原生精确预览功能已移除，请直接回贴到文档。'};
  }
  if(input?.op==='open-result')return openResult(input);
  if(input?.op==='runtime-check') {
    const started = Date.now();
    const res = await runtimeInstall.check(DATA_DIR, { force: Boolean(input?.force), timeoutMs: input?.timeoutMs });
    return { ...res, effectiveMode: runtimeMode(), commandMs: Date.now() - started };
  }
  if(input?.op==='open-installer')return runtimeInstall.openDownload(DATA_DIR);
  if(input?.op==='export-result')return exportResult(input);
  if(input?.op==='diagnostic-summary')return diagnosticSummary();
  const handlers = { status, "status-local":statusLocal,"photoshop-status":photoshopStatus,connection,resume,recover, generate, regenerate, job, select, paste,"paste-batch":pasteBatch, login, "force-stop":forceStop, "end-wait": endWait, "flow-window": flowWindow, "flow-visible": flowVisible, history,favorite,trash,"restore-job":restoreJob, "delete-job": deleteJob, deleteJob, "set-browser":setBrowser, "set-mode": setMode, "open-distribute": openDistribute, "capture-source": captureSource };
  const handler = handlers[input && input.op];
  if (!handler) throw fail("不支持的操作。", { status: 400 });
  const started = Date.now();
  const value = await handler(input);
  return {...value, commandMs:Date.now() - started};
}
module.exports = { dispatch, close:() => { verifiedMetaCache.clear(); psWorker.close(); }, publicJob, isBusy:() => Boolean(actionMutation), runtimeMode, isModeConfigured, normalizeMode };
if (require.main === module) {
  (async () => {
    let input;
    try { input = JSON.parse(fs.readFileSync(0, "utf8")); }
    catch { throw fail("请求不是有效 JSON。", { status: 400 }); }
    return dispatch({...input,preview:input.preview !== false});
  })().then(value => {
    process.stdout.write(JSON.stringify(value));
  }).catch(error => {
    process.stdout.write(JSON.stringify({ ok: false, error: error.message, code: error.code || undefined, field:error.field, submissionSent:error.submissionSent, job:error.job || undefined, uncertain:error.uncertain || undefined }));
    process.exitCode = 1;
  }).finally(() => psWorker.close());
}
