/* Invoked only by the Quicker CoreWebView2 controller, never an extension. */
async function psfbManaged(action, arg={}) {
  const visible=n=>!!n&&n.getClientRects().length>0;
  const buttons=()=>[...document.querySelectorAll('button')].filter(visible);
  const label=n=>{const c=n.cloneNode(true);c.querySelectorAll('mat-icon,flow-material-icon,svg,[aria-hidden=true]').forEach(i=>i.remove());return c.textContent.replace(/\s+/g,' ').trim();};
  const editor=()=>[...document.querySelectorAll('.ProseMirror')].find(visible);
  const key=url=>url.split('?')[0].replace(/=s\d+.*$/,'');
  const settings=()=>{
    const trigger=[...document.querySelectorAll('.settings-trigger-button')].find(visible)||document.querySelector('.settings-trigger-button');
    const t=(trigger?.textContent||'').replace(/\s+/g,' ').trim();
    const m=t.match(/(?:Nano\s*Banana|Imagen|Veo)(?:\s+(?:Pro|Fast|Ultra|Quality|\d+(?:\.\d+)*))*/i);
    const ratios={'crop_16_9':'16:9','crop_9_16':'9:16','crop_4_3':'4:3','crop_3_4':'3:4','crop_landscape':'4:3','crop_portrait':'3:4','crop_square':'1:1'};
    // Read checked controls while open; the closed summary uses semantic icons.
    const selected=buttons().filter(n=>n.getAttribute('aria-checked')==='true'||n.getAttribute('aria-pressed')==='true'||n.getAttribute('aria-selected')==='true');
    const ratio=selected.map(label).find(v=>/^(?:16:9|9:16|4:3|3:4|1:1)$/.test(v));
    const icon=Object.keys(ratios).find(v=>t.includes(v));
    const count=selected.map(label).map(v=>v.match(/^[x×]\s*([1-4])$/i)).find(Boolean)||t.match(/[x×]\s*([1-4])(?=\D|$)/i);
    return {model:m?.[0]||'',aspect:ratio||(icon?ratios[icon]:''),count:count?+count[1]:0};
  };
  // Flow also files every uploaded reference in the media library as an ordinary
  // grid tile. Once the upload settles that tile carries the same asset URL as
  // the composer chip, and it appears after the submit baseline was taken, so it
  // looks exactly like a fresh generated result. `closest()` only removes the
  // chip copy, never the library copy. Callers therefore pass the reference
  // identities they know about and those URLs are never counted as outputs.
  const outputImages=references=>{
    const keys=(references&&references.keys)||[],ids=(references&&references.ids)||[];
    // Every reference this bridge uploads is named `ps-flow-<kind>-<job8>...`.
    // Flow copies that filename into the media-library tile's aria-label, which
    // survives even when the batch card is virtualized away and the receipt
    // predates the recorded identities. Generated tiles are labelled with the
    // prompt, so this can never hide a real result.
    // The label rule is scoped to result identification (callers that pass the
    // job's reference identities). HD download asks for one explicit asset and
    // must still be able to select an uploaded reference tile.
    const uploadLabel=/^ps-flow-(?:base|ref|source|extra)-[0-9a-f]{8}(?:-|\.|$)/i;
    const isUploadTile=n=>!!references&&uploadLabel.test(String(n.closest('flow-grid-tile-container')?.getAttribute('aria-label')||n.getAttribute('alt')||'').trim());
    const isReference=src=>{
      if(keys.includes(key(src)))return true;
      if(!ids.length)return false;
      try{const path=new URL(src,location.href).pathname;return ids.some(id=>path.includes(id));}catch(_){return false;}
    };
    return [...new Map([...document.querySelectorAll('flow-grid-tile-container img,img')].filter(n=>
      (n.src.startsWith('https://flow-content.google/image/')||n.src.startsWith('https://flow.google.com/asb/'))&&
      !n.closest('.base-prompt-box,flow-ingredient-chip,flow-image-ingredient-chip')&&
      !isReference(n.src)&&!isUploadTile(n)
    ).map(n=>[key(n.src),n])).values()];
  };
  // Reference identities are collected from the composer chips themselves and
  // from the job record. A chip's thumbnail can land after the submit baseline
  // (Flow finishes the upload asynchronously), so the baseline alone cannot be
  // trusted to cover it; and the chip can be gone later while its media-library
  // copy stays, so the recorded identities must survive on their own.
  const referenceImageKeys=()=>{
    const keys=[];
    for(const chip of referenceChips()){
      const owner=chip.closest('flow-image-ingredient-chip,flow-ingredient-chip')||chip;
      for(const node of [chip,owner])for(const img of node.querySelectorAll('img')){
        const value=key(img.currentSrc||img.getAttribute('src')||'');
        if(value&&!keys.includes(value))keys.push(value);
      }
    }
    return keys;
  };
  const referenceAssetIds=()=>{
    const ids=[];
    const add=value=>{
      // Only real asset ids are worth matching inside a URL; short layout ids
      // would risk hiding a genuine result.
      const match=String(value||'').match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
      if(match&&!ids.includes(match[0]))ids.push(match[0]);
    };
    for(const chip of referenceChips()){
      const owner=chip.closest('flow-image-ingredient-chip,flow-ingredient-chip')||chip;
      for(const node of [chip,owner]){
        add(node.getAttribute('data-media-id'));
        add(node.getAttribute('data-asset-id'));
        // Flow's library tile can carry a different size suffix than the chip
        // thumbnail; the asset UUID in the URL survives that difference.
        for(const img of node.querySelectorAll('img'))add(img.currentSrc||img.getAttribute('src'));
      }
    }
    return ids;
  };
  // Once a batch finishes Flow clears the composer and moves its references
  // into the batch-info card. There the chip's overlay is `add` (a media
  // picker), not `cancel`, so the composer rules must not be applied to it -
  // and nothing here is ever clicked. These are still inputs: each asset is
  // also filed in the media library, whose tile would otherwise be counted as
  // a fresh result. The card can list references from earlier batches too;
  // every one of them is an input, so all of their identities are excluded.
  const batchReferenceIdentities=()=>{
    const keys=[],ids=[];
    const addId=value=>{
      const match=String(value||'').match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
      if(match&&!ids.includes(match[0]))ids.push(match[0]);
    };
    // Read the ingredient area only. The same card may show generated
    // thumbnails elsewhere, and those are outputs, not inputs.
    for(const root of document.querySelectorAll('flow-batch-info')){
      for(const node of root.querySelectorAll('flow-ingredient-chip,flow-image-ingredient-chip,button.chip-container')){
        if(node.closest('flow-grid-tile-container'))continue;
        addId(node.getAttribute('data-media-id'));
        addId(node.getAttribute('data-asset-id'));
      }
      for(const img of root.querySelectorAll('.ingredients-list img,flow-ingredient-chip img,flow-image-ingredient-chip img')){
        if(img.closest('flow-grid-tile-container'))continue;
        const src=img.currentSrc||img.getAttribute('src')||'';
        if(!(src.startsWith('https://flow-content.google/image/')||src.startsWith('https://flow.google.com/asb/')))continue;
        const value=key(src);
        if(value&&!keys.includes(value))keys.push(value);
        addId(src);
      }
    }
    return {keys,ids};
  };
  // Identity-only union: the composer chips and the batch-info card. The
  // composer is used for clearing/counting through referenceChips(), but that
  // cancel-overlay rule cannot see the post-submit batch card.
  const observedReferences=()=>{
    const keys=referenceImageKeys(),ids=referenceAssetIds();
    const batch=batchReferenceIdentities();
    for(const v of batch.keys)if(!keys.includes(v))keys.push(v);
    for(const v of batch.ids)if(!ids.includes(v))ids.push(v);
    return {keys,ids};
  };
  // Merge, in order: the identities recorded for this job (live context first,
  // then its submit receipt after a reload) and the live composer chips. Older
  // receipts predate the recorded fields, which is exactly why the live chips
  // are always consulted as well. A live context for a different job means the
  // composer now belongs to that job, so its chips must not leak into this one.
  const jobReferences=id=>{
    const keys=[],ids=[];
    const add=(k,i)=>{
      for(const v of k||[])if(v&&!keys.includes(v))keys.push(v);
      for(const v of i||[])if(v&&!ids.includes(v))ids.push(v);
    };
    const s=window.__psfbManaged;
    const live=s&&s.id===id?s:null;
    let saved=null;
    if(id){
      try{
        const receipt=JSON.parse(localStorage.getItem('psfb-managed-submit:'+id)||'null');
        if(receipt&&typeof receipt==='object')saved=receipt;
      }catch(_){}
    }
    if(live)add(live.refKeys,live.refIds);
    if(saved)add(saved.refKeys,saved.refIds);
    // `arm()` can snapshot a chip whose upload has not settled yet, so its asset
    // id may only appear later. Record whatever the chips reveal on the next
    // observation, otherwise a chip removed after that would take the identity
    // with it. The composer is only consulted when it belongs to this job. Only
    // an existing receipt is updated - a job that never armed must not gain one
    // from a read-only query.
    if(!s||live){
      const observed=observedReferences(),chipKeys=observed.keys,chipIds=observed.ids;
      add(chipKeys,chipIds);
      if(live){
        const liveKeys=Array.isArray(live.refKeys)?live.refKeys:[],liveIds=Array.isArray(live.refIds)?live.refIds:[];
        if(chipKeys.some(v=>!liveKeys.includes(v))||chipIds.some(v=>!liveIds.includes(v))){
          live.refKeys=[...liveKeys,...chipKeys.filter(v=>!liveKeys.includes(v))];
          live.refIds=[...liveIds,...chipIds.filter(v=>!liveIds.includes(v))];
        }
      }
      if(saved&&(chipKeys.some(v=>!(saved.refKeys||[]).includes(v))||chipIds.some(v=>!(saved.refIds||[]).includes(v)))){
        saved.refKeys=[...(Array.isArray(saved.refKeys)?saved.refKeys:[]),...chipKeys.filter(v=>!(saved.refKeys||[]).includes(v))];
        saved.refIds=[...(Array.isArray(saved.refIds)?saved.refIds:[]),...chipIds.filter(v=>!(saved.refIds||[]).includes(v))];
        try{localStorage.setItem('psfb-managed-submit:'+id,JSON.stringify(saved));}catch(_){}
      }
    }
    return {keys,ids};
  };
  // Flow keeps a failed generation in the grid as a persistent error tile
  // ("失败 / 此生成内容可能违反了我们的政策 / 本次生成不计费"). That is a confirmed
  // terminal state: the request was accepted, no image was produced, and for a
  // policy block Flow states nothing was billed. Tiles survive across jobs, so
  // only tiles that appeared after this job armed count as this job's own
  // failures; the arm-time snapshot is compared as a multiset.
  // Strip icon glyphs first: Flow renders the tile's action buttons as Material
  // icon ligatures (`refresh`, `undo`, `delete_forever`), and textContent glues
  // them onto the readable message ("...不计费。refreshundodelete_forever").
  // A cloned node keeps the baseline/sort comparison stable without mutating
  // the live page.
  const ERROR_BANNER_RE=/错误|失败|配额|额度|上限|超限|无法|异常|稍后再试|拒绝|违规|不计费|quota|limit|exceeded|error|failed|unavailable|try again|not (?:be )?charged|no charge/i;
  const stripIcons=n=>{const c=n.cloneNode(true);c.querySelectorAll('mat-icon,flow-material-icon,svg,[aria-hidden=true],.material-icons,.material-symbols-outlined,button').forEach(i=>i.remove());return String(c.textContent||'').replace(/\s+/g,' ').trim().slice(0,160);};
  const failureTiles=()=>{
    const tiles=[...document.querySelectorAll('.error-tile')].filter(visible).map(stripIcons).filter(Boolean);
    const banners=[...document.querySelectorAll('mat-snack-bar-container,.mat-mdc-snack-bar-container,.mat-mdc-snack-bar-label,[role="alert"],.cdk-overlay-container [role="status"]')].filter(visible)
      .map(stripIcons).filter(t=>t&&ERROR_BANNER_RE.test(t));
    return [...tiles,...new Set(banners)].sort();
  };
  const freshFailures=baseline=>{
    const remaining=(Array.isArray(baseline)?baseline.slice().sort():[]),fresh=[];
    for(const text of failureTiles()){const at=remaining.indexOf(text);if(at>=0)remaining.splice(at,1);else fresh.push(text);}
    return fresh;
  };
  // Only claim "safe to retry" when Flow itself says the attempt was not billed;
  // any other error tile is reported as a failure the user must verify in Flow.
  const failureCodeFor=text=>/不计费|not (?:be )?charged|no charge|won.t be charged/i.test(text||'')?'policy_rejected':'generation_failed';
  const closeMenu=()=>{document.querySelector('.cdk-overlay-backdrop')?.click();for(let i=0;i<2;i++)document.body.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',keyCode:27,bubbles:true}));};
  // Flow renders two different `button.chip-container` nodes in the composer:
  // the attached reference image (its overlay icon is the `cancel` ligature)
  // and the "add media" button (overlay icon `add`). Matching the overlay by
  // class alone clicked both, so clearing opened the media picker and could
  // leave another chip behind - attach() then aborted on every run. Match the
  // reference chip by its own overlay icon instead, and never click `add`.
  // A wrapper is only a chip when it has no inner button and no chip ancestor:
  // Flow nests `flow-image-ingredient-chip > button.chip-container`, and
  // counting both would double the same reference.
  const referenceChips=()=>{
    const composer=editor()?.closest('flow-base-prompt-box,flow-prompt-box,.base-prompt-box')||document.querySelector('.base-prompt-box');
    if(!composer)return [];
    const overlay=n=>n.querySelector('.hover-icon-overlay mat-icon,.hover-icon-overlay .material-symbols-outlined');
    const isReference=n=>String(overlay(n)?.textContent||'').trim()==='cancel';
    const standalone=w=>!w.querySelector('button.chip-container')&&
      !w.parentElement?.closest('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip');
    // One DOM-ordered pass keeps wrapper/button de-duplication and the visual
    // order Flow shows, which is what the reuse comparison depends on.
    return [...composer.querySelectorAll('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip')]
      .filter(n=>visible(n)&&(n.matches('button.chip-container')||standalone(n)))
      .filter(isReference);
  };
  // Never cache a data: URL: it carries the image itself. http(s) identities
  // drop the display-size suffix and query so a re-rendered thumbnail of the
  // same asset still compares equal; blob: URLs stay whole (they hold no bytes).
  const imageIdentity=value=>{
    if(!value)return '';
    try{
      const u=new URL(value,location.href);
      if(u.protocol==='http:'||u.protocol==='https:')return u.origin+u.pathname.replace(/=[^/]*$/,'');
      if(u.protocol==='blob:')return u.href;
    }catch(_){}
    return '';
  };
  const chipSignature=n=>{
    const owner=n.closest('flow-image-ingredient-chip,flow-ingredient-chip')||n;
    const id=owner.getAttribute('data-media-id')||owner.getAttribute('data-asset-id')||n.getAttribute('data-media-id')||n.getAttribute('data-asset-id');
    if(id)return 'asset:'+id;
    const images=[...n.querySelectorAll('img')].map(i=>imageIdentity(i.currentSrc||i.getAttribute('src'))).filter(Boolean);
    return images.length?'images:'+images.join('|'):'';
  };
  // Flow marks an uploading reference on the ingredient wrapper, while the
  // clickable node is the inner button. Readiness therefore covers both, or a
  // busy wrapper would look settled and arm() could submit too early.
  const chipReady=n=>{
    const owner=n.closest('flow-image-ingredient-chip,flow-ingredient-chip')||n;
    return [n,owner].every(node=>node.getAttribute('aria-busy')!=='true'&&
      !node.querySelector('[aria-busy=true],mat-progress-spinner,[role=progressbar]')&&
      !/uploading|loading/i.test(String(node.className||'')));
  };
  const referenceState=()=>{
    const chips=referenceChips().map(n=>({signature:chipSignature(n),ready:chipReady(n)}));
    return {count:chips.length,ready:chips.length>0&&chips.every(chip=>chip.ready),chips};
  };
  // Scope invalidates the cache on a reload (timeOrigin) and on any project or
  // route change (path). It holds no image bytes, only digests and identities.
  const referenceScope=()=>location.origin+location.pathname+'|'+String(performance.timeOrigin||'');
  const referenceWaitMs=()=>{
    const value=Number(window.__psfbReferenceWaitMs);
    return Number.isFinite(value)&&value>=0?Math.min(45000,value):45000;
  };
  const waitReferenceState=async predicate=>{
    const deadline=Date.now()+referenceWaitMs();
    let v=referenceState();
    while(!predicate(v)&&Date.now()<deadline){
      await new Promise(r=>setTimeout(r,150));
      v=referenceState();
    }
    return v;
  };
  const referenceDigests=async payloads=>{
    if(!(window.crypto&&crypto.subtle&&crypto.subtle.digest))return null;
    try{
      const out=[];
      for(const bytes of payloads){
        const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));
        out.push([...hash].map(b=>b.toString(16).padStart(2,'0')).join(''));
      }
      return out;
    }catch(_){return null;}
  };
  const clearReferenceChips=async()=>{
    for(let round=0;round<3;round++){
      const chips=referenceChips();
      if(!chips.length)break;
      for(const chip of chips)(chip.querySelector('.hover-icon-overlay')||chip).click();
      await new Promise(r=>setTimeout(r,120));
    }
  };
  if(action==='hdOpenProject'){
    if(!/^[0-9a-f-]{36}$/i.test(arg.project||''))throw Error('Flow 项目编号无效。');
    location.assign('https://flow.google.com/project/'+arg.project);return {opening:true};
  }
  if(action==='hdCapabilities'||action==='hdDownload'){
    const image=outputImages().find(n=>key(n.src)===arg.assetKey);
    if(!image)throw Error('当前 Flow 项目中找不到所选原图，请打开对应项目后重试。');
    const tile=image.closest('flow-grid-tile-container');
    const menu=tile&&[...tile.querySelectorAll('button')].find(n=>/^(更多选项|More options)$/i.test(n.getAttribute('aria-label')||n.title||''));
    if(!menu)throw Error('未找到所选图片的下载菜单。');
    closeMenu();await new Promise(r=>setTimeout(r,100));menu.click();await new Promise(r=>setTimeout(r,180));
    const download=[...document.querySelectorAll('[role=menuitem]')].find(n=>/下载|Download/i.test(label(n)));
    if(!download){closeMenu();throw Error('该图片当前不支持下载。');}
    download.click();await new Promise(r=>setTimeout(r,180));
    const choices=[...document.querySelectorAll('[role=menuitem]')].map(n=>({node:n,label:label(n)})).filter(v=>/^[124]K\b/i.test(v.label));
    const allowed=v=>!v.node.disabled&&v.node.getAttribute('aria-disabled')!=='true'&&!v.node.classList.contains('mat-mdc-menu-item-disabled')&&!/升级|Upgrade|Unlock|解锁/i.test(v.label);
    const resolutions=choices.filter(allowed).map(v=>v.label.match(/^[124]K/i)[0].toUpperCase());
    if(action==='hdCapabilities'){closeMenu();return {resolutions};}
    const selected=choices.find(v=>v.label.toUpperCase().startsWith(arg.resolution+'\n')||v.label.toUpperCase().startsWith(arg.resolution+' ')||v.label.toUpperCase()===arg.resolution);
    if(!selected||!allowed(selected)){closeMenu();throw Error('当前账号未开放该清晰度，请重新查询权限。');}
    selected.node.click();return {requested:true,resolution:arg.resolution};
  }
  // --- Virtualised-grid self-healing -----------------------------------------
  // Flow renders the batch grid in a virtualised list, so only the cards inside
  // or near the viewport are mounted. Once the user has scrolled away, or the
  // progress bar vanished between two polls, this client can read no output at
  // all while the finished batch already sits at the top of the list - the panel
  // then waits on "等待 Flow 确认" forever. The helpers below re-scroll the list
  // so the newest batch is mounted and read again. They only ever write
  // `scrollTop`: never a click, an upload or a submit.
  const scrollFlowToTop=()=>{
    const reset=node=>{
      try{if(node&&node.scrollTop!==0)node.scrollTop=0;}catch(_){}
    };
    const scrollers=new Set();
    for(const selector of ['[data-testid="virtuoso-scroller"]','[data-testid="virtuoso-item-list"]','[data-virtuoso-scroller="true"]']){
      for(const node of document.querySelectorAll(selector)){
        scrollers.add(node);
        // The scrolling viewport is usually an ancestor of the item list, so walk
        // a bounded number of parents as well.
        let parent=node.parentElement;
        for(let depth=0;parent&&depth<6;parent=parent.parentElement,depth++)scrollers.add(parent);
      }
    }
    // Anything else that scrolls and holds result cards is a candidate too.
    for(const node of document.querySelectorAll('div,main,section,aside')){
      try{if(node.clientHeight>0&&node.scrollHeight>node.clientHeight+40&&node.querySelector('flow-grid-tile-container,img'))scrollers.add(node);}catch(_){}
    }
    for(const node of scrollers)if(node instanceof Element)reset(node);
    reset(document.documentElement);reset(document.body);reset(window);
    return scrollers.size;
  };
  const ARMED_SETTLE_MS=6000,HEAL_DEBOUNCE_MS=2000;
  // The settle window starts when the job armed. The live context carries that
  // timestamp and the one-shot receipt repeats it, so the window still applies
  // after a page or panel reload that cleared the context.
  const armedAtFor=(s,id)=>{
    const live=s&&s.id===id?Number(s.armedAt):0;
    if(Number.isFinite(live)&&live>0)return live;
    if(!id)return 0;
    try{
      const saved=JSON.parse(localStorage.getItem('psfb-managed-submit:'+id)||'null');
      const at=Number(saved&&saved.at);
      return Number.isFinite(at)&&at>0?at:0;
    }catch(_){return 0;}
  };
  const armedElapsed=id=>{
    const at=armedAtFor(window.__psfbManaged,id);
    return at>0?Date.now()-at:0;
  };
  // The declared batch size: the live context first, then its receipt. 0 means
  // "unknown" - it never confirms a job, it only decides whether to re-scroll.
  const declaredCountFor=(id,s)=>{
    const live=Number(s&&s.id===id?s.count:0);
    if(Number.isInteger(live)&&live>=1&&live<=4)return live;
    if(!id)return 0;
    try{
      const saved=JSON.parse(localStorage.getItem('psfb-managed-submit:'+id)||'null');
      const savedCount=Number(saved&&saved.count);
      return Number.isInteger(savedCount)&&savedCount>=1&&savedCount<=4?savedCount:0;
    }catch(_){return 0;}
  };
  const progressBars=()=>[...document.querySelectorAll('[role=progressbar],[class*=loading_percentage],[class*=loading-percentage]')].filter(visible);
  // Heal only when this job really armed, the settle window has passed, the
  // declared batch is still incomplete and nothing is visibly loading: a batch
  // that is still generating shows its progress bar and must be left alone. The
  // debounce keeps a fast poll loop from fighting the user's own scrolling.
  const healFlowViewport=(id,expected,got,loading)=>{
    if(!id||loading)return false;
    const size=Math.max(1,Number(expected)||0);
    if(Number(got)>=size)return false;
    if(armedElapsed(id)<ARMED_SETTLE_MS)return false;
    const last=window.__psfbManagedHeal;
    if(last&&last.id===id&&Date.now()-last.at<HEAL_DEBOUNCE_MS)return false;
    window.__psfbManagedHeal={id,at:Date.now(),count:size,outputs:Number(got)||0};
    scrollFlowToTop();
    return true;
  };
  // A virtualised list mounts the remounted cards on a later frame.
  const healSettle=()=>new Promise(r=>setTimeout(r,220));
  // The newest batch is the topmost group of generated cards. Ranking uses the
  // live layout, so a list that reorders its DOM still yields the batch the user
  // sees at the top. An image owned by a button, a role=button or an editable
  // node is a composer/chip copy and is never a result; uploaded references stay
  // excluded by the identity and filename rules inside outputImages().
  const topBatchUrls=(id,count)=>{
    const size=Number(count)||0;
    if(size<1)return null;
    const nodes=outputImages(jobReferences(id)).filter(n=>!n.closest('button, [role="button"], [contenteditable="true"]'));
    if(nodes.length<size)return null;
    const ranked=nodes.map(node=>{
      const tile=node.closest('flow-grid-tile-container')||node;
      const box=tile.getBoundingClientRect();
      return {node,top:box.top,left:box.left};
    });
    ranked.sort((a,b)=>a.top-b.top||a.left-b.left);
    return ranked.slice(0,size).map(v=>v.node.src);
  };
  const receiptFor=id=>{
    if(!id)return null;
    try{
      const saved=JSON.parse(localStorage.getItem('psfb-managed-submit:'+id)||'null');
      return saved&&typeof saved==='object'?saved:null;
    }catch(_){return null;}
  };
  const liveProject=()=>(location.pathname.match(/^\/project\/([0-9a-f-]{36})$/)||[])[1]||'';
  // The page only heals the grid it is actually showing: a probe that runs while
  // the user browses another project (HD download and friends) must not move that
  // page. Without a known job project the check stays permissive, exactly like
  // the read-only ops above.
  const projectAllowsHeal=(s,id)=>{
    const here=liveProject(),theirs=(s&&s.id===id?s.project:'')||(receiptFor(id)||{}).project||'';
    return !(here&&theirs)||here===theirs;
  };
  // One self-heal attempt for a known job, then wait for the virtualised list to
  // mount the remounted cards. Returns whether the grid was re-scrolled, so the
  // caller re-reads the page afterwards instead of trusting the first look.
  // `look` (when given) is the caller's own measurement of this job's grid, which
  // is authoritative when the live context belongs to a different job.
  const jobBaselineFor=(s,id)=>s&&s.id===id&&Array.isArray(s.baseline)?s.baseline:(Array.isArray((receiptFor(id)||{}).baseline)?receiptFor(id).baseline:null);
  const healWhenIdle=async id=>{
    if(!id)return false;
    const s=window.__psfbManaged;
    if(!projectAllowsHeal(s,id))return false;
    // Measured from the page with the same live-then-receipt baseline the read
    // paths use, so the decision matches what the caller is about to report.
    if(!healFlowViewport(id,declaredCountFor(id,s),freshUrls(id,jobBaselineFor(s,id)).length,progressBars().length))return false;
    await healSettle();
    return true;
  };
  // The images this job produced, in page order. Shared by the read paths so the
  // baseline/identity rules are applied in exactly one place.
  const freshUrls=(id,baseline)=>baseline?outputImages(jobReferences(id)).filter(n=>!baseline.includes(key(n.src))).map(n=>n.src):[];
  // Fetch one result so the recovery paths below share a single contract.
  const readOne=async(url,project)=>{
    const r=await fetch(url);if(!r.ok)throw Error('图片读取失败 '+r.status);
    const blob=await r.blob();if(!blob.type.startsWith('image/')||!blob.size||blob.size>64*1024*1024)throw Error('图片类型或大小无效');
    const data=await new Promise((resolve,reject)=>{const f=new FileReader();f.onload=()=>resolve(f.result);f.onerror=reject;f.readAsDataURL(blob);});
    return {base64:data.slice(data.indexOf(',')+1),mime:blob.type,assetKey:key(url),project};
  };
  const state=()=>{
    const s=window.__psfbManaged;
    const images=outputImages(s&&s.id?jobReferences(s.id):null);
    const refs=referenceState();
    const outputs=[...new Map(images.filter(n=>s&&!s.baseline.includes(key(n.src))).map(n=>[new URL(n.src).pathname,n.src])).values()];
    const progress=[...document.querySelectorAll('[role=progressbar],[class*=loading_percentage],[class*=loading-percentage]')].filter(visible).map(n=>Number((n.textContent.match(/(\d+(?:\.\d+)?)\s*%/)||[])[1])).filter(Number.isFinite);
    return {...settings(),project:(location.pathname.match(/^\/project\/([0-9a-f-]{36})$/)||[])[1]||'',editorFound:!!editor(),editorLength:editor()?.textContent.length||0,
      references:refs.count,referencesReady:refs.ready,
      jobID:s?.id||null,kind:s?.kind||null,requests:s?.requests||0,submitAttempts:s?.submitAttempts||0,submitLocked:!!document.querySelector('.generate-icon-button[type=submit]')?.disabled,
      responses:s?.responses.map(r=>({status:r.status,error:r.error||null}))||[],outputs:outputs.length,percent:progress.length?Math.round(progress.reduce((a,b)=>a+b,0)/progress.length):null,
      // Fresh failed tiles for this job (baseline excludes older jobs' tiles).
      failures:s?freshFailures(s.failureBaseline).length:0,
      failureText:s?(freshFailures(s.failureBaseline)[0]||''):'',
      failureCode:s&&freshFailures(s.failureBaseline).length?failureCodeFor(freshFailures(s.failureBaseline)[0]):''};
  };
  if(action==='probe'){
    let current=state();
    // The panel polls this op while it waits for Flow to confirm. A finished batch
    // whose virtualised list scrolled out of the viewport reads as "no output",
    // so re-scroll and report the remounted cards in the same call: one poll is
    // then enough to leave "等待 Flow 确认" instead of waiting for a manual scroll.
    if(await healWhenIdle(current.jobID))current=state();
    return current;
  }
  if(action==='enterProject'){
    if(state().project)return state();
    if(location.origin!=='https://flow.google.com'||location.pathname!=='/')return state();
    const a=document.querySelector('a[href^="/project/"]');
    if(a){a.click();return {opening:true};}
    const b=buttons().find(n=>n.textContent.includes('新建项目'));if(b)b.click();
    return {opening:!!b};
  }
  if(action==='attach'){
    if(!state().project||!editor())throw Error('请先在内置 Flow 打开图像项目，未提交生成。');
    const isText=arg.kind==='text2image';
    // Check the one-shot receipt before touching the page. A job that already
    // armed must fail here, not after clearAssets() has wiped whatever the user
    // currently has in the Flow composer.
    if(localStorage.getItem('psfb-managed-submit:'+arg.id))throw Error('PSFB_ALREADY_SUBMITTED');
    const hasExtra=isText?false:Boolean(arg.extraBase64);
    // The local base alone defines output geometry; the global view only informs it.
    const references=[...(isText?[]:[{base64:arg.base64}]),...(!isText&&arg.contextBase64?[{base64:arg.contextBase64}]:[]),...(hasExtra?[{base64:arg.extraBase64}]:[]),...(arg.references||[])];
    // Refuse an oversized or malformed set before any DOM operation: the user's
    // existing references must survive a rejected job untouched.
    if(references.length>4||references.some(item=>!item||typeof item.base64!=='string'||!item.base64))throw Error('参考图数量或数据无效，未提交生成。');
    const payloads=references.map(item=>Uint8Array.from(atob(item.base64),c=>c.charCodeAt(0)));
    const s=window.__psfbManaged={id:arg.id,project:state().project,kind:isText?'text2image':'image2image',requests:0,responses:[],baseline:[],failureBaseline:failureTiles(),count:arg.count,prompt:arg.prompt,hasExtraImage:hasExtra,expectedRefs:references.length};
    // configure() rewrites the prompt after this; dropping the previous text
    // here keeps a stale prompt from being submitted with the new references.
    const ed=editor();ed.focus();
    const sel=window.getSelection(),range=document.createRange();
    range.selectNodeContents(ed);sel.removeAllRanges();sel.addRange(range);
    document.execCommand('delete');
    if(ed.textContent.trim()){
      range.selectNodeContents(ed);sel.removeAllRanges();sel.addRange(range);
      document.execCommand('insertText',false,'');
    }
    if(!references.length){
      // Pure text generation: the composer must end with zero chips.
      await clearReferenceChips();
      const empty=await waitReferenceState(v=>v.count===0);
      if(empty.count)throw Error('Flow 提示框残留参考图无法清空，未覆盖、未提交生成。');
      window.__psfbManagedRefs=null;
      return {attached:true,jobID:s.id,kind:'text2image',references:0,reused:false};
    }
    if(localStorage.getItem('psfb-managed-submit:'+arg.id))throw Error('PSFB_ALREADY_SUBMITTED');
    const scope=referenceScope(),digests=await referenceDigests(payloads),cached=window.__psfbManagedRefs;
    const live=referenceState();
    const sameIdentity=(state,chips)=>state.count===references.length&&
      state.chips.every((chip,index)=>!!chip.signature&&chip.signature===chips[index]);
    // Reuse requires all four: same page scope, same byte sequence, the same
    // live chip identities in the same order, and every chip ready. The live
    // DOM is authoritative - the cache only says what to compare against.
    const reusable=!!(cached&&digests&&cached.scope===scope&&
      cached.digests.length===digests.length&&cached.digests.every((d,index)=>d===digests[index])&&
      sameIdentity(live,cached.chips));
    if(reusable){
      // A chip can still be uploading. Wait for it instead of clearing and
      // pasting the same bytes again; a timeout fails without touching the page.
      const settled=live.ready?live:await waitReferenceState(v=>v.ready&&sameIdentity(v,cached.chips));
      if(!sameIdentity(settled,cached.chips))throw Error('Flow 参考素材已变化，未上传、未提交生成。');
      if(!settled.ready)throw Error('Flow 参考素材尚未就绪，未上传、未提交生成。');
      s.refKeys=referenceImageKeys();s.refIds=referenceAssetIds();
      return {attached:true,jobID:s.id,references:settled.count,reused:true};
    }
    // Content, order, count, page or project changed (or Flow dropped the
    // chips): resynchronise from scratch and never reuse a stale cache.
    window.__psfbManagedRefs=null;
    await clearReferenceChips();
    const cleared=await waitReferenceState(v=>v.count===0);
    // Fail loudly instead of pasting a second reference on top of one Flow
    // refused to remove; arm() would otherwise abort with a vaguer message.
    if(cleared.count)throw Error('Flow 提示框残留参考图无法清空，未覆盖、未提交生成。');
    if(localStorage.getItem('psfb-managed-submit:'+arg.id))throw Error('PSFB_ALREADY_SUBMITTED');
    const dt=new DataTransfer();
    payloads.forEach((bytes,index)=>dt.items.add(new File([bytes],'ps-flow-ref-'+arg.id.slice(0,8)+'-'+index+'.png',{type:'image/png'})));
    editor().focus();editor().dispatchEvent(new ClipboardEvent('paste',{bubbles:true,cancelable:true,clipboardData:dt}));
    const attached=await waitReferenceState(v=>v.count===references.length&&v.ready);
    if(attached.count!==references.length)throw Error('Flow 未确认参考图，未提交生成。');
    if(!attached.ready)throw Error('Flow 参考素材尚未就绪，未提交生成。');
    // A chip with no asset id or image URL is still a valid upload: Flow can
    // render only the cancel overlay. It just cannot be compared later, so it
    // is never cached and the next identical request uploads again.
    const identities=attached.chips.map(chip=>chip.signature);
    window.__psfbManagedRefs=digests&&identities.every(Boolean)?{scope,digests,chips:identities}:null;
    // Capture the uploaded assets now that the chips are settled: arm() may run
    // when a thumbnail is still missing, and the composer chip can be gone by
    // the time the results are read.
    s.refKeys=referenceImageKeys();s.refIds=referenceAssetIds();
    return {attached:true,jobID:s.id,references:attached.count,reused:false};
  }
  const s=window.__psfbManaged;
  // Read-only recovery ops must stay reachable after a page or panel reload,
  // where the in-memory context is gone: they rebuild the baseline from the
  // one-shot receipt and never click generate. Everything that can submit
  // still requires the exact live context below.
  const recoveryOp=action==='queryResults'||action==='readResults'||action==='pendingReceipts';
  if(!recoveryOp&&(!s||s.id!==arg.id||s.project!==state().project))throw Error('Flow 任务上下文已变化，不会重新提交。');
  if(action==='pendingReceipts'){
    // One-shot submit receipts survive a reload, so the controller can still
    // discover a job it stranded in "unknown". Newest first, bounded.
    const prefix='psfb-managed-submit:',ids=[];
    // Read every receipt before trimming: receipts are never pruned, so a busy
    // profile holds far more than the handful of jobs that are stranded at once.
    // Capping during the scan would drop whichever job happens to sit past the
    // cutoff in insertion order - often the newest one, which is the one the
    // controller most likely needs to recover right now.
    for(let i=0;i<localStorage.length;i++){
      const name=localStorage.key(i);if(!name||!name.startsWith(prefix))continue;
      // One corrupt receipt must not abort the whole scan and hide every later
      // receipt, including the newest stranded job this scan exists to find.
      try{
        const saved=JSON.parse(localStorage.getItem(name)||'null');
        if(saved&&Array.isArray(saved.baseline))ids.push({id:name.slice(prefix.length),at:Number(saved.at)||0});
      }catch(_){}
    }
    ids.sort((a,b)=>b.at-a.at);
    return {ids:ids.slice(0,20).map(v=>v.id)};
  }
  const pause=()=>new Promise(r=>setTimeout(r,150));
  if(action==='configure'){
    const matches=m=>arg.model==='gemini-3.0-pro-image'?/Nano\s*Banana\s*Pro/i.test(m):/Nano\s*Banana\s*2(?:\.\d+)*/i.test(m);
    const open=async()=>{if(!buttons().some(n=>/^x[1-4]$/.test(label(n)))){document.querySelector('.settings-trigger-button')?.click();await pause();}};
    await open();
    if(!matches(settings().model)){
      document.querySelector('[aria-label="选择模型系列"]')?.click();await pause();
      const model=buttons().find(n=>!n.classList.contains('settings-trigger-button')&&!n.getAttribute('aria-haspopup')&&matches(label(n)));
      if(!model)throw Error('未找到指定 Flow 模型，未提交生成。');model.click();await pause();await open();
    }
    if(settings().aspect!==arg.aspect){
      const ratio=buttons().find(n=>label(n)===arg.aspect);if(!ratio)throw Error('未找到所需比例，未提交生成。');
      ratio.click();await pause();
    }
    if(settings().count!==arg.count){
      const count=buttons().find(n=>label(n)==='x'+arg.count);if(!count)throw Error('未找到所需张数，未提交生成。');
      count.click();await pause();
    }
    let v=settings();
    for(let i=0;i<10&&(!matches(v.model)||v.aspect!==arg.aspect||v.count!==arg.count);i++){await pause();v=settings();}
    if(!matches(v.model)||v.aspect!==arg.aspect||v.count!==arg.count)throw Error('Flow 设置回读不一致，未提交生成。预期 '+(arg.model==='gemini-3.0-pro-image'?'Nano Banana Pro':'Nano Banana 2')+' / '+arg.aspect+' / x'+arg.count+'；读到 '+(v.model||'未识别模型')+' / '+(v.aspect||'未识别比例')+' / '+(v.count?'x'+v.count:'未识别张数'));
    if(buttons().some(n=>/^x[1-4]$/.test(label(n)))){document.querySelector('.settings-trigger-button').click();await pause();}
    const edInput=editor();edInput.focus();
    const selInput=window.getSelection(),rangeInput=document.createRange();
    rangeInput.selectNodeContents(edInput);selInput.removeAllRanges();selInput.addRange(rangeInput);
    document.execCommand('insertText',false,arg.prompt);await pause();
    const normalize=value=>String(value||'').replace(/\r\n?/g,'\n').replace(/\n+/g,'\n').trim();
    if(normalize(editor().innerText)!==normalize(arg.prompt))throw Error('提示词回读不一致，未提交生成。');
    return state();
  }
  if(action==='arm'){
    const v=state(),b=document.querySelector('.generate-icon-button[type=submit]');
    const normalize=value=>String(value||'').replace(/\r\n?/g,'\n').replace(/\n+/g,'\n').trim();
    // Text jobs must show zero reference chips; any surviving chip means the
    // composer still holds a previous job's image and the submit must not run.
    const expectedRefs=s.expectedRefs;
    // Count alone is not enough: a chip that is still uploading has the right
    // count but no usable asset, so readiness is part of the same gate.
    const refsReady=expectedRefs===0||v.referencesReady===true;
    if(v.references!==expectedRefs||!refsReady||v.count!==arg.count||v.aspect!==arg.aspect||normalize(editor()?.innerText)!==normalize(arg.prompt)||!b?.isConnected||b.disabled)throw Error('提交前页面状态无效，未提交生成。');
    if(localStorage.getItem('psfb-managed-submit:'+arg.id))throw Error('PSFB_ALREADY_SUBMITTED');
    // Record the references this job uploaded. Flow may finish filing them into
    // the media library after this snapshot, so the baseline cannot be relied on
    // to contain their tiles; these identities keep the library copies out of
    // the result set even after the composer chips are gone.
    s.refKeys=referenceImageKeys();s.refIds=referenceAssetIds();
    s.baseline=[...document.querySelectorAll('img')].map(n=>key(n.src));
    // The self-heal settle window starts here: before this moment an empty grid
    // only means the batch has not started rendering yet.
    s.armedAt=Date.now();
    if(!window.__psfbManagedPatched){
      window.__psfbManagedPatched=true;
      const watched=u=>/ogiZ0b|StreamChat/.test(String(u)),open=XMLHttpRequest.prototype.open,send=XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open=function(m,u,...rest){this.__psfbManagedUrl=String(u);return open.call(this,m,u,...rest);};
      XMLHttpRequest.prototype.send=function(body){
        const current=window.__psfbManaged;
        if(current&&watched(this.__psfbManagedUrl)){current.requests++;this.addEventListener('loadend',()=>current.responses.push({status:this.status,error:this.status>=400||/reCAPTCHA|PERMISSION_DENIED|RESOURCE_EXHAUSTED|INTERNAL_ERROR/.test(this.responseText)?'Flow 返回生成错误':''}));}
        return send.call(this,body);
      };
      const original=window.fetch;window.fetch=function(input,init){
        const current=window.__psfbManaged,u=typeof input==='string'?input:input?.url;
        if(!current||!watched(u))return original.call(this,input,init);current.requests++;
        return original.call(this,input,init).then(r=>{r.clone().text().then(t=>current.responses.push({status:r.status,error:!r.ok||/reCAPTCHA|PERMISSION_DENIED|RESOURCE_EXHAUSTED|INTERNAL_ERROR/.test(t)?'Flow 返回生成错误':''}));return r;});
      };
    }
    // Persist the pre-submit baseline alongside the one-shot receipt so a query
    // can still identify this job's own outputs after a page or panel reload.
    localStorage.setItem('psfb-managed-submit:'+arg.id,JSON.stringify({project:s.project,at:s.armedAt,count:arg.count,baseline:s.baseline,failureBaseline:s.failureBaseline||[],refKeys:s.refKeys,refIds:s.refIds}));
    return {armed:true};
  }
  if(action==='submit'){
    const b=document.querySelector('.generate-icon-button[type=submit]');
    const normalize=value=>String(value||'').replace(/\r\n?/g,'\n').replace(/\n+/g,'\n').trim();
    if(s.inputSent||!localStorage.getItem('psfb-managed-submit:'+arg.id)||normalize(editor()?.innerText)!==normalize(arg.prompt)||!b?.isConnected||b.disabled)throw Error('提交状态待确认，不会重复点击。');
    // Runtime.evaluate supplies userGesture. DOM activation works while the owner window is hidden.
    s.inputSent=true;b.click();return {clicked:true};
  }
  if(action==='submitPoint'){
    // Flow ignores untrusted synthetic clicks (element.click() has isTrusted=false).
    // The controller must dispatch a real mouse event at these viewport coordinates.
    const b=document.querySelector('.generate-icon-button[type=submit]');
    const normalize=value=>String(value||'').replace(/\r\n?/g,'\n').replace(/\n+/g,'\n').trim();
    // Re-dispatch is allowed only while nothing has been seen on the wire: a click
    // that produced no request and left the button enabled provably did not submit,
    // so retrying it cannot double-generate. Once a request lands (or Flow disables
    // the button) this throws and the one-shot receipt stands.
    // New outputs are the strongest proof of acceptance: even if the request
    // sniffer missed the call (Flow changed its endpoint) a finished image means
    // this job already generated and must never be clicked again.
    const freshOutputs=outputImages(jobReferences(arg.id)).filter(n=>!s.baseline.includes(key(n.src))).length;
    if(s.requests>0||freshOutputs>0||b?.disabled||!localStorage.getItem('psfb-managed-submit:'+arg.id)||normalize(editor()?.innerText)!==normalize(arg.prompt)||!b?.isConnected)throw Error('提交状态待确认，不会重复点击。');
    const r=b.getBoundingClientRect();
    if(!r.width||!r.height)throw Error('生成按钮不可见，未提交生成。');
    const x=r.left+r.width/2,y=r.top+r.height/2,top=document.elementFromPoint(x,y);
    if(!top||!(top===b||b.contains(top))){
      // The settings pane occasionally stays mounted over the send button (its
      // toggle is a plain JS click). Close it and abort this attempt so the
      // controller re-measures instead of firing into the overlay.
      const trigger=document.querySelector('.settings-trigger-button');
      if(trigger&&trigger.getAttribute('aria-expanded')==='true')trigger.click();
      else closeMenu();
      throw Error('生成按钮被遮挡，未提交生成。');
    }
    s.inputSent=true;s.submitAttempts=(s.submitAttempts||0)+1;
    return {x:x,y:y,width:r.width,height:r.height,attempt:s.submitAttempts,hitsButton:true};
  }
  if(action==='readResults'){
    // `recover` is the caller saying "this is a recovery read"; it is the same
    // contract as the older `recovered` flag and is honoured by every gate here.
    const recovering=arg.recovered===true||arg.recover===true;
    const v=state();
    // Recovery harvests outputs the page has already produced; it must not depend
    // on the live request signal (a page reload clears it). Normal transfer keeps
    // the strict guard.
    if(!recovering&&(!v.requests||!v.responses.length||v.responses.some(r=>r.status!==200||r.error)||v.outputs!==s.count))throw Error('生成结果尚未确认，只查询不重提。');
    // Recovery may run after a reload, where the in-memory context is gone:
    // fall back to the baseline persisted with the submit receipt.
    let baseline=s&&s.id===arg.id&&Array.isArray(s.baseline)?s.baseline:null;
    let expectedProject=s&&s.id===arg.id?s.project:(arg.project||"");
    if(!baseline){
      try{
        const saved=JSON.parse(localStorage.getItem('psfb-managed-submit:'+arg.id)||'null');
        if(saved&&Array.isArray(saved.baseline)){baseline=saved.baseline;expectedProject=expectedProject||saved.project||"";}
      }catch(_){}
    }
    // A recovery read may still proceed without a baseline (see the top-batch
    // fallback below); every other caller needs one and keeps failing loudly.
    if(!baseline&&!recovering)throw Error('Flow 任务上下文已丢失，无法读取原任务结果。');
    // A reload keeps this op reachable while the page may have been navigated to
    // another project. Without this check every image of that other project is
    // "not in baseline" and would be harvested as this job's result.
    const liveProject=state().project;
    if(expectedProject&&liveProject&&liveProject!==expectedProject)throw Error('当前 Flow 项目与任务不一致，已停止读取；请切回原项目后重试。');
    // The reference identities are rebuilt from the live chips and the receipt,
    // so a library copy that appeared after arming, or whose chip is already
    // gone, is still excluded here - never by position or image size.
    // Flow mounts only the cards near the viewport: re-scroll before deciding that
    // nothing is on the page, otherwise a finished batch that merely scrolled out
    // of view looks like a job that never produced anything.
    await healWhenIdle(arg.id);
    let urls=freshUrls(arg.id,baseline);
    // Recovery only: the baseline can be unusable (a receipt written before
    // baselines were stored, or a page the user has since refreshed). Flow's newest
    // batch then sits at the top of the grid at exactly the declared size and
    // refusing to harvest it is what leaves "恢复原结果" spinning forever. The
    // count gate, the idle gate and the identity/filename exclusions in
    // outputImages()/topBatchUrls() all still apply, and the strict guard above
    // still governs every non-recovery read.
    let recoveredByTop=false;
    // Allowed for an explicit recovery read, and for a job whose settle window
    // has long passed (the reported symptom: the batch is on the page while the
    // panel still waits for confirmation).
    if(recovering||armedElapsed(arg.id)>=ARMED_SETTLE_MS){
      const need=Math.max(1,declaredCountFor(arg.id,s));
      if(urls.length<need&&!progressBars().length){
        const top=topBatchUrls(arg.id,need);
        if(top&&top.length>=need){urls=top;recoveredByTop=true;}
      }
    }
    const n=arg.index;if(!Number.isInteger(n)||n<0||n>=urls.length)throw Error('结果编号无效');
    const project=expectedProject||liveProject||"";
    const output=await readOne(urls[n],project);
    // `recovered` tells the controller this asset came from the top-batch
    // fallback rather than from an exact baseline diff.
    if(recoveredByTop)output.recovered=true;
    return output;
  }
  if(action==='queryResults'){
    // Recovery for a job stranded in "unknown": NEVER resubmits. It only reports
    // how many outputs are now present on the page so the controller can decide
    // whether to resync. The pre-submit baseline is persisted in the submit
    // receipt, so the count stays exact even after a page or panel reload.
    const s2=window.__psfbManaged;
    let baseline=s2&&s2.id===arg.id&&Array.isArray(s2.baseline)?s2.baseline:null;
    let failureBaseline=s2&&s2.id===arg.id&&Array.isArray(s2.failureBaseline)?s2.failureBaseline:null;
    let project=s2&&s2.id===arg.id?s2.project:null;
    // The expected count must also survive a reload. Falling back to the number
    // of fresh images would make "complete" self-fulfilling and could confirm a
    // job at the wrong size, so only a declared 1..4 count is accepted.
    let expectedCount=s2&&s2.id===arg.id?Number(s2.count)||0:0;
    // The receipt is read even when the live context still exists: it is a
    // valid source for the declared count, and the live context is only the
    // preferred baseline. A malformed receipt is ignored, never fatal.
    let receipt=null;
    try{
      const saved=JSON.parse(localStorage.getItem('psfb-managed-submit:'+arg.id)||'null');
      if(saved&&typeof saved==='object')receipt=saved;
    }catch(_){}
    if(!baseline&&receipt&&Array.isArray(receipt.baseline)){
      baseline=receipt.baseline;project=project||receipt.project||'';
    }
    if(!failureBaseline&&receipt&&Array.isArray(receipt.failureBaseline))failureBaseline=receipt.failureBaseline;
    if(!expectedCount&&receipt)expectedCount=Number(receipt.count)||0;
    if(!baseline)throw Error('Flow 任务上下文已丢失，无法查询原任务。');
    if(project&&state().project&&state().project!==project)throw Error('当前 Flow 项目与任务不一致，已停止读取；请切回原项目后重试。');
    // Re-scroll first: a batch that scrolled out of view must be remounted before
    // the count below decides whether this job can be confirmed.
    await healWhenIdle(arg.id);
    const images=outputImages(jobReferences(arg.id));
    const fresh=images.filter(n=>!baseline.includes(key(n.src)));
    const failures=freshFailures(failureBaseline||[]);
    // Never infer the expected size from what happens to be on the page. A
    // missing or malformed count means this job cannot be confirmed at all;
    // reporting "complete" from fresh.length would accept a partial harvest.
    const validCount=value=>Number.isInteger(value)&&value>=1&&value<=4;
    const requested=Number(arg.count);
    const expected=validCount(requested)?requested:(validCount(expectedCount)?expectedCount:0);
    const countError=expected?'':'任务缺少有效的生成张数（1-4），无法确认结果。';
    // The baseline can no longer match the page (a refresh, or a receipt written
    // before identities were recorded), yet the declared count is still the
    // contract. When the diff undercounts while the top of the grid already holds
    // at least that many non-reference results and nothing is loading, the batch
    // really is there: report it so a stranded job is not left waiting forever.
    // The declared count is still never inferred from fresh.length, and a job
    // without a valid count is still never confirmed.
    let topBatch=0,recoveredBatch=false;
    if(expected>0&&fresh.length<expected&&armedElapsed(arg.id)>=ARMED_SETTLE_MS&&!progressBars().length){
      const top=topBatchUrls(arg.id,expected);
      topBatch=top?top.length:0;
      recoveredBatch=topBatch>=expected;
    }
    return {id:arg.id,project:project,count:expected,countValid:!!expected,countError,baseline:baseline.length,imgTotal:images.length,
      requests:s2?s2.requests:0,responses:s2?s2.responses.map(r=>({status:r.status,error:r.error||null})):[],
      outputs:fresh.length,failures:failures.length,failureText:failures[0]||'',failureCode:failures.length?failureCodeFor(failures[0]):'',
      topBatch,recoveredBatch,complete:expected>0&&(fresh.length===expected||recoveredBatch)};
  }
  throw Error('不支持的内置浏览器操作');
}
