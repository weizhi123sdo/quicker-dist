const fs = require('fs').promises;
const path = require('path');

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const VALID_KINDS = ['jobs', 'action-jobs'];

const locks = new Map();

// Concurrency mutex for the same kind/id
async function withLock(key, fn) {
    while (locks.has(key)) {
        await locks.get(key);
    }
    let resolveLock;
    const lockPromise = new Promise(r => resolveLock = r);
    locks.set(key, lockPromise);
    try {
        return await fn();
    } finally {
        locks.delete(key);
        resolveLock();
    }
}

function validateId(id) {
    if (!id || !UUID_REGEX.test(id)) throw new Error(`Invalid UUID: ${id}`);
}

function validateKind(kind) {
    if (!VALID_KINDS.includes(kind)) throw new Error(`Invalid kind: ${kind}`);
}

async function moveToTrash(dataDir, id, kind = 'jobs') {
    validateId(id);
    validateKind(kind);
    const lockKey = `${kind}:${id}`;

    return withLock(lockKey, async () => {
        const livePath = path.join(dataDir, kind, id);
        const trashDir = path.join(dataDir, '.trash', kind);
        const trashPath = path.join(trashDir, id);

        try {
            await fs.access(livePath);
        } catch (err) {
            throw new Error(`Live record not found: ${id}`);
        }

        await fs.mkdir(trashDir, { recursive: true });

        try {await fs.access(trashPath);throw new Error('回收站已有同编号记录，已保留两份数据。');}
        catch(err){if(err.code!=='ENOENT')throw err;}
        await require('./atomic-file').writeTextAtomically(path.join(livePath,'trash-manifest.json'),JSON.stringify({schemaVersion:1,id,kind,deletedAt:new Date().toISOString()}));

        // Atomic rename
        await fs.rename(livePath, trashPath);
    });
}

async function restoreFromTrash(dataDir, id, kind = 'jobs') {
    validateId(id);
    validateKind(kind);
    const lockKey = `${kind}:${id}`;

    return withLock(lockKey, async () => {
        const livePath = path.join(dataDir, kind, id);
        const trashPath = path.join(dataDir, '.trash', kind, id);

        try {
            await fs.access(trashPath);
        } catch (err) {
            if (err.code === 'ENOENT') {
                const notFound = new Error(`Trash record not found: ${id}`);
                notFound.code = 'ENOENT';
                throw notFound;
            }
            throw err;
        }

        try {
            await fs.access(livePath);
            const existsErr = new Error(`Cannot restore: Live record with this ID already exists`);
            existsErr.code = 'EEXIST';
            throw existsErr;
        } catch (err) {
            if (err.code !== 'ENOENT') throw err;
        }

        const liveDir = path.join(dataDir, kind);
        await fs.mkdir(liveDir, { recursive: true });

        // Atomic rename
        await fs.rename(trashPath, livePath);
    });
}

async function listTrash(dataDir) {
    const result = { jobs: [], 'action-jobs': [] };
    for (const kind of VALID_KINDS) {
        const trashDir = path.join(dataDir, '.trash', kind);
        try {
            const files = await fs.readdir(trashDir, { withFileTypes: true });
            result[kind] = files
                .filter(f => f.isDirectory() && UUID_REGEX.test(f.name))
                .map(f => f.name);
        } catch (err) {
            if (err.code !== 'ENOENT') throw err;
        }
    }
    return result;
}

async function inspectTrashRecord(dataDir, id, kind = 'jobs') {
    validateId(id);
    validateKind(kind);
    const dir = path.join(dataDir, '.trash', kind, id);
    const payloadFile = path.join(dir, kind === 'action-jobs' ? 'capture.json' : 'job.json');
    const manifestFile = path.join(dir, 'trash-manifest.json');

    let payloadRaw;
    try {
        payloadRaw = await fs.readFile(payloadFile, 'utf8');
    } catch (err) {
        if (err.code === 'ENOENT') {
            return { ok: false, id, kind, issue: { id, kind, code: 'missing_file' } };
        }
        return { ok: false, id, kind, issue: { id, kind, code: 'inaccessible' } };
    }

    if (payloadRaw.charCodeAt(0) === 0xFEFF) {
        payloadRaw = payloadRaw.slice(1);
    }

    let record;
    try {
        record = JSON.parse(payloadRaw);
    } catch {
        return { ok: false, id, kind, issue: { id, kind, code: 'corrupt_json' } };
    }

    if (!record || typeof record !== 'object' || Array.isArray(record) || record.id !== id) {
        return { ok: false, id, kind, issue: { id, kind, code: 'invalid_record' } };
    }

    let deletedAt = null;
    try {
        let metaRaw = await fs.readFile(manifestFile, 'utf8');
        if (metaRaw.charCodeAt(0) === 0xFEFF) metaRaw = metaRaw.slice(1);
        const metaObj = JSON.parse(metaRaw);
        deletedAt = metaObj && typeof metaObj === 'object' ? metaObj.deletedAt || null : null;
    } catch { }

    return { ok: true, id, kind, record, deletedAt };
}

module.exports = {
    moveToTrash,
    restoreFromTrash,
    listTrash,
    inspectTrashRecord
};
