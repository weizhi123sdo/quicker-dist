"use strict";
const fs=require('node:fs/promises'),path=require('node:path'),sharp=require('sharp');
const LIMIT=25000000;
async function pixels(bytes,w,h){return sharp(bytes,{limitInputPixels:LIMIT}).resize(w,h,{fit:'fill'}).ensureAlpha().raw().toBuffer();}
async function maskPixels(job,dir){return job.mask?sharp(await fs.readFile(path.join(dir,'mask.png'))).removeAlpha().extractChannel(0).raw().toBuffer():null;}
function gray(data){const a=new Float32Array(data.length/4);for(let i=0;i<a.length;i++)a[i]=.299*data[i*4]+.587*data[i*4+1]+.114*data[i*4+2];return a;}
function estimate(source,generated,mask,w,h,editRegion=null,contextMarginPx=8){
  const a=gray(source),b=gray(generated),points=[];
  // Skip a one-pixel ring around the mask: after downscaling, boundary pixels mix the regenerated interior into the context and would bias the match.
  for(let y=contextMarginPx;y<h-contextMarginPx;y+=2)for(let x=contextMarginPx;x<w-contextMarginPx;x+=2){const i=y*w+x;if(editRegion&&x>=editRegion.left-1&&x<=editRegion.left+editRegion.width+1&&y>=editRegion.top-1&&y<=editRegion.top+editRegion.height+1)continue;if(mask[i]>=8||source[i*4+3]<=240)continue;if(mask[i-1]>=8||mask[i+1]>=8||mask[i-w]>=8||mask[i+w]>=8)continue;points.push([x,y,a[i]]);}
  if(points.length<40)return {status:'uncertain',reason:'insufficient_context',dx:0,dy:0,scale:1};
  const mean=points.reduce((s,p)=>s+p[2],0)/points.length,variance=points.reduce((s,p)=>s+(p[2]-mean)**2,0);
  const score=(dx,dy,scale)=>{let sum=0,sum2=0,cov=0,mae=0;for(const [x,y,v]of points){const xx=Math.max(0,Math.min(w-1,Math.round((x-w/2)*scale+w/2+dx))),yy=Math.max(0,Math.min(h-1,Math.round((y-h/2)*scale+h/2+dy))),q=b[yy*w+xx];sum+=q;sum2+=q*q;cov+=(v-mean)*q;mae+=Math.abs(v-q);}return {correlation:cov/Math.sqrt(Math.max(1,variance*(sum2-sum*sum/points.length))),mae:mae/points.length};};
  const scales=[.98,1,1.02],limit=6;
  const base=score(0,0,1);let best={...base,dx:0,dy:0,scale:1};
  for(const scale of scales)for(let dy=-limit;dy<=limit;dy++)for(let dx=-limit;dx<=limit;dx++){const s=score(dx,dy,scale);if(s.correlation>best.correlation)best={...s,dx,dy,scale};}
  // A peak sitting on the search edge means the real offset or scale may lie
  // outside the searched range; warping by it would silently drag the context.
  const boundary=Math.abs(best.dx)===limit||Math.abs(best.dy)===limit||best.scale===scales[0]||best.scale===scales[scales.length-1];
  if(variance/points.length<20)return {...best,status:base.mae<4?'unchanged':'uncertain',reason:'low_texture',dx:0,dy:0,scale:1};
  if(best.correlation<.72)return {...best,status:'uncertain',reason:'context_redrawn',dx:0,dy:0,scale:1};
  if(best.correlation-base.correlation<.025)return {...base,status:'unchanged',reason:'context_matches',dx:0,dy:0,scale:1};
  if(boundary)return {...best,status:'uncertain',reason:'search_boundary',dx:0,dy:0,scale:1};
  return {...best,status:'aligned',reason:'context_registration'};
}
function warp(raw,w,h,dx,dy,scale){
  const out=Buffer.alloc(raw.length);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const sx=Math.max(0,Math.min(w-1,(x-w/2)*scale+w/2+dx)),sy=Math.max(0,Math.min(h-1,(y-h/2)*scale+h/2+dy));
    const xx=Math.floor(sx),yy=Math.floor(sy),fx=sx-xx,fy=sy-yy;
    for(let c=0;c<4;c++){const p=(yy*w+xx)*4+c,q=(yy*w+Math.min(w-1,xx+1))*4+c,r=(Math.min(h-1,yy+1)*w+xx)*4+c,s=(Math.min(h-1,yy+1)*w+Math.min(w-1,xx+1))*4+c;out[(y*w+x)*4+c]=Math.round((1-fy)*((1-fx)*raw[p]+fx*raw[q])+fy*((1-fx)*raw[r]+fx*raw[s]));}
  }return out;
}
function feather(mask,w,h){
  if(mask.some(v=>v!==0&&v!==255))return null;
  const d=new Uint16Array(mask.length);for(let i=0;i<d.length;i++)d[i]=mask[i]?10000:0;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;if(d[i])d[i]=Math.min(d[i],x?d[i-1]+1:1,y?d[i-w]+1:1);}
  for(let y=h-1;y>=0;y--)for(let x=w-1;x>=0;x--){const i=y*w+x;if(d[i])d[i]=Math.min(d[i],x<w-1?d[i+1]+1:1,y<h-1?d[i+w]+1:1);}
  return d;
}
async function makeComposite(bytes,job,dir){
  if(job.kind==='text2image')return bytes;
  const w=job.source.width,h=job.source.height,mask=await maskPixels(job,dir);
  if(!mask)return bytes;
  const source=await pixels(await fs.readFile(path.join(dir,'source.png')),w,h),result=await pixels(bytes,w,h);
  for(let i=0;i<mask.length;i++){const weight=mask[i]/255;for(let c=0;c<4;c++)result[i*4+c]=Math.round(result[i*4+c]*weight+source[i*4+c]*(1-weight));}
  return sharp(result,{raw:{width:w,height:h,channels:4}}).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
}
async function processResult(bytes,job,dir){
  const meta=await sharp(bytes,{limitInputPixels:LIMIT}).metadata();
  if(!['png','jpeg','webp'].includes(meta.format))throw Object.assign(new Error('生成结果不是可用图片，任务和下载地址已保留。'),{code:'result_error'});
  if(job.kind==='text2image'){
    const output=await sharp(bytes,{limitInputPixels:LIMIT}).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
    return {output,width:meta.width,height:meta.height,alignment:{status:'unchanged',reason:'text2image_native_dimensions'}};
  }
  if(!job.source)throw Object.assign(new Error('原素材尺寸缺失，已保留结果。'),{code:'result_error'});
  const t=job.transform,w=job.source.width,h=job.source.height;
  // Only clearly wrong ratios are rejected; Flow occasionally returns a
  // near-but-not-exact aspect (a few percent off) that still crops cleanly.
  if(t && Math.abs(Math.log((meta.width/meta.height)/(t.paddedW/t.paddedH)))>.12)throw Object.assign(new Error('生成结果比例与请求差异过大，已保留原任务，未裁切或变形回贴。请检查生成服务比例设置。'),{code:'result_ratio'});
  let output;
  if(t){
    if(t.left===0&&t.top===0&&t.paddedW===w&&t.paddedH===h&&t.width===w&&t.height===h){
      output=await sharp(bytes).resize(w,h,{fit:'fill'}).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
    }else{
      const padded=await sharp(bytes).resize(t.paddedW,t.paddedH,{fit:'fill'}).png().toBuffer();
      const extracted=sharp(padded).extract({left:t.left,top:t.top,width:t.width,height:t.height});
      if(t.width!==w||t.height!==h){
        output=await extracted.resize(w,h).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
      }else{
        output=await extracted.toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
      }
    }
  }else output=await sharp(bytes).resize(w,h,{fit:'fill'}).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
    if(job.geometryVersion!==2 || !job.mask){
    if(job.mask && job.referencePolicy==='selection-outline' && job.resultMaskMode==='external'){
      const sourceBytes=await fs.readFile(path.join(dir,'source.png')),mask=await maskPixels(job,dir);
      const source=await pixels(sourceBytes,w,h);let generated=await pixels(output,w,h);
      for(let i=0;i<mask.length;i++){
        if(mask[i]===0){
          for(let c=0;c<4;c++) generated[i*4+c] = source[i*4+c];
        }
      }
      output=await sharp(generated,{raw:{width:w,height:h,channels:4}}).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
    }
    return {output,width:w,height:h,alignment:{status:'unchanged',reason:'no_context_registration'}};
  }
  // 128px was too coarse for large captures: one search step covered 8-12 real
  // pixels, so a few-pixel shift either snapped to a wrong peak or looked
  // "unchanged". 256 keeps the search cheap but halves that quantisation error.
  const sourceBytes=await fs.readFile(path.join(dir,'source.png')),mask=await maskPixels(job,dir),sw=Math.min(256,w),sh=Math.max(1,Math.round(h*sw/w));
  let estimateMask = mask;
  if(job.referencePolicy==='selection-outline' && mask){
    const {protectBoundary}=require('./reference-input');
    const expandOriginal=Math.ceil(((t?.guideGapPx??6)+(t?.guideLinePx??2)+3)*(w/(t?.width||w)));
    estimateMask=protectBoundary(mask,w,h,expandOriginal);
  }
  const [smallSource,smallResult,smallMask]=await Promise.all([pixels(sourceBytes,sw,sh),pixels(output,sw,sh),sharp(estimateMask,{raw:{width:w,height:h,channels:1}}).resize(sw,sh,{kernel:'nearest'}).toColourspace('b-w').raw().toBuffer()]);
  let region=null;
  if(job.referencePolicy==='selection-contrast'&&job.editRegion){
    region={left:job.editRegion.left*sw/w,top:job.editRegion.top*sh/h,width:job.editRegion.width*sw/w,height:job.editRegion.height*sh/h};
  }
  let contextMargin = 8;
  if(job.referencePolicy==='selection-outline') contextMargin = 2;
  const alignment=estimate(smallSource,smallResult,smallMask,sw,sh,region,contextMargin);
  alignment.dx*=w/sw;alignment.dy*=h/sh;
  const source=await pixels(sourceBytes,w,h);let generated=await pixels(output,w,h);
  if(alignment.status==='aligned')generated=warp(generated,w,h,alignment.dx,alignment.dy,alignment.scale);
  if(job.resultMaskMode==='external') {
    if(job.referencePolicy==='selection-outline' && mask){
      for(let i=0;i<mask.length;i++){
        if(mask[i]===0){
          for(let c=0;c<4;c++) generated[i*4+c] = source[i*4+c];
        }
      }
    }
    output=await sharp(generated,{raw:{width:w,height:h,channels:4}}).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
    return {output,width:w,height:h,alignment};
  }
  const distance=feather(mask,w,h);
  // Keep context pixels exact; inset blending is applied only to hard masks.
  for(let i=0;i<mask.length;i++){const weight=mask[i]===0?0:distance?Math.min(1,distance[i]/3):1;for(let c=0;c<4;c++)generated[i*4+c]=Math.round(generated[i*4+c]*weight+source[i*4+c]*(1-weight));}
  output=await sharp(generated,{raw:{width:w,height:h,channels:4}}).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
  return {output,width:w,height:h,alignment};
}
module.exports={processResult,makeComposite,estimate,warp};
