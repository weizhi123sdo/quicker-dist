"use strict";
const fs=require('node:fs/promises'),path=require('node:path'),crypto=require('node:crypto'),sharp=require('sharp');
const {processResult,warp}=require('./result-geometry');
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
async function prepareHd(bytes,job,directory){
 const meta=await sharp(bytes,{limitInputPixels:25000000}).metadata();
 if(!['png','jpeg','webp'].includes(meta.format))throw Error('下载文件不是可用的高清图片。');
 if (job.kind === 'text2image') {
  const png=await sharp(bytes,{limitInputPixels:25000000}).toColourspace('srgb').withIccProfile('srgb').png().toBuffer();
  return {output:png,width:meta.width,height:meta.height,alignment:{status:'unchanged',reason:'text2image_hd_native'},extension:meta.format==='jpeg'?'.jpg':'.'+meta.format};
 }
 const checked=await processResult(bytes,job,directory),t=job.transform;
 const left=t?Math.round(t.left*meta.width/t.paddedW):0,top=t?Math.round(t.top*meta.height/t.paddedH):0;
 const width=t?Math.min(meta.width-left,Math.round(t.width*meta.width/t.paddedW)):meta.width;
 const height=t?Math.min(meta.height-top,Math.round(t.height*meta.height/t.paddedH)):meta.height;
 let output=await sharp(bytes).extract({left,top,width,height}).toColourspace('srgb').ensureAlpha().raw().toBuffer();
 if(checked.alignment.status==='aligned')output=warp(output,width,height,checked.alignment.dx*width/job.source.width,checked.alignment.dy*height/job.source.height,checked.alignment.scale);
 if(job.mask){
  const mask=await sharp(await fs.readFile(path.join(directory,'mask.png'))).removeAlpha().extractChannel(0).resize(width,height,{kernel:'nearest'}).toColourspace('b-w').raw().toBuffer();
  const source=await sharp(await fs.readFile(path.join(directory,'source.png'))).resize(width,height,{fit:'fill'}).ensureAlpha().raw().toBuffer();
  for(let i=0;i<mask.length;i++)if(mask[i]===0)source.copy(output,i*4,i*4,i*4+4);
 }
 const png=await sharp(output,{raw:{width,height,channels:4}}).withIccProfile('srgb').png().toBuffer();
 return {output:png,width,height,alignment:checked.alignment,extension:meta.format==='jpeg'?'.jpg':'.'+meta.format};
}
async function saveOriginal(bytes,job,dataDir,index,resolution,extension){
 const filename='PSFlow-'+job.id.slice(0,8)+'-'+index+'-'+resolution+'-'+crypto.randomUUID().slice(0,8)+extension;
 if(typeof job.documentPath==='string'&&path.isAbsolute(job.documentPath)){
  try{const stat=await fs.stat(job.documentPath);if(stat.isFile()){const target=path.join(path.dirname(job.documentPath),filename);await fs.writeFile(target,bytes,{flag:'wx'});return {path:target,location:'source'};}}catch{}
 }
 const folder=path.join(dataDir,'cache','hd-originals',job.id);await fs.mkdir(folder,{recursive:true});
 const target=path.join(folder,filename);await fs.writeFile(target,bytes,{flag:'wx'});return {path:target,location:'cache'};
}
module.exports={prepareHd,saveOriginal,hash};
