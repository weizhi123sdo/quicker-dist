"use strict";

const fs = require("node:fs/promises");
const path = require("node:path");
const crypto = require("node:crypto");
const os = require("node:os");

const REFERENCE_RULE_VERSION = "20261013-v1";
const RETRYABLE_ERRORS = new Set(["EPERM", "EACCES", "EBUSY"]);

// In-process flight map to deduplicate concurrent preparations for the same key
const inFlightRequests = new Map();

const stats = {
  hits: 0,
  misses: 0,
  writes: 0,
  invalidations: 0,
  dedupedConcurrent: 0
};

function resetStats() {
  stats.hits = 0;
  stats.misses = 0;
  stats.writes = 0;
  stats.invalidations = 0;
  stats.dedupedConcurrent = 0;
}

function buildKeyDescriptor({
  sourceHash,
  maskHash,
  model,
  selectedAspect,
  width,
  height,
  paddedW,
  paddedH,
  left,
  top,
  policy,
  geometryVersion,
  bounds,
  editBounds,
  editRegion
}) {
  return {
    ruleVersion: REFERENCE_RULE_VERSION,
    sourceHash,
    maskHash: maskHash || null,
    model: model || "default",
    aspect: selectedAspect ? selectedAspect.aspect : null,
    ratio: selectedAspect ? selectedAspect.ratio : null,
    width,
    height,
    paddedW,
    paddedH,
    left,
    top,
    policy: policy || "default",
    geometryVersion: geometryVersion || 1,
    bounds: bounds ? {
      left: bounds.left,
      top: bounds.top,
      width: bounds.width,
      height: bounds.height
    } : null,
    editBounds: editBounds ? {
      left: editBounds.left,
      top: editBounds.top,
      width: editBounds.width,
      height: editBounds.height
    } : null,
    editRegion: editRegion ? {
      left: editRegion.left,
      top: editRegion.top,
      width: editRegion.width,
      height: editRegion.height
    } : null
  };
}

function computeKey(descriptor) {
  const serialized = JSON.stringify(descriptor);
  return crypto.createHash("sha256").update(serialized).digest("hex");
}

function resolveCacheDir(options = {}, directory = null) {
  if (options.cacheDir) return path.resolve(options.cacheDir);
  if (options.dataDir) return path.resolve(options.dataDir, "cache", "prepared-references");
  if (directory) {
    const parent = path.dirname(directory);
    if (path.basename(parent) === "jobs") {
      return path.resolve(path.dirname(parent), "cache", "prepared-references");
    }
  }
  const envData = process.env.PSFB_DATA_DIR;
  if (envData) return path.resolve(envData, "cache", "prepared-references");
  const localApp = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
  return path.resolve(localApp, "PSFlowBridge", "cache", "prepared-references");
}

async function retryableRename(source, target) {
  for (let attempt = 0; ; attempt++) {
    try {
      await fs.rename(source, target);
      break;
    } catch (err) {
      if (!RETRYABLE_ERRORS.has(err.code) || attempt >= 5) throw err;
      await new Promise(r => setTimeout(r, 20 * (2 ** attempt)));
    }
  }
}

async function writeCache(cacheDir, key, entry) {
  await fs.mkdir(cacheDir, { recursive: true });
  const metaTarget = path.join(cacheDir, key + ".json");
  const imageTarget = path.join(cacheDir, key + ".png");

  const nonce = `${process.pid}.${crypto.randomUUID()}`;
  const metaTmp = path.join(cacheDir, `${key}.${nonce}.json.tmp`);
  const imageTmp = path.join(cacheDir, `${key}.${nonce}.png.tmp`);

  const paddedBytes = entry.padded;
  const paddedSha256 = crypto.createHash("sha256").update(paddedBytes).digest("hex");

  const metadata = {
    version: 1,
    key,
    keyDescriptor: entry.keyDescriptor || null,
    model: entry.model,
    transform: entry.transform,
    hasReferencePng: Boolean(entry.hasReferencePng),
    paddedSha256,
    transformSha256:crypto.createHash('sha256').update(JSON.stringify(entry.transform)).digest('hex'),
    paddedByteLength: paddedBytes.length,
    createdAt: new Date().toISOString()
  };

  try {
    await fs.writeFile(imageTmp, paddedBytes);
    await retryableRename(imageTmp, imageTarget);

    await fs.writeFile(metaTmp, JSON.stringify(metadata, null, 2), "utf8");
    await retryableRename(metaTmp, metaTarget);

    stats.writes++;
  } catch (err) {
    await fs.unlink(imageTmp).catch(() => {});
    await fs.unlink(metaTmp).catch(() => {});
    throw err;
  }
}

async function invalidateCache(cacheDir, key) {
  stats.invalidations++;
  const metaTarget = path.join(cacheDir, key + ".json");
  const imageTarget = path.join(cacheDir, key + ".png");
  await Promise.allSettled([
    fs.unlink(metaTarget).catch(() => {}),
    fs.unlink(imageTarget).catch(() => {})
  ]);
}

async function readCache(cacheDir, key, expectedDescriptor = null) {
  const metaTarget = path.join(cacheDir, key + ".json");
  const imageTarget = path.join(cacheDir, key + ".png");

  let metaRaw;
  try {
    metaRaw = await fs.readFile(metaTarget, "utf8");
  } catch (err) {
    if (err.code === "ENOENT") return null;
    await invalidateCache(cacheDir, key);
    return null;
  }

  let metadata;
  try {
    metadata = JSON.parse(metaRaw);
  } catch (_) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  if (!metadata || metadata.version !== 1 || typeof metadata.paddedSha256 !== "string" || !metadata.transform) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  if (metadata.key !== key) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  if (!metadata.keyDescriptor || computeKey(metadata.keyDescriptor) !== key || crypto.createHash('sha256').update(JSON.stringify(metadata.transform)).digest('hex') !== metadata.transformSha256) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  if (expectedDescriptor && metadata.keyDescriptor && JSON.stringify(metadata.keyDescriptor) !== JSON.stringify(expectedDescriptor)) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  let imageBytes;
  try {
    imageBytes = await fs.readFile(imageTarget);
  } catch (_) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  if (!imageBytes || imageBytes.length === 0) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  if (
    imageBytes.length < 8 ||
    imageBytes[0] !== 0x89 || imageBytes[1] !== 0x50 ||
    imageBytes[2] !== 0x4e || imageBytes[3] !== 0x47 ||
    imageBytes[4] !== 0x0d || imageBytes[5] !== 0x0a ||
    imageBytes[6] !== 0x1a || imageBytes[7] !== 0x0a
  ) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  const hash = crypto.createHash("sha256").update(imageBytes).digest("hex");
  if (hash !== metadata.paddedSha256) {
    await invalidateCache(cacheDir, key);
    return null;
  }

  stats.hits++;
  return {
    key,
    model: metadata.model,
    padded: imageBytes,
    transform: metadata.transform,
    hasReferencePng: Boolean(metadata.hasReferencePng),
    fromCache: true
  };
}

async function getOrPrepareReference({
  cacheDir,
  dataDir,
  directory,
  job,
  config,
  source,
  maskBytes,
  model,
  selected,
  scale,
  width,
  height,
  computeFn
}) {
  const resolvedCacheDir = resolveCacheDir({ cacheDir, dataDir }, directory);

  const sourceHash = crypto.createHash("sha256").update(source).digest("hex");
  const maskHash = maskBytes ? crypto.createHash("sha256").update(maskBytes).digest("hex") : null;

  const policy = job.referencePolicy || "default";
  let paddedW, paddedH, left, top;
  if (policy === "selection-outline") {
    const margin = 12;
    paddedW = Math.max(width + margin * 2, Math.ceil((height + margin * 2) * selected.ratio));
    paddedH = Math.max(height + margin * 2, Math.ceil((width + margin * 2) / selected.ratio));
    left = Math.floor((paddedW - width) / 2);
    top = Math.floor((paddedH - height) / 2);
  } else {
    paddedW = Math.max(width, Math.ceil(height * selected.ratio));
    paddedH = Math.max(height, Math.ceil(width / selected.ratio));
    left = Math.floor((paddedW - width) / 2);
    top = Math.floor((paddedH - height) / 2);
  }

  const keyDescriptor = buildKeyDescriptor({
    sourceHash,
    maskHash,
    model,
    selectedAspect: selected,
    width,
    height,
    paddedW,
    paddedH,
    left,
    top,
    policy,
    geometryVersion: job.geometryVersion,
    bounds: job.bounds,
    editBounds: job.editBounds,
    editRegion: job.editRegion
  });

  const key = computeKey(keyDescriptor);

  const cached = await readCache(resolvedCacheDir, key, keyDescriptor);
  if (cached) {
    return cached;
  }

  stats.misses++;
  const flightKey=resolvedCacheDir+'\n'+key;

  if (inFlightRequests.has(flightKey)) {
    stats.dedupedConcurrent++;
    return inFlightRequests.get(flightKey);
  }

  const computePromise = (async () => {
    try {
      const secondCheck = await readCache(resolvedCacheDir, key, keyDescriptor);
      if (secondCheck) return secondCheck;

      const computed = await computeFn();
      computed.keyDescriptor = keyDescriptor;

      try {
        await writeCache(resolvedCacheDir, key, computed);
      } catch (_) {
        // Cache write error must not fail execution
      }

      return {
        key,
        model: computed.model,
        padded: computed.padded,
        transform: computed.transform,
        hasReferencePng: Boolean(computed.hasReferencePng),
        fromCache: false
      };
    } finally {
      inFlightRequests.delete(flightKey);
    }
  })();

  inFlightRequests.set(flightKey, computePromise);
  return computePromise;
}

module.exports = {
  REFERENCE_RULE_VERSION,
  buildKeyDescriptor,
  computeKey,
  resolveCacheDir,
  readCache,
  writeCache,
  invalidateCache,
  getOrPrepareReference,
  stats,
  resetStats
};
