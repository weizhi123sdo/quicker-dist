"use strict";
// Startup + runtime health for the on-disk job store.
//
// The helper must never silently skip a damaged job folder, and it must never
// delete or overwrite a file it could not read. This module classifies every
// failure into a small, path-free vocabulary that is published through
// GET /api/health as the frozen cross-module `dataHealth` contract:
//
//   {schemaVersion, checkedAt, issueCount, errorCount, warningCount,
//    issues:[{jobId, code, stage, retryable}]}
//
// Nothing here may expose paths, stacks, credentials or prompts.
//
// Load-stage codes:
//   incomplete_upload  folder looks like an upload still in progress (warning)
//   missing_file       job.json absent and nothing suggests an in-flight write
//   corrupt_json       job.json exists but is not parseable JSON
//   invalid_record     job.json parsed but is not a JSON object
//   inaccessible       transient OS error (locked / permission / device)
//   unreadable         any other read failure
// Persist-stage codes are the OS error code of the failed durable write.
const fs = require("node:fs/promises");
const path = require("node:path");

const SCHEMA_VERSION = 1;
const MAX_ISSUES = 50;
// Internal tracking is bounded too: a permanently broken disk must not grow an
// unbounded in-memory issue set for the lifetime of the helper.
const MAX_TRACKED_ISSUES = 200;
const DEFAULT_INCOMPLETE_MS = 5 * 60 * 1000;
const SAFE_ID = /^[0-9a-f-]{36}$/i;
// Errors that usually clear on their own; these are reported as warnings and
// marked retryable. Anything else is a hard error.
const TRANSIENT_CODES = new Set(["EACCES", "EPERM", "EBUSY", "EMFILE", "ENFILE", "EAGAIN", "EIO", "ENOMEM", "ENOTREADY", "EEXIST"]);
// Writers in this codebase use these suffixes for not-yet-committed files.
const PARTIAL_MARKER = /\.(part|partial|tmp|temp|download|crdownload)$/i;
const UPLOAD_MARKER = /^(source|mask)\.(raw|png)$/i;

const LOAD_CODES = Object.freeze([
  "incomplete_upload",
  "missing_file",
  "corrupt_json",
  "invalid_record",
  "inaccessible",
  "unreadable"
]);
// Codes that are expected to resolve without operator action.
const WARNING_CODES = new Set(["incomplete_upload", "inaccessible"]);
const RETRYABLE_CODES = new Set(["incomplete_upload", "inaccessible"]);

function stripBom(text) {
  return String(text).replace(/^\uFEFF/, "");
}

function classifyReadError(error) {
  if (!error) return "unreadable";
  if (error.code === "ENOENT") return "missing_file";
  if (TRANSIENT_CODES.has(error.code)) return "inaccessible";
  return "unreadable";
}

// Persist failures surface the raw OS code so callers can distinguish disk-full
// from a Windows sharing violation. Unknown codes collapse to a safe literal.
function safeErrorCode(error) {
  const code = error && typeof error.code === "string" ? error.code : "";
  return /^[A-Z0-9_]{1,24}$/.test(code) ? code : "UNKNOWN";
}

function safeJobId(jobId) {
  const value = String(jobId || "");
  return SAFE_ID.test(value) ? value : null;
}

// A folder without job.json is only permanently damaged if nothing about it
// suggests an in-flight write. Partial files, raw uploads and a fresh mtime all
// mean "not finished yet", so they must not be reported as data loss.
async function looksLikeIncompleteUpload(dir, io, now, incompleteMs) {
  let entries;
  try {
    entries = await io.readdir(dir, { withFileTypes: true });
  } catch {
    return false;
  }
  if (entries.some(entry => PARTIAL_MARKER.test(entry.name) || UPLOAD_MARKER.test(entry.name))) return true;
  try {
    const stat = await io.stat(dir);
    return Number.isFinite(stat.mtimeMs) && now - stat.mtimeMs < incompleteMs;
  } catch {
    return false;
  }
}

async function readJobStore(jobsDir, { io = fs, incompleteMs = DEFAULT_INCOMPLETE_MS, now = Date.now() } = {}) {
  const records = [];
  const issues = [];
  let entries;
  try {
    entries = await io.readdir(jobsDir, { withFileTypes: true });
  } catch (error) {
    if (error.code === "ENOENT") return { scanned: 0, records, issues };
    throw error;
  }
  const folders = entries.filter(entry => entry.isDirectory() && SAFE_ID.test(entry.name));
  for (const folder of folders) {
    const id = folder.name;
    const dir = path.join(jobsDir, id);
    let raw;
    try {
      raw = await io.readFile(path.join(dir, "job.json"), "utf8");
    } catch (error) {
      const category = error.code === "ENOENT"
        ? (await looksLikeIncompleteUpload(dir, io, now, incompleteMs) ? "incomplete_upload" : "missing_file")
        : classifyReadError(error);
      issues.push({ jobId: id, category });
      continue;
    }
    let data;
    try {
      data = JSON.parse(stripBom(raw));
    } catch {
      issues.push({ jobId: id, category: "corrupt_json" });
      continue;
    }
    if (!data || typeof data !== "object" || Array.isArray(data)) {
      issues.push({ jobId: id, category: "invalid_record" });
      continue;
    }
    // A record whose own id disagrees with its folder would make saveJob write a
    // different job's file, so it is reported and left untouched. Legacy records
    // that predate the id field are normalized to the folder id instead.
    if (data.id === undefined || data.id === null || data.id === "") {
      data.id = id;
    } else if (String(data.id) !== id || !SAFE_ID.test(String(data.id))) {
      issues.push({ jobId: id, category: "invalid_record" });
      continue;
    }
    records.push({ id, data, raw: stripBom(raw) });
  }
  return { scanned: folders.length, records, issues };
}

function createDataHealth({ now = () => new Date().toISOString() } = {}) {
  const issues = new Map();

  function add(jobId, code, stage) {
    if (stage === "load" && !LOAD_CODES.includes(code)) return;
    if (stage === "persist" && !/^[A-Z0-9_]{1,24}$/.test(code)) return;
    const id = safeJobId(jobId);
    const retryable = stage === "persist"
      ? TRANSIENT_CODES.has(code)
      : RETRYABLE_CODES.has(code);
    // Persist failures are keyed per job so a later success can resolve them;
    // load issues are immutable facts about the startup scan.
    const key = stage === "persist"
      ? "persist|" + (id || "") + "|" + code
      : (id || "") + "|" + stage + "|" + code;
    issues.set(key, { jobId: id, code, stage, retryable });
    if (issues.size > MAX_TRACKED_ISSUES) {
      // Drop the oldest entry (Map preserves insertion order) to stay bounded.
      const oldest = issues.keys().next().value;
      if (oldest !== undefined) issues.delete(oldest);
    }
  }

  return {
    recordScan(result) {
      if (!result) return;
      for (const issue of result.issues || []) add(issue.jobId, issue.category, "load");
    },
    recordIssue(jobId, code) { add(jobId, code, "load"); },
    recordPersistFailure(jobId, error) {
      add(jobId, safeErrorCode(error), "persist");
    },
    // A successful durable write clears this job's outstanding persist issues;
    // a transient disk error must not keep health red forever.
    recordPersistSuccess(jobId) {
      const id = safeJobId(jobId);
      const prefix = "persist|" + (id || "") + "|";
      for (const key of [...issues.keys()]) if (key.startsWith(prefix)) issues.delete(key);
    },
    // Public, path-free summary in the frozen cross-module schema.
    snapshot() {
      const all = [...issues.values()];
      const warnings = all.filter(issue => WARNING_CODES.has(issue.code) || (issue.stage === "persist" && issue.retryable));
      const errors = all.filter(issue => !warnings.includes(issue));
      return {
        schemaVersion: SCHEMA_VERSION,
        checkedAt: now(),
        issueCount: all.length,
        errorCount: errors.length,
        warningCount: warnings.length,
        issues: all.slice(0, MAX_ISSUES).map(issue => ({
          jobId: issue.jobId, code: issue.code, stage: issue.stage, retryable: issue.retryable
        }))
      };
    }
  };
}

module.exports = { LOAD_CODES, MAX_ISSUES, SCHEMA_VERSION, classifyReadError, createDataHealth, readJobStore };
