"use strict";
const TIMING_KEYS = ["captureMs","duplicateMs","cropMs","sourceExportMs","maskExportMs","maskEncodeMs","totalPsMs","profileMs","sourceSaveMs"];
function captureTimings(input = {}) {
  const result = {};
  for (const key of TIMING_KEYS) if (Number.isFinite(input[key]) && input[key] >= 0) result[key] = Math.round(input[key]);
  return {captureMs:0,...result};
}
function recoveryFor(job) {
  const urls = Array.isArray(job.batchResultUrls) && job.batchResultUrls.length > 0 || !!job.backendResultUrl || !!job.pendingImageDownload;
  if (job.status === "unknown" || job.status === "importing" || (job.status === 'cancelled' && mayHaveSubmitted(job))) return {action:"query",label:job.waitingStopped?'恢复原任务结果':'查询原任务',submissionSafe:false,state:job.recoveryState||'waiting',unknownSince:job.unknownSince||null};
  if(job.status === "uploading" && (!job.sourceReady || !job.maskReady || job.hasExtraImage&&!job.extraReady))return {action:"resume",phase:"upload",label:"继续传入原素材",submissionSafe:true};
  if (job.status !== "failed") return null;
  if (urls) return {action:"resume",phase:"download",label:"继续下载原结果",submissionSafe:true};
  if(job.failureCode==='pre_submission_configuration'&&job.submissionSent===false&&job.submissionState==='not_submitted')return {action:'resume',phase:'prepare',label:'继续准备原任务',submissionSafe:true};
  // A resolved failure (Flow reported its own terminal error tile) already spent
  // this job's one-shot submit receipt, so re-queueing the same id could never
  // attach again. Those are re-sent as a new job via 再次生成, not resumed.
  if (job.failureCode && job.retrySafe === true) return {action:"query",label:"查询原任务",submissionSafe:false};
  if (job.retrySafe === true) return {action:"resume",phase:"prepare",label:"继续准备原任务",submissionSafe:true};
  return {action:"query",label:"查询原任务",submissionSafe:false};
}
function lifecycleSnapshot(job) {
  return {schemaVersion:1,phase:job.status,operationId:job.operationId || job.id,
    failureCode:job.failureCode || null,submission:job.batchResultUrls?.length ? "confirmed" : job.status === "unknown" ? "unknown" : job.submissionState || "unconfirmed",
    waitingStopped:job.waitingStopped===true,unknownSince:job.unknownSince||null,recoveryState:job.recoveryState||null,recoveryRequestedAt:job.recoveryRequestedAt||null};
}
function mayHaveSubmitted(job){
  if(job.submissionSent===true||job.submissionState==='confirmed'||job.backendResultUrl||job.pendingImageDownload||job.batchResultUrls?.length)return true;
  if(job.status==='failed'&&job.failureCode==='pre_submission_configuration'&&job.submissionSent===false&&job.submissionState==='not_submitted')return false;
  return !!job.browserInput||['generating','downloading','unknown'].includes(job.status);
}
function cancelJob(job){
  if(['ready','imported'].includes(job.status))return job;
  const stamp=new Date().toISOString(),submitted=mayHaveSubmitted(job);
  job.cancellation=job.cancellation||{mode:submitted?'stop_waiting':'cancel_queue',requestedAt:stamp};
  job.waitingStopped=submitted;job.status=submitted?'unknown':'cancelled';
  if(submitted){job.submissionSent=true;job.submissionState=job.submissionState==='confirmed'?'confirmed':'unknown';job.unknownSince=job.unknownSince||stamp;job.recoveryState=job.recoveryState||'waiting';}
  job.error=null;job.updatedAt=stamp;return job;
}
function validEditMode(value){if(value===undefined)return 'auto';if(!['auto','repair','text','remove','replace','outpaint'].includes(value))throw Object.assign(new Error('编辑模式无效。'),{status:400});return value;}
module.exports={captureTimings,recoveryFor,lifecycleSnapshot,validEditMode,mayHaveSubmitted,cancelJob};
