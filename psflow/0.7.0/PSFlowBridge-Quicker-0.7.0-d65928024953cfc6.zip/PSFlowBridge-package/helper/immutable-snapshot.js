"use strict";
const fs=require('node:fs/promises');
// Only use for completed snapshot PNGs/raw masks. Writers must create a new
// snapshot rather than update linked files. Deleting one job only unlinks it.
async function shareSnapshot(source,target){
  const stat=await fs.lstat(source);if(!stat.isFile()||stat.isSymbolicLink())throw Error('原素材文件无效，已保留任务。');
  try{await fs.link(source,target);return 'linked';}
  catch(error){
    if(error.code==='EEXIST'){
      const dst=await fs.lstat(target);if(!dst.isFile()||dst.isSymbolicLink())throw error;
      if(stat.size===dst.size&&(stat.ino===dst.ino&&stat.dev===dst.dev||require('node:crypto').createHash('sha256').update(await fs.readFile(source)).digest('hex')===require('node:crypto').createHash('sha256').update(await fs.readFile(target)).digest('hex')))return 'existing';
      throw Object.assign(Error('中断快照与原素材不同，已保留两份文件。'),{status:409});
    }
    if(!['EXDEV','EPERM','ENOTSUP','EACCES','EMLINK'].includes(error.code))throw error;await fs.copyFile(source,target,require('node:fs').constants.COPYFILE_EXCL);return 'copied';
  }
}
module.exports={shareSnapshot};
