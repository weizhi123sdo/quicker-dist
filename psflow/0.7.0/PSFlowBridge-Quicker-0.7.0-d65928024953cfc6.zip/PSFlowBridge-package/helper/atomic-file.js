"use strict";
const fs = require("node:fs/promises");
const crypto = require("node:crypto");
const RETRYABLE = new Set(["EPERM", "EACCES", "EBUSY"]);

async function writeAtomically(target, data, io = fs) {
  const temporary = target + "." + crypto.randomUUID() + ".tmp";
  try {
    await io.writeFile(temporary, data);
    for (let attempt = 0; ; attempt++) {
      try {
        await io.rename(temporary, target);
        break;
      } catch (error) {
        // Windows file readers and scanners can briefly prevent replacement.
        // Keep the original intact; retry the same snapshot for at most 620 ms.
        if (!RETRYABLE.has(error.code) || attempt >= 5) throw error;
        await new Promise(resolve => setTimeout(resolve, 20 * (2 ** attempt)));
      }
    }
  } finally {
    await io.unlink(temporary).catch(() => {});
  }
}

async function writeTextAtomically(target, text, io = fs) {
  return writeAtomically(target, text, io);
}

async function writeBufferAtomically(target, buffer, io = fs) {
  return writeAtomically(target, buffer, io);
}

module.exports = { writeTextAtomically, writeBufferAtomically, writeAtomically };
