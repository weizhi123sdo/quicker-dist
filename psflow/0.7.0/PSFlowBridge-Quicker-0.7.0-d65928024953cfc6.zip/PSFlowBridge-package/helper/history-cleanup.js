"use strict";

const DAY_MS = 86400000;
const AGE_DAYS = Object.freeze({ older3: 3, older7: 7, older30: 30 });

function invalid(message, code, status) {
  return Object.assign(new Error(message), { code, status });
}

// The caller supplies one cutoff for the entire batch, so records cannot age
// into the selection while the user is confirming it.
function checkCleanup(job, cleanup, now = Date.now()) {
  if (!cleanup || typeof cleanup !== "object" || Array.isArray(cleanup))
    throw invalid("清理条件无效。", "invalid_cleanup", 400);
  const { mode, cutoff } = cleanup;
  const days = AGE_DAYS[mode];
  if (mode !== "failed" && mode !== "all" && !days)
    throw invalid("清理条件无效。", "invalid_cleanup", 400);
  if (days && (!Number.isFinite(cutoff) || cutoff < 0 || cutoff > now - days * DAY_MS))
    throw invalid("清理截止时间无效，未删除记录。", "invalid_cutoff", 400);
  if (job.favorite === true || job.isFavorite === true)
    throw invalid("收藏记录已跳过，请先取消收藏再批量清理。", "favorite_protected", 409);
  const created = Date.parse(job.createdAt);
  if ((mode === "failed" && job.status !== "failed") ||
      (days && (!Number.isFinite(created) || created > cutoff)))
    throw invalid("记录已不符合清理条件，未删除。", "cleanup_mismatch", 409);
}

module.exports = { checkCleanup };
