(function(root,factory){
  'use strict';
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.DocumentIdentity=api;
})(typeof globalThis==='undefined'?this:globalThis,function(){
  'use strict';
  function normalizePath(value){
    if(typeof value!=='string')return '';
    const p=value.replace(/\//g,'\\');
    if(!/^(?:[a-z]:\\|\\\\[^\\]+\\[^\\]+)/i.test(p))return '';
    const prefix=p.startsWith('\\\\')?'\\\\':p.slice(0,3),parts=p.slice(prefix.length).split('\\'),out=[];
    for(const part of parts){if(!part||part==='.')continue;if(part==='..'){out.pop();continue;}out.push(part);}
    return (prefix+out.join('\\')).toLowerCase();
  }
  function normalizeDocument(doc){
    if(!doc||typeof doc!=='object')return null;
    const id=Number(doc.documentID||doc.id);
    return {documentID:Number.isInteger(id)&&id>0?id:'',documentName:String(doc.documentName||doc.name||''),documentPath:normalizePath(doc.documentPath||doc.path),documentSession:String(doc.documentSession||doc.psSession||'')};
  }
  function sameDocument(a,b){
    a=normalizeDocument(a);b=normalizeDocument(b);
    if(!a||!b)return false;
    if(a.documentSession&&a.documentSession===b.documentSession&&a.documentID&&b.documentID)return a.documentID===b.documentID;
    return !!(a.documentPath&&a.documentPath===b.documentPath);
  }
  function identityKey(doc){
    const d=normalizeDocument(doc);
    if(!d)return 'unknown';
    if(d.documentSession&&d.documentID)return 'session:'+d.documentSession+':'+d.documentID;
    return d.documentPath?'path:'+d.documentPath:'unknown';
  }
  function sameHistoryDocument(a,b){
    if(sameDocument(a,b))return true;
    a=normalizeDocument(a);b=normalizeDocument(b);
    return !!(a&&b&&a.documentPath&&a.documentPath===b.documentPath);
  }
  return {normalizeDocument,normalizePath,sameDocument,sameHistoryDocument,identityKey};
});
