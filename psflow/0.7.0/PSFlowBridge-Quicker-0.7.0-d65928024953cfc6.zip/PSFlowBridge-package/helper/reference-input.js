"use strict";
const sharp = require('sharp');

function protectBoundary(mask, width, height, radius) {
  const horizontal = Buffer.alloc(mask.length), protectedMask = Buffer.alloc(mask.length);
  for (let y = 0; y < height; y++) {
    let count = 0;
    for (let x = 0; x <= Math.min(radius, width - 1); x++) count += mask[y * width + x] > 0 ? 1 : 0;
    for (let x = 0; x < width; x++) {
      horizontal[y * width + x] = count ? 255 : 0;
      if (x - radius >= 0) count -= mask[y * width + x - radius] > 0 ? 1 : 0;
      if (x + radius + 1 < width) count += mask[y * width + x + radius + 1] > 0 ? 1 : 0;
    }
  }
  for (let x = 0; x < width; x++) {
    let count = 0;
    for (let y = 0; y <= Math.min(radius, height - 1); y++) count += horizontal[y * width + x] > 0 ? 1 : 0;
    for (let y = 0; y < height; y++) {
      protectedMask[y * width + x] = count ? 255 : 0;
      if (y - radius >= 0) count -= horizontal[(y - radius) * width + x] > 0 ? 1 : 0;
      if (y + radius + 1 < height) count += horizontal[(y + radius + 1) * width + x] > 0 ? 1 : 0;
    }
  }
  return protectedMask;
}

function projectMaskSupport(mask, sourceW, sourceH, width, height) {
  // Forward projection keeps even a one-pixel feathered island when shrinking.
  // This mask only guides drawing; Photoshop's original grayscale mask stays intact.
  const out = Buffer.alloc(width * height);
  for (let y = 0; y < sourceH; y++) {
    for (let x = 0; x < sourceW; x++) {
      if (mask[y * sourceW + x] > 0) {
        const xx = Math.min(width - 1, Math.floor(x * width / sourceW));
        const yy = Math.min(height - 1, Math.floor(y * height / sourceH));
        out[yy * width + xx] = 255;
      }
    }
  }
  return out;
}

function exteriorMask(mask, width, height) {
  const outside = Buffer.alloc(mask.length);
  const queue = new Uint32Array(mask.length);
  let head = 0, tail = 0;
  const add = i => {
    if (!mask[i] && !outside[i]) {
      outside[i] = 1;
      queue[tail++] = i;
    }
  };
  for (let x = 0; x < width; x++) {
    add(x);
    add((height - 1) * width + x);
  }
  for (let y = 0; y < height; y++) {
    add(y * width);
    add(y * width + width - 1);
  }
  while (head < tail) {
    const i = queue[head++];
    const x = i % width;
    const y = Math.floor(i / width);
    if (x) add(i - 1);
    if (x + 1 < width) add(i + 1);
    if (y) add(i - width);
    if (y + 1 < height) add(i + width);
  }
  return outside;
}

async function selectionReference(source, maskBytes, width, height, options = {}) {
  const raw = await sharp(source).resize(width, height, { fit: 'fill' }).ensureAlpha().raw().toBuffer();
  const mask = maskBytes ? await sharp(maskBytes).removeAlpha().extractChannel(0).resize(width, height, { kernel: 'nearest' }).toColourspace('b-w').raw().toBuffer() : null;
  const sum = [0, 0, 0];
  let weights = 0;
  const stride = Math.max(1, Math.floor(width * height / 4096));
  for (let i = 0; i < width * height; i += stride) {
    const weight = (mask ? mask[i] / 255 : 1) * raw[i * 4 + 3] / 255;
    weights += weight;
    for (let c = 0; c < 3; c++) sum[c] += raw[i * 4 + c] * weight;
  }
  const mean = sum.map(x => weights ? x / weights : 128);
  const color = mean.map(x => x >= 128 ? 0 : 255);
  const rgb = Buffer.alloc(width * height * 3);
  // The soft selection controls placement, never contamination by the guide color.
  const protectedMask = mask ? protectBoundary(mask, width, height, 12) : null;
  const region = options.contextRegion;
  for (let i = 0; i < width * height; i++) {
    const x = i % width;
    const y = Math.floor(i / width);
    const context = region && (x < region.left || y < region.top || x >= region.left + region.width || y >= region.top + region.height);
    const weight = (context || !protectedMask || protectedMask[i] ? 1 : 0) * raw[i * 4 + 3] / 255;
    for (let c = 0; c < 3; c++) rgb[i * 3 + c] = Math.round(raw[i * 4 + c] * weight + color[c] * (1 - weight));
  }
  const image = await sharp(rgb, { raw: { width, height, channels: 3 } }).png().toBuffer();
  return { image, color, hex: '#' + color.map(x => x.toString(16).padStart(2, '0')).join('') };
}

async function outlineReference(source, maskBytes, width, height, options = {}) {
  const raw = await sharp(source).resize(width, height, { fit: 'fill' }).flatten({ background: '#ffffff' }).removeAlpha().raw().toBuffer();
  const mask = await sharp(maskBytes).removeAlpha().extractChannel(0).resize(width, height, { kernel: 'nearest' }).toColourspace('b-w').raw().toBuffer();
  if (!mask.some(v => v > 0)) throw Object.assign(new Error('选区蒙版没有有效内容，未提交生成。'), { code: 'mask_empty' });
  const gap = options.gapPx ?? 6, line = options.linePx ?? 2;
  const inner = protectBoundary(mask, width, height, gap);
  const outer = protectBoundary(mask, width, height, gap + line);
  const ring = Buffer.alloc(mask.length);
  const sum = [0, 0, 0];
  let count = 0;
  for (let i = 0; i < mask.length; i++) {
    if (outer[i] && !inner[i]) {
      ring[i] = 255;
      count++;
      for (let c = 0; c < 3; c++) sum[c] += raw[i * 3 + c];
    }
  }
  if (!count) throw Object.assign(new Error('参考图外缘不足，无法标记选区，未提交生成。'), { code: 'guide_empty' });
  const mean = sum.map(v => count ? v / count : 128);
  const palette = [[0, 190, 255], [255, 60, 180], [255, 200, 40]];
  const color = palette.reduce((best, c) => c.reduce((s, v, i) => s + (v - mean[i]) ** 2, 0) > best.reduce((s, v, i) => s + (v - mean[i]) ** 2, 0) ? c : best, palette[0]);
  const outside = exteriorMask(mask, width, height);
  const innerColor = palette.find(c => c !== color);
  let innerPixels = 0;
  for (let i = 0; i < ring.length; i++) {
    if (ring[i]) {
      const paint = outside[i] ? color : innerColor;
      if (!outside[i]) innerPixels++;
      for (let c = 0; c < 3; c++) raw[i * 3 + c] = paint[c];
    }
  }
  const image = await sharp(raw, { raw: { width, height, channels: 3 } }).png().toBuffer();
  return {
    image,
    color,
    hex: '#' + color.map(x => x.toString(16).padStart(2, '0')).join(''),
    innerColor: innerPixels ? innerColor : null,
    hasPreservedIslands: innerPixels > 0,
    gapPx: gap,
    linePx: line,
    guideMask: ring,
    guidePixels: count
  };
}

function editIntents(prompt) {
  const text = String(prompt || '').replace(/(?:不要|禁止|无需|不必|别)(?:再)?(?:删除|移除|去掉|去除|扩图|扩展|添加文字)/g, '');
  const intents = [];
  if (/去(?:掉|除|掉所有)?(?:文字|字样|字幕|水印)|删(?:除|掉).{0,8}(?:文字|字样|字幕)|擦(?:除|掉).{0,8}(?:文字|水印)|remove\s+(?:text|watermark)/i.test(text)) intents.push('text');
  if (/删除|移除|去掉|去除|擦除|抹掉|remove|erase/i.test(text)) intents.push('remove');
  if (/扩图|扩展(?:画布|背景|图像)|向.{0,4}扩|补全(?:背景|画面)|outpaint|extend\s+(?:canvas|background)/i.test(text)) intents.push('outpaint');
  if (/修补|修复|补洞|融合|接缝|repair|retouch/i.test(text)) intents.push('repair');
  if (/替换|换成|改成|更换|replace|change\s+(?:to|into)/i.test(text)) intents.push('replace');
  return intents;
}

function guidedPrompt(prompt, transform, editMode = 'auto') {
  const intents = editMode === 'auto' ? editIntents(prompt) : [editMode];
  const intentRules = [];
  if (intents.includes('text')) intentRules.push('去文字：移除用户指定的文字及其阴影、描边和残留，恢复其后的真实材质与纹理；保留用户明确要求保留的其他文字。');
  if (intents.includes('remove')) intentRules.push('删除内容：允许改变被删除对象的轮廓与占据区域，用周边背景连续补全遮挡处，不保留被删除对象的虚影，不新增替代物体。');
  if (intents.includes('outpaint')) intentRules.push('扩图：在已有画布的指定编辑区域内延续场景、透视、光照和纹理；保持原有内容坐标与尺寸，不通过缩小原图伪造扩图。比例定位纯色不属于可扩展区域；此操作不改变 Photoshop 画布大小。');
  if (intents.includes('repair')) intentRules.push('修补：只修复指定缺陷，保持周边材质、细节与噪点尺度，消除接缝、光晕、色差和重复纹理。');
  if (intents.includes('replace')) intentRules.push('替换：只将用户指定内容替换为目标内容，保持原位置、透视、接触关系、光照与阴影；允许目标本身形状变化，但不移动周边内容，不留下原物体残影。');

  if (transform && transform.hasExtraImage) {
    return [
      '输入包含两张图像：第一张为 Photoshop 当前选区底图，第二张为用户上传的附加参考图。',
      '以第一张底图作为主编辑底图与空间基准，保持未要求改变的画面构图、透视、原图坐标与背景。',
      '根据用户要求，将第二张参考图中的元素、特征、服装、材质或风格自然融入第一张底图的选区内。',
      '参考图仅作为内容/风格指引，不要把参考图的背景底色、杂物、黑边或边框复制到底图中。',
      '输出必须与第一张底图的环境光照、色调和视角自然衔接，贴回原图坐标。',
      ...intentRules,
      '用户要求：' + prompt
    ].join('\n');
  }

  const guide = transform && transform.guideColor;
  if (!guide) {
    return [
      '以参考图为编辑底图。',
      '只按用户要求修改指定内容。',
      ...intentRules,
      '保留未要求改变的画面构图、物体形状、视角与风格；除非用户明确要求整体改风格，不要默认重绘。',
      '用户要求优先于通用保形规则。用户要求：' + prompt
    ].join('\n');
  }

  const color = '#' + guide.map(x => x.toString(16).padStart(2, '0')).join('');

  if (transform && transform.referencePolicy === 'selection-outline') {
    const r = transform.editRegion;
    return [
      '对局部原图进行原位编辑；输出将按原坐标贴回 Photoshop。',
      '参考图中的 ' + color + ' 外轮廓线只是编辑区域指引，不是场景物体。它位于真实选区外侧；只按用户要求编辑被外轮廓限定的真实选区，线框与选区之间的缓冲带保持原图。',
      '标记线宽 ' + (transform.guideLinePx ?? 2) + ' 像素，距离真实选区至少 ' + (transform.guideGapPx ?? 6) + ' 像素；不要把这段缓冲背景当成需要编辑的内容。',
      transform.hasPreservedIslands ? '内部 ' + ('#' + transform.guideInnerColor.map(x => x.toString(16).padStart(2, '0')).join('')) + ' 保留轮廓围住未选中的原图内容，这些内圈内部必须保持不变。实际编辑区域位于外轮廓和这些保留内圈之间；扩图时补全外围空白，禁止重绘内圈中央已有商品、人物、文字和图案。' : '没有内圈保留区域时，按外轮廓内的选区编辑。',
      '输出必须移除这条标记线及所有内部保留轮廓线，以原有背景纹理自然还原其位置；不保留、复制或扩散任何标记颜色，不生成边框、描边、光晕或纯色遮挡。',
      '保持输出整体长宽比、原图坐标、未要求改变的物体位置与尺寸；禁止重新构图、自动缩放、额外裁切或移动画面。用户明确指定的删除、替换与形状改动优先于通用保形限制。',
      '参考画布 ' + transform.paddedW + '×' + transform.paddedH + '；原图内容左 ' + transform.left + '、上 ' + transform.top + '、宽 ' + transform.width + '、高 ' + transform.height + '。外围补边仅用于比例与线框定位，不是需要扩图的编辑目标，不改变各边界相对位置。',
      r ? '编辑区域外接矩形：左 ' + r.left + '、上 ' + r.top + '、宽 ' + r.width + '、高 ' + r.height + '；不规则选区以实际轮廓形状为准，内部保留圈不属于选区。' : '编辑目标为线框限定的选区，内部保留圈不属于选区。',
      '保留框外原图的光照、材质、透视和纹理。修改内容与真实边缘上下文连续衔接，不重绘未要求修改的区域。除非用户明确要求，否则不新增文字；不添加水印。',
      ...intentRules.map(rule => rule.replace('比例定位纯色不属于可扩展区域', '外围比例补边不属于可扩展区域')),
      '用户要求：' + prompt
    ].join('\n');
  }

  return [
    '对上传的局部参考图做原位编辑，输出将按同一坐标贴回原图。',
    '保持输出整体长宽比与原图坐标。未要求改变的内容保持原视角、轮廓、位置与大小；禁止重新构图、额外裁切或自动放大。用户明确要求删除、替换、变形的目标可按要求改变，通用保形规则不得阻止用户编辑。',
    '纯色 ' + color + ' 区域是选区外遮挡与比例定位标记，不是场景内容，保持其位置、边界和颜色，不补画、不裁掉、不将此颜色延伸到编辑主体。',
    '内容外接矩形在参考图 ' + transform.paddedW + '×' + transform.paddedH + ' 中的位置为左 ' + transform.left + '、上 ' + transform.top + '、宽 ' + transform.width + '、高 ' + transform.height + '；保持各边界的相对位置。',
    '只修改用户要求的内容，其他颜色、光照、纹理和边缘保持一致。除非用户明确要求添加文字，否则不新增文字；不添加水印或装饰边框。',
    ...intentRules,
    '保留真实边缘缓冲区和外围原图的光照与纹理，编辑内容自然衔接；纯色标记不得进入有效内容，不添加描边。',
    '用户要求：' + prompt
    ].join('\n');
}

module.exports = {
  selectionReference,
  outlineReference,
  protectBoundary,
  projectMaskSupport,
  guidedPrompt,
  editIntents
};
