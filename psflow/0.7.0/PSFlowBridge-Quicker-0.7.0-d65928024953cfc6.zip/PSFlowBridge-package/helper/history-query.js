const DocumentIdentity = require('./document-identity');

function filterHistoryByDocument(historyRecords, targetDoc) {
    if (!historyRecords || !targetDoc) return [];
    
    return historyRecords.filter(record => {
        return DocumentIdentity.sameHistoryDocument(record.document || record, targetDoc);
    });
}

function paginate(records, page, pageSize) {
    const offset = (page - 1) * pageSize;
    return records.slice(offset, offset + pageSize);
}

module.exports = {
    filterHistoryByDocument,
    paginate,
    filterHistory
};

function filterHistory(jobs, input) {
    let filtered = Array.isArray(jobs) ? jobs : [];
    const legacy = input === undefined;
    input = input || {};
    if(input.rootJobId){
        const byId=new Map(filtered.map(job=>[job.id,job]));
        const rootOf=job=>{const seen=new Set();while(job&&!seen.has(job.id)){seen.add(job.id);if(job.rootJobId)return job.rootJobId;if(!job.parentJobId)return job.id;const parent=byId.get(job.parentJobId);if(!parent)return job.parentJobId;job=parent;}return null;};
        filtered=filtered.filter(job=>rootOf(job)===input.rootJobId);
    }
    if(input.document !== undefined) filtered=filterHistoryByDocument(filtered,input.document);
    else if(typeof input.documentName==='string'&&input.documentName)filtered=filtered.filter(job=>job.documentName===input.documentName);
    if(input.q){const q=String(input.q).trim().toLowerCase();filtered=filtered.filter(job=>((job.prompt||'')+' '+(job.documentName||'')).toLowerCase().includes(q));}
    if(input.status)filtered=filtered.filter(job=>job.status===input.status);
    if(input.favoritesOnly)filtered=filtered.filter(job=>job.favorite===true||job.isFavorite===true||job.favoritesOnly===true);
    const total=filtered.length,offset=Math.max(0,parseInt(input.offset,10)||0);
    const requested=parseInt(input.limit,10),limit=requested>0?Math.min(100,requested):legacy?total:100;
    const items=filtered.slice(offset,offset+limit),hasMore=offset+limit<total;
    if(legacy){items.total=total;items.hasMore=hasMore;items.items=items;return items;}
    return {items,total,hasMore};
}
