"use strict";
// Durable job persistence with ordered, rollback-safe writes.
//
// Rules enforced here:
//   * Writes for one job are serialized in call order.
//   * Memory may only advance to a snapshot that actually committed.
//   * Only the newest outstanding save may roll memory back. If an older save
//     fails while a newer one is already queued, the newer snapshot decides the
//     final state, so a stale rollback cannot leave memory behind the file.
//   * The original file is never deleted or overwritten by a failed write.
//   * A committed write clears that job's outstanding persist health issues.
//
// `write` is injected so tests can force A-fails / B-succeeds and A-fails /
// B-fails orderings without touching the real disk.
function createJobPersister({ write, jobs, committedJobs, dataHealth, key = job => job.id }) {
  const pending = new Map();
  const latestSeq = new Map();
  let sequence = 0;

  function rollback(job) {
    const id = key(job);
    const raw = committedJobs.get(id);
    if (raw === undefined) {
      // Never persisted: memory must not keep a phantom job.
      if (jobs.get(id) === job) jobs.delete(id);
      return;
    }
    let saved;
    try { saved = JSON.parse(raw); } catch { return; }
    for (const name of Object.keys(job)) delete job[name];
    Object.assign(job, saved);
  }

  async function save(job) {
    const id = key(job);
    if (job.status === "unknown") {
      job.unknownSince = job.unknownSince || new Date().toISOString();
      job.recoveryState = job.recoveryState || "waiting";
    }
    const snapshot = JSON.stringify(job, null, 2);
    const seq = ++sequence;
    latestSeq.set(id, seq);
    const previous = pending.get(id) || Promise.resolve();
    // Preserve transition order when cancellation or an import ACK overlaps a
    // worker save.
    const current = previous.catch(() => {}).then(async () => {
      try {
        await write(job, snapshot);
        committedJobs.set(id, snapshot);
        dataHealth.recordPersistSuccess(id);
      } catch (error) {
        dataHealth.recordPersistFailure(id, error);
        if (latestSeq.get(id) === seq) rollback(job);
        throw error;
      }
    });
    pending.set(id, current);
    try {
      await current;
    } finally {
      if (pending.get(id) === current) pending.delete(id);
      if (latestSeq.get(id) === seq) latestSeq.delete(id);
    }
  }

  return { save, pendingCount: () => pending.size, isPending: id => pending.has(id) };
}

module.exports = { createJobPersister };
