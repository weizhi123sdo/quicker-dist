﻿# PS Flow Bridge 启动器的纯函数助手。这里不启动、不结束任何进程。
Set-StrictMode -Version Latest

function Get-PsFlowRoot {
  param([string]$Root = '')
  if ([string]::IsNullOrWhiteSpace($Root)) { $Root = Join-Path $env:LOCALAPPDATA 'PSFlowBridge' }
  return $Root
}

function Test-IsLoopbackUrl {
  param([string]$Url)
  if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
  try { $uri = [Uri]$Url } catch { return $false }
  if ($uri.Scheme -ne 'http') { return $false }
  if (@('127.0.0.1', 'localhost') -notcontains $uri.Host) { return $false }
  if (-not [string]::IsNullOrWhiteSpace($uri.UserInfo)) { return $false }
  if ($uri.AbsolutePath -ne '/') { return $false }
  if (-not [string]::IsNullOrWhiteSpace($uri.Query)) { return $false }
  if (-not [string]::IsNullOrWhiteSpace($uri.Fragment)) { return $false }
  return $true
}

function Read-BackendConfig {
  param([string]$Root)
  $path = Join-Path $Root 'backend.json'
  if (-not (Test-Path -LiteralPath $path)) { return $null }
  $config = (Get-Content -LiteralPath $path -Raw -ErrorAction Stop) | ConvertFrom-Json -ErrorAction Stop
  function Get-Field([string]$Name) {
    if ($config.PSObject.Properties[$Name]) { return $config.PSObject.Properties[$Name].Value }
    return $null
  }
  $enabled = [bool](Get-Field 'enabled')
  if (-not $enabled) { return [pscustomobject]@{ enabled = $false } }
  $baseUrl = [string](Get-Field 'baseUrl')
  if (-not (Test-IsLoopbackUrl $baseUrl)) { throw 'backend.json 的 baseUrl 必须是本机 http 地址。' }
  $apiKey = [string](Get-Field 'apiKey')
  if ($apiKey.Length -lt 16) { throw 'backend.json 缺少可用的 apiKey。' }
  $model = [string](Get-Field 'model')
  return [pscustomobject]@{
    enabled   = $true
    baseUrl   = $baseUrl
    apiKey    = $apiKey
    model     = $model
    timeoutMs = (Get-Field 'timeoutMs')
  }
}

function Read-PairingToken {
  param([string]$Root)
  $path = Join-Path $Root 'config.json'
  if (-not (Test-Path -LiteralPath $path)) { return $null }
  try {
    $config = (Get-Content -LiteralPath $path -Raw -ErrorAction Stop) | ConvertFrom-Json -ErrorAction Stop
  } catch { return $null }
  if (-not $config.PSObject.Properties['pairingToken']) { return $null }
  $token = [string]$config.PSObject.Properties['pairingToken'].Value
  if ([string]::IsNullOrWhiteSpace($token)) { return $null }
  return $token
}

function Get-PsFlowProcess {
  param([int]$ProcessId)
  if ($ProcessId -le 0) { return $null }
  return (Get-CimInstance Win32_Process -Filter "ProcessId=$ProcessId" -ErrorAction SilentlyContinue)
}

function Get-PortListeners {
  param([int]$Port)
  $connections = @(Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue)
  return @($connections | ForEach-Object { $_.OwningProcess } | Sort-Object -Unique)
}

# 固定的 venv python.exe 是转发外壳：它会再启动基础解释器，所以 8787 的真正监听者
# 可能是它的子进程，而子进程的可执行文件在运行时目录之外。
# 只要监听者或它的父进程属于固定运行时，就认定为 PS Flow 自己的服务。
function Test-BackendProcess {
  param([int]$ProcessId, [string]$Root, [int]$Port = 8787)
  $process = Get-PsFlowProcess -ProcessId $ProcessId
  if (-not $process) { return $false }
  $commandLine = [string]$process.CommandLine
  if ([string]::IsNullOrWhiteSpace($commandLine)) { return $false }
  if ($commandLine -notmatch 'flow_cli\.api_server') { return $false }
  if ($commandLine -notmatch ('--port\s+{0}' -f $Port)) { return $false }
  $runtime = (Join-Path $Root 'runtime\flow-api').TrimEnd('\')
  $chain = @($process)
  if ($process.ParentProcessId) {
    $parent = Get-PsFlowProcess -ProcessId $process.ParentProcessId
    if ($parent) { $chain += $parent }
  }
  foreach ($candidate in $chain) {
    $executable = [string]$candidate.ExecutablePath
    if ($executable -and $executable.StartsWith($runtime + '\', [StringComparison]::OrdinalIgnoreCase)) { return $true }
  }
  return $false
}

function Test-HelperProcess {
  param([int]$ProcessId, [string]$HelperDir)
  $process = Get-PsFlowProcess -ProcessId $ProcessId
  if (-not $process) { return $false }
  $commandLine = [string]$process.CommandLine
  if ([string]::IsNullOrWhiteSpace($commandLine)) { return $false }
  if ($commandLine -notmatch 'server\.js') { return $false }
  return $commandLine.ToLowerInvariant().Contains($HelperDir.ToLowerInvariant())
}

function Test-OwnedHelperProcess {
  param([int]$ProcessId, [string]$Root, [string]$HelperDir)
  if (Test-HelperProcess $ProcessId $HelperDir) { return $true }
  $process = Get-PsFlowProcess $ProcessId
  if (-not $process) { return $false }
  $prefix = [regex]::Escape([IO.Path]::GetFullPath((Join-Path $Root 'apps')).TrimEnd('\') + '\')
  return [string]$process.CommandLine -match ('(?:^|["\s])' + $prefix + '[0-9a-f]{16}(?:-repair-[0-9a-f]+)?\\PSFlowBridge-package\\helper\\server\.js(?:["\s]|$)')
}

function Get-JsonResponse {
  param([string]$Uri, [int]$TimeoutSec = 3, [hashtable]$Headers = @{})
  try {
    $response = Invoke-WebRequest -Uri $Uri -Headers $Headers -TimeoutSec $TimeoutSec -UseBasicParsing -ErrorAction Stop
  } catch { return $null }
  try { $body = $response.Content | ConvertFrom-Json -ErrorAction Stop }
  catch { return $null }
  return [pscustomobject]@{ status = [int]$response.StatusCode; body = $body }
}

# 真正判断“可用”必须问服务自己：后端要 /health 的 app = PSFlowBridge-FlowAPI。
function Test-BackendIdentity {
  param([string]$BaseUrl, [int]$TimeoutSec = 3, [string]$ExpectedRuntimeBuildId = '')
  $response = Get-JsonResponse -Uri ($BaseUrl + '/health') -TimeoutSec $TimeoutSec -Headers @{ Host = '127.0.0.1:8787' }
  if (-not $response) { return $false }
  if ($response.status -ne 200) { return $false }
  if (-not $response.body.PSObject.Properties['app']) { return $false }
  if (([string]$response.body.app) -ne 'PSFlowBridge-FlowAPI') { return $false }
  if ((Get-HealthField $response.body 'draining') -eq $true) { return $false }
  if (-not $ExpectedRuntimeBuildId) { return $false }
  return (Compare-ServiceBuildId $ExpectedRuntimeBuildId (Get-HealthField $response.body 'runtimeBuildId')) -eq 'match'
}

# 助手要 /api/health 的 app = PSFlowBridge；身份以 buildId 为准，版本号只做展示，绝不打印配对码。
function Test-HelperIdentity {
  param([string]$BaseUrl, [string]$Root, [int]$TimeoutSec = 3, [string]$ExpectedBuildId = '')
  $token = Read-PairingToken -Root $Root
  if (-not $token) { return $false }
  $response = Get-JsonResponse -Uri ($BaseUrl + '/api/health') -TimeoutSec $TimeoutSec `
    -Headers @{ Host = ([Uri]$BaseUrl).Authority; Authorization = ('Bearer ' + $token) }
  if (-not $response) { return $false }
  if ($response.status -ne 200) { return $false }
  if (-not $response.body.PSObject.Properties['app']) { return $false }
  if (-not $response.body.PSObject.Properties['version']) { return $false }
  if ([string]$response.body.app -ne 'PSFlowBridge') { return $false }
  if (-not [string]::IsNullOrWhiteSpace($ExpectedBuildId)) {
    if (-not $response.body.PSObject.Properties['buildId']) { return $false }
    $verdict = Compare-ServiceBuildId -Expected $ExpectedBuildId -Observed ([string]$response.body.buildId)
    if ($verdict -ne 'match') { return $false }
  }
  return $true
}

# /api/health 响应体（仅 200），用于占用端口的身份取证；配对码只用于请求。
function Get-HelperHealthBody {
  param([string]$BaseUrl, [string]$Root, [int]$TimeoutSec = 3)
  $token = Read-PairingToken -Root $Root
  if (-not $token) { return $null }
  $response = Get-JsonResponse -Uri ($BaseUrl + '/api/health') -TimeoutSec $TimeoutSec `
    -Headers @{ Host = ([Uri]$BaseUrl).Authority; Authorization = ('Bearer ' + $token) }
  if (-not $response) { return $null }
  if ($response.status -ne 200) { return $null }
  return $response.body
}

# 包目录名只允许安全文件名字符，杜绝 current 指针带来的路径穿越。
function Test-SafeAppName {
  param([string]$Name)
  if ([string]::IsNullOrWhiteSpace($Name)) { return $false }
  if ($Name.Length -gt 80) { return $false }
  if ($Name -match '[/\\]') { return $false }
  if ($Name -match '[\x00-\x1f]') { return $false }
  if ($Name -eq '.' -or $Name -eq '..') { return $false }
  if ($Name.EndsWith('.') -or $Name.EndsWith(' ')) { return $false }
  return $Name -match '^[A-Za-z0-9][A-Za-z0-9._-]*$'
}

function Resolve-AppsCurrentName {
  param([string]$AppsDir, [ValidateSet('current', 'previous')][string]$Pointer = 'current')
  $pointerPath = Join-Path $AppsDir $Pointer
  if (-not (Test-Path -LiteralPath $pointerPath -PathType Leaf)) { return '' }
  try {
    $name = (Get-Content -LiteralPath $pointerPath -Raw).Trim()
  } catch { return '' }
  if (-not (Test-SafeAppName -Name $name)) { return '' }
  return $name
}

function Get-InstalledPackageRoot {
  param([string]$AppsDir)
  if ([string]::IsNullOrWhiteSpace($AppsDir)) { throw 'apps 目录为空，无法定位已安装包。' }
  if (-not (Test-Path -LiteralPath $AppsDir -PathType Container)) {
    throw ('未找到已安装包目录 {0}。请先通过 Quicker 动作安装 PSFlowBridge（会生成 apps\current），或直接运行已解压包内的 bootstrap.ps1。' -f $AppsDir)
  }
  $name = Resolve-AppsCurrentName -AppsDir $AppsDir
  if (-not $name) {
    throw ('apps\current 指针缺失或无效：{0}。请重新通过 Quicker 动作安装，或直接运行已解压包内的 bootstrap.ps1。' -f (Join-Path $AppsDir 'current'))
  }
  $packageRoot = Join-Path $AppsDir (Join-Path $name 'PSFlowBridge-package')
  if (-not (Test-Path -LiteralPath (Join-Path $packageRoot 'bootstrap.ps1') -PathType Leaf)) {
    throw ('apps\current 指向的包不完整：{0}。请重新安装 PSFlowBridge。' -f $packageRoot)
  }
  return (Resolve-Path -LiteralPath $packageRoot).Path
}

function Write-AppsCurrentPointer {
  param([string]$AppsDir, [string]$Name, [ValidateSet('current', 'previous')][string]$Pointer = 'current')
  if (-not (Test-SafeAppName -Name $Name)) { throw ('无效的包目录名：{0}' -f $Name) }
  New-Item -ItemType Directory -Force -Path $AppsDir | Out-Null
  $pointerPath = Join-Path $AppsDir $Pointer
  $tempPath = Join-Path $AppsDir ('.current.' + [System.IO.Path]::GetRandomFileName() + '.tmp')
  Set-Content -LiteralPath $tempPath -Value $Name -Encoding ASCII -NoNewline
  try {
    if (Test-Path -LiteralPath $pointerPath) { [IO.File]::Replace($tempPath, $pointerPath, [System.Management.Automation.Language.NullString]::Value) }
    else { [IO.File]::Move($tempPath, $pointerPath) }
  } finally { if (Test-Path -LiteralPath $tempPath) { Remove-Item -LiteralPath $tempPath -Force } }
}

# 纯函数：给出目录名清单，返回应删除的清单。current/previous 保留，
# 不符合安全名字规则的条目一律视为未知目录，绝不进入删除清单。
function Get-AppsPrunePlan {
  param([string[]]$EntryNames, [string]$CurrentName, [string]$PreviousName)
  $keep = @($CurrentName)
  if (-not [string]::IsNullOrWhiteSpace($PreviousName) -and $PreviousName -ne $CurrentName) {
    $keep += $PreviousName
  }
  $plan = @()
  foreach ($entry in $EntryNames) {
    if ($keep -contains $entry) { continue }
    if (Test-SafeAppName -Name $entry) { $plan += $entry }
  }
  return @($plan)
}

# 写入新 current（previous = 旧 current），然后只保留 current + previous。
function Update-AppsHistory {
  param([string]$AppsDir, [string]$CurrentName, [string[]]$ProtectedPaths = @())
  if (-not (Test-SafeAppName -Name $CurrentName)) { throw ('无效的包目录名：{0}' -f $CurrentName) }
  $oldCurrent = Resolve-AppsCurrentName -AppsDir $AppsDir
  $previousName = Resolve-AppsCurrentName -AppsDir $AppsDir -Pointer previous
  if ($oldCurrent -and $oldCurrent -ne $CurrentName) {
    $previousName = $oldCurrent
    Write-AppsCurrentPointer -AppsDir $AppsDir -Name $previousName -Pointer previous
  }
  Write-AppsCurrentPointer -AppsDir $AppsDir -Name $CurrentName

  $appsResolved = (Resolve-Path -LiteralPath $AppsDir).Path.TrimEnd('\')
  $protectedResolved = @()
  foreach ($candidate in @($ProtectedPaths)) {
    try { $protectedResolved += ((Resolve-Path -LiteralPath $candidate).Path.TrimEnd('\')) } catch { }
  }
  $entries = @(Get-ChildItem -LiteralPath $AppsDir -Directory | ForEach-Object { $_.Name })
  $pruned = @()
  $failed = @()
  # Enumeration failure is not evidence that a directory is unused.
  $runningCommands = $null
  try { $runningCommands = @(Get-CimInstance Win32_Process -ErrorAction Stop | ForEach-Object { [string]$_.CommandLine }) }
  catch { $runningCommands = $null }
  foreach ($entry in (Get-AppsPrunePlan -EntryNames $entries -CurrentName $CurrentName -PreviousName $previousName)) {
    $target = Join-Path $AppsDir $entry
    try {
      $resolved = (Resolve-Path -LiteralPath $target).Path.TrimEnd('\')
      if (-not $resolved.StartsWith($appsResolved + '\', [StringComparison]::OrdinalIgnoreCase)) { continue }
      if (@($protectedResolved | Where-Object { $_ -eq $resolved -or $_.StartsWith($resolved + '\', [StringComparison]::OrdinalIgnoreCase) }).Count -gt 0) { continue }
      if ($null -eq $runningCommands) { continue }
      if (@($runningCommands | Where-Object { $_.IndexOf($resolved + '\', [StringComparison]::OrdinalIgnoreCase) -ge 0 }).Count -gt 0) { continue }
      if ((Get-Item -LiteralPath $resolved).Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
      Remove-Item -LiteralPath $resolved -Recurse -Force
      $pruned += $entry
    } catch {
      $failed += $entry
    }
  }
  return @{
    current  = $CurrentName
    previous = $previousName
    pruned   = @($pruned)
    failed   = @($failed)
  }
}

# 三态判定：match / mismatch / unknown（任一侧缺失都视为未知，不允许复用）。
function Compare-ServiceBuildId {
  param([string]$Expected, [string]$Observed)
  if ([string]::IsNullOrWhiteSpace($Expected) -or [string]::IsNullOrWhiteSpace($Observed)) { return 'unknown' }
  if ($Expected.Trim() -eq $Observed.Trim()) { return 'match' }
  return 'mismatch'
}

function Get-HealthBuildId {
  param([object]$HealthBody)
  if ($null -eq $HealthBody) { return '' }
  $prop = $HealthBody.PSObject.Properties['buildId']
  if (-not $prop) { return '' }
  return [string]$prop.Value
}

function Get-HealthField {
  param([object]$Body, [string]$Name)
  if ($null -eq $Body) { return $null }
  $prop = $Body.PSObject.Properties[$Name]
  if ($prop) { return $prop.Value }
  return $null
}

function Get-RuntimePatchNames {
  return @('api_server.py', 'client.py', 'flow_current.py', 'config.py', 'personal_captcha.py', 'window_policy.py', 'service_logging.py')
}

function Get-PsfbFileHash {
  param([string]$Path)
  $sha = [Security.Cryptography.SHA256]::Create()
  $stream = [IO.File]::OpenRead($Path)
  try { return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
  finally { $stream.Dispose(); $sha.Dispose() }
}

function Get-RuntimeBuildId {
  param([string]$PatchDir)
  $hashes = foreach ($name in (Get-RuntimePatchNames)) {
    $file = Join-Path $PatchDir $name
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { return '' }
    Get-PsfbFileHash $file
  }
  $sha = [Security.Cryptography.SHA256]::Create()
  try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::ASCII.GetBytes($hashes -join "`n")))).Replace('-', '').ToLowerInvariant() }
  finally { $sha.Dispose() }
}

# A loaded hash can never be replaced with a hash inferred from disk.
function Get-ServiceUpgradeDecision {
  param([object]$Health, [string]$App, [string]$Expected, [string]$Field = 'buildId')
  if ((Get-HealthField $Health 'app') -ne $App) { return 'conflict' }
  if ((Get-HealthField $Health 'draining') -eq $true) { return 'deferred' }
  if ($Expected -and (Compare-ServiceBuildId $Expected (Get-HealthField $Health $Field)) -eq 'match') { return 'reuse' }
  $active = Get-HealthField $Health 'activeTasks'
  if ($App -eq 'PSFlowBridge') {
    $busy = Get-HealthField $Health 'busy'
    if ($busy -isnot [bool] -or $busy) { return 'deferred' }
    if ($null -eq $active) { $active = 0 }
  }
  if ($null -eq $active -or $active -is [bool] -or [string]$active -notmatch '^\d+$') { return 'deferred' }
  if ([long]$active -ne 0) { return 'deferred' }
  return 'upgrade'
}

function Test-ServiceDrainResponse {
  param([int]$StatusCode, [object]$Body)
  if ($StatusCode -ne 200) { return $false }
  $active = Get-HealthField $Body 'activeTasks'
  if ($null -eq $active -or $active -is [bool] -or [string]$active -notmatch '^0$') { return $false }
  $drained = Get-HealthField $Body 'drained'
  if ($drained -is [bool] -and $drained) { return $true }
  foreach ($field in @('success', 'closed', 'draining')) {
    $value = Get-HealthField $Body $field
    if ($value -isnot [bool] -or -not $value) { return $false }
  }
  return $true
}

function Test-PackageManifest {
  param([string]$PackageRoot)
  try {
    $manifest = Get-Content -LiteralPath (Join-Path $PackageRoot 'manifest.json') -Raw | ConvertFrom-Json
    if ($manifest.schema -ne 'psflowbridge.package/1' -or @($manifest.files).Count -eq 0) { return $false }
    $base = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\') + '\'
    foreach ($record in $manifest.files) {
      if (-not ([string]$record.entry).StartsWith('PSFlowBridge-package/')) { return $false }
      $file = [IO.Path]::GetFullPath((Join-Path $base ([string]$record.entry).Substring(21)))
      if (-not $file.StartsWith($base, [StringComparison]::OrdinalIgnoreCase)) { return $false }
      if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { return $false }
      if ((Get-PsfbFileHash $file) -ne $record.sha256) { return $false }
    }
    return $true
  } catch { return $false }
}

function Sync-RuntimePatches {
  param([string]$PatchDir, [string]$RuntimeDir, [string]$Expected)
  if ((Get-RuntimeBuildId $PatchDir) -ne $Expected) { throw 'Package patches changed during startup.' }
  $stage = Join-Path $RuntimeDir ('.psfb-patches-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $stage | Out-Null
  $replaced = @()
  try {
    foreach ($name in (Get-RuntimePatchNames)) {
      Copy-Item -LiteralPath (Join-Path $PatchDir $name) -Destination (Join-Path $stage $name)
      $target = Join-Path $RuntimeDir $name
      if (Test-Path -LiteralPath $target) { Copy-Item -LiteralPath $target -Destination (Join-Path $stage ($name + '.old')) }
    }
    if ((Get-RuntimeBuildId $stage) -ne $Expected) { throw 'Staged patch hash mismatch.' }
    foreach ($name in (Get-RuntimePatchNames)) {
      $target = Join-Path $RuntimeDir $name
      if (Test-Path -LiteralPath $target) { [IO.File]::Replace((Join-Path $stage $name), $target, [System.Management.Automation.Language.NullString]::Value) }
      else { [IO.File]::Move((Join-Path $stage $name), $target) }
      $replaced += $name
    }
    if ((Get-RuntimeBuildId $RuntimeDir) -ne $Expected) { throw 'Runtime patch hash mismatch.' }
  } catch {
    foreach ($name in $replaced) {
      $backup = Join-Path $stage ($name + '.old')
      if (Test-Path -LiteralPath $backup) { Copy-Item -LiteralPath $backup -Destination (Join-Path $RuntimeDir $name) -Force }
      else { Remove-Item -LiteralPath (Join-Path $RuntimeDir $name) -Force }
    }
    throw
  } finally {
    $resolved = [IO.Path]::GetFullPath($stage)
    if (-not $resolved.StartsWith([IO.Path]::GetFullPath($RuntimeDir).TrimEnd('\') + '\.psfb-patches-', [StringComparison]::OrdinalIgnoreCase)) { throw 'Unsafe patch staging path.' }
    Remove-Item -LiteralPath $resolved -Recurse -Force
  }
}

function Get-PortConflictMessage {
  param([string]$Service, [int]$Port, [string]$ProcessId, [string]$Expected, [string]$Observed)
  return ('端口 {0} 已被不同或不明的{1}占用（PID {2}）。运行中身份：{3}；期望身份：{4}。请先停止旧进程（Stop-Process -Id {2}）或重启电脑后重试；身份未确认前不会静默复用。' -f $Port, $Service, $ProcessId, $Observed, $Expected)
}

# 镜像 helper/api-backend.js 的 status()，纯读取：不启动、不停止、不做 finalize。
function Get-BackendStatus {
  param([string]$Root, [int]$TimeoutSec = 3)
  $offline = [pscustomobject]@{
    configured    = $false
    online        = $false
    loginRequired = $false
    mode          = 'browser'
    model         = ''
    message       = '点击 PS Flow 助手，准备生成服务。'
  }
  try { $config = Read-BackendConfig -Root $Root }
  catch { $offline.message = $_.Exception.Message; return $offline }
  if (-not $config -or -not $config.enabled) { return $offline }

  $result = [pscustomobject]@{
    configured    = $true
    online        = $false
    loginRequired = $true
    mode          = 'api'
    model         = [string]$config.model
    message       = '点击 PS Flow 助手，启动生成服务。'
  }
  if (-not (Test-BackendIdentity -BaseUrl $config.baseUrl -TimeoutSec $TimeoutSec -ExpectedRuntimeBuildId (Get-RuntimeBuildId (Join-Path $Root 'runtime\flow-api\flow_cli')))) {
    $result.message = '生成服务未响应或身份不符，请检查启动入口。'
    return $result
  }
  $result.online = $true
  $setup = Get-JsonResponse -Uri ($config.baseUrl + '/setup/status') -TimeoutSec $TimeoutSec -Headers @{ Host = '127.0.0.1:8787' }
  $ready = $false
  if ($setup -and $setup.status -eq 200) {
    $ready = [bool]$setup.body.has_st -and [bool]$setup.body.project_ready
  }
  $result.loginRequired = -not $ready
  $result.message = if ($result.loginRequired) {
    '登录状态未确认：新版 flow.google.com 兼容待验证，暂不自动创建项目。'
  } else { '已连接，可以提交生成任务。' }
  return $result
}

function Format-StatusText {
  param([object]$Status)
  $state = if ($Status.online -and -not $Status.loginRequired) { '可提交' }
  elseif ($Status.online) { '待确认登录' }
  else { '离线' }
  return ('{0} · {1}' -f $state, $Status.message)
}
