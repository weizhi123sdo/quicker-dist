@echo off
chcp 65001 >nul
setlocal
set "PSFB_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PSFB_DIR%start.ps1" %*
