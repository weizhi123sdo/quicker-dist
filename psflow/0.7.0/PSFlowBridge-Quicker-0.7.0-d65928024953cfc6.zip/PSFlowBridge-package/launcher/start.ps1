﻿# PS Flow Bridge 启动器（薄壳）。
# 生命周期唯一入口是已安装包内的 bootstrap.ps1；这里只负责通过
# %LOCALAPPDATA%\PSFlowBridge\apps\current 找到已安装包并转发参数。
# 保持兼容参数：-Login、-Root、-TimeoutSec。
[CmdletBinding()]
param(
  [switch]$Login,
  [string]$Root = '',
  [ValidateRange(1, 60)][int]$TimeoutSec = 20
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
. (Join-Path $PSScriptRoot 'launcher-lib.ps1')

$root = Get-PsFlowRoot -Root $Root
$appsDir = Join-Path $root 'apps'
$packageRoot = Get-InstalledPackageRoot -AppsDir $appsDir
$bootstrap = Join-Path $packageRoot 'bootstrap.ps1'
if (-not (Test-PackageManifest -PackageRoot $packageRoot)) { throw 'Installed package manifest check failed; use the generated Quicker launcher to stage a repair.' }

$psArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $bootstrap, '-Root', $root, '-TimeoutSec', [string]$TimeoutSec)
if ($Login) { $psArgs += '-Login' }

& (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe') @psArgs
exit $LASTEXITCODE
