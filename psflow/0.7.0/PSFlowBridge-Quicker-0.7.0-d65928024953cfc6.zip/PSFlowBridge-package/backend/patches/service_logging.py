"""Bounded rolling service logging for the local API backend.

Enabled only when the service is actually started (``api_server.main``) and
``PSFB_LOG_DIR`` is set by the launcher. Importing this module, or importing
``api_server`` for tests, never installs handlers and never writes files.

Three things are bounded here:

* Python ``logging`` output goes through a standard ``RotatingFileHandler``
  (default 2 MiB, 5 archives).
* Every structured record is truncated to a UTF-8 byte budget before it is
  written, so a single oversized ``logger.info("%s", huge)`` cannot exceed the
  cap or bypass rotation.
* ``sys.stdout``/``sys.stderr`` are wrapped by a stream that keeps only the most
  recent lines (also a UTF-8 byte budget) and routes them to a second rotating
  file, so a runaway ``print`` cannot fill the disk.

Nothing in this module may raise, and no failure path may write to
``sys.stderr``: that stream is itself wrapped into the logger, so the default
``logging.Handler.handleError`` would recurse. The safe handler below swallows
errors instead.
"""
from __future__ import annotations

import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

DEFAULT_MAX_BYTES = 2 * 1024 * 1024
DEFAULT_ARCHIVES = 5
# Per-record and per-line byte budgets. Truncation is measured in UTF-8 bytes,
# not characters, so a multibyte CJK payload cannot blow past the budget.
MAX_RECORD_BYTES = 8192
MAX_LINE_BYTES = 8192
TRUNCATION_SUFFIX = "...[truncated]"
_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s %(message)s"


def _safe_int(value, default, low, high):
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return parsed if low <= parsed <= high else default


def _truncate_utf8(text, budget):
    """Return text within a UTF-8 byte budget without splitting a character."""
    raw = text.encode("utf-8", "replace")
    if len(raw) <= budget:
        return text
    suffix = TRUNCATION_SUFFIX
    keep = max(0, budget - len(suffix.encode("utf-8")))
    # Decoding with errors="ignore" drops any partial trailing multibyte char.
    return raw[:keep].decode("utf-8", "ignore") + suffix


class _BoundedFormatter(logging.Formatter):
    """Formatter that caps each rendered record at a UTF-8 byte budget."""

    def __init__(self, fmt=None, max_bytes=MAX_RECORD_BYTES):
        super().__init__(fmt)
        self.max_bytes = max_bytes

    def format(self, record):
        try:
            text = super().format(record)
        except Exception:
            text = "[unformattable log record]"
        return _truncate_utf8(text, self.max_bytes)


class _SafeRotatingFileHandler(RotatingFileHandler):
    """Rotating handler whose failures never raise and never touch stderr.

    ``logging``'s default ``handleError`` prints the traceback to
    ``sys.stderr``. Here that stream is replaced by a logger, so the default
    would recurse through this very handler. ``FileHandler.emit`` can also raise
    from ``_open()``/rollover before its own error handling, so ``emit`` is
    wrapped as well.
    """

    def handleError(self, record):  # noqa: N802 - logging API name
        # Intentionally silent: see the class docstring.
        return

    def emit(self, record):
        try:
            super().emit(record)
        except Exception:
            self.handleError(record)


class _BoundedStream:
    """Text stream that forwards complete, length-capped lines to a logger."""

    def __init__(self, logger, level, original):
        self._logger = logger
        self._level = level
        self._original = original
        self._buffer = ""

    def write(self, text):
        try:
            self._buffer += str(text)
            while "\n" in self._buffer:
                line, self._buffer = self._buffer.split("\n", 1)
                self._emit(line)
            # A single line without a newline must still be bounded.
            if len(self._buffer.encode("utf-8", "replace")) > MAX_LINE_BYTES:
                self._emit(self._buffer)
                self._buffer = ""
        except Exception:
            pass
        return len(text) if isinstance(text, str) else 0

    def _emit(self, line):
        if line == "":
            return
        self._logger.log(self._level, "%s", _truncate_utf8(line, MAX_LINE_BYTES))

    def flush(self):
        try:
            if self._buffer:
                self._emit(self._buffer)
                self._buffer = ""
            for handler in self._logger.handlers:
                handler.flush()
        except Exception:
            pass

    def isatty(self):
        return False

    @property
    def encoding(self):
        return "utf-8"

    def fileno(self):
        # Some libraries probe fileno(); refuse rather than expose a wrong fd.
        raise OSError("service log stream has no file descriptor")


_state = {"installed": False, "handlers": [], "original_stdout": None, "original_stderr": None}


def install_service_logging(log_dir=None, max_bytes=None, archives=None):
    """Install rolling logging. Idempotent, non-throwing, safe to call twice."""
    if _state["installed"]:
        return True
    try:
        directory = log_dir if log_dir is not None else os.environ.get("PSFB_LOG_DIR", "")
        if not directory:
            return False
        root = Path(directory)
        root.mkdir(parents=True, exist_ok=True)
        size = _safe_int(max_bytes if max_bytes is not None else os.environ.get("PSFB_LOG_MAX_BYTES"),
                         DEFAULT_MAX_BYTES, 8192, 64 * 1024 * 1024)
        count = _safe_int(archives if archives is not None else os.environ.get("PSFB_LOG_ARCHIVES"),
                          DEFAULT_ARCHIVES, 1, 10)

        logger = logging.getLogger("psflowbridge.backend")
        logger.setLevel(logging.INFO)
        logger.propagate = False
        record_bytes = min(MAX_RECORD_BYTES, size)
        handler = _SafeRotatingFileHandler(
            str(root / "backend.log"), maxBytes=size, backupCount=count, encoding="utf-8", delay=True
        )
        handler.setFormatter(_BoundedFormatter(_LOG_FORMAT, record_bytes))
        logger.addHandler(handler)

        stream_logger = logging.getLogger("psflowbridge.backend.stdio")
        stream_logger.setLevel(logging.INFO)
        stream_logger.propagate = False
        stream_handler = _SafeRotatingFileHandler(
            str(root / "backend.stdio.log"), maxBytes=size, backupCount=count, encoding="utf-8", delay=True
        )
        stream_handler.setFormatter(_BoundedFormatter(_LOG_FORMAT, record_bytes))
        stream_logger.addHandler(stream_handler)

        _state["original_stdout"] = sys.stdout
        _state["original_stderr"] = sys.stderr
        sys.stdout = _BoundedStream(stream_logger, logging.INFO, sys.stdout)
        sys.stderr = _BoundedStream(stream_logger, logging.ERROR, sys.stderr)
        _state["handlers"] = [handler, stream_handler]
        _state["installed"] = True
        return True
    except Exception:
        # Logging setup must never block service start; restore what we changed.
        try:
            uninstall_service_logging()
        except Exception:
            pass
        return False


def uninstall_service_logging():
    """Restore original streams and close handlers. Used by tests and shutdown."""
    try:
        if _state["original_stdout"] is not None:
            sys.stdout = _state["original_stdout"]
        if _state["original_stderr"] is not None:
            sys.stderr = _state["original_stderr"]
        for handler in _state["handlers"]:
            try:
                handler.close()
            except Exception:
                pass
            logging.getLogger("psflowbridge.backend").removeHandler(handler)
            logging.getLogger("psflowbridge.backend.stdio").removeHandler(handler)
    finally:
        _state.update({"installed": False, "handlers": [], "original_stdout": None, "original_stderr": None})
