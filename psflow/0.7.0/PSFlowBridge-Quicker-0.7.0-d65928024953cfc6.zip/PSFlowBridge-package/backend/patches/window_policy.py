"""Shared Chromium window policy for Flow login and personal reCAPTCHA.

Precedence:
1. ``personal_headless=True`` is pure headless.
2. Generation and profile restoration are headed but off-screen by default.
3. Only explicit visibility or confirmed login/human verification shows a window.
"""

from __future__ import annotations

from dataclasses import dataclass


BROWSER_WINDOW_TITLE_PREFIX = "PSFlowBridge Flow Browser"
WINDOW_TITLE_PREFIX_ARG = "--window-name=PSFlowBridge Flow Browser"
HIDDEN_WINDOW_POSITION = (-2600, -1200)
HIDDEN_WINDOW_SIZE = (1280, 800)
VISIBLE_WINDOW_SIZE = (1440, 900)


@dataclass(frozen=True)
class WindowPolicy:
    headless: bool
    on_screen: bool
    launch_args: tuple[str, ...]
    viewport: dict[str, int]


def browser_launch_args(
    mode: str,
    *,
    visible_browser: bool = False,
    personal_headless: bool = False,
    login_required: bool = False,
) -> WindowPolicy:
    """Resolve the one supported Chromium window mode."""
    if mode not in {"generation", "login", "restore"}:
        raise ValueError("mode must be 'generation', 'login' or 'restore'")

    if personal_headless:
        return WindowPolicy(True, False, _base_args(), {"width": 1440, "height": 900})
    if mode == "login" or visible_browser or login_required:
        return WindowPolicy(
            False,
            True,
            (*_base_args(), *_visible_args()),
            {"width": VISIBLE_WINDOW_SIZE[0], "height": VISIBLE_WINDOW_SIZE[1]},
        )
    return WindowPolicy(False, False, (*_base_args(), *_hidden_args()), {"width": 1440, "height": 900})


def _base_args() -> tuple[str, ...]:
    return (
        "--disable-blink-features=AutomationControlled",
        "--no-default-browser-check",
        "--disable-dev-shm-usage",
        WINDOW_TITLE_PREFIX_ARG,
        "--remote-debugging-port=8938",
    )


def _hidden_args() -> tuple[str, ...]:
    x, y = HIDDEN_WINDOW_POSITION
    width, height = HIDDEN_WINDOW_SIZE
    return (f"--window-position={x},{y}", f"--window-size={width},{height}")


def _visible_args() -> tuple[str, ...]:
    width, height = VISIBLE_WINDOW_SIZE
    return (f"--window-size={width},{height}",)
