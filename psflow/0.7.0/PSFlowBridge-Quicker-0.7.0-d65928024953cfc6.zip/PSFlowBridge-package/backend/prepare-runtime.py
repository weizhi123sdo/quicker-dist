"""Scope the pinned upstream backend to PSFlowBridge's private runtime directory."""
import json
import os
from pathlib import Path
import secrets
import sys
import shutil


root = (Path(os.environ["PSFB_ROOT"]) if os.environ.get("PSFB_ROOT")
        else Path(os.environ["LOCALAPPDATA"]) / "PSFlowBridge")
runtime = root / "runtime" / "flow-api"
state = root / "flow-state"
# The seven reviewed patches are complete modules. Reapplying old string edits to
# newer API code is not idempotent and can reject a healthy already-patched tree.
patches = Path(__file__).resolve().parent / "patches"
patch_names = ("api_server.py", "client.py", "flow_current.py", "config.py", "personal_captcha.py", "window_policy.py", "service_logging.py")
if not (runtime / "flow_cli").is_dir():
    raise RuntimeError("Backend runtime package directory is missing")
for name in patch_names:
    compile((patches / name).read_bytes(), name, "exec")
for name in patch_names:
    shutil.copyfile(patches / name, runtime / "flow_cli" / name)

if "--code-only" in sys.argv:
    print("PSFlowBridge backend code prepared; state and credentials untouched.")
    sys.exit(0)

state.mkdir(parents=True, exist_ok=True)

config_path = state / "config.toml"
if not config_path.exists():
    config_path.write_text('[flow]\nmax_retries = 1\ntimeout = 180\n\n[captcha]\nmethod = "personal"\npersonal_headless = false\n', encoding="utf-8")

backend_path = root / "backend.json"
if not backend_path.exists():
    backend_path.write_text(json.dumps({
        "enabled": True,
        "baseUrl": "http://127.0.0.1:8787",
        "apiKey": secrets.token_urlsafe(32),
        "model": "gemini-3.1-flash-image",
        "timeoutMs": 300000,
        "aspects": ["1:1", "16:9", "9:16"],
    }, indent=2), encoding="utf-8")
else:
    try:
        backend_config = json.loads(backend_path.read_text(encoding="utf-8-sig"))
        if isinstance(backend_config, dict) and backend_config.get("enabled"):
            api_key = backend_config.get("apiKey")
            if not isinstance(api_key, str) or len(api_key.strip()) < 16:
                raise RuntimeError("Existing backend API key is invalid; repair it explicitly before starting. Credentials were preserved.")
    except (OSError, ValueError):
        raise RuntimeError("backend.json is unreadable; repair it before starting.")

print("PSFlowBridge backend runtime prepared; credentials remain local.")
