"use strict";
/**
 * dependency-cache.cjs
 * Stable dependency tree fingerprinting, cache validation, migration,
 * and dry-run audit for PSFlowBridge dependencies.
 */
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { spawnSync } = require("node:child_process");

const CACHE_FORMAT_VERSION = "v1";

function readJsonFile(filePath) {
  try {
    const raw = fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, "");
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function extractDependencyTree(lockJson) {
  if (!lockJson || typeof lockJson !== "object") return {};
  const clone = JSON.parse(JSON.stringify(lockJson));
  delete clone.name;
  delete clone.version;
  if (clone.packages && clone.packages[""]) {
    delete clone.packages[""].name;
    delete clone.packages[""].version;
  }
  return clone;
}

function canonicalStringify(obj) {
  if (obj === null || typeof obj !== "object") {
    return JSON.stringify(obj);
  }
  if (Array.isArray(obj)) {
    return "[" + obj.map(canonicalStringify).join(",") + "]";
  }
  const keys = Object.keys(obj).sort();
  return "{" + keys.map((k) => JSON.stringify(k) + ":" + canonicalStringify(obj[k])).join(",") + "}";
}

function computeFingerprint(lockPathOrJson, options = {}) {
  const lock =
    typeof lockPathOrJson === "string"
      ? readJsonFile(lockPathOrJson)
      : lockPathOrJson;
  if (!lock) throw new Error("Invalid or unreadable package-lock.json");

  const depTree = extractDependencyTree(lock);
  const canonicalTree = canonicalStringify(depTree);
  const treeSha256 = crypto.createHash("sha256").update(canonicalTree).digest("hex");

  const nodeAbi = String(options.nodeAbi || process.versions.modules);
  const nodeMajor = String(options.nodeMajor || process.versions.node.split(".")[0]);
  const platform = String(options.platform || process.platform);
  const arch = String(options.arch || process.arch);
  const formatVersion = String(options.formatVersion || CACHE_FORMAT_VERSION);

  const payload = {
    formatVersion,
    platform,
    arch,
    nodeAbi,
    nodeMajor,
    treeSha256,
  };

  const canonicalPayload = canonicalStringify(payload);
  const fingerprint = crypto.createHash("sha256").update(canonicalPayload).digest("hex");

  return {
    fingerprint,
    treeSha256,
    platform,
    arch,
    nodeAbi,
    nodeMajor,
    formatVersion,
  };
}

function createManifest(fingerprintInfo) {
  return {
    schemaVersion: 1,
    fingerprint: fingerprintInfo.fingerprint,
    treeSha256: fingerprintInfo.treeSha256,
    platform: fingerprintInfo.platform,
    arch: fingerprintInfo.arch,
    nodeAbi: fingerprintInfo.nodeAbi,
    nodeMajor: fingerprintInfo.nodeMajor,
    formatVersion: fingerprintInfo.formatVersion,
    createdAt: new Date().toISOString(),
  };
}

function testDependencyCache(cacheDir, nodeExe = process.execPath) {
  const sharpPath = path.join(cacheDir, "node_modules", "sharp");
  if (!fs.existsSync(sharpPath)) return false;
  const probeScript =
    "try { const s = require(process.argv[1]); if (!s || !s.versions || !s.versions.vips) process.exit(1); } catch { process.exit(1); }";
  try {
    const res = spawnSync(nodeExe, ["-e", probeScript, sharpPath], {
      timeout: 5000,
      windowsHide: true,
      stdio: "ignore",
    });
    return res.status === 0;
  } catch {
    return false;
  }
}

function getDirectorySizeBytes(dirPath) {
  let total = 0;
  try {
    const entries = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const ent of entries) {
      const full = path.join(dirPath, ent.name);
      if (ent.isDirectory()) {
        total += getDirectorySizeBytes(full);
      } else if (ent.isFile()) {
        try {
          total += fs.statSync(full).size;
        } catch {}
      }
    }
  } catch {}
  return total;
}

function findReusableCache(dependenciesDir, targetFingerprintInfo, nodeExe = process.execPath) {
  if (!fs.existsSync(dependenciesDir)) return null;

  // 1. Direct match on fingerprint directory: the directory name is only a hint,
  // the manifest must prove the full fingerprint (tree + ABI + platform + arch +
  // format version) before the cache is trusted.
  const directPath = path.join(dependenciesDir, targetFingerprintInfo.fingerprint);
  if (fs.existsSync(directPath)) {
    if (verifyCacheManifest(directPath, targetFingerprintInfo) && testDependencyCache(directPath, nodeExe)) {
      return { path: directPath, reason: "exact_fingerprint_match" };
    }
  }

  // 2. Scan existing directories for matching manifest or matching lockfile tree
  try {
    const entries = fs.readdirSync(dependenciesDir, { withFileTypes: true });
    for (const ent of entries) {
      if (!ent.isDirectory() || ent.name.startsWith(".") || ent.name.includes("staging")) continue;
      const candidateDir = path.join(dependenciesDir, ent.name);
      const manifestPath = path.join(candidateDir, "manifest.json");
      if (fs.existsSync(manifestPath)) {
        if (verifyCacheManifest(candidateDir, targetFingerprintInfo)) {
          if (testDependencyCache(candidateDir, nodeExe)) {
            return { path: candidateDir, reason: "manifest_match", sourceName: ent.name };
          }
        }
      } else {
        // Legacy cache: check package-lock.json if present
        const lockPath = path.join(candidateDir, "package-lock.json");
        if (fs.existsSync(lockPath)) {
          try {
            const oldInfo = computeFingerprint(lockPath, {
              nodeAbi: targetFingerprintInfo.nodeAbi,
              nodeMajor: targetFingerprintInfo.nodeMajor,
              platform: targetFingerprintInfo.platform,
              arch: targetFingerprintInfo.arch,
              formatVersion: targetFingerprintInfo.formatVersion,
            });
            if (oldInfo.fingerprint === targetFingerprintInfo.fingerprint) {
              if (testDependencyCache(candidateDir, nodeExe)) {
                return { path: candidateDir, reason: "legacy_tree_match", sourceName: ent.name };
              }
            }
          } catch {}
        }
      }
    }
  } catch {}
  return null;
}

/**
 * A cache is only reusable when its manifest proves the exact fingerprint:
 * same dependency tree hash, same Node ABI/major, same platform/arch and the
 * same cache format version. A missing or unreadable manifest is a rejection,
 * never an implicit approval.
 */
function verifyCacheManifest(cacheDir, targetFingerprintInfo) {
  const manifestPath = path.join(cacheDir, "manifest.json");
  const manifest = readJsonFile(manifestPath);
  if (!manifest || typeof manifest !== "object") return false;
  if (manifest.schemaVersion !== 1) return false;
  if (manifest.fingerprint !== targetFingerprintInfo.fingerprint) return false;
  if (manifest.formatVersion !== targetFingerprintInfo.formatVersion) return false;
  if (targetFingerprintInfo.treeSha256 && manifest.treeSha256 !== targetFingerprintInfo.treeSha256) return false;
  if (targetFingerprintInfo.platform && manifest.platform !== targetFingerprintInfo.platform) return false;
  if (targetFingerprintInfo.arch && manifest.arch !== targetFingerprintInfo.arch) return false;
  if (targetFingerprintInfo.nodeAbi && manifest.nodeAbi !== targetFingerprintInfo.nodeAbi) return false;
  return true;
}

function getFileSha256(filePath) {
  try {
    const data = fs.readFileSync(filePath);
    return crypto.createHash("sha256").update(data).digest("hex");
  } catch {
    return null;
  }
}

function getActiveNodeProcessReferences() {
  const referencedDepDirs = new Set();
  const referencedAppLocks = new Set();
  const result = {
    depHashes: referencedDepDirs,
    appLockFingerprints: referencedAppLocks,
    runningHelperProcesses: 0,
    helperReferenceUnknown: false,
    queried: false,
  };
  try {
    // Query running node processes via PowerShell with timeout
    const psCmd = 'Get-CimInstance Win32_Process -Filter "Name=\'node.exe\'" | Select-Object ProcessId, CommandLine | ConvertTo-Json -Compress';
    const res = spawnSync("powershell.exe", ["-NoProfile", "-Command", psCmd], {
      timeout: 10000,
      encoding: "utf8",
      windowsHide: true,
    });
    if (res.status === 0 && res.stdout) {
      result.queried = true;
      let procs = [];
      try {
        const parsed = JSON.parse(res.stdout);
        procs = Array.isArray(parsed) ? parsed : [parsed];
      } catch {}
      for (const p of procs) {
        const cmd = String(p.CommandLine || "");
        // Match dependencies/<hash>
        const match = cmd.match(/dependencies[\\/]([0-9a-f]{16,64})/i);
        if (match) referencedDepDirs.add(match[1].toLowerCase());
        // A running helper exposes the app directory it was launched from. Its
        // dependency directory is derived from that app's package-lock, so we
        // protect the fingerprint even though we cannot read the process env.
        if (/[\\/]helper[\\/]server\.js/i.test(cmd)) {
          result.runningHelperProcesses++;
          const appMatch = cmd.match(/apps[\\/]([0-9a-f]{16}(?:-repair-[0-9a-f]+)?)[\\/]/i);
          if (appMatch) referencedAppLocks.add(appMatch[1].toLowerCase());
          else result.helperReferenceUnknown = true;
        }
      }
    }
  } catch {}
  return result;
}

function auditDependencyCaches(stateRoot) {
  const root = stateRoot || path.join(process.env.LOCALAPPDATA || "", "PSFlowBridge");
  const depDir = path.join(root, "dependencies");
  const appsDir = path.join(root, "apps");

  const report = {
    timestamp: new Date().toISOString(),
    dryRun: true,
    stateRoot: root,
    dependenciesDir: depDir,
    totalCachesCount: 0,
    totalSizeBytes: 0,
    totalSizeMiB: "0.00",
    currentAppHash: null,
    previousAppHash: null,
    protectedHashes: {},
    activeCaches: [],
    reclaimCandidates: [],
    undetermined: [],
    damaged: [],
    runningProcesses: {
      queried: false,
      runningHelperProcesses: 0,
      helperReferenceUnknown: false,
    },
  };

  if (!fs.existsSync(depDir)) {
    report.message = "dependencies directory does not exist";
    return report;
  }

  // 1. Collect protected hashes from every retained app package (not just the
  // current one): both the stable dependency fingerprint and the raw whole-lock
  // hash are protected, because old installs keyed caches by the raw lock hash.
  const activeHashes = new Set();
  const readPointer = (name) => {
    try {
      const pointer = path.join(appsDir, name);
      if (fs.existsSync(pointer) && fs.statSync(pointer).isFile()) {
        return fs.readFileSync(pointer, "utf8").trim() || null;
      }
    } catch {}
    return null;
  };
  report.currentAppHash = readPointer("current");
  report.previousAppHash = readPointer("previous");

  if (fs.existsSync(appsDir)) {
    try {
      const appEntries = fs.readdirSync(appsDir, { withFileTypes: true });
      for (const appEnt of appEntries) {
        if (!appEnt.isDirectory()) continue;
        const appRoot = path.join(appsDir, appEnt.name);
        const pkgHelperDir = path.join(appRoot, "PSFlowBridge-package", "helper");
        const directHelperDir = path.join(appRoot, "helper");
        const helperDir = fs.existsSync(pkgHelperDir) ? pkgHelperDir : directHelperDir;
        const lockPath = path.join(helperDir, "package-lock.json");
        if (fs.existsSync(lockPath)) {
          const rawHash = getFileSha256(lockPath);
          if (rawHash) {
            activeHashes.add(rawHash.toLowerCase());
            report.protectedHashes[rawHash.toLowerCase()] = { app: appEnt.name, type: "raw_lockfile_hash" };
          }
          try {
            const fpInfo = computeFingerprint(lockPath);
            activeHashes.add(fpInfo.fingerprint.toLowerCase());
            report.protectedHashes[fpInfo.fingerprint.toLowerCase()] = { app: appEnt.name, type: "stable_fingerprint" };
          } catch {}
        }
      }
    } catch {}
  }

  // 2. Query running processes for dependency-directory references. A helper
  // launched from apps/<hash> protects that app's fingerprint; a helper we
  // cannot map makes otherwise-unreferenced caches undetermined, never
  // reclaimable.
  const running = getActiveNodeProcessReferences();
  report.runningProcesses = {
    queried: running.queried,
    runningHelperProcesses: running.runningHelperProcesses,
    helperReferenceUnknown: running.helperReferenceUnknown,
  };
  for (const ref of running.depHashes) {
    activeHashes.add(ref);
    report.protectedHashes[ref] = { type: "running_process_reference" };
  }
  for (const appName of running.appLockFingerprints) {
    const appRoot = path.join(appsDir, appName);
    const pkgHelperDir = path.join(appRoot, "PSFlowBridge-package", "helper");
    const directHelperDir = path.join(appRoot, "helper");
    const helperDir = fs.existsSync(pkgHelperDir) ? pkgHelperDir : directHelperDir;
    const lockPath = path.join(helperDir, "package-lock.json");
    if (!fs.existsSync(lockPath)) continue;
    try {
      const fpInfo = computeFingerprint(lockPath);
      activeHashes.add(fpInfo.fingerprint.toLowerCase());
      report.protectedHashes[fpInfo.fingerprint.toLowerCase()] = { app: appName, type: "running_helper_app_fingerprint" };
    } catch {}
    const rawHash = getFileSha256(lockPath);
    if (rawHash) {
      activeHashes.add(rawHash.toLowerCase());
      report.protectedHashes[rawHash.toLowerCase()] = { app: appName, type: "running_helper_app_raw_lockfile" };
    }
  }

  // 3. Classify all dependency directories
  const entries = fs.readdirSync(depDir, { withFileTypes: true });
  for (const ent of entries) {
    if (!ent.isDirectory()) continue;
    report.totalCachesCount++;
    const full = path.join(depDir, ent.name);
    const size = getDirectorySizeBytes(full);
    report.totalSizeBytes += size;
    const lowerName = ent.name.toLowerCase();

    const manifestPath = path.join(full, "manifest.json");
    const manifest = readJsonFile(manifestPath);
    const hasSharp = fs.existsSync(path.join(full, "node_modules", "sharp"));
    const lockPath = path.join(full, "package-lock.json");
    const hasLock = fs.existsSync(lockPath);

    const item = {
      name: ent.name,
      path: full,
      sizeBytes: size,
      sizeMiB: (size / (1024 * 1024)).toFixed(2),
      hasManifest: !!manifest,
      hasSharp,
      hasLock,
    };

    if (ent.name.includes("staging")) {
      item.reason = "abandoned_staging_directory";
      report.reclaimCandidates.push(item);
    } else if (!hasSharp) {
      item.reason = "incomplete_missing_sharp";
      report.damaged.push(item);
    } else if (
      activeHashes.has(lowerName) ||
      (manifest && manifest.fingerprint && activeHashes.has(String(manifest.fingerprint).toLowerCase()))
    ) {
      item.reason = "referenced_by_active_app_or_process";
      item.protection =
        report.protectedHashes[lowerName] ||
        (manifest && manifest.fingerprint ? report.protectedHashes[String(manifest.fingerprint).toLowerCase()] : undefined);
      report.activeCaches.push(item);
    } else {
      // It has sharp but is not directly referenced. Legacy caches carry a
      // package-lock we can fingerprint; a match still means "active".
      let legacyFingerprint = null;
      if (hasLock) {
        try {
          legacyFingerprint = computeFingerprint(lockPath).fingerprint.toLowerCase();
        } catch {
          legacyFingerprint = null;
        }
      }
      if (legacyFingerprint && activeHashes.has(legacyFingerprint)) {
        item.reason = "referenced_by_active_app_or_process";
        item.protection = report.protectedHashes[legacyFingerprint];
        report.activeCaches.push(item);
      } else if (!manifest && !hasLock) {
        item.reason = "unknown_legacy_cache_cannot_verify_origin";
        report.undetermined.push(item);
      } else if (running.helperReferenceUnknown) {
        // A helper is running whose dependency directory we could not map, so
        // we cannot prove this cache is unused. Never mark it reclaimable.
        item.reason = "running_helper_reference_unknown";
        report.undetermined.push(item);
      } else {
        item.reason = "unreferenced_legacy_cache";
        report.reclaimCandidates.push(item);
      }
    }
  }

  report.totalSizeMiB = (report.totalSizeBytes / (1024 * 1024)).toFixed(2);
  return report;
}

// CLI handler
if (require.main === module) {
  const args = process.argv.slice(2);
  const cmd = args[0] || "fingerprint";

  if (cmd === "fingerprint") {
    const lockPath = args[1] || path.join(__dirname, "../helper/package-lock.json");
    const fp = computeFingerprint(lockPath);
    console.log(JSON.stringify(fp, null, 2));
  } else if (cmd === "reuse") {
    // Print the reusable-cache lookup result for a lock file + dependencies dir.
    // Read-only: never installs, copies or deletes anything.
    const lockPath = args[1] || path.join(__dirname, "../helper/package-lock.json");
    const depsDir = args[2];
    if (!depsDir) {
      console.error("reuse requires a dependencies directory");
      process.exit(1);
    }
    const fp = computeFingerprint(lockPath);
    const found = findReusableCache(depsDir, fp, process.execPath);
    console.log(JSON.stringify({ fingerprint: fp.fingerprint, found: found || null }, null, 2));
  } else if (cmd === "manifest") {
    // Write (or refresh) manifest.json inside an existing cache directory.
    const cacheDir = args[1];
    const lockPath = args[2] || path.join(__dirname, "../helper/package-lock.json");
    if (!cacheDir) {
      console.error("manifest requires a cache directory");
      process.exit(1);
    }
    const fp = computeFingerprint(lockPath);
    const manifest = createManifest(fp);
    fs.mkdirSync(cacheDir, { recursive: true });
    fs.writeFileSync(path.join(cacheDir, "manifest.json"), JSON.stringify(manifest, null, 2) + "\n", "utf8");
    console.log(JSON.stringify({ written: path.join(cacheDir, "manifest.json"), fingerprint: fp.fingerprint }, null, 2));
  } else if (cmd === "audit") {
    let root = null;
    let out = null;
    for (let i = 1; i < args.length; i++) {
      if (args[i] === "--root" && args[i + 1]) root = args[++i];
      if (args[i] === "--output" && args[i + 1]) out = args[++i];
    }
    const report = auditDependencyCaches(root);
    const jsonStr = JSON.stringify(report, null, 2);
    if (out) {
      fs.mkdirSync(path.dirname(out), { recursive: true });
      fs.writeFileSync(out, jsonStr, "utf8");
      console.log(`Dry-run audit written to ${out}`);
    } else {
      console.log(jsonStr);
    }
  } else {
    console.error(`Unknown command: ${cmd}`);
    process.exit(1);
  }
}

module.exports = {
  CACHE_FORMAT_VERSION,
  computeFingerprint,
  createManifest,
  verifyCacheManifest,
  testDependencyCache,
  findReusableCache,
  auditDependencyCaches,
  extractDependencyTree,
};
