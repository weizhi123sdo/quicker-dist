'use strict';
const fs=require('node:fs/promises');
const path=require('node:path');
const {writeTextAtomically}=require('../helper/atomic-file');
const KEYS=Object.freeze(['psflow.action-ui.v1','psflow.text-draft.v1','psflow.generation-kind','psflow_drafts','psflow.personal-presets.v1','psflow.personal-presets.v2']);
const MAX_BYTES=4*1024*1024;
function error(code,message){return Object.assign(new Error(message),{code});}
function values(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw error('user_state_invalid','用户设置格式无效，未写入。');
  const result={};
  for(const [key,value] of Object.entries(input)){
    if(!KEYS.includes(key)||typeof value!=='string')throw error('user_state_invalid','用户设置包含不支持的数据，未写入。');
    Object.defineProperty(result,key,{value,enumerable:true,writable:true,configurable:true});
  }
  if(Buffer.byteLength(JSON.stringify(result),'utf8')>MAX_BYTES)throw error('user_state_too_large','用户设置超过存储上限，原数据已保留。');
  return result;
}
function createUserStateStore({file,io=fs,write=(target,text)=>writeTextAtomically(target,text,io)}){
  let tail=Promise.resolve();
  async function read(){
    let raw;
    try{raw=await io.readFile(file,'utf8');}
    catch(e){if(e.code==='ENOENT')return {ok:true,exists:false,state:{schemaVersion:1,revision:0,values:{}}};throw error('user_state_unreadable','用户设置暂时无法读取，已暂停写入并保留原数据。');}
    try{
      if(Buffer.byteLength(raw,'utf8')>MAX_BYTES+8192)throw new Error('large');
      const state=JSON.parse(raw);
      if(state.schemaVersion!==1||!Number.isSafeInteger(state.revision)||state.revision<1)throw new Error('schema');
      return {ok:true,exists:true,state:{schemaVersion:1,revision:state.revision,values:values(state.values)}};
    }catch{throw error('user_state_unreadable','用户设置损坏或版本不受支持，已暂停写入并保留原文件。');}
  }
  function save(input){
    const operation=tail.catch(()=>{}).then(async()=>{
      if(!Number.isSafeInteger(input.expectedRevision)||input.expectedRevision<0)throw error('user_state_invalid','用户设置版本无效，未写入。');
      const nextValues=values(input.values),current=await read();
      if(current.state.revision!==input.expectedRevision)throw error('user_state_conflict','另一个窗口已更新设置，请重新打开助手后继续。当前输入已保留。');
      if(JSON.stringify(current.state.values)===JSON.stringify(nextValues)&&current.exists)return current;
      const state={schemaVersion:1,revision:current.state.revision+1,values:nextValues};
      try{
        await io.mkdir(path.dirname(file),{recursive:true});
        if(!current.exists){
          try{await io.writeFile(file+'.legacy.json',JSON.stringify({schemaVersion:1,values:nextValues},null,2),{flag:'wx'});}
          catch(e){if(e.code!=='EEXIST')throw e;}
        }
        await write(file,JSON.stringify(state,null,2));
      }catch{throw error('user_state_write_failed','用户设置未能保存，原数据已保留，请检查目录是否可写。');}
      return {ok:true,exists:true,state};
    });
    tail=operation;
    return operation;
  }
  return {read,save};
}
module.exports={KEYS,MAX_BYTES,values,createUserStateStore};
