"use strict";

const SUPPORTED_KINDS = Object.freeze(["image2image", "text2image"]);
const DEFAULT_KIND = "image2image";
const TEXT2IMAGE_ASPECT_RATIOS = Object.freeze(["1:1", "4:3", "3:4", "16:9", "9:16"]);
const DEFAULT_TEXT_ASPECT = "1:1";

function isText2Image(jobOrKind) {
  if (!jobOrKind) return false;
  const kind = typeof jobOrKind === "string" ? jobOrKind : jobOrKind.kind;
  return kind === "text2image";
}

function isStandalone(job) {
  if (!job || typeof job !== "object") return false;
  if (job.standalone === true) return true;
  if (job.kind === "text2image") return true;
  if (!job.documentID && !job.documentSession) return true;
  return false;
}

function isValidTextAspect(aspect) {
  return typeof aspect === "string" && TEXT2IMAGE_ASPECT_RATIOS.includes(aspect);
}

function normalizeKind(kind) {
  return kind === "text2image" ? "text2image" : "image2image";
}

module.exports = {
  SUPPORTED_KINDS,
  DEFAULT_KIND,
  TEXT2IMAGE_ASPECT_RATIOS,
  DEFAULT_TEXT_ASPECT,
  isText2Image,
  isStandalone,
  isValidTextAspect,
  normalizeKind
};
