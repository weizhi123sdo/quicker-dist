(function(root,factory){'use strict';const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;if(root)root.PSFlowUserState=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const KEYS=Object.freeze(['psflow.action-ui.v1','psflow.text-draft.v1','psflow.generation-kind','psflow_drafts','psflow.personal-presets.v1','psflow.personal-presets.v2']);
 function failure(value){return Object.assign(new Error(value&&value.error||'用户设置同步失败，当前输入已保留。'),{code:value&&value.code||'user_state_unavailable'});}
 function checked(value){
  if(!value||value.ok!==true)throw failure(value);
  const state=value.state;
  if(typeof value.exists!=='boolean'||!state||state.schemaVersion!==1||!Number.isSafeInteger(state.revision)||state.revision<0||!state.values||typeof state.values!=='object'||Array.isArray(state.values))throw failure();
  if((value.exists&&state.revision<1)||(!value.exists&&(state.revision!==0||Object.keys(state.values).length!==0)))throw failure();
  if(Object.entries(state.values).some(([key,item])=>!KEYS.includes(key)||typeof item!=='string'))throw failure();
  return value;
 }
 async function prepare({storage,call,onError=()=>{},delayMs=300}){
  let revision=0,blocked=false,closed=false,timer=null,pending=null,dirty=false,view={};
  function report(e){blocked=true;try{onError(e);}catch{}return e;}
  function snapshot(){const result={};for(const key of KEYS){const value=storage.getItem(key);if(value!==null)result[key]=value;}return result;}
  try{
   const legacy=snapshot(),remote=checked(await call({op:'user-state-read'}));
   revision=remote.state.revision;
   const resolved=remote.exists?remote:checked(await call({op:'user-state-write',expectedRevision:revision,values:legacy}));
   revision=resolved.state.revision;view={...resolved.state.values};
   // Keep the local origin intact if hydration is interrupted; it is a recovery
   // copy, while only the fixed user-data file is authoritative after success.
   const before=snapshot();
   try{for(const key of KEYS){if(Object.prototype.hasOwnProperty.call(view,key))storage.setItem(key,view[key]);else storage.removeItem(key);}}
   catch(e){for(const key of KEYS)try{if(Object.prototype.hasOwnProperty.call(before,key))storage.setItem(key,before[key]);else storage.removeItem(key);}catch{}throw e;}
  }catch(e){report(e);}
  async function flush(){
   clearTimeout(timer);timer=null;
   if(blocked||closed)return false;
   if(pending){await pending;if(dirty&&!blocked&&!closed)return flush();return !blocked;}
   if(!dirty)return true;
   dirty=false;
   let next;
   try{next=snapshot();}catch(e){report(e);return false;}
   pending=(async()=>{
    try{const saved=checked(await call({op:'user-state-write',expectedRevision:revision,values:next}));revision=saved.state.revision;view={...saved.state.values};return true;}
    catch(e){report(e);return false;}
   })();
   try{await pending;}finally{pending=null;}
   if(dirty&&!blocked&&!closed)return flush();
   return !blocked;
  }
  function changed(){dirty=true;clearTimeout(timer);timer=setTimeout(()=>void flush(),delayMs);}
  const proxy={
   getItem:key=>storage.getItem(key),
   setItem(key,value){if(KEYS.includes(key)&&blocked)throw failure({code:'user_state_blocked',error:'用户设置同步已暂停，原数据已保留；请重新打开助手。'});storage.setItem(key,String(value));if(KEYS.includes(key))changed();},
   removeItem(key){if(KEYS.includes(key)&&blocked)throw failure({code:'user_state_blocked',error:'用户设置同步已暂停，未删除原数据。'});storage.removeItem(key);if(KEYS.includes(key))changed();},
   key:index=>storage.key(index),
   get length(){return storage.length;}
  };
  return {storage:proxy,flush,close(){closed=true;clearTimeout(timer);},get blocked(){return blocked;},get revision(){return revision;}};
 }
 return {KEYS,prepare};
});
