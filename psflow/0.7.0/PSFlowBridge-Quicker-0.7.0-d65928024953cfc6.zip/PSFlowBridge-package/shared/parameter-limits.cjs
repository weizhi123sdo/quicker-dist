'use strict';
module.exports=Object.freeze(require('./parameter-limits.json'));
