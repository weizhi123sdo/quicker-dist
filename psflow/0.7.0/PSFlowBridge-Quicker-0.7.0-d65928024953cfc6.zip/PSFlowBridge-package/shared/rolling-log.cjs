'use strict';
// Service logs have one writer. Bridge stdout remains a separate JSON channel.
const fs = require('node:fs');
const path = require('node:path');
const MAX_LINE_BYTES = 8192;
const installed = Symbol.for('psflowbridge.consoleLogger');

function redact(value) {
  return String(value)
    .replace(/\bBearer\s+[^\s"'<>]+/gi, 'Bearer [redacted]')
    .replace(/((?:api[_-]?key|pairingToken|password|access[_-]?token|refresh[_-]?token|cookie|authorization|secret)["']?\s*[:=]\s*["']?)[^\s"',;}]+/gi, '$1[redacted]')
    .replace(/\bsk-[a-zA-Z0-9_-]{12,}\b/g, '[redacted]')
    .slice(0, 4096);
}

function summarize(value) {
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return redact(value);
  if (value && typeof value === 'object') {
    // Do not serialize arbitrary request/config objects or image data.
    const fields = {};
    for (const key of ['name', 'message', 'code', 'status']) {
      if (['string', 'number', 'boolean'].includes(typeof value[key])) fields[key] = redact(value[key]);
    }
    return Object.keys(fields).length ? fields : '[object omitted]';
  }
  return value == null ? String(value) : '[value omitted]';
}

function createRollingLogger({directory, name = 'helper', maxBytes = 2 * 1024 * 1024, archives = 5} = {}) {
  if (typeof directory !== 'string' || !directory || !/^[a-z][a-z0-9-]{0,39}$/i.test(name)) throw Error('Invalid service log destination');
  if (!Number.isInteger(maxBytes) || maxBytes < MAX_LINE_BYTES || maxBytes > 64 * 1024 * 1024) throw Error('Invalid service log size');
  if (!Number.isInteger(archives) || archives < 1 || archives > 10) throw Error('Invalid service log archive count');
  const filename = path.join(directory, name + '.log');
  let failures = 0;
  function size(file) {
    try { const stat = fs.lstatSync(file); if (!stat.isFile() || stat.isSymbolicLink()) throw Error('Log destination is not a regular file'); return stat.size; }
    catch (error) { if (error.code === 'ENOENT') return 0; throw error; }
  }
  function rotate() {
    // Validate all destinations before moving any file (Windows can lock logs).
    for (let i = 0; i <= archives; i++) size(i ? filename + '.' + i : filename);
    if (fs.existsSync(filename + '.' + archives)) fs.unlinkSync(filename + '.' + archives);
    for (let i = archives - 1; i >= 1; i--) {
      if (fs.existsSync(filename + '.' + i)) fs.renameSync(filename + '.' + i, filename + '.' + (i + 1));
    }
    if (fs.existsSync(filename)) fs.renameSync(filename, filename + '.1');
  }
  return {
    filename,
    get failures() { return failures; },
    write(level, ...values) {
      try {
        fs.mkdirSync(directory, {recursive: true});
        const line = Buffer.from(JSON.stringify({timestamp: new Date().toISOString(), level: ['debug', 'info', 'warn', 'error'].includes(level) ? level : 'info', values: values.slice(0, 8).map(summarize)}) + '\n');
        // Never split a JSON record or allow a single oversized record to bypass
        // the cap. Large payloads are omitted instead of consuming the budget.
        const record = line.length <= MAX_LINE_BYTES ? line : Buffer.from(JSON.stringify({timestamp: new Date().toISOString(), level: 'warn', values: ['Oversized log record omitted']}) + '\n');
        const bytes = size(filename);
        if (bytes + record.length > maxBytes) rotate();
        fs.appendFileSync(filename, record);
        return true;
      } catch (_) { failures++; return false; }
    }
  };
}

function installConsoleLogger(options) {
  if (console[installed]) return console[installed];
  let logger;
  try { logger = createRollingLogger(options); } catch (_) { return {dispose() {}, failed: true}; }
  const originals = {}, wrappers = {};
  for (const [method, level] of [['log', 'info'], ['info', 'info'], ['warn', 'warn'], ['error', 'error'], ['debug', 'debug']]) {
    originals[method] = console[method];
    wrappers[method] = (...values) => { logger.write(level, ...values); };
    console[method] = wrappers[method];
  }
  const handle = {logger, dispose() {
    for (const method of Object.keys(originals)) if (console[method] === wrappers[method]) console[method] = originals[method];
    if (console[installed] === handle) delete console[installed];
  }};
  console[installed] = handle;
  return handle;
}

module.exports = {createRollingLogger, installConsoleLogger, redact};
