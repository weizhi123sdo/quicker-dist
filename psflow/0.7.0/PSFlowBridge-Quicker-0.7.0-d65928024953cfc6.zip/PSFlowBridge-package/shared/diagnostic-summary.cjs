'use strict';
/**
 * shared/diagnostic-summary.cjs
 *
 * Sanitized, privacy-safe diagnostic summary for PSFlowBridge UI and status inspection.
 *
 * Strictly enforces value-level whitelisting:
 *   - version: semver regex or 'unknown' (no hardcoded default version)
 *   - buildId: 16-hex regex (/^[0-9a-f]{16}$/i) or 'unknown'
 *   - mode: strictly 'browser' or 'local', otherwise 'unknown'
 *   - errorCode: strictly short machine code (/^[A-Z0-9_]{3,40}$/) or null (no raw error text)
 *   - timestamp: valid date parsed and emitted as ISO-8601 string
 *   - probeDurations: strictly fixed allowed key set and finite non-negative numbers
 *   - taskCounts: sanitized integers (total, completed, failed, active)
 *   - healthy: boolean
 *   - runtimeReady: boolean
 *
 * Security & Privacy:
 *   - Sensitive values stuffed into allowed fields are strictly rejected.
 *   - Never reads raw log files from disk.
 *   - Never makes network connections.
 *   - Zero runtime dependencies.
 */

const SEMVER_REGEX = /^\d{1,5}\.\d{1,5}\.\d{1,5}(?:-[0-9A-Za-z.]{1,20})?$/;
const BUILD_ID_REGEX = /^[0-9a-f]{16}$/i;
const ERROR_CODE_REGEX = /^[A-Z][A-Z0-9_]{2,39}$/;

const ALLOWED_MODES = new Set(['browser', 'local']);

const ALLOWED_PROBE_KEYS = new Set([
  'psProbeMs',
  'runtimeProbeMs',
  'helperProbeMs',
  'backendProbeMs',
  'browserProbeMs',
  'networkProbeMs',
  'totalMs',
]);

const ALLOWED_TOP_LEVEL_FIELDS = new Set([
  'version',
  'buildId',
  'mode',
  'taskCounts',
  'errorCode',
  'probeDurations',
  'timestamp',
  'healthy',
  'runtimeReady',
  'dataHealth',
]);

function sanitizeVersion(val) {
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (SEMVER_REGEX.test(trimmed)) {
      return trimmed;
    }
  }
  return 'unknown';
}

function sanitizeBuildId(val) {
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (BUILD_ID_REGEX.test(trimmed)) {
      return trimmed.toLowerCase();
    }
  }
  return 'unknown';
}

function sanitizeMode(val) {
  if (typeof val === 'string') {
    const trimmed = val.trim().toLowerCase();
    if (ALLOWED_MODES.has(trimmed)) {
      return trimmed;
    }
  }
  return 'unknown';
}

function sanitizeErrorCode(val) {
  if (typeof val === 'string') {
    const trimmed = val.trim();
    if (ERROR_CODE_REGEX.test(trimmed) && trimmed !== 'OK' && trimmed !== 'NONE' && trimmed !== 'NULL') {
      return trimmed;
    }
  }
  return null;
}

function sanitizeTimestamp(val) {
  if (typeof val === 'string' || typeof val === 'number') {
    const d = new Date(val);
    if (!isNaN(d.getTime())) {
      const yr = d.getUTCFullYear();
      if (yr >= 2020 && yr <= 2100) return d.toISOString();
    }
  }
  return new Date().toISOString();
}

function sanitizeTaskCounts(raw) {
  const defaults = { total: 0, completed: 0, failed: 0, active: 0 };
  if (!raw || typeof raw !== 'object') return defaults;
  const num = (v) => {
    const n = parseInt(v, 10);
    return isNaN(n) || n < 0 ? 0 : n;
  };
  const total = num(raw.total);
  const completed = num(raw.completed);
  const failed = num(raw.failed);
  const active = num(raw.active);
  const sumParts = completed + failed + active;
  return {
    total: Math.max(total, sumParts),
    completed,
    failed,
    active,
  };
}

function sanitizeProbeDurations(raw) {
  const res = {};
  if (!raw || typeof raw !== 'object') return res;
  for (const [k, v] of Object.entries(raw)) {
    if (!ALLOWED_PROBE_KEYS.has(k)) continue;
    const n = typeof v === 'number' ? v : parseFloat(v);
    if (Number.isFinite(n) && n >= 0 && n <= 3600000) {
      res[k] = Number(n.toFixed(2));
    }
  }
  return res;
}

function sanitizeDataHealth(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const count = key => Number.isSafeInteger(raw[key]) && raw[key] >= 0 ? Math.min(raw[key], 1000000000) : 0;
  // Job ids, file paths, issue payloads and user material never leave the
  // aggregate diagnostic export, even if injected into an allowed parent key.
  return {issueCount: count('issueCount'), errorCount: count('errorCount'), warningCount: count('warningCount')};
}

function buildDiagnosticSummary(rawInput = {}) {
  const input = (rawInput && typeof rawInput === 'object') ? rawInput : {};

  const version = sanitizeVersion(input.version);
  const buildId = sanitizeBuildId(input.buildId);
  const mode = sanitizeMode(input.mode);
  const taskCounts = sanitizeTaskCounts(input.taskCounts);
  // Strictly read machine code input.errorCode or input.code only; NEVER raw error text / prompt
  const errorCode = sanitizeErrorCode(input.errorCode || input.code);
  const probeDurations = sanitizeProbeDurations(input.probeDurations || input.timings);
  const healthy = typeof input.healthy === 'boolean' ? input.healthy : (errorCode === null);
  const runtimeReady = typeof input.runtimeReady === 'boolean' ? input.runtimeReady : false;
  const timestamp = sanitizeTimestamp(input.timestamp);

  const summary = {
    version,
    buildId,
    mode,
    taskCounts,
    errorCode,
    probeDurations,
    timestamp,
    healthy,
    runtimeReady,
    dataHealth: sanitizeDataHealth(input.dataHealth),
  };

  return Object.freeze(summary);
}

function formatDiagnosticSummaryText(rawInput) {
  const summary = buildDiagnosticSummary(rawInput);
  // Always formatted via buildDiagnosticSummary
  if (!rawInput) return 'Diagnostic summary: unavailable';
  const parts = [
    `Version: ${summary.version || 'unknown'}`,
    `Build: ${summary.buildId || 'unknown'}`,
    `Mode: ${summary.mode || 'unknown'}`,
    `Health: ${summary.healthy ? 'Healthy' : 'Degraded'}`,
    `Runtime: ${summary.runtimeReady ? 'Ready' : 'Not Ready'}`,
    `Tasks: total=${summary.taskCounts ? summary.taskCounts.total : 0}, active=${summary.taskCounts ? summary.taskCounts.active : 0}, completed=${summary.taskCounts ? summary.taskCounts.completed : 0}, failed=${summary.taskCounts ? summary.taskCounts.failed : 0}`,
  ];
  if (summary.errorCode) {
    parts.push(`Error: ${summary.errorCode}`);
  }
  if (summary.probeDurations && Object.keys(summary.probeDurations).length > 0) {
    const probeList = Object.entries(summary.probeDurations)
      .map(([k, ms]) => `${k}=${ms}ms`)
      .join(', ');
    parts.push(`Probes: [${probeList}]`);
  }
  return parts.join(' | ');
}

module.exports = {
  ALLOWED_TOP_LEVEL_FIELDS,
  ALLOWED_MODES,
  ALLOWED_PROBE_KEYS,
  SEMVER_REGEX,
  BUILD_ID_REGEX,
  ERROR_CODE_REGEX,
  buildDiagnosticSummary,
  formatDiagnosticSummaryText,
  sanitizeVersion,
  sanitizeBuildId,
  sanitizeMode,
  sanitizeErrorCode,
  sanitizeTimestamp,
  sanitizeTaskCounts,
  sanitizeProbeDurations,
  sanitizeDataHealth,
};
