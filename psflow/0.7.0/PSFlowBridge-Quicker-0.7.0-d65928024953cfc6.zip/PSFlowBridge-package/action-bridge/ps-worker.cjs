"use strict";
const { spawn } = require("node:child_process");
function fault(message, uncertain=false, code="photoshop") { return Object.assign(new Error(message), {code,uncertain}); }
// One long-lived PowerShell/COM bridge process per lane. Requests are strictly
// FIFO on that process. A timeout, a broken pipe or an unexpected exit always
// means "the write may have reached Photoshop": the worker is torn down and the
// caller gets uncertain:true so nothing is automatically retried.
function createPsWorker({executable,args,timeoutMs=60000,idleMs=60000,maxQueued=8}) {
  if(!Number.isInteger(maxQueued)||maxQueued<1)throw new Error("Photoshop 队列上限无效。");
  let child=null, pending=null, tail=Promise.resolve(), count=0, closed=false, idleTimer=null, restarts=0;
  function stop(error) {
    clearTimeout(idleTimer);
    const old=child; child=null;
    if(pending) { const task=pending;pending=null;clearTimeout(task.timer);task.reject(error||fault("Photoshop 操作尚未确认。",true)); }
    if(old) { try{old.stdin.destroy();}catch{} old.kill(); if(error)restarts++; }
  }
  function ensure() {
    if(child) return child;
    const proc=spawn(executable,args,{windowsHide:true,stdio:["pipe","pipe","pipe"]});
    child=proc;let buffer="";
    proc.stdout.setEncoding("utf8");
    proc.stdout.on("data", chunk=>{
      if(child!==proc)return;
      buffer+=chunk;
      if(buffer.length>1024*1024)return stop(fault("Photoshop 输出过大。",true));
      let split;
      while((split=buffer.indexOf("\n"))!==-1) {
        const line=buffer.slice(0,split).trim();buffer=buffer.slice(split+1);
        if(!line)continue;
        if(!pending || pending.proc!==proc)return stop(fault("Photoshop 输出顺序无法确认。",true));
        const task=pending;let value;
        try { value=JSON.parse(line); } catch {return stop(fault("Photoshop 输出无效。",true));}
        pending=null;clearTimeout(task.timer);
        if(value.ok)task.resolve(value);else task.reject(fault(value.error||"Photoshop 操作失败。",value.uncertain===true));
        idleTimer=setTimeout(()=>{if(!pending && child===proc)stop();},idleMs);idleTimer.unref();
      }
    });
    proc.stderr.on("data",()=>{});
    proc.stdin.on("error",()=>{if(child===proc)stop(fault("Photoshop 桥连接中断，操作未确认。",true));});
    proc.once("error",()=>{if(child===proc)stop(fault("Photoshop 桥启动失败。"));});
    proc.once("close",()=>{if(child===proc)stop(fault("Photoshop 桥已断开，操作未确认。",!!pending));});
    return proc;
  }
  function invoke(request,limit=timeoutMs) {
    if(closed)return Promise.reject(fault("Photoshop 桥已关闭。",false,"closed"));
    // Bounded queue: saturation is a clear, retry-safe refusal. It never queues
    // behind the running request and never drops the request silently.
    if(count>=maxQueued)return Promise.reject(fault("Photoshop 操作队列繁忙，请稍后再试。",false,"queue_full"));
    count++;
    const work=tail.then(()=>{
      if(closed)throw fault("Photoshop 桥已关闭。",false,"closed");
      clearTimeout(idleTimer);
      return new Promise((resolve,reject)=>{
        const proc=ensure();
        const timer=setTimeout(()=>stop(fault("Photoshop 操作超时；结果待确认，请查询原任务。",true)),limit);
        pending={resolve,reject,timer,proc};
        proc.stdin.write(JSON.stringify(request)+"\n","utf8",error=>{
          if(error && pending && pending.proc===proc)stop(fault("Photoshop 桥请求未确认。",true));
        });
      });
    });
    tail=work.catch(()=>{}).finally(()=>{count--;});
    return work;
  }
  return {
    invoke,
    close(){closed=true;stop();},
    // Read-only observability: whether a process is alive and how many times a
    // dead/timed-out bridge was replaced. No request data is exposed.
    stats:()=>({alive:!!child,pending:!!pending,queued:count,closed,restarts})
  };
}
module.exports={createPsWorker};
