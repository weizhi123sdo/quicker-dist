"use strict";
function decodeRawMask(bytes,meta,source){
  if(!meta||meta.width!==source.width||meta.height!==source.height||meta.channels!==4||meta.alphaIndex!==3||meta.interleaved!==true||!Number.isSafeInteger(meta.width*meta.height)||meta.width<1||meta.height<1||meta.width*meta.height>25000000||bytes.length!==meta.width*meta.height*4)throw Error('选区通道大小或布局不一致，未提交生成。');
  const mask=Buffer.allocUnsafe(meta.width*meta.height);for(let i=0;i<mask.length;i++)mask[i]=bytes[i*4+3];return mask;
}
module.exports={decodeRawMask};
