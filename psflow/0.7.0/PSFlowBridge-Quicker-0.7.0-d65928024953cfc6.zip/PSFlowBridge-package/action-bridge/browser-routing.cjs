"use strict";
const fs = require('node:fs');
const path = require('node:path');
const {spawn} = require('node:child_process');
const URL = 'https://labs.google/fx/tools/flow';
const choices = ['quicker','default','edge','chrome'];
function preference(root) {
  try {
    const raw = fs.readFileSync(path.join(root, 'browser.json'), 'utf8').replace(/^\uFEFF/, '');
    const value = JSON.parse(raw);
    const b = value && value.browser;
    if (b === 'edge' || b === 'chrome') return b;
    // Legacy 'default', missing, or invalid values migrate to 'quicker'
    return 'quicker';
  } catch {
    return 'quicker';
  }
}
function launchSpec(browser, env=process.env, exists=fs.existsSync) {
  if(!choices.includes(browser)) throw Error('不支持的浏览器。');
  if(browser==='quicker')throw Error('QK 内置浏览器由动作宿主打开。');
  if(browser==='default') return {executable:path.join(env.WINDIR||'C:\\Windows','System32','rundll32.exe'),args:['url.dll,FileProtocolHandler',URL]};
  const relative=browser==='edge'?'Microsoft/Edge/Application/msedge.exe':'Google/Chrome/Application/chrome.exe';
  const executable=[env.LOCALAPPDATA,env.PROGRAMFILES,env['PROGRAMFILES(X86)']].filter(Boolean).map(root=>path.join(root,relative)).find(exists);
  if(!executable) throw Error('未找到 '+(browser==='edge'?'Microsoft Edge':'Google Chrome')+'，请安装或选择系统默认浏览器。');
  return {executable,args:[URL]};
}
async function open(root) {
  if(preference(root)==='quicker') return {ok:true,browser:'quicker',managed:true,visible:true,message:'Flow 内置浏览器已就绪。'};
  const browser=preference(root), spec=launchSpec(browser);
  await new Promise((resolve,reject)=>{ const child=spawn(spec.executable,spec.args,{detached:true,stdio:'ignore',windowsHide:true}); child.once('error',reject); child.once('spawn',()=>{child.unref();resolve();}); });
  return {ok:true,browser,visible:true,message:'已打开 Flow，请进入项目并保持扩展开启。'};
}
module.exports={choices,preference,launchSpec,open};
