// Bridge the Quicker WebView2 Flow session into the local Playwright profile.
var result = new Newtonsoft.Json.Linq.JObject { ["ok"] = false, ["message"] = "" };
try {
    var cookies = context.GetVarValue<string>("cookies") ?? "";
    if (string.IsNullOrWhiteSpace(cookies)) throw new System.Exception("内嵌登录窗口未返回登录 Cookie（若重复出现，说明该窗口没有带出 Cookie，请重试登录）。");
    var stateRoot = System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData), "PSFlowBridge");
    var backendPath = System.IO.Path.Combine(stateRoot, "backend.json");
    if (!System.IO.File.Exists(backendPath)) throw new System.Exception("生成服务尚未配置，请先打开一次 PS Flow 动作面板。");
    var backend = Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(backendPath));
    if ((bool?)backend["enabled"] != true) throw new System.Exception("生成服务未启用，请在设置中开启 PS Flow 服务。");
    var baseUrl = ((string)backend["baseUrl"] ?? "").TrimEnd('/');
    var apiKey = (string)backend["apiKey"];
    if (string.IsNullOrWhiteSpace(baseUrl) || string.IsNullOrWhiteSpace(apiKey)) throw new System.Exception("生成服务配置不完整。");
    var request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(baseUrl + "/setup/import-cookies");
    request.Proxy = null;
    request.Method = "POST";
    request.Timeout = 30000;
    request.ReadWriteTimeout = 30000;
    request.ContentType = "application/json; charset=utf-8";
    request.Headers["Authorization"] = "Bearer " + apiKey;
    var payload = new Newtonsoft.Json.Linq.JObject { ["cookies"] = cookies, ["origin"] = "https://flow.google.com" };
    var bytes = new System.Text.UTF8Encoding(false).GetBytes(payload.ToString(Newtonsoft.Json.Formatting.None));
    request.ContentLength = bytes.Length;
    using (var stream = request.GetRequestStream()) stream.Write(bytes, 0, bytes.Length);
    using (var response = request.GetResponse())
    using (var reader = new System.IO.StreamReader(response.GetResponseStream(), System.Text.Encoding.UTF8)) {
        var body = Newtonsoft.Json.Linq.JObject.Parse(reader.ReadToEnd());
        var ready = (bool?)body["session_ready"] == true;
        result["ok"] = true;
        result["sessionReady"] = ready;
        result["imported"] = body["imported"];
        result["message"] = ready
            ? "已通过动作内嵌窗口完成登录，会话已经就绪。"
            : "登录 Cookie 已导入，但会话尚未确认；请在窗口中确认已进入 Flow。";
    }
} catch (System.Net.WebException error) {
    var code = "(连接失败)"; var detail = error.Message;
    try {
        using (var response = error.Response)
        {
            if (response is System.Net.HttpWebResponse hr) code = ((int)hr.StatusCode).ToString();
            using (var reader = new System.IO.StreamReader(response.GetResponseStream(), System.Text.Encoding.UTF8)) {
                var body = Newtonsoft.Json.Linq.JObject.Parse(reader.ReadToEnd());
                var message = (string)(body["error"]?["message"] ?? body["error"] ?? body["detail"]);
                if (!string.IsNullOrWhiteSpace(message)) detail = message;
            }
        }
    } catch { }
    result["message"] = "登录会话导入失败（HTTP " + code + "，路径 /setup/import-cookies）：" + detail;
} catch (System.Exception error) {
    result["waitingForLogin"] = error.Message.Contains("未返回登录 Cookie");
    result["message"] = error.Message;
}
context.SetVarValue("result", result.ToString(Newtonsoft.Json.Formatting.None));
