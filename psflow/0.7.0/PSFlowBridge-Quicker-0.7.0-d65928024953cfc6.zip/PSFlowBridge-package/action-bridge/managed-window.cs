var view=context.GetVarValue("managedView");
if(view==null)throw new System.Exception("内置 Flow 窗口未打开。");
var operation=context.GetVarValue<string>("operation")??"show";
bool visible=false;
var dispatcher=(System.Windows.Threading.Dispatcher)view.GetType().GetProperty("Dispatcher").GetValue(view);
dispatcher.Invoke(new System.Action(()=>{
    var window=System.Windows.Window.GetWindow(view as System.Windows.DependencyObject);
    if(window==null)throw new System.Exception("未找到内置 Flow 窗口。");
    if(operation=="hide")window.Hide();
    else if(operation!="probe") {window.Show();if(operation=="login")context.WriteState("managedLoginPending","true");}
    visible=window.IsVisible;
}));
context.SetVarValue("response","{\"ok\":true,\"visible\":"+(visible?"true":"false")+"}");
return true;
