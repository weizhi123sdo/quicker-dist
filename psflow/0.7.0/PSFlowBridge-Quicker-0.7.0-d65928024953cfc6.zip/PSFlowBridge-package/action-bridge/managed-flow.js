/* Invoked only by the Quicker CoreWebView2 controller, never an extension. */
async function psfbManaged(action, arg={}) {
  const visible=n=>!!n&&n.getClientRects().length>0;
  const buttons=()=>[...document.querySelectorAll('button')].filter(visible);
  const label=n=>{const c=n.cloneNode(true);c.querySelectorAll('mat-icon,flow-material-icon,svg,[aria-hidden=true]').forEach(i=>i.remove());return c.textContent.replace(/\s+/g,' ').trim();};
  const editor=()=>[...document.querySelectorAll('.ProseMirror')].find(visible);
  const key=url=>url.split('?')[0].replace(/=s\d+.*$/,'');
  const settings=()=>{
    const trigger=[...document.querySelectorAll('.settings-trigger-button')].find(visible)||document.querySelector('.settings-trigger-button');
    const t=(trigger?.textContent||'').replace(/\s+/g,' ').trim();
    const m=t.match(/(?:Nano\s*Banana|Imagen|Veo)(?:\s+(?:Pro|Fast|Ultra|Quality|\d+(?:\.\d+)*))*/i);
    const ratios={'crop_16_9':'16:9','crop_9_16':'9:16','crop_4_3':'4:3','crop_3_4':'3:4','crop_landscape':'4:3','crop_portrait':'3:4','crop_square':'1:1'};
    // Read checked controls while open; the closed summary uses semantic icons.
    const selected=buttons().filter(n=>n.getAttribute('aria-checked')==='true'||n.getAttribute('aria-pressed')==='true'||n.getAttribute('aria-selected')==='true');
    const ratio=selected.map(label).find(v=>/^(?:16:9|9:16|4:3|3:4|1:1)$/.test(v));
    const icon=Object.keys(ratios).find(v=>t.includes(v));
    const count=selected.map(label).map(v=>v.match(/^[x×]\s*([1-4])$/i)).find(Boolean)||t.match(/[x×]\s*([1-4])(?=\D|$)/i);
    return {model:m?.[0]||'',aspect:ratio||(icon?ratios[icon]:''),count:count?+count[1]:0};
  };
  const outputImages=()=>[...new Map([...document.querySelectorAll('flow-grid-tile-container img,img')].filter(n=>
    (n.src.startsWith('https://flow-content.google/image/')||n.src.startsWith('https://flow.google.com/asb/'))&&
    !n.closest('.base-prompt-box,flow-ingredient-chip,flow-image-ingredient-chip')
  ).map(n=>[key(n.src),n])).values()];
  // Flow keeps a failed generation in the grid as a persistent error tile
  // ("失败 / 此生成内容可能违反了我们的政策 / 本次生成不计费"). That is a confirmed
  // terminal state: the request was accepted, no image was produced, and for a
  // policy block Flow states nothing was billed. Tiles survive across jobs, so
  // only tiles that appeared after this job armed count as this job's own
  // failures; the arm-time snapshot is compared as a multiset.
  // Strip icon glyphs first: Flow renders the tile's action buttons as Material
  // icon ligatures (`refresh`, `undo`, `delete_forever`), and textContent glues
  // them onto the readable message ("...不计费。refreshundodelete_forever").
  // A cloned node keeps the baseline/sort comparison stable without mutating
  // the live page.
  const failureTiles=()=>[...document.querySelectorAll('.error-tile')].filter(visible)
    .map(n=>{const c=n.cloneNode(true);c.querySelectorAll('mat-icon,flow-material-icon,svg,[aria-hidden=true],.material-icons,.material-symbols-outlined').forEach(i=>i.remove());return String(c.textContent||'').replace(/\s+/g,' ').trim().slice(0,160);}).filter(Boolean).sort();
  const freshFailures=baseline=>{
    const remaining=(Array.isArray(baseline)?baseline.slice().sort():[]),fresh=[];
    for(const text of failureTiles()){const at=remaining.indexOf(text);if(at>=0)remaining.splice(at,1);else fresh.push(text);}
    return fresh;
  };
  // Only claim "safe to retry" when Flow itself says the attempt was not billed;
  // any other error tile is reported as a failure the user must verify in Flow.
  const failureCodeFor=text=>/不计费|not (?:be )?charged|no charge|won.t be charged/i.test(text||'')?'policy_rejected':'generation_failed';
  const closeMenu=()=>{document.querySelector('.cdk-overlay-backdrop')?.click();for(let i=0;i<2;i++)document.body.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',keyCode:27,bubbles:true}));};
  if(action==='hdOpenProject'){
    if(!/^[0-9a-f-]{36}$/i.test(arg.project||''))throw Error('Flow 项目编号无效。');
    location.assign('https://flow.google.com/project/'+arg.project);return {opening:true};
  }
  if(action==='hdCapabilities'||action==='hdDownload'){
    const image=outputImages().find(n=>key(n.src)===arg.assetKey);
    if(!image)throw Error('当前 Flow 项目中找不到所选原图，请打开对应项目后重试。');
    const tile=image.closest('flow-grid-tile-container');
    const menu=tile&&[...tile.querySelectorAll('button')].find(n=>/^(更多选项|More options)$/i.test(n.getAttribute('aria-label')||n.title||''));
    if(!menu)throw Error('未找到所选图片的下载菜单。');
    closeMenu();await new Promise(r=>setTimeout(r,100));menu.click();await new Promise(r=>setTimeout(r,180));
    const download=[...document.querySelectorAll('[role=menuitem]')].find(n=>/下载|Download/i.test(label(n)));
    if(!download){closeMenu();throw Error('该图片当前不支持下载。');}
    download.click();await new Promise(r=>setTimeout(r,180));
    const choices=[...document.querySelectorAll('[role=menuitem]')].map(n=>({node:n,label:label(n)})).filter(v=>/^[124]K\b/i.test(v.label));
    const allowed=v=>!v.node.disabled&&v.node.getAttribute('aria-disabled')!=='true'&&!v.node.classList.contains('mat-mdc-menu-item-disabled')&&!/升级|Upgrade|Unlock|解锁/i.test(v.label);
    const resolutions=choices.filter(allowed).map(v=>v.label.match(/^[124]K/i)[0].toUpperCase());
    if(action==='hdCapabilities'){closeMenu();return {resolutions};}
    const selected=choices.find(v=>v.label.toUpperCase().startsWith(arg.resolution+'\n')||v.label.toUpperCase().startsWith(arg.resolution+' ')||v.label.toUpperCase()===arg.resolution);
    if(!selected||!allowed(selected)){closeMenu();throw Error('当前账号未开放该清晰度，请重新查询权限。');}
    selected.node.click();return {requested:true,resolution:arg.resolution};
  }
  const state=()=>{
    const s=window.__psfbManaged;
    const images=outputImages();
    const outputs=[...new Map(images.filter(n=>s&&!s.baseline.includes(key(n.src))).map(n=>[new URL(n.src).pathname,n.src])).values()];
    const progress=[...document.querySelectorAll('[role=progressbar],[class*=loading_percentage],[class*=loading-percentage]')].filter(visible).map(n=>Number((n.textContent.match(/(\d+(?:\.\d+)?)\s*%/)||[])[1])).filter(Number.isFinite);
    return {...settings(),project:(location.pathname.match(/^\/project\/([0-9a-f-]{36})$/)||[])[1]||'',editorFound:!!editor(),editorLength:editor()?.textContent.length||0,
      references:[...document.querySelectorAll('.base-prompt-box img')].filter(n=>n.naturalWidth>0).length,
      jobID:s?.id||null,kind:s?.kind||null,requests:s?.requests||0,submitAttempts:s?.submitAttempts||0,submitLocked:!!document.querySelector('.generate-icon-button[type=submit]')?.disabled,
      responses:s?.responses.map(r=>({status:r.status,error:r.error||null}))||[],outputs:outputs.length,percent:progress.length?Math.round(progress.reduce((a,b)=>a+b,0)/progress.length):null,
      // Fresh failed tiles for this job (baseline excludes older jobs' tiles).
      failures:s?freshFailures(s.failureBaseline).length:0,
      failureText:s?(freshFailures(s.failureBaseline)[0]||''):'',
      failureCode:s&&freshFailures(s.failureBaseline).length?failureCodeFor(freshFailures(s.failureBaseline)[0]):''};
  };
  if(action==='probe')return state();
  if(action==='enterProject'){
    if(state().project)return state();
    if(location.origin!=='https://flow.google.com'||location.pathname!=='/')return state();
    const a=document.querySelector('a[href^="/project/"]');
    if(a){a.click();return {opening:true};}
    const b=buttons().find(n=>n.textContent.includes('新建项目'));if(b)b.click();
    return {opening:!!b};
  }
  if(action==='attach'){
    if(!state().project||!editor())throw Error('请先在内置 Flow 打开图像项目，未提交生成。');
    // Pure text generation carries no reference image at all. The composer must
    // end up with zero reference chips, so a leftover chip from a previous job
    // is cleared before anything else and its absence is verified below.
    const isText=arg.kind==='text2image';
    // Check the one-shot receipt before touching the page. A job that already
    // armed must fail here, not after clearAssets() has wiped whatever the user
    // currently has in the Flow composer.
    if(localStorage.getItem('psfb-managed-submit:'+arg.id))throw Error('PSFB_ALREADY_SUBMITTED');
    // Flow renders two different `button.chip-container` nodes in the composer:
    // the attached reference image (its overlay icon is the `cancel` ligature)
    // and the "add media" button (overlay icon `add`). Matching the overlay by
    // class alone clicked both, so clearing opened the media picker and could
    // leave another chip behind - attach() then aborted on every run. Match the
    // reference chip by its own overlay icon instead, and never click `add`.
    const referenceChips=()=>[...document.querySelectorAll('button.chip-container,flow-ingredient-chip,flow-image-ingredient-chip')]
      .filter(chip=>{
        const icon=chip.querySelector('.hover-icon-overlay mat-icon,.hover-icon-overlay .material-symbols-outlined');
        return String(icon?.textContent||'').trim()==='cancel';
      });
    const clearAssets=async()=>{
      for(let round=0;round<3;round++){
        const chips=referenceChips();
        if(!chips.length)break;
        for(const chip of chips)(chip.querySelector('.hover-icon-overlay')||chip).click();
        await new Promise(r=>setTimeout(r,120));
      }
    };
    await clearAssets();
    // Verify the chip is really gone before touching the prompt text. If Flow
    // refused to remove it we abort here, with the user's prompt still intact,
    // instead of deleting their text and then failing.
    if(document.querySelector('.base-prompt-box img'))
      throw Error('Flow 提示框残留参考图无法清空，未覆盖、未提交生成。');
    const ed=editor();ed.focus();
    const sel=window.getSelection(),range=document.createRange();
    range.selectNodeContents(ed);sel.removeAllRanges();sel.addRange(range);
    document.execCommand('delete');
    if(ed.textContent.trim()){
      range.selectNodeContents(ed);sel.removeAllRanges();sel.addRange(range);
      document.execCommand('insertText',false,'');
    }
    if(document.querySelectorAll('.base-prompt-box img').length>0)await clearAssets();
    // Fail loudly instead of pasting a second reference on top of one Flow refused
    // to remove; otherwise arm() aborts later with a vaguer "页面状态无效" message.
    // Only the reference chip is checked here - the prompt is re-verified by
    // configure() and arm(), and Flow's empty editor can still expose placeholder
    // text that would make a textContent check misfire on a perfectly good job.
    if(document.querySelector('.base-prompt-box img'))
      throw Error('Flow 提示框残留参考图无法清空，未覆盖、未提交生成。');
    if(localStorage.getItem('psfb-managed-submit:'+arg.id))throw Error('PSFB_ALREADY_SUBMITTED');
    const hasExtra=isText?false:Boolean(arg.extraBase64);
    const s=window.__psfbManaged={id:arg.id,project:state().project,kind:isText?'text2image':'image2image',requests:0,responses:[],baseline:[],failureBaseline:failureTiles(),count:arg.count,prompt:arg.prompt,hasExtraImage:hasExtra};
    // Text jobs stop here: no image paste, so the composer holds only the prompt.
    if(isText)return {attached:true,jobID:s.id,kind:'text2image',references:0};
    const bytes=Uint8Array.from(atob(arg.base64),c=>c.charCodeAt(0)),dt=new DataTransfer();
    dt.items.add(new File([bytes],'ps-flow-base-'+arg.id.slice(0,8)+'.png',{type:'image/png'}));
    if(hasExtra){
      const extraBytes=Uint8Array.from(atob(arg.extraBase64),c=>c.charCodeAt(0));
      dt.items.add(new File([extraBytes],'ps-flow-ref-'+arg.id.slice(0,8)+'.png',{type:'image/png'}));
    }
    editor().focus();editor().dispatchEvent(new ClipboardEvent('paste',{bubbles:true,cancelable:true,clipboardData:dt}));
    return {attached:true,jobID:s.id};
  }
  const s=window.__psfbManaged;
  // Read-only recovery ops must stay reachable after a page or panel reload,
  // where the in-memory context is gone: they rebuild the baseline from the
  // one-shot receipt and never click generate. Everything that can submit
  // still requires the exact live context below.
  const recoveryOp=action==='queryResults'||action==='readResults'||action==='pendingReceipts';
  if(!recoveryOp&&(!s||s.id!==arg.id||s.project!==state().project))throw Error('Flow 任务上下文已变化，不会重新提交。');
  if(action==='pendingReceipts'){
    // One-shot submit receipts survive a reload, so the controller can still
    // discover a job it stranded in "unknown". Newest first, bounded.
    const prefix='psfb-managed-submit:',ids=[];
    // Read every receipt before trimming: receipts are never pruned, so a busy
    // profile holds far more than the handful of jobs that are stranded at once.
    // Capping during the scan would drop whichever job happens to sit past the
    // cutoff in insertion order - often the newest one, which is the one the
    // controller most likely needs to recover right now.
    for(let i=0;i<localStorage.length;i++){
      const name=localStorage.key(i);if(!name||!name.startsWith(prefix))continue;
      // One corrupt receipt must not abort the whole scan and hide every later
      // receipt, including the newest stranded job this scan exists to find.
      try{
        const saved=JSON.parse(localStorage.getItem(name)||'null');
        if(saved&&Array.isArray(saved.baseline))ids.push({id:name.slice(prefix.length),at:Number(saved.at)||0});
      }catch(_){}
    }
    ids.sort((a,b)=>b.at-a.at);
    return {ids:ids.slice(0,20).map(v=>v.id)};
  }
  const pause=()=>new Promise(r=>setTimeout(r,150));
  if(action==='configure'){
    const matches=m=>arg.model==='gemini-3.0-pro-image'?/Nano\s*Banana\s*Pro/i.test(m):/Nano\s*Banana\s*2(?:\.\d+)*/i.test(m);
    const open=async()=>{if(!buttons().some(n=>/^x[1-4]$/.test(label(n)))){document.querySelector('.settings-trigger-button')?.click();await pause();}};
    await open();
    if(!matches(settings().model)){
      document.querySelector('[aria-label="选择模型系列"]')?.click();await pause();
      const model=buttons().find(n=>!n.classList.contains('settings-trigger-button')&&!n.getAttribute('aria-haspopup')&&matches(label(n)));
      if(!model)throw Error('未找到指定 Flow 模型，未提交生成。');model.click();await pause();await open();
    }
    if(settings().aspect!==arg.aspect){
      const ratio=buttons().find(n=>label(n)===arg.aspect);if(!ratio)throw Error('未找到所需比例，未提交生成。');
      ratio.click();await pause();
    }
    if(settings().count!==arg.count){
      const count=buttons().find(n=>label(n)==='x'+arg.count);if(!count)throw Error('未找到所需张数，未提交生成。');
      count.click();await pause();
    }
    let v=settings();
    for(let i=0;i<10&&(!matches(v.model)||v.aspect!==arg.aspect||v.count!==arg.count);i++){await pause();v=settings();}
    if(!matches(v.model)||v.aspect!==arg.aspect||v.count!==arg.count)throw Error('Flow 设置回读不一致，未提交生成。预期 '+(arg.model==='gemini-3.0-pro-image'?'Nano Banana Pro':'Nano Banana 2')+' / '+arg.aspect+' / x'+arg.count+'；读到 '+(v.model||'未识别模型')+' / '+(v.aspect||'未识别比例')+' / '+(v.count?'x'+v.count:'未识别张数'));
    if(buttons().some(n=>/^x[1-4]$/.test(label(n)))){document.querySelector('.settings-trigger-button').click();await pause();}
    const edInput=editor();edInput.focus();
    const selInput=window.getSelection(),rangeInput=document.createRange();
    rangeInput.selectNodeContents(edInput);selInput.removeAllRanges();selInput.addRange(rangeInput);
    document.execCommand('insertText',false,arg.prompt);await pause();
    const normalize=value=>String(value||'').replace(/\r\n?/g,'\n').replace(/\n+/g,'\n').trim();
    if(normalize(editor().innerText)!==normalize(arg.prompt))throw Error('提示词回读不一致，未提交生成。');
    return state();
  }
  if(action==='arm'){
    const v=state(),b=document.querySelector('.generate-icon-button[type=submit]');
    const normalize=value=>String(value||'').replace(/\r\n?/g,'\n').replace(/\n+/g,'\n').trim();
    // Text jobs must show zero reference chips; any surviving chip means the
    // composer still holds a previous job's image and the submit must not run.
    const expectedRefs=(s&&s.kind==='text2image')||arg.kind==='text2image'?0:((s&&s.hasExtraImage)||arg.hasExtraImage?2:1);
    if(v.references!==expectedRefs||v.count!==arg.count||v.aspect!==arg.aspect||normalize(editor()?.innerText)!==normalize(arg.prompt)||!b?.isConnected||b.disabled)throw Error('提交前页面状态无效，未提交生成。');
    if(localStorage.getItem('psfb-managed-submit:'+arg.id))throw Error('PSFB_ALREADY_SUBMITTED');
    s.baseline=[...document.querySelectorAll('img')].map(n=>key(n.src));
    if(!window.__psfbManagedPatched){
      window.__psfbManagedPatched=true;
      const watched=u=>/ogiZ0b|StreamChat/.test(String(u)),open=XMLHttpRequest.prototype.open,send=XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open=function(m,u,...rest){this.__psfbManagedUrl=String(u);return open.call(this,m,u,...rest);};
      XMLHttpRequest.prototype.send=function(body){
        const current=window.__psfbManaged;
        if(current&&watched(this.__psfbManagedUrl)){current.requests++;this.addEventListener('loadend',()=>current.responses.push({status:this.status,error:this.status>=400||/reCAPTCHA|PERMISSION_DENIED|RESOURCE_EXHAUSTED|INTERNAL_ERROR/.test(this.responseText)?'Flow 返回生成错误':''}));}
        return send.call(this,body);
      };
      const original=window.fetch;window.fetch=function(input,init){
        const current=window.__psfbManaged,u=typeof input==='string'?input:input?.url;
        if(!current||!watched(u))return original.call(this,input,init);current.requests++;
        return original.call(this,input,init).then(r=>{r.clone().text().then(t=>current.responses.push({status:r.status,error:!r.ok||/reCAPTCHA|PERMISSION_DENIED|RESOURCE_EXHAUSTED|INTERNAL_ERROR/.test(t)?'Flow 返回生成错误':''}));return r;});
      };
    }
    // Persist the pre-submit baseline alongside the one-shot receipt so a query
    // can still identify this job's own outputs after a page or panel reload.
    localStorage.setItem('psfb-managed-submit:'+arg.id,JSON.stringify({project:s.project,at:Date.now(),count:arg.count,baseline:s.baseline,failureBaseline:s.failureBaseline||[]}));
    return {armed:true};
  }
  if(action==='submit'){
    const b=document.querySelector('.generate-icon-button[type=submit]');
    const normalize=value=>String(value||'').replace(/\r\n?/g,'\n').replace(/\n+/g,'\n').trim();
    if(s.inputSent||!localStorage.getItem('psfb-managed-submit:'+arg.id)||normalize(editor()?.innerText)!==normalize(arg.prompt)||!b?.isConnected||b.disabled)throw Error('提交状态待确认，不会重复点击。');
    // Runtime.evaluate supplies userGesture. DOM activation works while the owner window is hidden.
    s.inputSent=true;b.click();return {clicked:true};
  }
  if(action==='submitPoint'){
    // Flow ignores untrusted synthetic clicks (element.click() has isTrusted=false).
    // The controller must dispatch a real mouse event at these viewport coordinates.
    const b=document.querySelector('.generate-icon-button[type=submit]');
    const normalize=value=>String(value||'').replace(/\r\n?/g,'\n').replace(/\n+/g,'\n').trim();
    // Re-dispatch is allowed only while nothing has been seen on the wire: a click
    // that produced no request and left the button enabled provably did not submit,
    // so retrying it cannot double-generate. Once a request lands (or Flow disables
    // the button) this throws and the one-shot receipt stands.
    // New outputs are the strongest proof of acceptance: even if the request
    // sniffer missed the call (Flow changed its endpoint) a finished image means
    // this job already generated and must never be clicked again.
    const freshOutputs=outputImages().filter(n=>!s.baseline.includes(key(n.src))).length;
    if(s.requests>0||freshOutputs>0||b?.disabled||!localStorage.getItem('psfb-managed-submit:'+arg.id)||normalize(editor()?.innerText)!==normalize(arg.prompt)||!b?.isConnected)throw Error('提交状态待确认，不会重复点击。');
    const r=b.getBoundingClientRect();
    if(!r.width||!r.height)throw Error('生成按钮不可见，未提交生成。');
    const x=r.left+r.width/2,y=r.top+r.height/2,top=document.elementFromPoint(x,y);
    if(!top||!(top===b||b.contains(top))){
      // The settings pane occasionally stays mounted over the send button (its
      // toggle is a plain JS click). Close it and abort this attempt so the
      // controller re-measures instead of firing into the overlay.
      const trigger=document.querySelector('.settings-trigger-button');
      if(trigger&&trigger.getAttribute('aria-expanded')==='true')trigger.click();
      else closeMenu();
      throw Error('生成按钮被遮挡，未提交生成。');
    }
    s.inputSent=true;s.submitAttempts=(s.submitAttempts||0)+1;
    return {x:x,y:y,width:r.width,height:r.height,attempt:s.submitAttempts,hitsButton:true};
  }
  if(action==='readResults'){
    const v=state();
    // Recovery harvests outputs the page has already produced; it must not depend
    // on the live request signal (a page reload clears it). Normal transfer keeps
    // the strict guard.
    if(!arg.recovered&&(!v.requests||!v.responses.length||v.responses.some(r=>r.status!==200||r.error)||v.outputs!==s.count))throw Error('生成结果尚未确认，只查询不重提。');
    // Recovery may run after a reload, where the in-memory context is gone:
    // fall back to the baseline persisted with the submit receipt.
    let baseline=s&&s.id===arg.id&&Array.isArray(s.baseline)?s.baseline:null;
    let expectedProject=s&&s.id===arg.id?s.project:(arg.project||"");
    if(!baseline){
      try{
        const saved=JSON.parse(localStorage.getItem('psfb-managed-submit:'+arg.id)||'null');
        if(saved&&Array.isArray(saved.baseline)){baseline=saved.baseline;expectedProject=expectedProject||saved.project||"";}
      }catch(_){}
    }
    if(!baseline)throw Error('Flow 任务上下文已丢失，无法读取原任务结果。');
    // A reload keeps this op reachable while the page may have been navigated to
    // another project. Without this check every image of that other project is
    // "not in baseline" and would be harvested as this job's result.
    const liveProject=state().project;
    if(expectedProject&&liveProject&&liveProject!==expectedProject)throw Error('当前 Flow 项目与任务不一致，已停止读取；请切回原项目后重试。');
    const urls=outputImages().filter(n=>!baseline.includes(key(n.src))).map(n=>n.src);
    const n=arg.index;if(!Number.isInteger(n)||n<0||n>=urls.length)throw Error('结果编号无效');
    const r=await fetch(urls[n]);if(!r.ok)throw Error('图片读取失败 '+r.status);
    const blob=await r.blob();if(!blob.type.startsWith('image/')||!blob.size||blob.size>64*1024*1024)throw Error('图片类型或大小无效');
    const data=await new Promise((resolve,reject)=>{const f=new FileReader();f.onload=()=>resolve(f.result);f.onerror=reject;f.readAsDataURL(blob);});
    const project=expectedProject||liveProject||"";
    return {base64:data.slice(data.indexOf(',')+1),mime:blob.type,assetKey:key(urls[n]),project};
  }
  if(action==='queryResults'){
    // Recovery for a job stranded in "unknown": NEVER resubmits. It only reports
    // how many outputs are now present on the page so the controller can decide
    // whether to resync. The pre-submit baseline is persisted in the submit
    // receipt, so the count stays exact even after a page or panel reload.
    const s2=window.__psfbManaged;
    let baseline=s2&&s2.id===arg.id&&Array.isArray(s2.baseline)?s2.baseline:null;
    let failureBaseline=s2&&s2.id===arg.id&&Array.isArray(s2.failureBaseline)?s2.failureBaseline:null;
    let project=s2&&s2.id===arg.id?s2.project:null;
    if(!baseline){
      try{
        const saved=JSON.parse(localStorage.getItem('psfb-managed-submit:'+arg.id)||'null');
        if(saved&&Array.isArray(saved.baseline)){
          baseline=saved.baseline;project=project||saved.project;
          if(!failureBaseline&&Array.isArray(saved.failureBaseline))failureBaseline=saved.failureBaseline;
        }
      }catch(_){}
    }
    if(!baseline)throw Error('Flow 任务上下文已丢失，无法查询原任务。');
    if(project&&state().project&&state().project!==project)throw Error('当前 Flow 项目与任务不一致，已停止读取；请切回原项目后重试。');
    const images=outputImages();
    const fresh=images.filter(n=>!baseline.includes(key(n.src)));
    const failures=freshFailures(failureBaseline||[]);
    const expected=arg.count||(s2&&s2.id===arg.id?s2.count:0)||fresh.length;
    return {id:arg.id,project:project,count:expected,baseline:baseline.length,imgTotal:images.length,
      requests:s2?s2.requests:0,responses:s2?s2.responses.map(r=>({status:r.status,error:r.error||null})):[],
      outputs:fresh.length,failures:failures.length,failureText:failures[0]||'',failureCode:failures.length?failureCodeFor(failures[0]):'',
      complete:expected>0&&fresh.length===expected};
  }
  throw Error('不支持的内置浏览器操作');
}
