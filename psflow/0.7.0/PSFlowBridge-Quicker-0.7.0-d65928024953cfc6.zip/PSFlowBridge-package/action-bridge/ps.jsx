// parameter-limits:begin
var PSFB_LIMITS = {"promptMax":4000,"featherMin":0,"featherMax":250,"legacyPresetPromptMax":12000};
// parameter-limits:end
function psfbJson(v) {
    if (v === null || v === undefined) return 'null';
    if (typeof v === 'boolean' || typeof v === 'number') return String(v);
    if (typeof v === 'string') return '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t').replace(/[^\x20-\x7e]/g, function(c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); }) + '"';
    var a = [], i;
    if (v instanceof Array) { for (i = 0; i < v.length; i++) a.push(psfbJson(v[i])); return '[' + a.join(',') + ']'; }
    for (i in v) if (v.hasOwnProperty(i)) a.push(psfbJson(i) + ':' + psfbJson(v[i]));
    return '{' + a.join(',') + '}';
}
function psfbPx(v) { return Math.round(v.as('px')); }
function psfbDoc(id) {
    for (var i = 0; i < app.documents.length; i++) if (app.documents[i].id === Number(id)) return app.documents[i];
    throw Error('The captured document is no longer open. The result has been kept.');
}
function psfbSelection(d) { try { return d.selection.bounds; } catch (e) { return null; } }
function psfbClose(d) { if (d) try { d.close(SaveOptions.DONOTSAVECHANGES); } catch (e) {} }
function psfbPng(d, p) { d.saveAs(new File(p), new PNGSaveOptions(), true, Extension.LOWERCASE); }
function psfbRawMask(d, alpha, p, w, h) {
    // Export the selection alpha directly, without painting or color conversion.
    // Only disposable channels are changed. Fixed interleaving and byte size are
    // verified; unsupported RAW exports fall back to the existing PNG path.
    d.activeChannels = [d.channels[0], d.channels[1], d.channels[2]];
    var selectionName=alpha.name;
    for (var i=d.channels.length-1;i>=3;i--) if (d.channels[i].name !== selectionName) d.channels[i].remove();
    var descriptor=new ActionDescriptor(), format=new ActionDescriptor();
    format.putString(charIDToTypeID('FlCr'),'8BIM');
    format.putBoolean(charIDToTypeID('ChnI'),true);
    format.putBoolean(charIDToTypeID('AlpC'),true);
    format.putInteger(charIDToTypeID('HdSz'),0);
    descriptor.putObject(charIDToTypeID('As  '),charIDToTypeID('Rw  '),format);
    descriptor.putPath(charIDToTypeID('In  '),new File(p));
    descriptor.putInteger(charIDToTypeID('DocI'),d.id);
    descriptor.putBoolean(charIDToTypeID('Cpy '),true);
    executeAction(charIDToTypeID('save'),descriptor,DialogModes.NO);
    var file=new File(p);
    if (!file.exists || file.length !== w*h*4) throw Error('Raw selection channel layout was not confirmed.');
    return {path:p,width:w,height:h,channels:4,alphaIndex:3,interleaved:true};
}
function psfbRGB(d) {
    if (d.mode !== DocumentMode.RGB || d.bitsPerChannel !== BitsPerChannelType.EIGHT) throw Error('Use an RGB/8-bit document for this version.');
}
// Shared pre-flight for every operation that will touch the captured document.
// It runs before any duplicate/crop/export so an unsupported document mode or a
// changed canvas fails with an accurate reason instead of halfway through a
// render. The user's document mode is never modified.
function psfbValidateTarget() {
    var target = psfbDoc(CFG.documentID);
    psfbRGB(target);
    if (CFG.canvas && (psfbPx(target.width) !== CFG.canvas.width || psfbPx(target.height) !== CFG.canvas.height)) throw Error('The canvas changed after capture. The result has been kept.');
    return target;
}
function psfbCapture() {
    if (!app.documents.length) throw Error('Open a document in Photoshop first.');
    var original = app.activeDocument, copy = null, maskDoc = null, savedHistory = original.activeHistoryState;
    var alphaName = 'psflow_selection_' + new Date().getTime();
    psfbRGB(original);
    var sb = psfbSelection(original), w = psfbPx(original.width), h = psfbPx(original.height);
    var b = sb ? {left:psfbPx(sb[0]), top:psfbPx(sb[1]), right:psfbPx(sb[2]), bottom:psfbPx(sb[3])} : {left:0, top:0, right:w, bottom:h};
    b.width = b.right - b.left; b.height = b.bottom - b.top;
    if (b.width < 1 || b.height < 1 || b.width * b.height > 25000000) throw Error('Invalid or oversized capture area.');
    var edit = {left:b.left,top:b.top,right:b.right,bottom:b.bottom,width:b.width,height:b.height};
    if (sb && CFG.includeContext) {
        var margin = CFG.contextMarginPx === undefined ? Math.max(64, Math.round(Math.max(b.width,b.height) * 0.35)) : Math.max(1, Math.round(Number(CFG.contextMarginPx)));
        b = {left:Math.max(0,b.left-margin),top:Math.max(0,b.top-margin),right:Math.min(w,b.right+margin),bottom:Math.min(h,b.bottom+margin)};
        b.width=b.right-b.left; b.height=b.bottom-b.top;
        if (b.width*b.height>25000000) throw Error('Selection context is too large. Select a smaller region.');
    }
    var captureStarted = new Date().getTime(), phaseStarted, timings = {}, documentPath = null, maskRectangle = null, maskRaw = null;
    try { documentPath = original.fullName.fsName; } catch (pathError) {}
    try {
        if (sb) {
            var originalSelection = original.channels.add(); originalSelection.name = alphaName;
            original.selection.store(originalSelection, SelectionType.REPLACE);
        }
        phaseStarted = new Date().getTime();
        copy = original.duplicate('psflow_capture_' + captureStarted, true);
        timings.duplicateMs = new Date().getTime() - phaseStarted;
        if (sb) { app.activeDocument = original; original.activeHistoryState = savedHistory; }
        app.activeDocument = copy;
        copy.selection.deselect();
        phaseStarted = new Date().getTime();
        copy.crop([UnitValue(b.left,'px'), UnitValue(b.top,'px'), UnitValue(b.right,'px'), UnitValue(b.bottom,'px')]);
        timings.cropMs = new Date().getTime() - phaseStarted;
        phaseStarted = new Date().getTime();
        copy.convertProfile('sRGB IEC61966-2.1', Intent.RELATIVECOLORIMETRIC, true, false);
        psfbPng(copy, CFG.imagePath);
        timings.sourceExportMs = new Date().getTime() - phaseStarted;
        // Source is safely exported. Reuse this cropped disposable document for
        // the mask instead of creating and switching to a second full canvas.
        if (sb) {
            phaseStarted = new Date().getTime();
            var alpha = copy.channels.getByName(alphaName);
            if (CFG.externalRectangleMask) {
                copy.activeChannels = [alpha]; alpha.visible = true;
                var histogram = alpha.histogram, partial = 0;
                for (var hi = 1; hi < 255; hi++) partial += histogram[hi];
                if (partial === 0 && histogram[255] === edit.width * edit.height) {
                    maskRectangle = {left:edit.left-b.left,top:edit.top-b.top,width:edit.width,height:edit.height};
                }
                alpha.visible = false;
            }
            if (!maskRectangle) {
            if (CFG.externalRawMask) {
                try { maskRaw=psfbRawMask(copy,alpha,CFG.maskPath+'.raw',b.width,b.height); }
                catch (rawError) { try { new File(CFG.maskPath+'.raw').remove(); } catch (cleanupError) {} }
                alpha=copy.channels.getByName(alphaName);
            }
            if (!maskRaw) {
            copy.activeChannels = [copy.channels[0], copy.channels[1], copy.channels[2]];
            var black = new SolidColor(); black.rgb.red = black.rgb.green = black.rgb.blue = 0;
            var white = new SolidColor(); white.rgb.red = white.rgb.green = white.rgb.blue = 255;
            var painted = copy.artLayers.add();
            copy.selection.selectAll(); copy.selection.fill(black); copy.selection.deselect();
            copy.selection.load(alpha, SelectionType.REPLACE); copy.selection.fill(white); copy.selection.deselect();
            alpha.remove(); copy.flatten();
            psfbPng(copy, CFG.maskPath);
            }
            }
            timings.maskExportMs = new Date().getTime() - phaseStarted;
        }
        timings.totalPsMs = new Date().getTime() - captureStarted;
        return {ok:true, documentID:original.id, documentName:original.name, documentPath:documentPath, canvas:{width:w,height:h}, bounds:b,
            captureTimings:timings, captureMethod:maskRectangle?'single-document-rectangle-mask':maskRaw?'single-document-raw-alpha':'single-cropped-document',maskRectangle:maskRectangle,maskRaw:maskRaw,
            geometryVersion:CFG.includeContext?2:1,editBounds:edit,
            editRegion:{left:edit.left-b.left,top:edit.top-b.top,width:edit.width,height:edit.height},
            scope:sb?'selection':'canvas', imagePath:CFG.imagePath, maskPath:sb?CFG.maskPath:null,
            aspectTarget:{width:b.width,height:b.height}, source:{width:b.width,height:b.height,components:4,colorProfile:'sRGB IEC61966-2.1'}};
    } finally { psfbClose(copy); app.activeDocument = original; if (sb) original.activeHistoryState = savedHistory; }
}

var psfbTarget, psfbImported, psfbImageDoc, psfbMaskDoc, psfbSavedSelection;
function psfbPad(d, left, top, width, height) {
    if (d.activeLayer.isBackgroundLayer) d.activeLayer.isBackgroundLayer = false;
    if (left || top) d.resizeCanvas(UnitValue(psfbPx(d.width)+left,'px'), UnitValue(psfbPx(d.height)+top,'px'), AnchorPosition.BOTTOMRIGHT);
    d.resizeCanvas(UnitValue(width,'px'), UnitValue(height,'px'), AnchorPosition.TOPLEFT);
}
function psfbMakeMaskFromSelection() {
    var d = new ActionDescriptor(), r = new ActionReference();
    d.putClass(charIDToTypeID('Nw  '), charIDToTypeID('Chnl'));
    r = new ActionReference(); r.putEnumerated(charIDToTypeID('Chnl'), charIDToTypeID('Chnl'), charIDToTypeID('Msk '));
    d.putReference(charIDToTypeID('At  '), r);
    d.putEnumerated(charIDToTypeID('Usng'), charIDToTypeID('UsrM'), charIDToTypeID('RvlS'));
    executeAction(charIDToTypeID('Mk  '), d, DialogModes.NO);
}
function psfbMaskFeather(pixels) {
    var ref = new ActionReference(), desc = new ActionDescriptor(), value = new ActionDescriptor();
    ref.putEnumerated(charIDToTypeID('Lyr '), charIDToTypeID('Ordn'), charIDToTypeID('Trgt'));
    desc.putReference(charIDToTypeID('null'), ref);
    value.putUnitDouble(stringIDToTypeID('userMaskFeather'), charIDToTypeID('#Pxl'), pixels);
    desc.putObject(charIDToTypeID('T   '), charIDToTypeID('Lyr '), value);
    executeAction(charIDToTypeID('setd'), desc, DialogModes.NO);
}
function psfbPaste() {
    psfbImported = psfbImageDoc = psfbMaskDoc = null;
    var previous = app.documents.length ? app.activeDocument : null;
    psfbTarget = psfbValidateTarget();
    // The layer marker makes a lost completion response safe to recover.
    var existingLayer=psfbFindLayer(psfbTarget,'PS Flow '+CFG.importId);
    if(existingLayer){
        try { psfbTarget.selection.deselect(); } catch (_) {}
        return {ok:true,documentID:psfbTarget.id,layerID:existingLayer.id,recovered:true};
    }
    app.activeDocument = psfbTarget;
    var history = psfbTarget.activeHistoryState; psfbSavedSelection = null;
    var featherPx = CFG.maskFeatherPx === undefined ? 3 : Number(CFG.maskFeatherPx);
    if (!isFinite(featherPx) || featherPx < PSFB_LIMITS.featherMin || featherPx > PSFB_LIMITS.featherMax) throw Error('Mask feather must be between 0 and 250 pixels.');
    try {
        var b = CFG.bounds;
        psfbImageDoc = app.open(new File(CFG.imagePath));
        if (CFG.highResolution) {
            if (psfbPx(psfbImageDoc.width) !== CFG.imagePixelWidth || psfbPx(psfbImageDoc.height) !== CFG.imagePixelHeight) throw Error('HD result geometry changed.');
            executeAction(stringIDToTypeID('newPlacedLayer'), undefined, DialogModes.NO);
            psfbImageDoc.resizeImage(UnitValue(b.width, 'px'), UnitValue(b.height, 'px'), null, ResampleMethod.BICUBIC);
        } else if (psfbPx(psfbImageDoc.width) !== b.width || psfbPx(psfbImageDoc.height) !== b.height) throw Error('Result geometry does not match the captured area.');
        psfbPad(psfbImageDoc, b.left, b.top, CFG.canvas.width, CFG.canvas.height);
        if (CFG.maskPath) {
            psfbMaskDoc = app.open(new File(CFG.maskPath));
            if (psfbPx(psfbMaskDoc.width) !== b.width || psfbPx(psfbMaskDoc.height) !== b.height) throw Error('Mask geometry does not match the captured area.');
            psfbPad(psfbMaskDoc, b.left, b.top, CFG.canvas.width, CFG.canvas.height);
            var black = new SolidColor(); black.rgb.red = black.rgb.green = black.rgb.blue = 0;
            var bottom = psfbMaskDoc.artLayers.add(); bottom.move(psfbMaskDoc.layers[psfbMaskDoc.layers.length-1], ElementPlacement.PLACEAFTER);
            psfbMaskDoc.selection.selectAll(); psfbMaskDoc.selection.fill(black); psfbMaskDoc.selection.deselect(); psfbMaskDoc.flatten();
        }
        app.activeDocument = psfbImageDoc;
        psfbImageDoc.activeLayer.name = 'PS Flow ' + CFG.importId;
        // Prepare the full smart object first, then attach an editable external
        // mask in the disposable canvas. One duplicate touches the target only.
        if (CFG.smartObject && !CFG.highResolution) executeAction(stringIDToTypeID('newPlacedLayer'), undefined, DialogModes.NO);
        if (psfbMaskDoc) {
            app.activeDocument = psfbMaskDoc;
            var maskChannel = psfbMaskDoc.channels[0].duplicate(psfbImageDoc);
            app.activeDocument = psfbImageDoc;
            psfbImageDoc.selection.load(maskChannel, SelectionType.REPLACE);
            maskChannel.remove();
            psfbImageDoc.activeChannels = [psfbImageDoc.channels[0], psfbImageDoc.channels[1], psfbImageDoc.channels[2]];
            psfbMakeMaskFromSelection();
            psfbImageDoc.selection.deselect();
            psfbMaskFeather(featherPx);
        }
        app.activeDocument = psfbTarget;
        var srcLyrId = psfbImageDoc.activeLayer.id, srcDocId = psfbImageDoc.id, tgtDocId = psfbTarget.id;
        psfbTarget.suspendHistory('PS Flow ' + CFG.importId, 'var desc = new ActionDescriptor(), sRef = new ActionReference(), tRef = new ActionReference(); sRef.putIdentifier(charIDToTypeID("Lyr "), ' + srcLyrId + '); sRef.putIdentifier(charIDToTypeID("Dcmn"), ' + srcDocId + '); desc.putReference(charIDToTypeID("null"), sRef); tRef.putIdentifier(charIDToTypeID("Dcmn"), ' + tgtDocId + '); desc.putReference(charIDToTypeID("T   "), tRef); executeAction(charIDToTypeID("Dplc"), desc, DialogModes.NO); try { psfbTarget.selection.deselect(); } catch(e) {}');
        app.activeDocument = psfbTarget;
        psfbImported = psfbFindLayer(psfbTarget,'PS Flow '+CFG.importId);
        if(!psfbImported)throw Error('Imported layer was not confirmed.');
        return {ok:true,documentID:psfbTarget.id,layerID:psfbImported.id};
    } catch (e) { app.activeDocument = psfbTarget; psfbTarget.activeHistoryState = history; throw e; }
    finally {
        app.activeDocument = psfbTarget;
        if (psfbSavedSelection) {
            try { psfbTarget.selection.load(psfbSavedSelection, SelectionType.REPLACE); psfbSavedSelection.remove(); } catch (selectionError) {}
            psfbSavedSelection = null;
        }
        try { psfbTarget.selection.deselect(); } catch (_) {}
        psfbClose(psfbImageDoc); psfbClose(psfbMaskDoc); if (previous) app.activeDocument = previous;
    }
}
function psfbFindLayer(container, name) {
    for (var i=0;i<container.layers.length;i++) {
        var layer=container.layers[i];
        if(layer.name===name)return layer;
        if(layer.typename==='LayerSet'){var found=psfbFindLayer(layer,name);if(found)return found;}
    }
    return null;
}
function psfbPasteBatch() {
    var cfg=CFG, previous=app.documents.length?app.activeDocument:null, target=psfbDoc(cfg.documentID), history=null, group=null, receipt=null;
    psfbRGB(target);
    if(psfbPx(target.width)!==cfg.canvas.width||psfbPx(target.height)!==cfg.canvas.height)throw Error('The canvas changed after capture. The result has been kept.');
    if(!(cfg.items instanceof Array)||!cfg.items.length||cfg.items.length>4||typeof cfg.importId!=='string'||!/^[a-zA-Z0-9_-]{8,100}$/.test(cfg.importId))throw Error('Invalid batch import contract.');
    var seen={},preferred=-1,i;
    for(i=0;i<cfg.items.length;i++){
        var item=cfg.items[i];
        if(typeof item.index!=='number'||item.index<0||Math.floor(item.index)!==item.index||seen['i'+item.index])throw Error('Invalid batch result indexes.');
        seen['i'+item.index]=true;if(item.index===cfg.preferredIndex)preferred=i;
    }
    if(preferred<0)throw Error('Preferred result is not included in the batch.');
    var marker='PS Flow batch '+cfg.importId,existing=psfbFindLayer(target,marker);
    if(existing){
        if(existing.typename!=='LayerSet'||existing.layers.length!==cfg.items.length)throw Error('Batch import marker is incomplete. Preserve the result and check Photoshop.');
        var recoveredIds=[];
        for(i=0;i<cfg.items.length;i++){var recoveredLayer=psfbFindLayer(existing,'PS Flow '+cfg.importId+'_'+cfg.items[i].index);if(!recoveredLayer||recoveredLayer.parent.id!==existing.id)throw Error('Batch import marker is incomplete.');recoveredIds.push(recoveredLayer.id);}
        try { target.selection.deselect(); } catch (_) {}
        return {ok:true,documentID:target.id,groupID:existing.id,layerID:recoveredIds[preferred],layerIDs:recoveredIds,indexes:cfg.indexes,recovered:true};
    }
    // Preflight every input before changing the target document.
    for(i=0;i<cfg.items.length;i++)if(!(new File(cfg.items[i].imagePath)).exists)throw Error('Batch result file is missing.');
    if(cfg.maskPath&&!(new File(cfg.maskPath)).exists)throw Error('Batch mask file is missing.');
    app.activeDocument=target;history=target.activeHistoryState;
    try {
        group=target.layerSets.add();group.name=marker;
        var ids=[],indexes=[];
        for(i=0;i<cfg.items.length;i++){
            item=cfg.items[i];
            CFG={documentID:cfg.documentID,canvas:cfg.canvas,bounds:cfg.bounds,imagePath:item.imagePath,maskPath:cfg.maskPath,importId:cfg.importId+'_'+item.index,smartObject:true,maskFeatherPx:cfg.maskFeatherPx,highResolution:item.highResolution,imagePixelWidth:item.imagePixelWidth,imagePixelHeight:item.imagePixelHeight};
            var placed=psfbPaste(),layer=psfbFindLayer(target,'PS Flow '+CFG.importId);
            if(!layer||layer.id!==placed.layerID)throw Error('Batch layer was not confirmed.');
            app.activeDocument=target;if(layer.parent.id!==group.id)layer.move(group,ElementPlacement.INSIDE);layer.visible=i===preferred;ids.push(layer.id);indexes.push(item.index);
        }
        target.activeLayer=psfbFindLayer(group,'PS Flow '+cfg.importId+'_'+cfg.preferredIndex);
        receipt={ok:true,documentID:target.id,groupID:group.id,layerID:ids[preferred],layerIDs:ids,indexes:indexes};
        try { target.selection.deselect(); } catch (_) {}
        return receipt;
    } catch(error) {
        app.activeDocument=target;
        try{target.activeHistoryState=history;}catch(rollbackError){try{if(group)group.remove();}catch(removeError){}throw Error('Batch rollback could not be confirmed. Check Photoshop before retrying.');}
        throw error;
    } finally {
        CFG=cfg;
        try { target.selection.deselect(); } catch (_) {}
        if(previous)app.activeDocument=previous;
    }
}
function psfbMain() {
    var dialogs = app.displayDialogs, units = app.preferences.rulerUnits;
    try {
        app.displayDialogs = DialogModes.NO; app.preferences.rulerUnits = Units.PIXELS;
        if (CFG.op === 'status') {
            var active=app.documents.length?app.activeDocument:null,path=null;
            if(active)try{path=active.fullName.fsName;}catch(noSavedPath){}
            return {ok:true,version:app.version,documents:app.documents.length,documentID:active?active.id:null,documentName:active?active.name:null,documentPath:path,canvas:active?{width:psfbPx(active.width),height:psfbPx(active.height)}:null};
        }
        if (CFG.op === 'capture') return psfbCapture();
        if (CFG.op === 'open-result') {
            var resultFile = new File(CFG.imagePath);
            if (!resultFile.exists) throw Error('The result file is missing.');
            var openedResult = app.open(resultFile);
            return {ok:true,documentID:openedResult.id,documentName:openedResult.name};
        }
        if (CFG.op === 'validate-target') {
            var target=psfbValidateTarget();
            return {ok:true,documentID:target.id};
        }
        if (CFG.op === 'paste') return psfbPaste();
        if (CFG.op === 'paste-batch') return psfbPasteBatch();
        if (CFG.op === 'test') return eval(CFG.script);
        throw Error('Unknown Photoshop operation.');
    } catch (e) { return {ok:false,error:String(e),line:e.line||null}; }
    finally { app.displayDialogs = dialogs; app.preferences.rulerUnits = units; }
}
psfbJson(psfbMain());
