"use strict";
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const browserRouting = require('./browser-routing.cjs');

const CHECK_CACHE_TTL_MS = 15000;
const checkCache = new Map();
const inFlightChecks = new Map();

function clearCache() {
  checkCache.clear();
  inFlightChecks.clear();
}

function normalizeRoot(root) {
  return typeof root === 'string' && root.length > 0 ? path.resolve(root) : process.cwd();
}

/**
 * Synchronous static inspection of the runtime environment.
 * Kept strictly synchronous for existing callers and fast status checks.
 * Never executes Python processes.
 */
function inspect(root) {
  const baseRoot = normalizeRoot(root);
  const pythonExe = path.join(baseRoot, 'runtime', 'flow-api', '.venv', 'Scripts', 'python.exe');
  const apiServerPy = path.join(baseRoot, 'runtime', 'flow-api', 'flow_cli', 'api_server.py');

  const isFile = file => { try { return fs.statSync(file).isFile(); } catch { return false; } };
  const pythonExists = isFile(pythonExe);
  const apiServerExists = isFile(apiServerPy);

  const missing = [];
  if (!pythonExists) missing.push('runtime/flow-api/.venv/Scripts/python.exe');
  if (!apiServerExists) missing.push('runtime/flow-api/flow_cli/api_server.py');

  const installed = pythonExists && apiServerExists;

  let downloadPageUrl = null;
  let actionId = null;

  const installerConfigPath = path.join(baseRoot, 'installer.json');
  try {
    if (fs.existsSync(installerConfigPath)) {
      const content = fs.readFileSync(installerConfigPath, 'utf8').replace(/^\uFEFF/, '');
      const parsed = JSON.parse(content);
      if (parsed && typeof parsed === 'object') {
        if (typeof parsed.downloadPageUrl === 'string') {
          const trimmed = parsed.downloadPageUrl.trim();
          const url = new URL(trimmed);
          if (url.protocol === 'https:' && url.hostname && !url.username && !url.password && !/[\r\n]/.test(trimmed)) downloadPageUrl = url.href;
        }
        if (typeof parsed.actionId === 'string' && parsed.actionId.trim().length > 0) {
          actionId = parsed.actionId.trim();
        }
      }
    }
  } catch {
    // 格式异常或读取失败时，保持默认 null
  }

  return {
    ok: true,
    installed,
    checkState: installed ? 'ready' : 'missing',
    reason: installed ? null : 'missing_files',
    missing,
    downloadPageUrl,
    actionId,
    paths: {
      pythonExe,
      apiServerPy
    }
  };
}

/**
 * Default probe runner using bounded child process.
 * Verifies python executable starts and can import api_server.
 */
function defaultProbeRunner(pythonExe, apiServerPy, timeoutMs = 3000) {
  return new Promise((resolve) => {
    let resolved = false;
    let timer = null;
    let child = null;
    let stdout = '';
    let stderr = '';

    const finish = (result) => {
      if (resolved) return;
      resolved = true;
      if (timer) clearTimeout(timer);
      resolve(result);
    };

    timer = setTimeout(() => {
      if (child) {
        try { child.kill(); } catch {}
      }
      finish({ ok: false, checkState: 'unknown', reason: 'probe_timeout' });
    }, timeoutMs);

    try {
      const checkScript = 'import sys, os; root = os.path.dirname(os.path.dirname(os.path.abspath(sys.argv[1]))); sys.path.insert(0, root); import flow_cli.api_server; sys.stdout.write("ready")';
      child = spawn(pythonExe, ['-c', checkScript, apiServerPy], {
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true
      });

      child.stdout.on('data', (d) => { stdout += d.toString('utf8'); });
      child.stderr.on('data', (d) => { stderr += d.toString('utf8'); });

      child.once('error', (err) => {
        const isPerm = err.code === 'EACCES' || err.code === 'EPERM';
        finish({
          ok: false,
          checkState: 'unknown',
          reason: isPerm ? 'permission_denied' : 'probe_failed',
          error: err.message
        });
      });

      child.once('close', (code) => {
        if (code === 0 && stdout.includes('ready')) {
          finish({ ok: true, checkState: 'ready', reason: null });
        } else {
          const isMissingModule = /ModuleNotFoundError|ImportError|No module named/i.test(stderr);
          finish({
            ok: false,
            checkState: isMissingModule ? 'missing' : 'unknown',
            reason: isMissingModule ? 'missing_modules' : 'probe_failed',
            exitCode: code
          });
        }
      });
    } catch (err) {
      const isPerm = err.code === 'EACCES' || err.code === 'EPERM';
      finish({
        ok: false,
        checkState: 'unknown',
        reason: isPerm ? 'permission_denied' : 'probe_failed',
        error: err.message
      });
    }
  });
}

function readEffectiveMode(baseRoot) {
  try {
    const raw = fs.readFileSync(path.join(baseRoot, "mode.json"), "utf8").replace(/^\uFEFF/, "");
    const parsed = JSON.parse(raw);
    if (parsed && parsed.mode === "local") {
      const staticInspect = inspect(baseRoot);
      return staticInspect.installed ? "local" : "browser";
    }
    return "browser";
  } catch {
    return "browser";
  }
}

/**
 * Asynchronous runtime capability check.
 * Performs fast static inspection followed by a bounded process probe if files are present.
 * Caches results and coalesces concurrent in-flight requests.
 */
async function check(root, options = {}) {
  const baseRoot = normalizeRoot(root);
  const now = Date.now();
  const force = Boolean(options.force);
  const timeoutMs = typeof options.timeoutMs === 'number' && options.timeoutMs > 0 ? options.timeoutMs : 3000;
  const runner = typeof options.probeRunner === 'function' ? options.probeRunner : defaultProbeRunner;

  // Coalesce in-flight checks even when force: true to avoid concurrent probe storms
  const inFlight = inFlightChecks.get(baseRoot);
  if (inFlight) return inFlight;

  if (!force) {
    const cached = checkCache.get(baseRoot);
    if (cached && (now - cached.timestamp < CHECK_CACHE_TTL_MS)) {
      return cached.value;
    }
  }

  const checkPromise = (async () => {
    // 1. Static check
    const staticInspect = inspect(baseRoot);

    let checkState = 'missing';
    let reason = 'missing_files';
    let probeInstalled = false;

    if (!staticInspect.installed) {
      checkState = 'missing';
      reason = 'missing_files';
      probeInstalled = false;
    } else {
      // 2. Bounded probe
      const probeRes = await runner(staticInspect.paths.pythonExe, staticInspect.paths.apiServerPy, timeoutMs);
      if (probeRes && probeRes.ok && probeRes.checkState === 'ready') {
        checkState = 'ready';
        reason = null;
        probeInstalled = true;
      } else {
        checkState = (probeRes && probeRes.checkState) || ((probeRes && probeRes.timedOut) ? 'unknown' : 'missing');
        reason = (probeRes && probeRes.reason) || 'probe_failed';
        probeInstalled = false;
      }
    }

    const effectiveMode = readEffectiveMode(baseRoot);
    const browser = browserRouting.preference(baseRoot);

    const result = {
      ok: true,
      installed: checkState === 'ready',
      checkState,
      reason,
      missing: staticInspect.missing,
      downloadPageUrl: staticInspect.downloadPageUrl,
      actionId: staticInspect.actionId,
      paths: staticInspect.paths,
      checkedAt: new Date().toISOString(),
      effectiveMode,
      browser,
      canSwitch: checkState === 'ready'
    };

    checkCache.set(baseRoot, { timestamp: Date.now(), value: result });
    return result;
  })();

  inFlightChecks.set(baseRoot, checkPromise);
  try {
    return await checkPromise;
  } finally {
    inFlightChecks.delete(baseRoot);
  }
}

async function openDownload(root, options = {}) {
  const state = inspect(root);
  if (!state.downloadPageUrl) {
    return {
      ok: false,
      code: 'installer_not_configured',
      message: '未配置合法的安装包下载地址（必须为 https:// 链接）。'
    };
  }

  const targetUrl = state.downloadPageUrl;
  if (!/^https:\/\//i.test(targetUrl)) {
    return {
      ok: false,
      code: 'installer_not_configured',
      message: '下载地址必须为 https:// 开头。'
    };
  }

  const launcher = options.launcher || (async (url) => {
    const env = options.env || process.env;
    const executable = path.join(env.WINDIR || 'C:\\Windows', 'System32', 'rundll32.exe');
    const args = ['url.dll,FileProtocolHandler', url];
    await new Promise((resolve, reject) => {
      const child = spawn(executable, args, { detached: true, stdio: 'ignore', windowsHide: true });
      child.once('error', reject);
      child.once('spawn', () => {
        child.unref();
        resolve();
      });
    });
  });

  await launcher(targetUrl);

  return {
    ok: true,
    url: targetUrl,
    actionId: state.actionId,
    message: '已使用默认浏览器打开安装包下载页面。'
  };
}

module.exports = {
  inspect,
  check,
  openDownload,
  clearCache
};
