"use strict";
const fs=require('node:fs/promises');
const {writeTextAtomically}=require('../helper/atomic-file');
const LIMIT=64*1024*1024;
async function prepareUpload(file, sharp, limit=LIMIT) {
  let bytes=await fs.readFile(file);
  if(bytes.length>limit) {
    const before=await sharp(bytes).metadata();
    const encoded=await sharp(bytes).keepMetadata().png({compressionLevel:9,adaptiveFiltering:true,palette:false}).toBuffer();
    const after=await sharp(encoded).metadata();
    if(before.width!==after.width||before.height!==after.height)throw Error('素材压缩尺寸发生变化，未提交生成。');
    if(encoded.length>limit)throw Error('素材超过 64 MB 上传限制，请缩小选区后重试；未提交生成。');
    await writeTextAtomically(file,encoded);
    bytes=encoded;
  }
  return bytes;
}
module.exports={prepareUpload,LIMIT};
