"use strict";
// Resource policy for the accurate (native) preview lane.
//
// The accurate preview must decide what it is going to do BEFORE it reads a
// whole image or asks Photoshop to render. Every refusal here is explicit and
// carries a machine-readable code, so the panel can explain the limit instead
// of failing with a generic error.
//
// Two different budgets exist and must never be confused:
//  - the render/image budget decides whether the full-size render is allowed;
//  - the display budget only caps the picture that is handed to the panel.
// A downscaled display image never counts as an original-size check.
const LIMITS = {
  // Photoshop-side pixel budget. Mirrors PSFB_LIMITS/capture (25 MP).
  renderMaxPixels: 25000000,
  // Accurate preview duplicates the whole document before it crops, so the
  // canvas itself must be bounded too. A 25 MP selection inside a 500 MP canvas
  // would otherwise still cost a full-canvas copy. 100 MP is generous for
  // poster/print work while keeping the duplicate explainable.
  canvasMaxPixels: 100000000,
  // Any opened result/mask document larger than this is refused before render.
  imageMaxPixels: 25000000,
  // Hard cap on bytes we are willing to stat/hash/read from disk.
  sourceFileMaxBytes: 96 * 1024 * 1024,
  maskFileMaxBytes: 96 * 1024 * 1024,
  previewFileMaxBytes: 96 * 1024 * 1024,
  // Long edge of the picture returned to the panel. The real render keeps its
  // full size on disk; only the displayed copy is bounded.
  displayMaxEdge: 2048,
  // Bounded latest-only preview queue: one running + one pending request.
  maxPendingRequests: 1
};

function isPositiveInteger(value) { return Number.isInteger(value) && value > 0; }

function resourceError(code, message) {
  return Object.assign(new Error(message), { code, resource: true });
}

// Physical size of the picture that will be shown to the user. Never used for
// geometry validation; that always uses the real rendered dimensions.
// Field names match the frozen UI contract exactly:
//   {width,height,originalWidth,originalHeight,downscaled}
// so the panel can label a downscaled picture instead of presenting it as an
// original-size check.
function displayPlan(width, height, maxEdge = LIMITS.displayMaxEdge) {
  if (!isPositiveInteger(width) || !isPositiveInteger(height)) throw resourceError("preview_geometry", "预览尺寸无效，已停止准确预览。");
  const longEdge = Math.max(width, height);
  const base = { originalWidth: width, originalHeight: height };
  if (longEdge <= maxEdge) return { ...base, width, height, downscaled: false };
  const scale = maxEdge / longEdge;
  return {
    ...base,
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
    downscaled: true
  };
}

// The mask document is a full-context asset: its size follows the captured
// source, not the edit bounds. Comparing it against bounds would reject valid
// selections that use a context margin, so the expected size comes from the
// recorded capture source/mask identity.
function expectedMaskSize(input) {
  // The captured source geometry is authoritative; the recorded mask descriptor
  // is only a fallback for older captures that never stored a source block.
  const expected = input.source || input.mask;
  if (!expected || !isPositiveInteger(expected.width) || !isPositiveInteger(expected.height)) return null;
  return { width: expected.width, height: expected.height };
}

// Pre-render assessment. Called after metadata is known and before the whole
// image is read into memory or handed to Photoshop.
function assessPreviewResources(input) {
  const { bounds, image, mask, canvas, source } = input || {};
  if (!bounds || !isPositiveInteger(bounds.width) || !isPositiveInteger(bounds.height))
    throw resourceError("preview_geometry", "预览区域无效，已停止准确预览。");
  const renderPixels = bounds.width * bounds.height;
  if (!Number.isSafeInteger(renderPixels) || renderPixels > LIMITS.renderMaxPixels)
    throw resourceError("preview_too_large", "准确预览区域超过 " + Math.round(LIMITS.renderMaxPixels / 1e6) + " 百万像素上限，请缩小选区后重试。");
  if (canvas && (!isPositiveInteger(canvas.width) || !isPositiveInteger(canvas.height)))
    throw resourceError("preview_geometry", "文档画布尺寸无效，已停止准确预览。");
  // Whole-canvas budget: the preview duplicates the canvas, so its cost is the
  // canvas, not the selection.
  if (canvas) {
    const canvasPixels = canvas.width * canvas.height;
    if (!Number.isSafeInteger(canvasPixels) || canvasPixels > LIMITS.canvasMaxPixels)
      throw resourceError("preview_canvas_too_large", "文档画布超过 " + Math.round(LIMITS.canvasMaxPixels / 1e6) + " 百万像素，准确预览需要复制整张画布，已停止。请在更小的文档或副本上预览。");
  }
  if (canvas && renderPixels > canvas.width * canvas.height)
    throw resourceError("preview_geometry", "预览区域超出文档画布，已停止准确预览。");
  if (canvas && Number.isInteger(bounds.left) && Number.isInteger(bounds.top) &&
      (bounds.left < 0 || bounds.top < 0 || bounds.left + bounds.width > canvas.width || bounds.top + bounds.height > canvas.height))
    throw resourceError("preview_geometry", "预览区域超出文档画布，已停止准确预览。");
  if (!image || !isPositiveInteger(image.width) || !isPositiveInteger(image.height))
    throw resourceError("preview_geometry", "预览图片尺寸无效，已停止准确预览。");
  const imagePixels = image.width * image.height;
  if (!Number.isSafeInteger(imagePixels) || imagePixels > LIMITS.imageMaxPixels)
    throw resourceError("preview_too_large", "预览图片超过 " + Math.round(LIMITS.imageMaxPixels / 1e6) + " 百万像素上限，请缩小选区或改用较低分辨率结果。");
  const expectedMask = expectedMaskSize({ mask: input.mask, source });
  if (expectedMask && mask) {
    if (!isPositiveInteger(mask.width) || !isPositiveInteger(mask.height))
      throw resourceError("preview_geometry", "预览蒙版尺寸无效，已停止准确预览。");
    if (mask.width !== expectedMask.width || mask.height !== expectedMask.height)
      throw resourceError("preview_geometry", "预览蒙版与捕获的源图尺寸不一致，已停止准确预览。");
  }
  return {
    ok: true,
    renderPixels,
    imagePixels,
    // The exported preview is cropped to the edit bounds, so that is the real
    // rendered size. The host replaces this with the measured file size after
    // the render; here it is only a pre-flight estimate.
    display: displayPlan(bounds.width, bounds.height),
    limits: LIMITS
  };
}

// Byte budgets are checked from stat() before any read so an oversized asset
// is refused without allocating a buffer for it.
function assertFileBudget(size, maxBytes, label) {
  if (!Number.isFinite(size) || size < 0) throw resourceError("preview_resource", label + "大小无法确认，已停止准确预览。");
  if (size > maxBytes) throw resourceError("preview_resource", label + "超过 " + Math.round(maxBytes / (1024 * 1024)) + " MB 上限，已停止准确预览。");
  return size;
}

module.exports = { LIMITS, displayPlan, assessPreviewResources, assertFileBudget, resourceError };
