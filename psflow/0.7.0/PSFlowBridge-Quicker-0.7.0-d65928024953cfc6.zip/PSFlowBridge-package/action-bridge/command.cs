var root = context.ReadState("packageRoot", null);
if (string.IsNullOrWhiteSpace(root)) {
    context.SetVarValue("response", "{\"ok\":false,\"error\":\"请先启动 PS Flow 侧边助手。\"}");
    return false;
}
try {
    var configPath = System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData), "PSFlowBridge", "config.json");
    var config = Newtonsoft.Json.Linq.JObject.Parse(System.IO.File.ReadAllText(configPath));
    var token = (string)config["pairingToken"];
    if (string.IsNullOrWhiteSpace(token)) throw new System.Exception("本地连接尚未准备好，请重新打开动作。");
    var request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://127.0.0.1:47831/api/action-command");
    request.Proxy = null;
    request.Method = "POST";
    request.Timeout = 90000;
    request.ReadWriteTimeout = 90000;
    request.ContentType = "application/json; charset=utf-8";
    request.Headers["Authorization"] = "Bearer " + token;
    var bytes = new System.Text.UTF8Encoding(false).GetBytes(context.GetVarValue<string>("request"));
    request.ContentLength = bytes.Length;
    using (var stream = request.GetRequestStream()) stream.Write(bytes, 0, bytes.Length);
    using (var response = request.GetResponse())
    using (var reader = new System.IO.StreamReader(response.GetResponseStream(), System.Text.Encoding.UTF8)) {
        var result = reader.ReadToEnd();
        Newtonsoft.Json.Linq.JObject.Parse(result);
        context.SetVarValue("response", result);
    }
    return true;
} catch (System.Net.WebException error) {
    var code = "(连接失败)"; var body = "";
    try {
        using (var er = error.Response as System.Net.HttpWebResponse) {
            if (er != null) {
                code = ((int)er.StatusCode).ToString();
                using (var reader = new System.IO.StreamReader(er.GetResponseStream(), System.Text.Encoding.UTF8)) body = reader.ReadToEnd();
            }
        }
    } catch { }
    var detail = body.Length > 120 ? body.Substring(0, 120) : body;
    context.SetVarValue("response", new Newtonsoft.Json.Linq.JObject {
        ["ok"] = false, ["error"] = "操作请求失败（HTTP " + code + "，路径 /api/action-command）" + (string.IsNullOrEmpty(detail) ? "" : "：" + detail),
        ["uncertain"] = true
    }.ToString(Newtonsoft.Json.Formatting.None));
    return false;
} catch (System.Exception error) {
    context.SetVarValue("response", new Newtonsoft.Json.Linq.JObject {
        ["ok"] = false, ["error"] = "操作结果尚未确认，请查询当前任务。 " + error.Message,
        ["uncertain"] = true
    }.ToString(Newtonsoft.Json.Formatting.None));
    return false;
}
