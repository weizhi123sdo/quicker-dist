﻿param([string]$RequestPath, [switch]$Serve)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
$script:psApplication = $null
$script:psSession = ''
$script:jsxSource = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'ps.jsx'))
function ConvertTo-PsAsciiJson {
  param([string]$Json)
  return [regex]::Replace($Json, '[^\x20-\x7e]', [System.Text.RegularExpressions.MatchEvaluator]{
    param($Match)
    return ('\u{0:x4}' -f [int][char]$Match.Value[0])
  })
}
function Invoke-PsRequest {
  param([string]$RequestJson)
  try {
    $photoshopProcess = Get-Process Photoshop -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $photoshopProcess) { throw 'Photoshop is not running.' }
    $session = '{0}:{1}' -f $photoshopProcess.Id, $photoshopProcess.StartTime.ToUniversalTime().Ticks
    $request = $RequestJson | ConvertFrom-Json
    if ($request.expectedSession -and $request.expectedSession -ne $session) { throw 'Photoshop restarted after capture. The result has been kept.' }
    if ($script:psSession -ne $session -or $null -eq $script:psApplication) {
      if ($null -ne $script:psApplication) { try { [Runtime.InteropServices.Marshal]::FinalReleaseComObject($script:psApplication) | Out-Null } catch {} }
      try { $script:psApplication = [Runtime.InteropServices.Marshal]::GetActiveObject('Photoshop.Application') }
      catch { $script:psApplication = [Activator]::CreateInstance([Type]::GetTypeFromProgID('Photoshop.Application')) }
      $script:psSession = $session
    }
    $prefix = 'var CFG = ' + (ConvertTo-PsAsciiJson -Json ($request | ConvertTo-Json -Depth 32 -Compress)) + ';' + [Environment]::NewLine
    $result = $script:psApplication.GetType().InvokeMember('DoJavaScript', [Reflection.BindingFlags]::InvokeMethod, $null, $script:psApplication, @($prefix + $script:jsxSource))
    $value = ([string]$result).Trim() | ConvertFrom-Json
    $value | Add-Member -NotePropertyName 'psSession' -NotePropertyValue $session -Force
    return (ConvertTo-PsAsciiJson -Json ($value | ConvertTo-Json -Depth 32 -Compress))
  } catch {
    $script:psApplication = $null
    $script:psSession = ''
    return (ConvertTo-PsAsciiJson -Json (@{ok=$false; error=$_.Exception.Message} | ConvertTo-Json -Compress))
  }
}
if ($Serve) {
  while ($null -ne ($line = [Console]::ReadLine())) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    [Console]::WriteLine((Invoke-PsRequest -RequestJson $line))
  }
} else {
  if ([string]::IsNullOrWhiteSpace($RequestPath)) { throw 'RequestPath is required.' }
  $response = Invoke-PsRequest -RequestJson ([IO.File]::ReadAllText($RequestPath))
  [Console]::WriteLine($response)
  if (-not ($response | ConvertFrom-Json).ok) { exit 1 }
}
